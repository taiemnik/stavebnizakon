# Stavební zákon po novele — konsolidované znění (pracovní pomůcka)

Úplné znění stavebního zákona se zapracovaným senátním tiskem 272/0. Základ: e-Sbírka ke **2026-06-11**. Rušený text ~~škrtnutý~~, nový text **tučně** (slovní diff). Včetně příloh. Pracovní artefakt — ověř proti PDF.

---

## Zákon č. 283/2021 Sb., stavební zákon

### ČÁST PRVNÍ

*ÚVODNÍ USTANOVENÍ*

#### HLAVA I

*OBECNÁ USTANOVENÍ*

#### § 1 — ~~Předmět úpravy~~ **Předmět a účel zákona**  `[272 Čl.I/1; 272 Čl.I/2; 272 Čl.I/3]` {uc=A}

(1) Tento zákon upravuje působnost **úřadů rozvoje území, územních samosprávných celků a dotčených** orgánů ~~stavební správy, orgánů územního plánování a orgánů územní samosprávy~~ v oblasti územního plánování a stavebního řádu, stanoví cíle, úkoly a nástroje územního plánování, požadavky na výstavbu a stavební řád. {uc=A}

(2) Tento zákon dále upravuje podmínky pro integrovanou ochranu veřejných zájmů při územním plánování, povolování staveb a výstavbě, povinnosti osob při přípravě a provádění staveb, podmínky pro projektovou činnost a provádění staveb, některé účely vyvlastnění, oprávnění autorizovaných inspektorů a výkon kontroly.

(3) Účelem stavebního zákona je zajistit integrovanou ochranu veřejných zájmů při územním plánování, povolování staveb a výstavbě a vytvářet podmínky pro **bydlení, práci, podnikání a život lidí,** udržitelný rozvoj území a zvyšování kvality vystavěného prostředí, architektury a stavební kultury. {uc=A}

#### § 1a — **Základní zásady**  `[272 Čl.I/4]` {uc=A}

**(1) Orgány územního plánování a stavební úřady zajišťují ochranu a rovnováhu dotčených zájmů, které koordinují, a usilují o předcházení jejich rozporům a o naplnění účelu tohoto zákona. Uplatňování požadavku ochrany veřejného zájmu nesmí vést k nepřiměřenému dotčení jiných veřejných zájmů a k narušení nebo znehodnocení charakteru, potenciálu a hodnot území jako celku.** {uc=A}

**(2) V případě rozporu zájmů orgán územního plánování nebo stavební úřad porovná jejich význam a závažnost s cílem zajistit, aby zásah do žádného z nich svými nepříznivými následky nepřesahoval přínosy, nepřekračoval limitní hodnoty stanovené právními předpisy a výsledné řešení bylo v souladu s převažujícím veřejným zájmem, s právními předpisy včetně práva Evropské unie a s mezinárodními závazky a oprávněnými zájmy přímo dotčených osob. Přitom vychází ze stávajícího stavu poznání a ekonomicky a technicky přijatelných možností řešení. V odůvodnění opatření obecné povahy nebo v rozhodnutí orgán územního plánování nebo stavební úřad uvede, jak byly tyto požadavky zohledněny.** {uc=A}

**(3) Znemožnit rozvoj sídel, hospodářství, veřejné infrastruktury nebo výstavbu lze jen tehdy, není-li možné zajistit dostatečnou ochranu jiných hodnot podmínkami, kompenzačními anebo zmírňujícími opatřeními.** {uc=A}

**(4) Při řešení rozporů a námitek podle tohoto zákona orgány územního plánování a stavební úřady usilují o dosažení smíru.** {uc=A}

#### § 1b — **Ochrana veřejných zájmů**  `[272 Čl.I/4]` {uc=A}

**(1) Stavební úřady posuzují a chrání veřejné zájmy podle tohoto zákona a další veřejné zájmy zejména v oblasti** {uc=A}

**a) života a zdraví lidí68),** {uc=A}

**b) životního prostředí69),** {uc=A}

**c) státní památkové péče70),** {uc=A}

**d) veřejné infrastruktury71),** {uc=A}

**e) zemědělství, lesnictví a ochrany zvířat72),** {uc=A}

**f) nerostů, hornické činnosti, těžby a výbušnin a surovinové bezpečnosti a soběstačnosti73),** {uc=A}

**g) výroby a hospodaření s energií a energetické bezpečnosti74),** {uc=A}

**h) požární ochrany a integrovaného záchranného systému75),** {uc=A}

**i) prevence závažných havárií, integrované prevence a omezování znečištění76),** {uc=A}

**j) práva na územní samosprávu územních samosprávných celků77),** {uc=A}

**k) hospodářského a průmyslového rozvoje78).** {uc=A}

**(2) Při posuzování a ochraně veřejných zájmů podle odstavce 1 v řízení podle části šesté, deváté a desáté tohoto zákona vykonávají stavební úřady pravomoc dotčených orgánů podle jiných zákonů namísto těchto orgánů, nestanoví-li zvláštní zákon jinak. Rozhodnutí stavebního úřadu podle části šesté, deváté a desáté tohoto zákona nahrazuje rozhodnutí, závazná stanoviska a jiné úkony dotčených orgánů, nestanoví-li zvláštní zákon jinak; v rozhodnutí stanoví stavební úřad i podmínky k ochraně veřejných zájmů chráněných jinými právními předpisy. __________** {uc=A}

#### § 2 — Dotčené orgány  `[272 Čl.I/5; 272 Čl.I/6; 272 Čl.I/7]` {uc=A}

**(1) Dotčené orgány uplatňují stanoviska, vyjádření nebo závazná stanoviska k záležitostem podle tohoto zákona pouze v mezích své působnosti a činí tak co nejdříve a v první fázi, kdy je to možné; přitom dbají, aby se jejich stanoviska, vyjádření nebo závazná stanoviska dotýkala oprávněných zájmů a práv osob jen v nezbytném rozsahu, který je potřebný k ochraně jimi hájeného veřejného zájmu, a zvláště dbají zachování účelu tohoto zákona, jeho základních zásad a jeho ustanovení, která se týkají jejich působnosti.** {uc=A}

~~(1)~~ **(2)** Dotčený orgán je vázán svým předchozím stanoviskem, vyjádřením nebo závazným stanoviskem, které vydal jako podklad pro úkony podle tohoto zákona. {uc=A}

~~(2)~~ **(3)** Při pořizování navazující územně plánovací dokumentace se nepřihlíží ~~ke~~ **k vyjádřením a** stanoviskům dotčených orgánů ve věcech, o nichž bylo rozhodnuto při schválení politiky územního rozvoje a vydání nadřazené územně plánovací dokumentace. {uc=A}

~~(3)~~ **(4)** Při postupech podle části šesté se nepřihlíží k vyjádření nebo závaznému stanovisku ve věcech, o kterých bylo rozhodnuto v územně plánovací dokumentaci nebo v územním opatření**, a ve věcech, které byly vyhodnoceny v závazném stanovisku k posouzení vlivů provedení záměru na životní prostředí podle jiného právního předpisu**. {uc=A}

#### § 3 — Změna podmínek  `[272 Čl.I/8]` {uc=A}

(1) Nové stanovisko, vyjádření nebo závazné stanovisko může dotčený orgán v téže věci uplatňovat pouze v rozsahu nově zjištěných skutečností, které nemohly být zjištěny dříve, nebo na základě změny právních předpisů, a pokud se jimi změnily podmínky, za kterých bylo stanovisko, vyjádření nebo závazné stanovisko vydáno, a to jen v rozsahu změny podmínek. **Změnit své původní vyjádření, stanovisko nebo závazné stanovisko může dotčený orgán též za účelem řešení rozporu, je-li to pro stavebníka příznivější.** {uc=A}

(2) Nové stanovisko, vyjádření nebo závazné stanovisko může dotčený orgán vydat také tehdy, pokud původní bylo vydáno na základě údajů nepravdivých, neúplných nebo zkreslených.

(3) Nové stanovisko k územně plánovací dokumentaci může dotčený orgán uplatnit také na základě skutečností vyplývajících z větší podrobnosti pořizované územně plánovací dokumentace, nebo na základě výsledku řešení rozporů.

#### HLAVA II

*POJMY*

#### § 4 — Záměr  `[272 Čl.I/9]` {uc=A}

(1) Záměrem se v tomto zákoně rozumí stavba, soubor staveb, zařízení, údržba dokončené stavby, změna využití území~~, dělení nebo scelování pozemků~~ a stanovení ochranného pásma. {uc=A}

(2) Záměrem EIA se v tomto zákoně rozumí záměr podle odstavce 1, který podléhá posouzení vlivů na životní prostředí podle zákona o posuzování vlivů na životní prostředí.

#### § 5 — Stavba  `[272 Čl.I/10; 272 Čl.I/11; 272 Čl.I/12]` {uc=AB}

(1) Stavbou se v tomto zákoně rozumí stavební dílo, které vzniká stavební nebo montážní činností ze stavebních výrobků, materiálů nebo konstrukcí za účelem užívání na určitém místě. Za stavbu se považuje také výrobek plnící funkci stavby.

(2) Stavby jsou

a) drobné, které jsou uvedeny v příloze č. 1 k tomuto zákonu,

b) jednoduché, které jsou uvedeny v příloze č. 2 k tomuto zákonu,

c) vyhrazené, které jsou uvedeny v příloze č. 3 k tomuto zákonu, a

d) ostatní.

(3) Souborem staveb se v tomto zákoně rozumí vzájemně související stavby, jimiž se v rámci jednoho záměru **nebo více souvisejících záměrů anebo v etapách** uskutečňuje výstavba na souvislém území nebo za společným účelem. {uc=A}

(4) Stavbou hlavní souboru staveb se v tomto zákoně rozumí stavba, která určuje účel výstavby**, druh stavby podle odstavce 2 a příslušnost stavebního úřadu k celému** souboru staveb. Vedlejší stavbou v souboru staveb se v tomto zákoně rozumí stavba, která se stavbou hlavní svým účelem užívání nebo umístěním souvisí a která zabezpečuje uživatelnost stavby hlavní nebo doplňuje účel užívání stavby hlavní. {uc=A}

(5) Dočasnou stavbou se v tomto zákoně rozumí stavba, u které stavební úřad předem omezí dobu jejího trvání.

(6) Používá-li se v tomto zákoně pojem stavba, rozumí se tím podle okolností také její část nebo změna dokončené stavby.

**(7) Stavbou pro hromadné bydlení je stavba nebo soubor staveb s převažující funkcí bydlení s celkovou podlahovou plochou od 10 000 m2.** {uc=B}

**(8) Plánování, příprava, výstavba a provozování veřejné infrastruktury a vyhrazených staveb je ve veřejném zájmu.** {uc=B}

#### § 6 — Změna a údržba dokončené stavby  `[272 Čl.I/13]` {uc=A}

(1) Změnou dokončené stavby se v tomto zákoně rozumí

a) nástavba, kterou se stavba zvyšuje,

b) přístavba, kterou se stavba půdorysně rozšiřuje a která je vzájemně provozně propojena s dosavadní stavbou, a

c) stavební úprava, při které se zachovává vnější půdorysné i výškové ohraničení stavby.

(2) Změnou dokončené stavby se v tomto zákoně rozumí také změna ~~v užívání stavby spočívající~~**, která spočívá** ve změně ~~v~~ {uc=A}

a) ~~způsobu~~ **účelu** užívání stavby, **ve změně v době trvání dočasné stavby nebo ve změně dočasné stavby na stavbu trvalou, nebo**

b) ~~provozním zařízení stavby~~ **činnosti**, **jejíž účinky by mohly ohrozit život nebo veřejné zdraví, život a zdraví zvířat, bezpečnost nebo životní prostředí.**

~~c) způsobu výroby nebo podstatném rozšíření výroby,~~

~~d) činnosti, jejíž účinky by mohly ohrozit život nebo veřejné zdraví, život a zdraví zvířat, bezpečnost nebo životní prostředí, nebo~~

~~e) době trvání dočasné stavby, anebo změně dočasné stavby na stavbu trvalou.~~

(3) Údržbou dokončené stavby se v tomto zákoně rozumí udržovací práce, jimiž se zabezpečuje dobrý stavebně technický stav stavby tak, aby se co nejvíce snížilo nebezpečí výskytu závady nebo havárie stavby a nedocházelo ke znehodnocení stavby.

#### § 7 — Zařízení

(1) Zařízením se v tomto zákoně rozumí technické zařízení nebo reklamní zařízení, pokud nejde o stavbu, které vzniká za účelem užívání na určitém místě.

(2) Reklamním zařízením se v tomto zákoně rozumí panel, tabule, deska nebo konstrukce, které slouží k šíření reklamy nebo jiných informací. Reklamní zařízení o celkové ploše větší než 8 m2 se považuje za stavbu.

#### § 8 — Terénní úprava

Terénní úpravou se v tomto zákoně rozumí zemní práce a změny terénu, jimiž se podstatně mění vzhled prostředí nebo odtokové poměry, těžební a jim podobné a s nimi související práce, nejde-li o hornickou činnost nebo činnost prováděnou hornickým způsobem.

#### § 9 — Staveniště

(1) Staveništěm se v tomto zákoně rozumí místo, na kterém se provádí stavba, zařízení, terénní úprava nebo udržovací práce anebo na kterém se stavba, zařízení nebo terénní úprava odstraňuje.

(2) Staveniště zahrnuje stavební pozemek nebo jeho část anebo část stavby, popřípadě, v rozsahu vymezeném stavebním úřadem, též jiný pozemek nebo jeho část anebo část jiné stavby potřebné pro provedení nebo odstranění stavby, zařízení nebo terénní úpravy.

#### § 10 — Veřejná infrastruktura  `[272 Čl.I/14]` {uc=A}

(1) Veřejnou infrastrukturou se v tomto zákoně rozumí pozemky, stavby a zařízení sloužící veřejné potřebě, a to

a) dopravní infrastruktura, kterou jsou zejména stavby **cest,** pozemních komunikací, drah, vodních cest, leteckých staveb a s nimi související stavby a zařízení, {uc=A}

b) technická infrastruktura, kterou jsou zejména systémy a sítě technické infrastruktury a s nimi související stavby a zařízení pro zásobování vodou, odvádění a čištění odpadních vod, energetiku, včetně výroben a zdrojů energie, zařízení pro ukládání energie, dobíjecích stanic a zásobníků plynu, produktovody a elektronické komunikace, a dále stavby a zařízení ke snižování nebezpečí v území a pro zlepšování stavu povrchových a podzemních vod nebo k nakládání s odpady,

c) zelená infrastruktura, kterou je plánovaný, převážně spojitý systém ploch a jiných prvků vegetačních, vodních a pro hospodaření s vodou, přírodního a polopřírodního charakteru, které svým cílovým stavem umožňují nebo významně podporují plnění široké škály ekosystémových služeb a funkcí; součástí zelené infrastruktury je také územní systém ekologické stability krajiny,

d) občanské vybavení, kterým jsou stavby, zařízení a pozemky sloužící k zajištění základních potřeb obyvatel, zejména pro vzdělávání, výchovu a sport, sociální a zdravotní služby, kulturu, veřejnou správu a ochranu obyvatelstva,

e) veřejná prostranství1).

(2) Sítí technické infrastruktury se v tomto zákoně rozumí liniové nebo prostorové vedení inženýrské sítě, včetně armatur, zařízení a konstrukcí na vedení a jeho koncových prvků, zabezpečující napojení na jednotlivé druhy využívaných médií.

(3) Sítě technické infrastruktury jsou podle účelu zejména energetické, vodovodní a kanalizační, elektronických komunikací a produktovody.

#### § 11 — Veřejně prospěšná stavba a opatření  `[272 Čl.I/15]` {uc=A}

(1) Veřejně prospěšnou stavbou se v tomto zákoně rozumí stavba nebo zařízení pro veřejnou infrastrukturu určená k rozvoji nebo ochraně území obce, kraje nebo státu vymezená v územně plánovací dokumentaci **nebo v zákoně** a stavby a zařízení s ní související nebo podmiňující její realizaci **a strategická investiční stavba79)**. {uc=A}

(2) Veřejně prospěšným opatřením se v tomto zákoně rozumí opatření nestavební povahy sloužící ke snižování nebezpečí v území, vytváření prvků územního systému ekologické stability2) a k rozvoji anebo k ochraně přírodního, kulturního a archeologického dědictví, vymezené v územně plánovací dokumentaci.

#### § 12 — Základní pojmy územního plánování  `[272 Čl.I/16; 272 Čl.I/17; 272 Čl.I/18; 272 Čl.I/19; 272 Čl.I/20; 272 Čl.I/21; 272 Čl.I/22; 272 Čl.I/23; 272 Čl.I/24; 272 Čl.I/25; 272 Čl.I/26; 272 Čl.I/27; 272 Čl.I/28; 272 Čl.I/29]` {uc=A}

V tomto zákoně se rozumí

a) změnou v území změna jeho ~~funkčního využití nebo~~ prostorového uspořádání **nebo využití**, včetně umisťování staveb nebo jejich změn, {uc=A}

b) stavebním pozemkem pozemek, jeho část nebo soubor pozemků vymezený a určený k zastavění,

c) ~~zastavěným stavebním~~ pozemkem **zázemí stavby** pozemek evidovaný v katastru nemovitostí jako stavební parcela a další pozemkové parcely zpravidla pod společným oplocením tvořící souvislý funkční a prostorový celek se stavbami majícími určující funkci v tomto souvislém celku, {uc=A}

d) plochou část území tvořená jedním nebo více pozemky nebo jejich částmi, která je vymezena v ~~územním rozvojovém plánu~~ **nástrojích územního plánování pro určité prostorové uspořádání nebo využití**, ~~zásadách územního rozvoje nebo územním plánu, popřípadě v územně plánovacích podkladech, s ohledem na stávající nebo požadovaný způsob využití nebo její význam,~~ {uc=A}

e) koridorem území vymezené pro zpravidla liniový záměr dopravní nebo technické infrastruktury nebo opatření nestavební povahy **v nástrojích územního plánování**, {uc=A}

f) plochou nebo koridorem celostátního významu plocha nebo koridor, které svým významem, rozsahem nebo využitím ovlivní území více krajů nebo států,

g) plochou nebo koridorem nadmístního významu plocha nebo koridor, které svým významem, rozsahem nebo využitím ovlivní území více obcí; v případě hlavního města Prahy se za plochu nebo koridor nadmístního významu považují plocha nebo koridor, které ~~svým významem~~ **mají celoměstský význam**, ~~rozsahem~~ **rozsah** nebo ~~využitím ovlivní území více městských částí~~ **využití**, {uc=A}

h) ~~zastavěným~~ **zastavitelným** územím **území vymezené v územním plánu, které obsahuje zastavitelné plochy a nestavební plochy; dále se zastavitelným územím rozumí zastavitelné** území vymezené samostatným postupem podle ~~tohoto zákona~~ **§ 116 až 121** (dále jen „vymezení ~~zastavěného~~ **zastavitelného** území“) ~~nebo územním plánem~~, {uc=A}

i) zastavitelnou plochou plocha určená k zastavění vymezená v územním rozvojovém plánu, zásadách územního rozvoje nebo územním plánu,

j) ~~nezastavěným územím~~ **nestavební plochou plocha v zastavitelném** území ~~nezahrnuté do zastavěného území nebo do zastavitelné plochy~~, **která není určena k umístění zástavby, s výjimkou veřejné infrastruktury,** {uc=A}

**k) nezastavitelným územím území nezahrnuté do zastavitelného území,** {uc=A}

~~k)~~ **l)** ~~transformační~~ plochou **změny v zastavitelném území zastavitelná nebo nestavební** plocha určená ~~k vytvoření zcela nového~~ **ke změně** charakteru území nebo k obnově znehodnoceného, nebo zanedbaného území za účelem jeho opětovného využití ~~vymezená územním rozvojovým plánem~~, ~~zásadami územního rozvoje nebo v zastavěném území územním plánem,~~ {uc=A}

~~l)~~ **m)** plochou změny v ~~krajině~~ **nezastavitelném území** plocha určená ke změně stávajícího využití na jiné využití ~~nezastavěného~~ **nezastavitelného** území vymezená v ~~nezastavěném~~ **nezastavitelném** území územním plánem, {uc=A}

~~m)~~ **n)** uliční čarou hranice mezi ~~pozemky~~ **uličním prostranstvím** a ~~veřejným prostranstvím~~ **bloky**, {uc=A}

**o) blokem ucelená část území tvořená souborem pozemků, jedním pozemkem nebo jeho částí, zpravidla ohraničená uličním prostranstvím a vymezená uliční čarou; bloky se rozlišují na stavební, které jsou určené převážně k zastavění budovami, a nestavební, které jsou určené převážně k nestavebním účelům,** {uc=A}

~~n)~~ **p)** stavební čarou rozhraní mezi stavbou a nezastavěnou částí pozemku, která určuje polohu hrany stavby ve výši rostlého nebo upraveného terénu; ~~stavební čára může být~~ **typy stavebních čar stanoví prováděcí právní předpis,** {uc=A}

1. uzavřená, která stanoví rozhraní souvisle zastavěné, v celé délce stavby, nebo

2. otevřená, která stanoví rozhraní přerušované stavebními mezerami,

~~o)~~ **q)** stavební prolukou nezastavěný prostor ve stávající souvislé zástavbě, včetně nezastavěného nároží, který je určen k zastavění, {uc=A}

~~p)~~ **r)** nadřazenou územně plánovací dokumentací se pro {uc=A}

1. regulační plán rozumí územní plán, zásady územního rozvoje a územní rozvojový plán,

2. územní plán rozumí zásady územního rozvoje a územní rozvojový plán,

3. zásady územního rozvoje rozumí územní rozvojový plán,

~~q)~~ **s)** navazující územně plánovací dokumentací se pro {uc=A}

1. politiku územního rozvoje rozumí územní rozvojový plán, zásady územního rozvoje, územní plán a regulační plán,

2. územní rozvojový plán rozumí zásady územního rozvoje, územní plán a regulační plán,

3. zásady územního rozvoje rozumí územní plán a regulační plán,

4. územní plán rozumí regulační plán,

~~r)~~ **t)** limitem využití území omezení změn v území z důvodu ochrany veřejných zájmů, vyplývající z právních předpisů, nebo stanovené na základě jiných právních předpisů, nebo vyplývající z vlastností území, {uc=A}

~~s)~~ **u)** schématem výkres, ve kterém se zjednodušenou formou zobrazují jevy v ~~měřítku menším~~ **podrobnosti menší**, než je stanoveno pro jednotlivé územně plánovací dokumentace, {uc=A}

~~t)~~ **v)** vystavěným prostředím prostředí vytvořené nebo upravené člověkem zahrnující stavby a volná prostranství veřejná i neveřejná, {uc=A}

~~u)~~ **w)** asanací soubor opatření sloužících k ozdravění území, které vykazuje závady, zejména z důvodů hospodářských změn anebo postižení živelní pohromou nebo závažnou havárií, {uc=A}

~~v)~~ **x)** architektonickou soutěží postup hledání nejlepšího architektonického řešení stavby anebo zhotovitele projektové dokumentace, při němž jsou předkládány a hodnoceny návrhy architektonického řešení stavby, {uc=A}

~~w)~~ **y)** urbanistickou soutěží postup hledání nejlepšího urbanistického řešení území anebo zhotovitele územní studie nebo územně plánovací dokumentace, při němž jsou předkládány a hodnoceny návrhy urbanistického řešení území. {uc=A}

##### Základní pojmy stavebního řádu

#### § 13  `[272 Čl.I/30; 272 Čl.I/31; 272 Čl.I/32; 272 Čl.I/33; 272 Čl.I/34; 272 Čl.I/35]` {uc=A}

V tomto zákoně se dále rozumí

a) budovou nadzemní stavba, včetně její podzemní části, prostorově soustředěná a navenek převážně uzavřená obvodovými stěnami a střešní konstrukcí,

b) bytovým domem stavba pro bydlení, ve které více než polovina podlahové plochy slouží bydlení,

c) rodinným domem stavba pro bydlení, ve které více než polovina podlahové plochy slouží bydlení, a která má nejvýše tři samostatné byty, nejvýše dvě nadzemní a jedno podzemní podlaží a podkroví, nebo třetí nadzemní podlaží ustoupené od vnějšího líce obvodové stěny budovy orientované k uliční čáře alespoň o 2 metry,

d) přístupností vytváření podmínek pro samostatné a bezpečné využití pozemků a staveb **podle jejich potřeby a účelu** osobami s pohybovým, zrakovým nebo sluchovým postižením~~, osobami pokročilého věku, těhotnými ženami a osobami doprovázejícími dítě v kočárku nebo dítě do 3 let (dále jen „osoba s omezenou schopností pohybu nebo orientace“)~~ s cílem **zajištění jejich bezpečnosti a nezbytného** bezbariérového užívání, {uc=A}

e) stavbou ubytovacího zařízení stavba nebo její část pro poskytování ubytování a služby s tím spojené; stavbou ubytovacího zařízení není ~~bytový dům~~ **a**, rodinný dům ~~ani stavba pro rodinnou rekreaci~~, {uc=A}

f) stavbou pro obchod stavba s **převažující** prodejní plochou, {uc=A}

g) stavbou pro výrobu a skladování stavba pro průmyslovou, řemeslnou nebo jinou výrobu, popřípadě služby mající charakter výroby, a dále pro skladování výrobků, hmot a materiálů, kromě staveb pro skladování uvedených v písmenu h),

h) stavbou pro zemědělství stavba pro hospodářská zvířata, doprovodná stavba pro hospodářská zvířata, stavba pro rostlinnou výrobu**, a to i bez nutnosti využití místní půdy,** a pro posklizňovou úpravu, stavba pro zemědělské stroje, stavba pro skladování produktů rostlinné výroby, minerálních hnojiv, přípravků a prostředků na ochranu rostlin, {uc=A}

i) bytem soubor místností, popřípadě jedna obytná místnost, který svým stavebně technickým uspořádáním a vybavením splňuje požadavky na trvalé bydlení,

j) bytem zvláštního určení byt upravený k bydlení osob s těžkým pohybovým postižením nebo osob s těžkým zrakovým postižením,

k) místností prostorově uzavřená část stavby, vymezená podlahou, stropem nebo konstrukcí střechy a pevnými stěnami,

l) obytnou místností část bytu, která je určena k bydlení, splňuje požadavky na bydlení z hlediska velikosti, denního osvětlení, větrání, vytápění a hluku a má podlahovou plochu nejméně 8 m2; kuchyň se za obytnou místnost považuje, pokud má podlahovou plochu nejméně 12 m2; tvoří-li byt jediná obytná místnost, musí být její podlahová plocha nejméně 16 m2,

m) pobytovou místností místnost, která svou polohou, velikostí a stavebním uspořádáním splňuje požadavky na to, aby se v ní zdržovaly osoby,

n) podlahovou plochou součet ploch vymezených vnitřním lícem svislých konstrukcí jednotlivých místností a prostorů stavebně upravených k účelovému využití v budově; v podlažích se šikmými stěnami nebo šikmým stropem je vymezena vnitřním lícem konstrukcí v úrovni 1,2 m nad úrovní podlahy; u poloodkrytých popřípadě odkrytých prostorů se místo chybějících svislých konstrukcí podlahová plocha vymezí pravoúhlým průmětem obvodu vodorovné nosné konstrukce,

o) zastavěnou plochou stavby plocha ohraničená ~~pravoúhlými~~ **svislými** průměty vnějšího líce obvodových konstrukcí**, případně jejich spojnic,** všech nadzemních i podzemních podlaží do vodorovné roviny; plochy ~~lodžií~~ **balkonů** a arkýřů se ~~započítávají~~ **nezapočítávají**; u objektů poloodkrytých (bez některých obvodových stěn) je zastavěná plocha vymezena obalovými čarami vedenými vnějšími líci svislých konstrukcí do vodorovné roviny~~; u zastřešených staveb nebo jejich částí bez obvodových svislých konstrukcí je zastavěná plocha vymezena pravoúhlým průmětem střešní konstrukce do vodorovné roviny~~, {uc=A}

p) zastavěnou plochou pozemku součet všech zastavěných ploch jednotlivých staveb~~,~~**.** {uc=A}

~~q) domem pro dostupné nájemní bydlení bytový dům, k němuž je uzavřena plánovací smlouva o dostupném nájemním bydlení, nebo který je jako dům pro dostupné nájemní bydlení vymezen v regulačním plánu vydaném obcí, která je stavebníkem.~~ {uc=A}

#### § 14

V tomto zákoně se dále rozumí

a) stavebníkem osoba, která pro sebe žádá vydání povolení záměru nebo odstranění stavby, zařízení nebo terénní úpravy, a dále osoba, která provádí nebo odstraňuje stavbu, zařízení nebo terénní úpravu, pokud nejde o stavebního podnikatele jednajícího v rámci své podnikatelské činnosti,

b) projektantem fyzická osoba oprávněná podle autorizačního zákona ke zpracování územně plánovací dokumentace, územní studie a projektové dokumentace,

c) hlavním projektantem projektant pověřený koordinací při zpracování dokumentace,

d) stavebním podnikatelem osoba oprávněná k provádění stavebních nebo montážních prací jako předmětu své činnosti podle živnostenského zákona,

e) zhotovitelem stavebník v případě svépomocné formy výstavby, nebo stavební podnikatel,

f) stavbyvedoucím fyzická osoba oprávněná podle autorizačního zákona k odbornému vedení provádění nebo odstraňování stavby,

g) stavebním dozorem odborný dozor nad prováděním nebo odstraňováním stavby, zařízení anebo terénní úpravy svépomocí,

h) dozorem projektanta průběžný odborný dozor nad souladem realizace dokumentace pro provádění záměru s dokumentací o povolení záměru a nad prováděním záměru v souladu s dokumentací pro provedení záměru.

### ČÁST DRUHÁ

*ORGANIZACE A VÝKON VEŘEJNÉ SPRÁVY*

#### HLAVA I

*~~STAVEBNÍ~~ **VEŘEJNÁ** SPRÁVA*

#### § 15 — Obecné ustanovení  `[272 Čl.I/37]` {uc=A}

Působnost podle tohoto zákona vykonávají vláda, ~~Ministerstvo pro místní rozvoj (dále jen „ministerstvo~~ “), orgány územního plánování, stavební úřady, obce, a kraje**, obce, úřady rozvoje území, Ministerstvo obrany, Ministerstvo spravedlnosti a Ministerstvo vnitra**. {uc=A}

#### ~~§ 16 — Obec a kraj~~

> **Nahrazuje se novým zněním (níže).**

~~Obec a kraj soustavně sledují uplatňování jimi vydané územně plánovací dokumentace a vyhodnocují je podle tohoto zákona. Dojde-li ke změně podmínek, za kterých byla územně plánovací dokumentace vydána, pořídí změnu příslušné územně plánovací dokumentace.~~

#### § 16 — **Obec a kraj**  `[272 Čl.I/38]` {uc=A}

**(1) Obec a kraj prosazují a hájí veřejný zájem na všestranném rozvoji svého území a na vytváření podmínek pro bydlení, práci, podnikání a život lidí.** {uc=A}

**(2) K podpoře výkonu působnosti samosprávy podle tohoto zákona a k naplňování cílů tohoto zákona může obec, společenství obcí nebo kraj zřídit útvar architekta nebo jmenovat obecního, městského nebo krajského architekta.** {uc=A}

#### ~~§ 17 — Dopravní a energetický stavební úřad~~

> **Nahrazuje se novým zněním (níže).**

~~(1) Dopravní a energetický stavební úřad je správním úřadem s celostátní působností ve věcech stavebního řádu podřízený Ministerstvu dopravy.~~

~~(2) Sídlem Dopravního a energetického stavebního úřadu je Praha.~~

~~(3) Územní pracoviště Dopravního a energetického stavebního úřadu stanoví Ministerstvo dopravy vyhláškou.~~

~~(4) V čele Dopravního a energetického stavebního úřadu stojí ředitel. Pro účely zákona o státní službě je Ministerstvo dopravy bezprostředně nadřízeným správním úřadem Dopravního a energetického stavebního úřadu.~~

~~(5) Výběr, jmenování a odvolání ředitele se řídí zákonem o státní službě.~~

#### § 17 — **Úřady rozvoje území**  `[272 Čl.I/38]` {uc=A}

**(1) Zřizují se Úřad rozvoje území České republiky (dále jen „Úřad“), úřady rozvoje území krajů a jejich územní pracoviště.** {uc=A}

**(2) Úřad je účetní jednotkou. Úřady rozvoje území krajů a jejich územní pracoviště nejsou účetními jednotkami a pro účely hospodaření s majetkem České republiky, účetnictví a pracovněprávních vztahů mají postavení vnitřních organizačních jednotek Úřadu.** {uc=A}

#### § 17a — **Úřad**  `[272 Čl.I/39]` {uc=A}

**(1) Úřad je ústředním správním úřadem ve věcech územního plánování, stavebního řádu, vyvlastnění a dalších věcí upravených tímto zákonem. Úřad metodicky sjednocuje činnost orgánů územního plánování a řídí a metodicky sjednocuje činnost stavebních úřadů; dále provádí výzkum, publikační činnost a řeší koncepční otázky teorie a praxe v oblasti rozvoje území, územního plánování, stavebního řádu, stavební kultury a vystavěného prostředí, urbanismu a architektury.** {uc=A}

**(2) Sídlem Úřadu je Praha. Úřad může zřídit svá detašovaná územní pracoviště.** {uc=A}

**(3) V čele Úřadu je předseda, kterého jmenuje a odvolává vláda na návrh ministra pro místní rozvoj. Předsedu zastupují v jím vymezených oblastech místopředsedové, které na návrh předsedy jmenuje a odvolává ministr pro místní rozvoj. V případech stanovených vnitřním předpisem Úřadu nebo na základě písemného pověření předsedy může v úřadech rozvoje území právně jednat jménem státu i jiný státní zaměstnanec. Orgán, který předsedu nebo místopředsedu jmenoval, ho odvolá, pokud přestane splňovat podmínky pro jmenování.** {uc=A}

**(4) Předseda a místopředsedové Úřadu jsou jmenováni na dobu 6 let a mohou být jmenováni opakovaně. Předsedou a místopředsedou Úřadu může být jmenována osoba, jejíž znalosti, zkušenosti a morální vlastnosti jsou předpokladem, že bude svoji funkci řádně zastávat, a která** {uc=A}

**a) je státním občanem České republiky,** {uc=A}

**b) je plně svéprávná,** {uc=A}

**c) je bezúhonná a** {uc=A}

**d) má ukončené vysokoškolské vzdělání získané studiem v magisterském studijním programu.** {uc=A}

**(5) S funkcí předsedy a místopředsedy Úřadu je neslučitelný výkon funkce člena řídícího, dozorčího nebo kontrolního orgánu podnikajících osob, výkon výdělečné činnosti s výjimkou správy vlastního majetku a činnosti vědecké, pedagogické, literární, publicistické a umělecké.** {uc=A}

#### § 17b — **Úřady rozvoje území krajů**  `[272 Čl.I/39]` {uc=A}

**(1) Úřady rozvoje území krajů jsou územními správními orgány ve věcech územního plánování, stavebního řádu, vyvlastnění a dalších věcí upravených tímto zákonem.** {uc=A}

**(2) Úřady rozvoje území krajů jsou** {uc=A}

**a) Úřad rozvoje území pro hlavní město Prahu se sídlem v Praze,** {uc=A}

**b) Úřad rozvoje území pro Středočeský kraj se sídlem v Praze,** {uc=A}

**c) Úřad rozvoje území pro Jihočeský kraj se sídlem v Českých Budějovicích,** {uc=A}

**d) Úřad rozvoje území pro Plzeňský kraj se sídlem v Plzni,** {uc=A}

**e) Úřad rozvoje území pro Karlovarský kraj se sídlem v Karlových Varech,** {uc=A}

**f) Úřad rozvoje území pro Ústecký kraj se sídlem v Ústí nad Labem,** {uc=A}

**g) Úřad rozvoje území pro Liberecký kraj se sídlem v Liberci,** {uc=A}

**h) Úřad rozvoje území pro Královéhradecký kraj se sídlem v Hradci Králové,** {uc=A}

**i) Úřad rozvoje území pro Pardubický kraj se sídlem v Pardubicích,** {uc=A}

**j) Úřad rozvoje území pro Kraj Vysočina se sídlem v Jihlavě,** {uc=A}

**k) Úřad rozvoje území pro Jihomoravský kraj se sídlem v Brně,** {uc=A}

**l) Úřad rozvoje území pro Olomoucký kraj se sídlem v Olomouci,** {uc=A}

**m) Úřad rozvoje území pro Moravskoslezský kraj se sídlem v Ostravě,** {uc=A}

**n) Úřad rozvoje území pro Zlínský kraj se sídlem ve Zlíně.** {uc=A}

**(3) Územní pracoviště úřadů rozvoje území krajů (dále jen „územní pracoviště“) jsou územními správními orgány ve věcech stavebního řádu a územního plánování. Územní pracoviště jsou v obcích s rozšířenou působností. Úřad může zřídit detašovaná pracoviště územních pracovišť i v jiných obcích, je-li to potřebné. Detašované pracoviště je součástí územního pracoviště.** {uc=A}

**(4) Úřad rozvoje území kraje vykonává územní působnost v území příslušného kraje. Územní pracoviště vykonává územní působnost ve správním obvodu obce s rozšířenou působností, ve které má sídlo.** {uc=A}

**(5) V čele úřadu rozvoje území kraje stojí ředitel, v čele územního pracoviště stojí vedoucí.** {uc=A}

#### § 18 — Součinnost orgánů veřejné správy  `[272 Čl.I/40; 272 Čl.I/41; 272 Čl.I/42]` {uc=A}

(1) Orgány územního plánování a stavební úřady postupují při výkonu své působnosti ve vzájemné součinnosti s dotčenými orgány chránícími veřejné zájmy podle jiných právních předpisů **a v souladu se zásadami uvedenými v části první hlavě I zajišťují koordinaci jejich vyjádření, stanovisek a závazných stanovisek, řešení rozporů a odstraňování vad**. {uc=A}

(2) ~~Stavební úřad projednává s dotčenými orgány jimi vydaná vyjádření~~ **Orgány územního plánování** a ~~závazná stanoviska. Za účelem projednání vyjádření a závazných stanovisek nebo odstranění rozporů může~~ stavební ~~úřad svolat~~ **úřady mohou nařídit** společné jednání s **obcemi, kraji nebo** dotčenými orgány**, a to oznámením nejméně 5 pracovních dnů před jeho konáním, nedohodnou-li se jinak**. Společné jednání je neveřejné ~~a~~**,** o jeho ~~průběhu a~~ závěrech se sepisuje protokol~~. Stavební úřad oznámí dotčeným orgánům jeho konání nejméně 5 dnů předem~~. Je-li to účelné, ~~přizve stavební úřad~~ **lze** ke společnému jednání ~~stavebníka a ostatní účastníky řízení~~ **přizvat jiné osoby**. ~~V takovém případě nařídí~~ **Nezúčastní-li se dotčený orgán bez důvodné omluvy společného jednání, platí, že souhlasí s řešením orgánu územního plánování nebo stavebního úřadu. K odstranění rozporů nebo zjevných vad vyjádření, stanovisek nebo závazných stanovisek může orgán územního plánování nebo** stavební úřad ~~společné jednání jako ústní jednání~~ **stanovit dotčeným orgánům lhůtu, která nepřekročí 15 dní**. {uc=A}

(3) Nedojde-li postupem podle odstavce 2 k odstranění rozporu mezi stavebním úřadem a dotčenými orgány, jakož i mezi dotčenými orgány navzájem, postupuje se podle správního řádu **s tím, že je-li příslušným správním orgánem tentýž úřad, rozhodne o rozporu jeho vedoucí**. {uc=A}

(4) Stanoví-li dotčené orgány ve svém vyjádření nebo závazném stanovisku podmínky, které se staly součástí rozhodnutí stavebního úřadu, kontrolují v součinnosti se stavebním úřadem jejich dodržování.

#### HLAVA II

*PŮSOBNOST VE VĚCECH ÚZEMNÍHO PLÁNOVÁNÍ*

#### ~~§ 19 — Obecná ustanovení~~

> **Nahrazuje se novým zněním (níže).**

~~(1) Působnost ve věcech územního plánování vykonávají vláda a orgány územního plánování, kterými jsou~~

~~a) ministerstvo,~~

~~b) Ministerstvo obrany,~~

~~c) úřady územního plánování a~~

~~d) obecní úřad, který získal potvrzení o zajištění splnění kvalifikačních požadavků pro výkon územně plánovací činnosti.~~

~~(2) Úřady územního plánování jsou obecní úřady obcí s rozšířenou působností a krajské úřady.~~

~~(3) Působnost ve věcech územního plánování vykonávají dále zastupitelstvo obce, zastupitelstvo kraje, rada obce a rada kraje.~~

#### § 19 — **Obecná ustanovení**  `[272 Čl.I/43]` {uc=A}

**(1) Působnost ve věcech územního plánování vykonávají vláda a orgány územního plánování, kterými jsou** {uc=A}

**a) úřady rozvoje území,** {uc=A}

**b) Ministerstvo obrany,** {uc=A}

**c) kraje,** {uc=A}

**d) obce a** {uc=A}

**e) hlavní město Praha.** {uc=A}

**(2) Orgány územního plánování soustavně sledují uplatňování jimi vydané územně plánovací dokumentace a vyhodnocují je. Dojde-li ke změně podmínek, za kterých byla územně plánovací dokumentace vydána, pořídí změnu příslušné územně plánovací dokumentace.** {uc=A}

#### ~~§ 20 — Vláda~~

> **Nahrazuje se novým zněním (níže).**

~~Vláda~~

~~a) schvaluje politiku architektury a stavební kultury,~~

~~b) rozhoduje o pořízení politiky územního rozvoje,~~

~~c) schvaluje politiku územního rozvoje,~~

~~d) projednává a schvaluje zprávu o plnění politiky územního rozvoje a politiky architektury a stavební kultury,~~

~~e) vydává územní rozvojový plán,~~

~~f) projednává a schvaluje zprávu o uplatňování územního rozvojového plánu,~~

~~g) vydává územní opatření o stavební uzávěře, jedná-li se o změny v území celostátního významu,~~

~~h) vydává územní opatření o asanaci území, ovlivní-li svým významem, rozsahem nebo využitím území více krajů nebo států.~~

#### § 20 — **Vláda Vláda schvaluje**  `[272 Čl.I/43]` {uc=A}

**a) politiku architektury a stavební kultury,** {uc=A}

**b) politiku územního rozvoje,** {uc=A}

**c) územní rozvojový plán,** {uc=A}

**d) územní opatření celostátního významu.** {uc=A}

#### § 21 — ~~Ministerstvo~~ **Úřady rozvoje území**  `[272 Čl.I/44; 272 Čl.I/45; 272 Čl.I/46; 272 Čl.I/47; 272 Čl.I/48; 272 Čl.I/49; 272 Čl.I/50; 272 Čl.I/51; 272 Čl.I/52; 272 Čl.I/53]` {uc=A}

(1) ~~Ministerstvo~~ **Úřad** je nadřízeným správním orgánem ~~krajských~~ úřadů **rozvoje území krajů** jako ~~úřadů~~ **orgánů** územního plánování. {uc=A}

(2) ~~Ministerstvo~~ **Úřad** {uc=A}

a) vykonává kontrolu ve věcech územního plánování,

b) **zpracovává a** pořizuje politiku architektury a stavební kultury, {uc=A}

c) **zpracovává a** pořizuje politiku územního rozvoje, {uc=A}

d) **zpracovává,** pořizuje **a vydává** územní rozvojový plán, {uc=A}

e) **zpracovává a** pořizuje ~~územně plánovací podklady~~ **územní studie** v podrobnosti a rozsahu nezbytném pro pořizování politiky územního rozvoje a územního rozvojového plánu, popřípadě pro plnění dalších svých úkolů, {uc=A}

f) **zpracovává,** pořizuje **a vydává** územní opatření ~~o stavební uzávěře, jedná-li se o změny v území~~ celostátního významu, {uc=A}

g) ~~pořizuje územní opatření o asanaci území~~ **poskytuje údaje pro územně analytické podklady**, ~~ovlivní-li svým významem, rozsahem nebo využitím území více krajů nebo států,~~ {uc=A}

~~h) vede národní geoportál územního plánování a vkládá do něj data,~~ {uc=A}

~~i) zajišťuje metodickou podporu uplatňování soudobých poznatků vědy a techniky a metodicky sjednocuje výkladovou a aplikační činnost krajských úřadů a obecních úřadů v oblasti územního plánování, urbanismu a architektury,~~ {uc=A}

~~j)~~ **h)** vykonává další činnosti podle tohoto zákona. {uc=A}

**(3) Úřad rozvoje území kraje je nadřízeným orgánem krajů a obcí jako orgánů územního plánování.** {uc=A}

**(4) Úřad rozvoje území kraje, případně z jeho pověření jeho územní pracoviště** {uc=A}

**a) vykonává kontrolu ve věcech územního plánování,** {uc=A}

**b) pořizuje územní plán a územní opatření na žádost obce podle § 47 odst. 2,** {uc=A}

**c) pořizuje a vydává vymezení zastavitelného území obcí, které nemají územní plán, a** {uc=A}

**d) vykonává další činnosti podle tohoto zákona.** {uc=A}

#### § 22 — Ministerstvo obrany  `[272 Čl.I/54; 272 Čl.I/55; 272 Čl.I/56]` {uc=A}

Ministerstvo obrany pro území vojenských újezdů

a) pořizuje**, schvaluje** a vydává územní plán a regulační plán, {uc=A}

b) pořizuje ~~územně plánovací podklady~~ **územní studie** v podrobnosti a rozsahu nezbytném pro pořizování územních plánů, regulačních plánů, popřípadě pro další územně plánovací činnost Ministerstva obrany, {uc=A}

c) ~~vkládá data do národního geoportálu územního plánování~~ **poskytuje údaje pro územně analytické podklady**. {uc=A}

#### ~~§ 23 — Krajský úřad~~

> **Nahrazuje se novým zněním (níže).**

~~(1) Krajský úřad je nadřízeným správním orgánem obecních úřadů obcí s rozšířenou působností jako úřadů územního plánování a obecních úřadů podle § 26.~~

~~(2) Krajský úřad jako úřad územního plánování~~

~~a) vykonává kontrolu ve věcech územního plánování,~~

~~b) pořizuje zásady územního rozvoje,~~

~~c) pořizuje územně plánovací podklady v podrobnosti a rozsahu nezbytném pro pořizování zásad územního rozvoje, popřípadě pro další územně plánovací činnost kraje,~~

~~d) pořizuje územní opatření o stavební uzávěře, jedná-li se o změny v území nadmístního významu,~~

~~e) pořizuje územní opatření o asanaci území, ovlivní-li svým významem, rozsahem nebo využitím území více obcí,~~

~~f) vkládá data do národního geoportálu územního plánování,~~

~~g) vydává potvrzení o splnění kvalifikačních předpokladů pro výkon územně plánovací činnosti,~~

~~h) vykonává další činnosti podle tohoto zákona.~~

#### § 23 — **Kraj**  `[272 Čl.I/57]` {uc=A}

**Kraj v samostatné působnosti pro své území zpracovává, pořizuje, schvaluje a vydává zásady územního rozvoje, územní studie a územní opatření, poskytuje údaje pro územně analytické podklady a vykonává další územně plánovací činnosti v zájmu rozvoje kraje v rámci svého práva na samosprávu. Při tom jej lze omezit jen na základě zákona a jen v nezbytně nutném rozsahu.** {uc=A}

#### § 24 — Zastupitelstvo kraje a rada kraje  `[272 Čl.I/58; 272 Čl.I/59; 272 Čl.I/60; 272 Čl.I/61; 272 Čl.I/62; 272 Čl.I/63; 272 Čl.I/64]` {uc=A}

(1) Zastupitelstvo kraje

a) rozhoduje o pořízení zásad územního rozvoje,

b) schvaluje zadání zásad územního rozvoje,

~~c) schvaluje návrh výběru nejvhodnější varianty v návrhu zásad územního rozvoje,~~

~~d)~~ **c)** ~~vydává~~ **schvaluje** zásady územního rozvoje~~,~~**.** {uc=A}

~~d) projednává a schvaluje zprávu o uplatňování zásad územního rozvoje.~~

(2) Rada kraje

a) uplatňuje připomínky k návrhu politiky územního rozvoje a územního rozvojového plánu a zásad územního rozvoje sousedního kraje,

b) uplatňuje připomínky k návrhu územního opatření, který pořizuje ~~ministerstvo~~ **Úřad** a dotýká se území kraje, {uc=A}

c) rozhoduje o pořízení územního opatření ~~o stavební uzávěře a asanaci území~~, k ~~jejichž~~ **jehož** pořízení je příslušný ~~krajský úřad~~ **kraj**, {uc=A}

d) ~~vydává~~ **schvaluje** územní opatření ~~o stavební uzávěře a asanaci území~~, k jejichž pořízení je příslušný ~~krajský úřad~~ **kraj**, {uc=A}

e) podává podnět k pořízení změny politiky územního rozvoje, změny územního rozvojového plánu, změny územního plánu nebo změny regulačního plánu.

#### ~~§ 25 — Obecní úřad obce s rozšířenou působností~~

> **Nahrazuje se novým zněním (níže).**

~~Obecní úřad obce s rozšířenou působností jako úřad územního plánování~~

~~a) pořizuje územní plán a regulační plán,~~

~~b) pořizuje územní plán, regulační plán a územní opatření na žádost obce,~~

~~c) pořizuje územně plánovací podklady pro svůj správní obvod v podrobnosti a rozsahu nezbytném pro pořizování územních plánů, regulačních plánů, popřípadě pro další územně plánovací činnost obcí,~~

~~d) pořizuje a vydává vymezení zastavěného území,~~

~~e) pořizuje územní opatření o stavební uzávěře a územní opatření o asanaci území pro území obce,~~

~~f) vkládá data do národního geoportálu územního plánování,~~

~~g) vykonává další činnosti podle tohoto zákona.~~

#### § 25  `[272 Čl.I/65]` {uc=A}

**Společenství obcí Společenství obcí může na základě veřejnoprávní smlouvy s obcí v samostatné působnosti vykonávat odborné činnosti pořizovatele, jimiž se rozumí zpracovávání, pořizování a vydávání nástrojů územního plánování, pro obce, které jsou jeho členem.** {uc=A}

#### ~~§ 26 — Obecní úřad~~

> **Nahrazuje se novým zněním (níže).**

~~Obecní úřad, který získal potvrzení krajského úřadu o zajištění splnění kvalifikačních požadavků pro výkon územně plánovací činnosti, může vykonávat v přenesené působnosti působnost podle § 25 písm. a), e) a f) a pořizovat územní studii.~~

#### § 26 — **Obec**  `[272 Čl.I/65]` {uc=A}

**Obec v samostatné působnosti pro své území zpracovává, pořizuje, schvaluje a vydává územní plán, regulační plán, územní studii a územní opatření, poskytuje údaje pro územně analytické podklady a vykonává další územně plánovací činnosti v zájmu rozvoje obce v rámci svého práva na samosprávu. Při tom ji lze omezit jen na základě zákona a jen v nezbytně nutném rozsahu.** {uc=A}

#### § 27 — Zastupitelstvo obce a rada obce  `[272 Čl.I/66; 272 Čl.I/67; 272 Čl.I/68; 272 Čl.I/69; 272 Čl.I/70; 272 Čl.I/71; 272 Čl.I/72; 272 Čl.I/73; 272 Čl.I/74]` {uc=A}

(1) Zastupitelstvo obce

a) rozhoduje o pořízení územního plánu a regulačního plánu,

b) schvaluje zadání územního plánu a regulačního plánu,

~~c) schvaluje návrh výběru nejvhodnější varianty v návrhu územního plánu a regulačního plánu,~~

~~d)~~ **c)** ~~vydává~~ **schvaluje** územní plán a regulační plán~~,~~**.** {uc=A}

~~d) projednává a schvaluje zprávu o uplatňování územního plánu.~~

(2) Rada obce a v obcích, kde se rada nevolí, zastupitelstvo obce

a) uplatňuje připomínky k návrhu politiky územního rozvoje, územního rozvojového plánu, zásad územního rozvoje a územního plánu sousední obce,

b) uplatňuje připomínky k návrhu vymezení ~~zastavěného~~ **zastavitelného** území pro území obce, {uc=A}

c) uplatňuje připomínky k návrhu územního opatření ~~o asanaci území a územního opatření o stavební uzávěře~~, které pořizuje ~~krajský úřad jako úřad územního plánování,~~ **kraj** nebo ~~ministerstvo~~ **Úřad**, a dotýkají se území obce, {uc=A}

d) rozhoduje o pořízení územního opatření ~~o stavební uzávěře a o asanaci území~~ pro území obce, {uc=A}

e) ~~vydává~~ **schvaluje** územní opatření ~~o stavební uzávěře a o asanaci území~~ pro území obce, {uc=A}

~~f) rozhoduje o podání žádosti podle § 25 písm. b) anebo rozhoduje o uzavření smlouvy s osobou splňující předpoklady pro výkon územně plánovací činnosti podle § 46 odst. 2 písm. c),~~

~~g)~~ **f)** ~~rozhoduje o podání žádosti~~ **uděluje souhlas k možnosti odchýlit se od územně plánovací dokumentace nebo územního opatření** podle § ~~48~~ **193** odst. ~~3~~ **2**. {uc=A}

#### ~~§ 28 — Působnost na území hlavního města Prahy~~

> **Nahrazuje se novým zněním (níže).**

~~(1) Pořizuje-li územní plán pro území hlavního města Prahy Magistrát hlavního města Prahy, vykonává působnost krajského úřadu ministerstvo.~~

~~(2) Pořizuje-li územní plán pro vymezenou část území hlavního města Prahy úřad městské části, vykonává působnost krajského úřadu Magistrát hlavního města Prahy.~~

#### § 28  `[272 Čl.I/75]` {uc=A}

**Působnost na území hlavního města Prahy Hlavní město Praha v samostatné působnosti pro své území zpracovává, pořizuje, schvaluje a vydává zásady územního rozvoje, územní plán, regulační plán, územní studii a územní opatření, poskytuje údaje pro územně analytické podklady a vykonává další územně plánovací činnosti v zájmu rozvoje hlavního města Prahy v rámci svého práva na samosprávu. Při tom ji lze omezit jen na základě zákona a jen v nezbytně nutném rozsahu.** {uc=A}

#### ~~§ 29 — Ústav územního rozvoje~~  `[272 Čl.I/76]` {uc=A}

> **Zrušuje se celý paragraf.**

~~(1) Ústav územního rozvoje se sídlem v Brně je organizační složkou státu a účetní jednotkou, pro kterou plní funkci zřizovatele ministerstvo.~~

~~(2) Ústav územního rozvoje~~

~~a) provádí výzkum, publikační činnost a řeší koncepční otázky teorie a praxe v oboru územního plánování a stavebního řádu, stavební kultury a vystavěného prostředí, urbanismu a architektury,~~

~~b) zpracovává návrh politiky architektury a stavební kultury,~~

~~c) zpracovává návrh politiky územního rozvoje, jejích změn a úplné znění politiky územního rozvoje po její poslední změně,~~

~~d) zpracovává návrh územního rozvojového plánu, jeho změn a úplné znění územního rozvojového plánu po jeho změně,~~

~~e) zpracovává návrh územně plánovacích podkladů pro území státu,~~

~~f) vykonává další činnosti, kterými ho pověří ministerstvo.~~

#### HLAVA III

*PŮSOBNOST VE VĚCECH STAVEBNÍHO ŘÁDU*

#### ~~§ 30 — Obecná ustanovení~~

> **Nahrazuje se novým zněním (níže).**

~~(1) Působnost ve věcech stavebního řádu vykonávají stavební úřady, kterými jsou~~

~~a) ministerstvo,~~

~~b) Ministerstvo dopravy,~~

~~c) Ministerstvo průmyslu a obchodu,~~

~~d) Dopravní a energetický stavební úřad,~~

~~e) krajské stavební úřady,~~

~~f) obecní stavební úřady a~~

~~g) jiné stavební úřady3).~~

~~(2) Krajskými stavebními úřady jsou krajské úřady.~~

~~(3) Obecními stavebními úřady jsou~~

~~a) obecní úřady obcí s rozšířenou působností a~~

~~b) pověřené obecní úřady a obecní úřady, které stanoví ministerstvo prováděcím právním předpisem.~~

~~(4) Správní obvody obecních stavebních úřadů stanoví ministerstvo prováděcím právním předpisem. Stanovení obecního stavebního úřadu nebo jeho zrušení, popřípadě změnu jeho správního obvodu, lze provést pouze k počátku kalendářního roku.~~

~~(5) Dojde-li ke stanovení obecního stavebního úřadu nebo k jeho zrušení, popřípadě ke změně jeho správního obvodu, stanoví ministerstvo v prováděcím právním předpisu, který obecní stavební úřad dokončí neskončená správní řízení, a provede spisovou rozluku s rušeným obecním stavebním úřadem.~~

~~(6) Jinými stavebními úřady jsou Ministerstvo obrany, Ministerstvo vnitra a Ministerstvo spravedlnosti.~~

#### § 30 — **Obecná ustanovení**  `[272 Čl.I/77]` {uc=A}

**(1) Působnost ve věcech stavebního řádu vykonávají stavební úřady, kterými jsou úřady rozvoje území, jiné stavební úřady a autorizovaný inspektor.** {uc=A}

**(2) Jinými stavebními úřady jsou Ministerstvo obrany, Ministerstvo vnitra a Ministerstvo spravedlnosti.** {uc=A}

**(3) Úřad je nadřízeným správním orgánem úřadů rozvoje území krajů. Úřady rozvoje území krajů jsou nadřízeným správním orgánem svých územních pracovišť.** {uc=A}

**(4) Nadřízeným správním orgánem autorizovaného inspektora je stavební úřad, který v dané věci vydal povolení záměru, a není-li tomu tak, je jím úřad rozvoje území kraje, v němž má autorizovaný inspektor sídlo.** {uc=A}

**(5) Nadřízený úřad rozvoje území může usnesením pověřit prováděním postupů podle části šesté, deváté a desáté tohoto zákona jiný věcně příslušný stavební úřad, jestliže je to účelné; usnesení se pouze poznamená do spisu.** {uc=A}

#### ~~§ 30a — Kvalifikační požadavky pro výkon činnosti na úseku stavebního řádu~~  `[272 Čl.I/78]` {uc=A}

> **Zrušuje se celý paragraf.**

~~(1) Krajské stavební úřady a obecní stavební úřady vykonávají činnost na úseku stavebního řádu prostřednictvím úředníků6) splňujících kvalifikační požadavky pro výkon činnosti na úseku stavebního řádu.~~

~~(2) Kvalifikační požadavky pro výkon činnosti na úseku stavebního řádu splňuje fyzická osoba, která~~

~~a) má osvědčení zvláštní odborné způsobilosti pro správní činnost stavební řád a vyvlastnění podle jiného právního předpisu7), nebo osvědčení o úspěšném vykonání úřednické zkoušky pro obor státní služby, jehož součástí je stavební řád a~~

~~b) splňuje kvalifikační požadavky vzdělání podle tohoto zákona.~~

~~(3) Ustanovení jiného právního předpisu o vydávání osvědčení o uznání rovnocennosti vzdělání8) se pro podmínky podle odstavce 2 nepoužije.~~

~~(4) Kvalifikační požadavky vzdělání podle odstavce 2 písm. b) splňuje~~

~~a) autorizovaný architekt, kterému byla udělena autorizace pro obor architektura nebo bez specifikace oboru podle autorizačního zákona,~~

~~b) autorizovaný inženýr nebo autorizovaný technik, kterému byla udělena autorizace pro obor pozemní stavby, dopravní stavby, stavby vodního hospodářství a krajinného inženýrství, mosty a inženýrské konstrukce, statika a dynamika staveb nebo městské inženýrství,~~

~~c) fyzická osoba, která má vysokoškolské vzdělání ve studijním programu náležejícím do oblasti vzdělávání architektura a urbanismus, stavebnictví, ekonomické obory, doprava, biologie, ekologie a životní prostředí, lesnictví a dřevařství, vědy o zemi, nebo právo,~~

~~d) fyzická osoba, která má vyšší odborné vzdělání v oboru stavebnictví, geodézie a kartografie, obecně právní činnost, veřejnosprávní činnost, nebo doprava, nebo~~

~~e) fyzická osoba, která má střední vzdělání s maturitní zkouškou v oboru stavebnictví, geodézie a katastr nemovitostí, nebo veřejnosprávní činnost.~~

~~(5) Úředník nesplňující kvalifikační požadavky může vykonávat činnost stavebního úřadu na úseku stavebního řádu, pokud je zajištěno, že bude do doby splnění uvedených požadavků vykonávat tuto činnost pod odborným vedením úředníka splňujícího kvalifikační požadavky pro výkon činnosti na úseku stavebního řádu, nejvýše však po dobu 3 let.~~

#### ~~§ 31 — Metodická činnost~~

> **Nahrazuje se novým zněním (níže).**

~~(1) Ministerstvo metodicky sjednocuje výkon působnosti stavebních úřadů v oblasti stavebního řádu a požadavků na výstavbu.~~

~~(2) Ministerstvo dopravy metodicky sjednocuje u staveb dálnic, silnic, místních komunikací a veřejně přístupných účelových komunikací, staveb drah a civilních leteckých staveb výkon působnosti stavebních úřadů v oblasti požadavků na výstavbu.~~

#### § 31  `[272 Čl.I/79]` {uc=A}

**Metodická činnost Jiné ústřední orgány státní správy v rámci své působnosti metodicky podporují výkon působnosti Úřadu v oblastech, ve kterých stavební úřady rozhodují o věcech v působnosti jiných ústředních orgánů státní správy.** {uc=A}

#### ~~§ 32 — Ministerstvo~~

> **Nahrazuje se novým zněním (níže).**

~~(1) Ministerstvo je nadřízeným správním orgánem krajského stavebního úřadu, není-li jeho nadřízeným správním orgánem Dopravní a energetický stavební úřad.~~

~~(2) Ministerstvo~~

~~a) vede systém stavebně technické prevence, v němž sleduje a analyzuje závažné nebo opakující se závady nebo havárie staveb, kterým je třeba ve veřejném zájmu předcházet, a navrhuje opatření k zabránění jejich opakování,~~

~~b) sleduje účinnost technických předpisů pro stavby a dbá o zlepšování jejich úrovně,~~

~~c) navrhuje úpravy požadavků na stavby, jejich části, funkce, prvky a stavební výrobky a podává podněty k úpravě českých technických norem nebo certifikace stavebních výrobků anebo k jiným stavebně technickým opatřením,~~

~~d) připravuje seznam závazných českých technických norem nebo jejich částí obsahujících podrobnější technické požadavky na stavby, které určí Úřad pro technickou normalizaci, metrologii a státní zkušebnictví jako určené technické normy ve stavebnictví a oznámí je ve Věstníku podle jiného právního předpisu s výjimkou norem stanovených prováděcím právním předpisem územního samosprávného celku,~~

~~e) zajišťuje bezplatný přístup k určeným technickým normám ve stavebnictví podle jiného právního předpisu s výjimkou norem stanovených prováděcím právním předpisem územního samosprávného celku,~~

~~f) vykonává kontrolu ve věcech stavebního řádu,~~

~~g) vykonává kontrolu nad činností autorizovaných inspektorů.~~

~~(3) Ministerstvo může~~

~~a) vyhradit si zjišťování stavebně technických příčin havárií staveb nebo účast při něm, pokud se svým rozsahem nebo opakovanými důsledky ve značné míře dotýkají veřejných zájmů,~~

~~b) pověřit vedením systému stavebně technické prevence Ústav územního rozvoje.~~

~~(4) Ministerstvo nevykonává působnost podle tohoto zákona v rozsahu, v jakém ji vykonává Ministerstvo dopravy nebo Ministerstvo průmyslu a obchodu.~~

#### § 32 — **Úřad**  `[272 Čl.I/79]` {uc=A}

**(1) Úřad** {uc=A}

**a) vykonává působnost stavebního úřadu ve věcech vyhrazených a s nimi souvisejících staveb,** {uc=A}

**b) vydává rámcové povolení pro stavby jaderného zařízení a stavby související, nacházející se uvnitř i vně areálu jaderného zařízení,** {uc=A}

**c) vykonává působnost vyvlastňovacího úřadu ve věcech vyhrazených staveb,** {uc=A}

**d) vydává rozhodnutí o změně využití území pro stanovení prostoru pro dobývání ložisek nerostů, pro která se nestanoví dobývací prostor podle horního zákona,** {uc=A}

**e) rozhoduje v pochybnostech, zda se jedná o vyhrazenou stavbu nebo stavbu či záměr související s vyhrazenou stavbou,** {uc=A}

**f) vede systém stavebně technické prevence, v němž sleduje a analyzuje závažné nebo opakující se závady nebo havárie staveb, kterým je třeba ve veřejném zájmu předcházet, a navrhuje opatření k zabránění jejich opakování,** {uc=A}

**g) sleduje účinnost technických předpisů pro stavby a dbá o zlepšování jejich úrovně,** {uc=A}

**h) navrhuje úpravy požadavků na stavby, jejich části, funkce, prvky a stavební výrobky a podává podněty k úpravě českých technických norem nebo certifikace stavebních výrobků anebo k jiným stavebně technickým opatřením,** {uc=A}

**i) připravuje seznam závazných českých technických norem nebo jejich částí obsahujících podrobnější technické požadavky na stavby, které určí Úřad pro technickou normalizaci, metrologii a státní zkušebnictví jako určené technické normy ve stavebnictví a oznámí je ve Věstníku podle jiného právního předpisu s výjimkou norem stanovených prováděcím právním předpisem územního samosprávného celku,** {uc=A}

**j) zajišťuje bezplatný přístup k určeným technickým normám ve stavebnictví podle jiného právního předpisu s výjimkou norem stanovených prováděcím právním předpisem územního samosprávného celku,** {uc=A}

**k) vykonává kontrolu ve věcech stavebního řádu,** {uc=A}

**l) vykonává kontrolu nad činností autorizovaných inspektorů a** {uc=A}

**m) je jednotným kontaktním místem ve smyslu čl. 9 nařízení Evropského parlamentu a Rady (EU) 2024/1252 pro vyhrazené stavby.** {uc=A}

**(2) Proti rozhodnutí Úřadu vydanému v řízení podle části šesté tohoto zákona není přípustný rozklad.** {uc=A}

#### ~~§ 32a — Ministerstvo dopravy~~  `[272 Čl.I/80]` {uc=A}

> **Zrušuje se celý paragraf.**

~~(1) Ministerstvo dopravy je nadřízeným správním orgánem Dopravního a energetického stavebního úřadu, není-li jeho nadřízeným správním orgánem Ministerstvo průmyslu a obchodu.~~

~~(2) Ministerstvo dopravy ve věcech staveb dálnic, silnic, místních komunikací a veřejně přístupných účelových komunikací, staveb drah a civilních leteckých staveb~~

~~a) sleduje účinnost technických předpisů pro stavby a dbá o zlepšování jejich úrovně,~~

~~b) navrhuje úpravy požadavků na stavby, jejich části, funkce, prvky a stavební výrobky a podává podněty k úpravě českých technických norem nebo certifikace stavebních výrobků anebo k jiným stavebně technickým opatřením,~~

~~c) připravuje seznam závazných českých technických norem nebo jejich částí obsahujících podrobnější technické požadavky na stavby, které určí Úřad pro technickou normalizaci, metrologii a státní zkušebnictví jako určené technické normy ve stavebnictví a oznámí je ve Věstníku podle jiného právního předpisu s výjimkou norem stanovených prováděcím právním předpisem územního samosprávného celku,~~

~~d) zajišťuje bezplatný přístup k určeným technickým normám ve stavebnictví podle jiného právního předpisu s výjimkou norem stanovených prováděcím právním předpisem územního samosprávného celku,~~

~~e) vykonává kontrolu ve věcech stavebního řádu.~~

#### ~~§ 32b — Ministerstvo průmyslu a obchodu~~  `[272 Čl.I/80]` {uc=A}

> **Zrušuje se celý paragraf.**

~~(1) Ministerstvo průmyslu a obchodu je nadřízeným správním orgánem Dopravního a energetického stavebního úřadu ve věcech~~

~~a) vyhrazených staveb uvedených v příloze č. 3 písm. d) až p) k tomuto zákonu, včetně staveb souvisejících,~~

~~b) staveb uvedených v § 34 písm. a) bodu 3,~~

~~c) staveb technické infrastruktury pro energetiku a elektronické komunikace.~~

~~(2) Ministerstvo průmyslu a obchodu u staveb podle odstavce 1~~

~~a) sleduje účinnost technických předpisů pro stavby a dbá o zlepšování jejich úrovně,~~

~~b) vykonává kontrolu ve věcech stavebního řádu.~~

#### ~~§ 33 — Dopravní a energetický stavební úřad~~

> **Nahrazuje se novým zněním (níže).**

~~(1) Dopravní a energetický stavební úřad je nadřízeným správním orgánem krajského stavebního úřadu ve věcech staveb~~

~~a) silnic, místních komunikací a veřejně přístupných účelových komunikací,~~

~~b) uvedených v § 34 písm. a) bodu 3,~~

~~c) technické infrastruktury pro energetiku a elektronické komunikace.~~

~~(2) Dopravní a energetický stavební úřad~~

~~a) vykonává působnost stavebního úřadu ve věcech vyhrazených staveb,~~

~~b) vykonává působnost stavebního úřadu ve věcech staveb souvisejících s vyhrazenými stavbami, jež by jinak byly v působnosti krajského stavebního úřadu nebo obecního stavebního úřadu,~~

~~c) vydává rámcové povolení pro stavby jaderného zařízení a stavby související, nacházející se uvnitř i vně areálu jaderného zařízení, a~~

~~d) vykonává kontrolu ve věcech stavebního řádu.~~

~~(3) K přechodu související stavby do působnosti krajského úřadu nebo obecního stavebního úřadu se vyžaduje změna účelu užívání.~~

#### § 33 — **Úřad rozvoje území kraje Úřad rozvoje území kraje**  `[272 Čl.I/81]` {uc=A}

**a) vykonává působnost stavebního úřadu v případech, ve kterých nevykonává působnost Úřad nebo jiný stavební úřad, ve věcech** {uc=A}

**1. záměrů EIA,** {uc=A}

**2. silnic I. třídy,** {uc=A}

**3. výroben z obnovitelných zdrojů energie neuvedených v příloze č. 3 k tomuto zákonu,** {uc=A}

**4. vodních nádrží s celkovým objemem nad 1000000 m3 nebo s výškou vzdutí nad 10 m ode dna základové výpusti,** {uc=A}

**5. staveb a zařízení distribuční soustavy o napětí 110 kV včetně transformovny 110 kV a staveb a zařízení pro ukládání energie připojených do distribuční soustavy s napětím 110 kV,** {uc=A}

**6. staveb a zařízení distribuční soustavy plynu o tlakové hladině nad 4 do 40 barů včetně a souvisejících technologických objektů, u nichž se uvedené tlakové rozmezí týká výstupního tlaku,** {uc=A}

**b) vykonává působnost stavebního úřadu a vyvlastňovacího úřadu u staveb vyžadujících vyvlastňovací řízení, které by jinak spadaly do působnosti územního pracoviště úřadu rozvoje území kraje, a působnost vyvlastňovacího úřadu u drobných staveb a v dalších případech, není-li k nim příslušný Úřad,** {uc=A}

**c) vydává rámcové povolení pro stavby v působnosti jiného stavebního úřadu, včetně staveb souvisejících,** {uc=A}

**d) vykonává kontrolu ve věcech stavebního řádu a** {uc=A}

**e) uplatňuje stanovisko k návrhu územního opatření o podmínkách a zmírňujících opatřeních a jeho změnám podle zákona o urychlení využívání obnovitelných zdrojů energie a vykonává působnost stavebního úřadu ve věcech záměrů pro využití obnovitelného zdroje energie v akcelerační oblasti, u kterých nevykovává působnost Úřad.** {uc=A}

#### ~~§ 34 — Krajský stavební úřad~~

> **Nahrazuje se novým zněním (níže).**

~~Krajský stavební úřad~~

~~a) vykonává působnost stavebního úřadu ve věcech~~

~~1. záměrů EIA,~~

~~2. silnic I. třídy,~~

~~3. výroben z obnovitelných zdrojů energie neuvedených v příloze č. 3 k tomuto zákonu,~~

~~4. vodních děl na hraničních vodách,~~

~~5. čistíren odpadních vod sloužících k vypouštění odpadních vod do vod povrchových ze zdrojů znečištění o velikosti 10 000 ekvivalentních obyvatel nebo více,~~

~~6. vodních nádrží s celkovým objemem nad 1 000 000 m3 nebo s výškou vzdutí nad 10 m ode dna základové výpusti,~~

~~7. vodních děl sloužících k vypouštění odpadních vod z těžby a zpracování uranových rud a jaderných elektráren a odpadních vod s obsahem zvlášť nebezpečných závadných nebo nebezpečných závadných látek do vod povrchových a k vypouštění odpadních vod s obsahem zvlášť nebezpečné závadné látky nebo prioritní nebezpečné látky do kanalizace s výjimkou případů, kdy je instalováno zařízení s dostatečnou účinností podle jiného právního předpisu,~~

~~8. vodních děl sloužících k čerpání znečištěných podzemních vod za účelem snížení jejich znečištění a jejich následné vypouštění do těchto vod, popřípadě do vod povrchových,~~

~~9. staveb a zařízení distribuční soustavy o napětí 110 kV včetně transformovny 110 kV a staveb a zařízení pro ukládání energie připojených do distribuční soustavy s napětím 110 kV,~~

~~10. staveb a zařízení distribuční soustavy plynu o tlakové hladině 4 až 40 barů včetně souvisejících technologických objektů,~~

~~u kterých nevykonává působnost Dopravní a energetický stavební úřad nebo jiný stavební úřad,~~

~~b) vydává rámcové povolení pro stavby v působnosti jiného stavebního úřadu, včetně staveb souvisejících, a~~

~~c) vykonává kontrolu ve věcech stavebního řádu.~~

#### § 34 — **Územní pracoviště Územní pracoviště**  `[272 Čl.I/81]` {uc=A}

**a) vykonává působnost stavebního úřadu ve věcech záměrů, u kterých nevykonává působnost Úřad, úřad rozvoje území kraje nebo jiný stavební úřad, a** {uc=A}

**b) vykonává kontrolu ve věcech stavebního řádu.** {uc=A}

#### ~~§ 34a — Obecní stavební úřad~~  `[272 Čl.I/82]` {uc=A}

> **Zrušuje se celý paragraf.**

~~(1) Obecní stavební úřad~~

~~a) vykonává působnost stavebního úřadu ve věcech záměrů, u kterých nevykonává působnost Dopravní a energetický stavební úřad, krajský stavební úřad nebo jiný stavební úřad,~~

~~b) vykonává kontrolu ve věcech stavebního řádu.~~

~~(2) Působnost stavebního úřadu ve věcech záměru bytového domu, silnice II. a III. třídy, místní komunikace, veřejně přístupné účelové komunikace, technické infrastruktury, která je součástí distribuční soustavy v elektroenergetice nebo plynárenství, sítí elektronických komunikací, staveb a zařízení pro ukládání energie, vodního díla, u něhož nevykonává působnost stavebního úřadu krajský stavební úřad, a souboru staveb, jehož jsou tyto záměry součástí, vykonává obecní stavební úřad obce s rozšířenou působností; § 37 odst. 3 se pro určení příslušnosti stavebního úřadu nepoužije.~~

#### § 35 — Jiné stavební úřady  `[272 Čl.I/83]` {uc=A}

(1) Ministerstvo obrany vykonává působnost stavebního úřadu pro území vojenských újezdů a u záměrů, které slouží nebo mají sloužit k zajišťování obrany státu5), realizovaných Ministerstvem obrany, jím zřízenou nebo založenou právnickou osobou nebo, u staveb a záměrů, které slouží nebo mají sloužit k plnění úkolů Národního úřadu pro kybernetickou a informační bezpečnost, s výjimkou vydání rámcového povolení.

(2) Ministerstvo vnitra vykonává působnost stavebního úřadu u záměrů pro bezpečnost státu, kterými se rozumí stavby sloužící k plnění úkolů Ministerstva vnitra nebo jím zřízené organizační složky státu, Policie České republiky, Policejní akademie České republiky, Hasičského záchranného sboru České republiky, Úřadu pro zahraniční styky a informace, Bezpečnostní informační služby a Národního bezpečnostního úřadu, s výjimkou staveb nebo jejich částí převážně užívaných pro účely bytové nebo rekreační. Do výkonu působnosti podle věty první nenáleží vydání rámcového povolení.

(3) Ministerstvo spravedlnosti vykonává působnost stavebního úřadu u záměrů staveb pro účely Vězeňské služby České republiky a jejích organizačních jednotek, s výjimkou vydání rámcového povolení.

(4) K přechodu stavby podle odstavců 1 až 3 do působnosti ~~krajského úřadu nebo obecního stavebního úřadu~~ **úřadů rozvoje území** se vyžaduje změna účelu užívání. {uc=A}

#### HLAVA IV

*VYMEZENÁ ÚZEMÍ*

#### § 36  `[272 Čl.I/84; 272 Čl.I/85; 272 Čl.I/86]` {uc=C}

(1) Ministerstvo obrany a Ministerstvo vnitra vymezí opatřením obecné povahy území, v němž v zájmu zajišťování obrany ~~a~~ **nebo** bezpečnosti státu {uc=C}

a) vydává **vyjádření pro stavby kategorie I nebo** závazné stanovisko **pro stavby kategorie II** pro účely povolení záměru, {uc=C}

b) vydává vyjádření k návrhu zadání územně plánovací dokumentace a stanovisko k návrhu územně plánovací dokumentace nebo její změny, dotýká-li se vymezeného území, a

c) může se vyjádřit k nezbytným úpravám u již zřízených staveb nebo uplatnit požadavky na nezbytné úpravy.

(2) Opatření obecné povahy podle odstavce 1 se vydává bez řízení o jeho návrhu a nabývá účinnosti dnem vyvěšení veřejné vyhlášky.

(3) Náklady spojené s požadavky na nezbytné úpravy podle odstavce 1 písm. c) nese ministerstvo, které je uplatnilo.

**(4) Z hlediska dopadů na zajišťování obrany nebo bezpečnosti státu podle odstavce 1 se stavby člení na** {uc=C}

**a) stavbu kategorie 0, nepředstavující zvláštní dopady,** {uc=C}

**b) stavbu kategorie I, představující mírné dopady,** {uc=C}

**c) stavbu kategorie II, představující vyšší dopady.** {uc=C}

**(5) Prováděcí právní předpis stanoví charakteristiku stavby pro její zařazení do kategorie podle odstavce 4. Charakteristikou stavby je druh stavby, případně stavebně technický parametr stavby a její umístění.** {uc=C}

#### HLAVA V

*SPOLEČNÉ USTANOVENÍ*

#### ~~§ 37~~

> **Nahrazuje se novým zněním (níže).**

~~(1) Působnost stanovená tímto zákonem krajskému úřadu, obecnímu úřadu obce s rozšířenou působností a obecnímu úřadu je přenesenou působností.~~

~~(2) V pochybnostech, který stavební úřad je příslušný ve věcech týkajících se záměru, určí příslušný stavební úřad nadřízený stavební úřad.~~

~~(3) U souboru staveb se příslušnost stavebního úřadu k vydání povolení záměru řídí příslušností k povolení záměru stavby hlavní souboru staveb. Stavební úřad je příslušný k provedení všech úkonů, postupů a vydání rozhodnutí podle tohoto zákona pro všechny stavby souboru staveb.~~

#### § 37 — **Kvalifikační požadavky**  `[272 Čl.I/87]` {uc=A}

**(1) Orgány územního plánování a stavební úřady vykonávají činnost prostřednictvím osob splňujících kvalifikační požadavky podle tohoto zákona nebo podle jiných zákonů.** {uc=A}

**(2) Kvalifikační požadavky splňuje dále fyzická osoba, která má** {uc=A}

**a) osvědčení o zvláštní odborné způsobilosti pro úředníky územních samosprávných celků pro správní činnosti v územním plánování, stavebním řádu nebo vyvlastnění nebo osvědčení o úspěšném vykonání úřednické zkoušky pro obor specializace, jehož součástí je legislativa, právní činnost, stavebnictví, bydlení, regionální rozvoj, územní plánování nebo stavební řád, a** {uc=A}

**b) vzdělání** {uc=A}

**1. vysokoškolské ve studijním programu náležejícím do oblasti architektura a urbanismus, biologie, ekologie a životní prostředí, doprava, ekonomické obory, energetika, lesnictví a dřevařství, právo, stavebnictví, vědy o zemi, strojírenství, technologie a materiály,** {uc=A}

**2. vyšší odborné nebo střední s maturitní zkouškou v oboru stavebnictví, geodézie a katastr nemovitostí, obecně právní činnost, veřejnosprávní činnost nebo doprava.** {uc=A}

**(3) Pokud při postupech podle tohoto zákona vykonává stavební úřad působnost podle jiných právních předpisů, podílejí se na této činnosti oprávněné úřední osoby, které splňují kvalifikační požadavky podle jiných právních předpisů a mají osvědčení o zvláštní odborné způsobilosti pro úředníky územních samosprávných celků pro příslušnou správní činnost nebo osvědčení o úspěšném vykonání úřednické zkoušky pro příslušný obor.** {uc=A}

**(4) Osoba nesplňující kvalifikační požadavky může vykonávat činnost, pouze pokud je zajištěno, že bude do doby splnění požadavků vykonávat tuto činnost pod odborným vedením osoby splňující kvalifikační požadavky, nejvýše však po dobu 3 let.** {uc=A}

### ČÁST TŘETÍ

*ÚZEMNÍ PLÁNOVÁNÍ*

#### HLAVA I

*CÍLE A ÚKOLY ÚZEMNÍHO PLÁNOVÁNÍ*

#### § 38 — Cíle územního plánování  `[272 Čl.I/88]` {uc=A}

(1) Cílem územního plánování je ~~soustavně a komplexně řešit funkční využití území, stanovovat zásady jeho funkčního a prostorového uspořádání a~~ **ve veřejném zájmu** vytvářet předpoklady pro **využití a** udržitelný rozvoj území spočívající ve vyváženém vztahu podmínek pro ~~příznivé životní prostředí~~ **život lidí a jejich bydlení**, ~~pro hospodářský rozvoj~~ **práci, podnikání, rekreaci** a ~~pro~~ soudržnost společenství obyvatel území**, pro příznivé životní prostředí a pro hospodářský rozvoj**, který uspokojuje potřeby současné generace, aniž by ohrožoval podmínky života generací budoucích. **Cílem územního plánování ve veřejném zájmu je také zvyšovat kvalitu a krásu vystavěného prostředí sídel, rozvíjet jejich identitu a vytvářet funkční a harmonické prostředí pro každodenní život jejich obyvatel.** {uc=A}

(2) Územní plánování ~~zajišťuje předpoklady pro udržitelný rozvoj~~ **soustavně a komplexně řeší využití** území a ~~za tímto účelem vyhodnocuje potenciál rozvoje území~~ **stanovuje zásady jeho prostorového** a ~~prognózy jeho dalšího vývoje~~ **funkčního uspořádání**. {uc=A}

(3) ~~Cílem územního~~ **Územní** plánování ~~je také zvyšovat kvalitu vystavěného~~ **rozvíjí a chrání civilizační, kulturní a přírodní hodnoty území, včetně urbanistického, architektonického a archeologického dědictví a krajiny jako podstatné složky** prostředí ~~sídel~~ **života obyvatel a základ jejich totožnosti**, ~~rozvíjet jejich identitu~~ **to vše při zajištění životních potřeb lidí, hospodářského rozvoje** a ~~vytvářet funkční~~ **zdrojů energie** a ~~harmonické prostředí pro každodenní život jejich obyvatel~~ **surovin**. {uc=A}

(4) Územní plánování ~~chrání~~ **vytváří podmínky pro co nejlepší, efektivní** a ~~rozvíjí přírodní, kulturní a civilizační hodnoty~~ **hospodárné využívání zastavitelného** území, ~~včetně urbanistického~~ **vytváření kompaktních měst krátkých vzdáleností**, ~~architektonického a archeologického dědictví, a přitom chrání krajinu jako podstatnou složku prostředí života obyvatel a základ jejich totožnosti. S ohledem na to určuje podmínky pro hospodárné využívání zastavěného~~ **ochranu nezastavitelného** území a ~~zajišťuje ochranu nezastavěného území a ochranu a~~ rozvoj ~~zelené~~ **veřejné** infrastruktury. ~~Zastavitelné plochy se vymezují s ohledem na možnosti rozvoje území a míru využití zastavěného území.~~ {uc=A}

(5) Orgány územního plánování postupem podle tohoto zákona koordinují veřejné zájmy v území a podněty na provedení změn v území, výstavbu a jiné činnosti ovlivňující rozvoj území a konkretizují ochranu veřejných zájmů vyplývajících z tohoto zákona a jiných právních předpisů.

#### § 39 — Úkoly územního plánování  `[272 Čl.I/89; 272 Čl.I/90; 272 Čl.I/91; 272 Čl.I/92; 272 Čl.I/93; 272 Čl.I/94; 272 Čl.I/95; 272 Čl.I/96; 272 Čl.I/97]` {uc=A}

Úkolem územního plánování je ve veřejném zájmu **rozvíjet a chránit území, a za tím účelem** zejména {uc=A}

a) zjišťovat**, posuzovat** a ~~posuzovat~~ **vyhodnocovat** stav území, **potenciál** jeho ~~přírodní~~ **rozvoje, prognózy jeho dalšího vývoje a jeho civilizační**, kulturní a ~~civilizační~~ **přírodní** hodnoty, {uc=A}

b) stanovovat s ohledem na **jeho potenciál,** podmínky a hodnoty území koncepci využití a rozvoje území, včetně dlouhodobé urbanistické koncepce sídel, rozvoje **bydlení, hospodářství a** veřejné infrastruktury **s preferencí co nejlepšího** a **nejpestřejšího využití zastavitelného území,** ochrany volné krajiny a ~~stanovení podmínek~~ **zlepšování** prostupnosti území, {uc=A}

c) prověřovat a posuzovat potřebu změn v území, jejich přínosy, problémy a rizika s ohledem na **potenciál jeho rozvoje,** ochranu veřejných zájmů a hospodárné využívání území, {uc=A}

d) stanovovat urbanistické, architektonické, estetické a funkční požadavky na využívání a prostorové uspořádání území a na jeho změny, zejména na míru využití území, umístění, uspořádání a řešení staveb a kvalitu veřejných prostranství,

e) vytvářet předpoklady pro **efektivní** hospodárné využívání území, zejména důsledným využíváním ~~zastavěného~~ **zastavitelného** území ~~sídel prostřednictvím cílené revitalizace~~ **a revitalizací nevyužitých,** znehodnocených nebo zanedbaných ploch, {uc=A}

f) s ohledem na charakter území a kvalitu vystavěného prostředí ~~vyhodnocovat a, je-li to účelné,~~ vymezovat vhodné plochy pro výrobu**, skladování, distribuci a nakládání s odpady**; plochy pro výrobu**, skladování a distribuci** elektřiny, plynu a tepla včetně ploch pro jejich výrobu z obnovitelných zdrojů vymezovat rovněž s ohledem na cíle energetické koncepce67) a klimatické cíle státu, {uc=A}

g) stanovovat podmínky pro obnovu a rozvoj sídelní struktury, pro kvalitní bydlení**, příležitosti pro práci a podnikání** a pro rozvoj rekreace a cestovního ruchu, {uc=A}

~~h) prověřovat a posuzovat potřebu změn v území, zejména pak pro umístění a uspořádání staveb s ohledem na stávající charakter a hodnoty v území a na využitelnost navazujícího území, tyto změny navrhovat a stanovovat podmínky pro jejich provedení,~~ {uc=A}

~~i)~~ **h)** stanovovat pořadí provádění změn v území, {uc=A}

~~j)~~ **i)** koordinovat veřejné zájmy a podněty na provedení změn v území, {uc=A}

~~k)~~ **j)** vymezovat veřejně prospěšné stavby a veřejně prospěšná opatření, {uc=A}

~~l)~~ **k)** vytvářet a stanovovat podmínky pro snižování nebezpečí v území, zejména před účinky povodní, sucha, erozních jevů a extrémních teplot, {uc=A}

~~m)~~ **l)** uplatňovat požadavky na adaptaci sídel a uspořádání krajiny vyplývající ze změny klimatu, {uc=A}

~~n)~~ **m)** prověřovat a vytvářet v území podmínky pro hospodárné vynakládání prostředků z veřejných rozpočtů na změny v území, {uc=A}

~~o)~~ **n)** vytvářet v území podmínky pro zajištění obrany a bezpečnosti státu a civilní ochrany, {uc=A}

~~p)~~ **o)** vytvářet v území podmínky pro odstraňování následků náhlých hospodářských změn zejména prověřováním a případným vymezováním zastavitelných ploch nebo ~~transformačních~~ ploch **změn**, {uc=A}

~~q)~~ **p)** určovat nutné asanační a rekultivační zásahy do území, {uc=A}

~~r)~~ **q)** ~~regulovat~~ **stanovovat** rozsah ploch pro využívání přírodních a nerostných zdrojů, vytvářet a stanovovat podmínky pro jejich využití **s přihlédnutím k jedinečnosti a nepřemístitelnosti nerostných zdrojů a jejich významu pro surovinovou bezpečnost a soběstačnost**, {uc=A}

~~s)~~ **r)** vytvářet podmínky pro ochranu území podle jiných právních předpisů před významnými negativními vlivy záměrů na území a navrhovat kompenzační opatření, pokud tak stanoví jiný právní předpis. {uc=A}

#### § 39a — **Politika architektury a stavební kultury**  `[272 Čl.I/98]` {uc=A}

**(1) Politika architektury a stavební kultury je strategickým dokumentem s celostátní působností, který určuje vizi, cíle a opatření k dosažení kvality vystavěného prostředí.** {uc=A}

**(2) Politika architektury a stavební kultury rozvíjí cíle a úkoly územního plánování a je podkladem pro zpracování politiky územního rozvoje. Politika architektury a stavební kultury je kritériem pro posuzování hodnot chráněných stavebním zákonem.** {uc=A}

**(3) Úřad zajistí zveřejnění usnesení vlády, kterým byla schválena politika architektury a stavební kultury, ve Věstníku vlády pro orgány krajů a orgány obcí a v téže lhůtě zveřejní politiku architektury a stavební kultury způsobem umožňujícím dálkový přístup.** {uc=A}

**(4) Úřad nejpozději do 6 let od schválení politiky architektury a stavební kultury a poté nejméně jednou za 6 let předloží vládě zprávu o plnění politiky architektury a stavební kultury. Vláda může na jejím základě uložit Úřadu pořídit aktualizaci nebo novou politiku architektury a stavební kultury.** {uc=A}

#### § 40 — Vyhodnocení vlivů na udržitelný rozvoj území

(1) Úkolem územního plánování je také posoudit vlivy politiky územního rozvoje, územního rozvojového plánu, zásad územního rozvoje nebo územního plánu na udržitelný rozvoj území. Za tímto účelem se zpracovává vyhodnocení vlivů na udržitelný rozvoj území (dále jen „vyhodnocení vlivů“).

(2) Vyhodnocení vlivů se zpracovává k návrhu politiky územního rozvoje, územního rozvojového plánu, zásad územního rozvoje nebo územního plánu, je-li vyžadováno posouzení z hlediska vlivů na životní prostředí.

(3) Součástí vyhodnocení vlivů je vyhodnocení vlivů na

a) hospodářský rozvoj,

b) soudržnost společenství obyvatel území a

c) životní prostředí.

(4) Součástí vyhodnocení vlivů na životní prostředí je i posouzení vlivů na předmět ochrany a celistvost evropsky významné lokality nebo ptačí oblasti, je-li to vyžadováno podle jiného právního předpisu.

(5) Ve vyhodnocení vlivů se určí, popíší a posoudí možné významné vlivy podle odstavce 3 vyplývající z politiky územního rozvoje, územního rozvojového plánu, zásad územního rozvoje nebo územního plánu a rozumná náhradní řešení s přihlédnutím k cílům posuzovaných dokumentů. Vyhodnocení vlivů politiky územního rozvoje, nadřazené územně plánovací dokumentace nesmí obsahovat podrobnosti, které náleží vyhodnocení vlivů navazující územně plánovací dokumentace.

(6) Obsah a struktura vyhodnocení vlivů a vyhodnocení vlivů na životní prostředí jsou stanoveny v příloze č. 4 k tomuto zákonu. Náležitosti vyhodnocení vlivů na předmět ochrany nebo celistvost evropsky významné lokality nebo ptačí oblasti jsou stanoveny jiným právním předpisem.

#### § 41 — Charakter území  `[272 Čl.I/99; 272 Čl.I/100]` {uc=A}

Charakter území se určuje zejména podle ~~funkčního využití,~~ **stávající nebo plánované** struktury a typu zástavby, uspořádání veřejných prostranství, dalších prvků prostorového uspořádání a urbanistických, architektonických, estetických, kulturních a přírodních hodnot území, včetně jejich **využití a** vzájemných vztahů a vazeb, a to především vymezením v územně plánovací dokumentaci. {uc=A}

**(1) Při posuzování souladu s charakterem území se zohledňuje veřejný zájem na zvyšování kvality vystavěného prostředí, architektury a stavební kultury.** {uc=A}

#### HLAVA II

*OBECNÁ A SPOLEČNÁ USTANOVENÍ*

##### Díl 1

*Obecná ustanovení*

#### § 42 — Oprávněný investor  `[272 Čl.I/61; 272 Čl.I/101; 272 Čl.I/102; 272 Čl.I/103]` {uc=A}

(1) Oprávněným investorem se v tomto zákoně rozumí vlastník, správce nebo provozovatel veřejné dopravní nebo veřejné technické infrastruktury **a organizace podle horního zákona**. {uc=A}

(2) Oprávněný investor může požadovat, aby byl o úkonech orgánu územního plánování při projednání návrhů územně plánovací dokumentace a územních opatření vyrozuměn jednotlivě. Za tímto účelem se zřizuje seznam oprávněných investorů, který vede a spravuje ~~ministerstvo~~ **Úřad**. {uc=A}

(3) ~~Ministerstvo~~ **Úřad** zaznamená oprávněného investora do seznamu oprávněných investorů na základě žádosti. V žádosti oprávněný investor kromě obecných náležitostí podle správního řádu uvede {uc=A}

a) seznam obcí, popřípadě krajů, kterých se vyrozumění týká, a

b) doklad prokazující skutečnost, že je oprávněným investorem s územní působností na území uvedených obcí, popřípadě krajů.

(4) Je-li žádost podle odstavce 3 úplná, zaznamená ~~ministerstvo~~ **Úřad** oprávněného investora do 14 dnů ode dne obdržení žádosti do seznamu oprávněných investorů. Seznam oprávněných investorů zveřejňuje ~~ministerstvo~~ **Úřad** způsobem umožňujícím dálkový přístup ~~na~~ **v** národním geoportálu územního plánování. {uc=A}

(5) ~~Záznam v seznamu oprávněných investorů je veden po dobu 5 let ode dne jeho zveřejnění.~~ Žádost podle odstavce 3 lze podávat opakovaně. Změní-li se údaje poskytnuté oprávněným investorem podle odstavce 3, je oprávněný investor povinen o této skutečnosti neprodleně vyrozumět ~~ministerstvo~~ **Úřad**, ~~které~~ **který** údaje v seznamu oprávněných investorů upraví. {uc=A}

#### ~~§ 43 — Zveřejňování a ukládání dokumentů~~

> **Nahrazuje se novým zněním (níže).**

~~(1) Pořizovatel musí veřejnosti a dotčeným orgánům zajistit možnost seznámit se s návrhy zadání územně plánovací dokumentace, územně plánovací dokumentace nebo zprávy o jejím uplatňování, územních opatření a vymezení zastavěného území ode dne vyvěšení návrhu veřejnou vyhláškou.~~

~~(2) Příslušný pořizovatel zveřejňuje zadání územně plánovací dokumentace, zprávu o uplatňování územně plánovací dokumentace, územně plánovací dokumentaci, zastavěné území, územní studii a územní opatření a jejich návrhy v národním geoportálu územního plánování.~~

~~(3) Politiku územního rozvoje, včetně dokladů o jejím pořizování, územní rozvojový plán a územní opatření, které vydala vláda, včetně spisu k územnímu rozvojovému plánu a územnímu opatření o stavební uzávěře, ukládá ministerstvo.~~

~~(4) Zásady územního rozvoje, územní plán, regulační plán a územní opatření, včetně spisu, ukládá pořizovatel u kraje nebo obce, pro něž byly pořízeny.~~

~~(5) Vymezení zastavěného území, včetně spisu, a územně plánovací podklady, včetně dokladů o jejich pořizování, ukládá příslušný pořizovatel.~~

#### § 43 — **Zveřejňování a ukládání dokumentů**  `[272 Čl.I/105]` {uc=A}

**(1) Orgány územního plánování informují veřejnost a dotčené orgány o své činnosti, zejména o pořizování nástrojů územního plánování podle tohoto zákona; ustanovení části šesté správního řádu o zveřejňování a doručování se nepoužijí. Osobám, které nejsou schopny využít národní geoportál územního plánování, orgány územního plánování umožní nahlížet do zveřejňovaných informací a činit si z nich výpisy a kopie.** {uc=A}

**(2) Příslušný pořizovatel zveřejňuje zadání územně plánovací dokumentace, územně plánovací dokumentaci a její úplné znění, zastavitelné území, územní studii a územní opatření a jejich návrhy v národním geoportálu územního plánování.** {uc=A}

##### ~~Díl 2~~

*~~Kvalifikační požadavky pro výkon územně plánovací činnosti~~*

#### ~~§ 44 — Kvalifikační požadavky~~  `[272 Čl.I/106]` {uc=A}

> **Zrušuje se celý paragraf.**

~~(1) Úřady územního plánování vykonávají územně plánovací činnost podle § 23 a 25 prostřednictvím úředníků6) splňujících kvalifikační požadavky pro výkon územně plánovací činnosti.~~

~~(2) Kvalifikační požadavky pro výkon územně plánovací činnosti splňuje fyzická osoba, která~~

~~a) má osvědčení zvláštní odborné způsobilosti pro správní činnost územní plánování podle jiného právního předpisu7), nebo osvědčení o úspěšném vykonání úřednické zkoušky pro obor státní služby, jehož součástí je územní plánování,~~

~~b) splňuje kvalifikační požadavky vzdělání podle tohoto zákona a~~

~~c) splňuje kvalifikační požadavky praxe podle tohoto zákona.~~

~~(3) Ustanovení jiného právního předpisu o vydávání osvědčení o uznání rovnocennosti vzdělání8) se pro podmínky podle odstavce 2 nepoužije.~~

~~(4) Kvalifikační požadavky vzdělání a praxe podle odstavce 2 písm. b) a c) splňuje~~

~~a) autorizovaný architekt, kterému byla udělena autorizace pro obor územní plánování nebo bez specifikace oboru podle autorizačního zákona, nebo autorizovaný inženýr pro obor městské inženýrství,~~

~~b) fyzická osoba, která má vysokoškolské vzdělání uznané pro autorizaci v oboru územní plánování a nejméně 18 měsíců praxe při výkonu územně plánovací činnosti ve veřejné správě, nebo~~

~~c) fyzická osoba, která má vysokoškolské vzdělání ve studijním programu náležejícím do oblasti vzdělávání architektura a urbanismus, stavebnictví nebo geografie a nejméně 24 měsíců praxe při výkonu územně plánovací činnosti ve veřejné správě.~~

~~(5) Úředník nesplňující kvalifikační požadavky může vykonávat územně plánovací činnost úřadu územního plánování, pokud je zajištěno, že bude do doby splnění uvedených požadavků vykonávat tuto činnost pod odborným vedením úředníka splňujícího kvalifikační požadavky pro výkon územně plánovací činnosti, nejvýše však po dobu 3 let.~~

#### ~~§ 45 — Výjimka z kvalifikačních požadavků~~  `[272 Čl.I/106]` {uc=A}

> **Zrušuje se celý paragraf.**

~~(1) Výjimku z kvalifikačního požadavku vzdělání ministerstvo udělí na základě žádosti úředníka územního samosprávného celku, který vykonává územně plánovací činnost v souladu s právními předpisy, splňuje kvalifikační požadavky praxe a má osvědčení zvláštní odborné způsobilosti podle jiného právního předpisu7).~~

~~(2) Při posuzování žádosti ministerstvo vychází z kvality úkonů žadatele při pořizování územně plánovací dokumentace a územně plánovacích podkladů, na nichž se prokazatelně osobně podílel, a z příloh žádosti uvedených v odstavci 3 písm. b) a c).~~

~~(3) Součástí žádosti o udělení výjimky z kvalifikačního požadavku vzdělání je~~

~~a) doklad o praxi ve veřejné správě při pořizování územně plánovací dokumentace nebo územně plánovacích podkladů v délce nejméně 18 měsíců, včetně výčtu územně plánovacích dokumentací nebo územně plánovacích podkladů, na jejichž pořízení se žadatel osobně podílel, s uvedením rozsahu svého podílu,~~

~~b) kopie návrhu zadání nebo zprávy o uplatňování územně plánovací dokumentace a úkonů pořizovatele při pořizování návrhu územně plánovací dokumentace nebo její změny, anebo stanoviska krajského úřadu k návrhu územního plánu, na kterých se žadatel osobně podílel,~~

~~c) posudek o pracovní činnosti9) nebo jiný doklad prokazující kvalitu práce žadatele,~~

~~d) kopie osvědčení zvláštní odborné způsobilosti pro správní činnost územní plánování, nebo osvědčení o úspěšném vykonání úřednické zkoušky pro obor státní služby, jehož součástí je územní plánování.~~

##### Díl 2

*Pořizovatelská činnost*

##### Oddíl 1

*Pořizovatel a určený zastupitel*

#### ~~§ 46 — Pořizovatel~~

> **Nahrazuje se novým zněním (níže).**

~~(1) Pořizovatelem se v tomto zákoně rozumí~~

~~a) ministerstvo,~~

~~b) Ministerstvo obrany,~~

~~c) úřad územního plánování a~~

~~d) obecní úřad na základě potvrzení krajského úřadu o zajištění splnění kvalifikačních požadavků pro výkon územně plánovací činnosti.~~

~~(2) Pořizovatel vykonává územně plánovací činnost prostřednictvím~~

~~a) státního zaměstnance, který byl přijat do služebního poměru a zařazen na služební místo nebo jmenován na služební místo představeného k výkonu v oboru státní služby, jehož součástí je územní plánování,~~

~~b) úředníka územního samosprávného celku splňujícího kvalifikační požadavky pro výkon územně plánovací činnosti, nebyla-li mu z nich udělena výjimka, nebo~~

~~c) osoby splňující kvalifikační požadavky pro výkon územně plánovací činnosti, které bylo uděleno oprávnění k výkonu územně plánovací činnosti ministerstvem (dále jen „zástupce pořizovatele“), jde-li o pořizovatele podle odstavce 1 písm. d).~~

~~(3) Výkon územně plánovací činnosti osobami podle odstavce 2 a činnost projektanta jsou vzájemně neslučitelné.~~

#### § 46 — **Pořizovatel**  `[272 Čl.I/107]` {uc=A}

**(1) Pořizovatelem se v tomto zákoně rozumí orgán územního plánování.** {uc=A}

**(2) Pořizovatel vykonává odbornou územně plánovací činnost prostřednictvím** {uc=A}

**a) státního zaměstnance v oboru specializace, jehož součástí je územní plánování nebo regionální rozvoj,** {uc=A}

**b) úředníka územního samosprávného celku nebo zaměstnance jím zřízené právnické osoby nebo společenství obcí s osvědčením o zvláštní odborné způsobilosti pro správní činnost územní plánování podle jiného právního předpisu, nebo** {uc=A}

**c) osoby splňující kvalifikační požadavky pro výkon územně plánovací činnosti, které bylo uděleno oprávnění k výkonu územně plánovací činnosti Úřadem (dále jen „zástupce pořizovatele“).** {uc=A}

#### ~~§ 47 — Územně plánovací činnost vykonávaná obecním úřadem~~

> **Nahrazuje se novým zněním (níže).**

~~(1) Obecní úřad může vykonávat územně plánovací činnost podle § 26 pouze na základě potvrzení vydaného krajským úřadem o tom, že zajistil výkon územně plánovací činnosti prostřednictvím osoby, která splňuje kvalifikační požadavky pro výkon územně plánovací činnosti.~~

~~(2) V žádosti o vydání potvrzení obecní úřad uvede~~

~~a) své identifikační údaje,~~

~~b) informaci o tom, jakou územně plánovací dokumentaci, popřípadě územní studii hodlá pořizovat,~~

~~c) doklad, že bude vykonávat územně plánovací činnost prostřednictvím osoby splňující požadavky pro výkon územně plánovací činnosti.~~

~~(3) Krajský úřad do 30 dnů od obdržení žádosti podle odstavce 2 přezkoumá, zda obecní úřad bude územně plánovací činnost vykonávat prostřednictvím osoby splňující požadavky pro výkon územně plánovací činnosti, a vydá obecnímu úřadu potvrzení nebo mu sdělí, že potvrzení nelze vydat. Součástí potvrzení je stanovení rozsahu výkonu územně plánovací činnosti obecním úřadem. Potvrzení zašle krajský úřad současně ministerstvu a úřadu územního plánování.~~

~~(4) Ministerstvo zajistí obecnímu úřadu přístup do národního geoportálu územního plánování v rozsahu potvrzení podle odstavce 3.~~

#### § 47 — **Pořizování jiným pořizovatelem**  `[272 Čl.I/107]` {uc=A}

**(1) Obec může uzavřít veřejnoprávní smlouvu s jinou obcí, krajem nebo společenstvím obcí, jehož je členem, o výkonu odborných činností pořizovatele nástrojů územního plánování.** {uc=A}

**(2) Úřad rozvoje území kraje nebo jeho územní pracoviště pořídí bezplatně na základě veřejnoprávní smlouvy územní plán a územní opatření pro obec, pokud jej o to obec požádá.** {uc=A}

#### ~~§ 48 — Překážky výkonu územně plánovací činnosti~~  `[272 Čl.I/108]` {uc=A}

> **Zrušuje se celý paragraf.**

~~(1) Nemůže-li obecní úřad v průběhu pořizování územně plánovací dokumentace nebo územní studie zajistit výkon územně plánovací činnosti prostřednictvím osoby splňující kvalifikační požadavky pro výkon územně plánovací činnosti, pořizování neprodleně přeruší a sdělí tuto skutečnost ministerstvu a krajskému úřadu. Krajský úřad na základě oznámení podle věty první zruší obecnímu úřadu potvrzení podle § 47 odst. 3.~~

~~(2) Ve sdělení podle odstavce 1 obecní úřad uvede, zda~~

~~a) předloží zastupitelstvu návrh na ukončení pořizování,~~

~~b) požaduje, aby pořizování dokončil úřad územního plánování obce s rozšířenou působností, nebo~~

~~c) učiní kroky, aby zajistil výkon územně plánovací činnosti prostřednictvím osoby, která splňuje kvalifikační požadavky pro výkon územně plánovací činnosti.~~

~~(3) Požaduje-li obec, aby pořizování dokončil úřad územního plánování obce s rozšířenou působností, předá krajský úřad tuto žádost příslušnému úřadu územního plánování. Požadavek podle věty první se považuje za žádost obce podle § 25 písm. b).~~

~~(4) Je-li obsahem sdělení údaj podle odstavce 2 písm. c), postupuje se podle § 47 obdobně.~~

#### § 49 — Určený zastupitel  `[272 Čl.I/109; 272 Čl.I/110; 272 Čl.I/111; 272 Čl.I/112]` {uc=A}

(1) Zastupitelstvo obce ~~a zastupitelstvo kraje~~**, pro kterou pořizuje územní plán, regulační plán nebo územní studii jiný pořizovatel,** určí člena zastupitelstva, který při pořizování ~~územně plánovací dokumentace obce nebo kraje~~ spolupracuje s pořizovatelem (dále jen „určený zastupitel“). {uc=A}

(2) ~~Pořizovatel~~ **Jiný pořizovatel** při pořizování územně plánovací dokumentace postupuje v součinnosti s určeným zastupitelem. {uc=A}

(3) Nedojde-li mezi **jiným** pořizovatelem a určeným zastupitelem ke shodě, je pro pokračování v pořizování územně plánovací dokumentace z hlediska souladu návrhu s nadřazenou územně plánovací dokumentací, s právními předpisy a se stanovisky nadřízeného orgánu územního plánování a dotčených orgánů rozhodující řešení navržené pořizovatelem, v ostatních případech řešení navržené určeným zastupitelem. {uc=A}

~~(4) Je-li pro obec pořizována úřadem územního plánování územní studie, která je podmínkou pro rozhodování v území podle § 81 odst. 4, může zastupitelstvo určit zastupitele, který při jejím pořizování spolupracuje s pořizovatelem; ustanovení o určeném zastupiteli se použijí přiměřeně.~~ {uc=A}

##### Oddíl 2

*Zástupce pořizovatele*

#### § 50 — Obecná ustanovení  `[272 Čl.I/61; 272 Čl.I/102; 272 Čl.I/113; 272 Čl.I/114; 272 Čl.I/115]` {uc=A}

(1) ~~Ministerstvo~~ **Úřad** udělí oprávnění k výkonu územně plánovací činnosti osobě, která {uc=A}

a) je plně svéprávná,

b) má osvědčení **o** zvláštní odborné způsobilosti pro správní činnost v územním plánování, nebo osvědčení o úspěšném vykonání úřednické zkoušky pro obor ~~státní služby~~ **specializace**, jehož součástí je územní plánování, {uc=A}

c) splňuje kvalifikační požadavky ~~vzdělání a praxe~~ podle § ~~44 odst. 4~~ **37**, {uc=A}

d) je bezúhonná,

e) vykonávala územně plánovací činnost **ve veřejné správě po dobu nejméně 3 let** v souladu s právními předpisy; při posuzování ~~ministerstvo~~ **Úřad** vychází z kvality úkonů žadatele při pořizování územně plánovací dokumentace, na níž se osobně podílel. {uc=A}

(2) Seznam zástupců pořizovatele vede ~~ministerstvo~~ **Úřad** a zveřejňuje jej způsobem umožňujícím dálkový přístup v národním geoportálu územního plánování. {uc=A}

#### § 51 — Bezúhonnost  `[272 Čl.I/116; 272 Čl.I/117]` {uc=A}

~~(1)~~ Za bezúhonnou se pro účely udělení oprávnění k výkonu územně plánovací činnosti nepovažuje osoba, {uc=A}

a) která byla pravomocně odsouzena za trestný čin spáchaný úmyslně, jestliže byl tento trestný čin spáchán v souvislosti s výkonem územně plánovací činnosti, nehledí-li se na ni, jako by nebyla odsouzena, nebo

b) které bylo ~~Českou komorou architektů~~ pravomocně uloženo disciplinární opatření ve formě pozastavení nebo odnětí autorizace. {uc=A}

~~(2) Osoba, která není státním občanem České republiky a nemá na území České republiky povolen trvalý pobyt, dokládá bezúhonnost výpisem z evidence obdobné Rejstříku trestů vydaným státem, jehož je občanem, nebo státem posledního pobytu. Osoba, která je nebo byla státním občanem jiného členského státu Evropské unie nebo má nebo měla adresu bydliště v jiném členském státě Evropské unie, může místo výpisu z evidence obdobné Rejstříku trestů doložit bezúhonnost výpisem z Rejstříku trestů s přílohou obsahující informace, které jsou zapsané v evidenci trestů jiného členského státu Evropské unie.~~ {uc=A}

~~(3) Pro ověření bezúhonnosti si ministerstvo vyžádá výpis z Rejstříku trestů, včetně přílohy obsahující cizozemská odsouzení. Žádost o vydání výpisu z Rejstříku trestů a výpis z Rejstříku trestů se předávají v elektronické podobě, a to způsobem umožňujícím dálkový přístup.~~ {uc=A}

~~(4) Česká komora architektů bezodkladně uvědomí ministerstvo o pravomocném uložení disciplinárního opatření spočívajícího v pozastavení nebo odnětí autorizace zástupce pořizovatele.~~ {uc=A}

#### § 52 — Žádost o udělení oprávnění  `[272 Čl.I/118; 272 Čl.I/119; 272 Čl.I/120]` {uc=A}

~~(1)~~ Součástí žádosti o udělení oprávnění k výkonu územně plánovací činnosti je {uc=A}

a) doklad o dosaženém vzdělání ~~podle § 44 odst. 3~~, ~~nebo doklad o udělení výjimky podle § 45 odst. 1,~~ {uc=A}

b) doklad o praxi ve veřejné správě při pořizování územně plánovací dokumentace,

c) kopie osvědčení **o** zvláštní odborné způsobilosti v územním plánování, nebo kopie osvědčení o úspěšném vykonání úřednické zkoušky podle zákona o státní službě, {uc=A}

d) výčet žadatelem pořizované územně plánovací dokumentace, na níž se osobně podílel, s uvedením rozsahu jeho podílu.

~~(2) Ministerstvo může požádat krajský úřad o vyjádření, zda v posledních 3 letech před podáním žádosti u územně plánovací dokumentace, u které vykonával žadatel činnost pořizovatele, neučinil opatření při kontrole ve věcech územního plánování.~~ {uc=A}

#### § 53 — Udělení a zánik oprávnění  `[272 Čl.I/102; 272 Čl.I/121; 272 Čl.I/122; 272 Čl.I/123; 272 Čl.I/124; 272 Čl.I/125]` {uc=A}

~~(1) Oprávnění k výkonu územně plánovací činnosti se uděluje na dobu 5 let. Tato doba se na žádost zástupce pořizovatele prodlouží o 5 let, a to i opakovaně, splňuje-li podmínky § 50 odst. 1.~~ {uc=A}

~~(2)~~ **(1)** Oprávnění k výkonu územně plánovací činnosti zaniká {uc=A}

a) dnem doručení písemného prohlášení zástupce pořizovatele o ukončení činnosti ~~ministrovi pro místní rozvoj~~ **Úřadu**, {uc=A}

~~b) uplynutím doby, na kterou bylo uděleno,~~ {uc=A}

~~c)~~ **b)** dnem nabytí právní moci rozhodnutí soudu, kterým byla omezena svéprávnost zástupce pořizovatele, {uc=A}

~~d)~~ **c)** ztrátou bezúhonnosti, nebo {uc=A}

~~e)~~ **d)** zrušením oprávnění podle odstavce ~~3~~ **2**. {uc=A}

~~(3)~~ **(2)** ~~Ministerstvo~~ **Úřad** zruší oprávnění k výkonu územně plánovací činnosti, pokud zástupce pořizovatele {uc=A}

a) poruší opakovaně nebo hrubým způsobem právní předpisy při výkonu územně plánovací činnosti, nebo

b) přestal splňovat podmínky pro výkon funkce.

~~(4)~~ **(3)** Osoba, které zaniklo oprávnění k výkonu územně plánovací činnosti, o této skutečnosti bezodkladně informuje ~~obecní úřad~~ **pořizovatele**, pro ~~který~~ **kterého** tuto činnost vykonává, a předloží mu návrh dalšího postupu pořizování územně plánovací dokumentace nebo územní studie. {uc=A}

##### Díl 3

*Dotčené orgány v procesu územního plánování*

#### § 54 — Stanoviska a vyjádření dotčených orgánů  `[272 Čl.I/126; 272 Čl.I/127; 272 Čl.I/128; 272 Čl.I/129]` {uc=A}

**(1) Dotčené orgány chrání veřejné zájmy podle jiných zákonů80), jsou-li tyto zájmy dotčeny, způsobem podle § 2 a 3 a při respektování cílů a úkolů územního plánování a s přihlédnutím k zájmu územních samosprávných celků a státu na rozvoji svého území. __________** {uc=A}

~~(1)~~ **(2)** Dotčené orgány uplatňují stanoviska, která nejsou rozhodnutím ve správním řízení a jejichž obsah je **z hlediska souladu s dotčenými veřejnými zájmy chráněnými jinými zákony** závazný pro pořizování územně plánovací dokumentace, územních opatření nebo vymezení ~~zastavěného~~ **zastavitelného** území, není-li při řešení rozporů **dohodnuto nebo** stanoveno jinak. Ustanovení § 149 odst. 2 správního řádu se použije pro obsah stanovisek obdobně. **Pořizovatel nepřihlíží k vyjádřením a stanoviskům dotčených orgánů ve věcech, o nichž bylo rozhodnuto při schválení politiky územního rozvoje a vydání nadřazené územně plánovací dokumentace. Pořizovatel se může od stanoviska dotčeného orgánu odchýlit v části, ve které není stanovisko odůvodněno nebo překračuje působnost dotčeného orgánu nebo měřítko či podrobnost pořizované územně plánovací dokumentace.** {uc=A}

~~(2)~~ **(3)** Dotčené orgány uplatňují vyjádření k návrhu zadání územně plánovací dokumentace, vyhodnocení vlivů~~, návrhu zprávy o uplatňování územně plánovací dokumentace a návrhu zadání změny územně plánovací dokumentace~~. {uc=A}

~~(3)~~ **(4)** Obsahuje-li posuzovaný návrh varianty řešení, dotčený orgán posuzuje každou variantu samostatně. {uc=A}

~~(4)~~ **(5)** Jsou-li v rámci procesu pořizování nástrojů územního plánování stanoveny lhůty pro uplatnění stanovisek nebo vyjádření a dotčený orgán v této lhůtě stanovisko nebo vyjádření neuplatní, k později uplatněnému stanovisku nebo vyjádření se nepřihlíží. {uc=A}

#### ~~§ 55 — Řešení rozporů~~

> **Nahrazuje se novým zněním (níže).**

~~Orgány územního plánování projednávají protichůdná stanoviska dotčených orgánů. Dojde-li k rozporu mezi pořizovatelem a dotčenými orgány, jakož i mezi dotčenými orgány navzájem, postupuje se podle správního řádu.~~

#### § 55 — **Řešení rozporů**  `[272 Čl.I/130]` {uc=A}

**(1) Pořizovatel projednává protichůdná stanoviska dotčených orgánů a zájmy obcí, krajů a státu a oprávněných investorů, koordinuje je a řeší případné rozpory podle zásad uvedených v § 1a a § 18 odst. 1 a 2.** {uc=A}

**(2) Dojde-li k rozporu mezi dotčenými orgány nebo mezi obcí nebo krajem a dotčeným orgánem, projedná jej pořizovatel se stranami tohoto rozporu v dohodovacím řízení, jež je zahájeno dnem, kdy oznámení pořizovatele o jeho zahájení spolu s návrhem řešení dojde stranám rozporu. Nezúčastní-li se dotčený orgán bez důvodné omluvy dohodovacího řízení, které pořizovatel svolal alespoň 5 pracovních dnů před jeho konáním, platí, že od rozporu ustoupil.** {uc=A}

**(3) Nedojde-li k dohodě do 30 dnů od zahájení dohodovacího řízení, podá pořizovatel návrh na rozhodnutí o rozporu Úřadu spolu s návrhem řešení rozporu. Je-li pořizovatelem Ministerstvo obrany nebo Úřad, podá pořizovatel návrh na rozhodnutí o rozporu vládě spolu s návrhem řešení rozporu.** {uc=A}

**(4) Před rozhodnutím o rozporu Úřad vyzve příslušný ústřední orgán státní správy k vyjádření ve lhůtě 15 dnů. Před rozhodnutím o rozporu zašle Úřad vyjádření ústředního orgánu státní správy podle věty první stranám rozporu a může též nařídit společné jednání podle** {uc=A}

**§ 18 odst. 2.** {uc=A}

**(5) Úřad rozhodne o rozporu bez zbytečného odkladu, nejpozději do 60 dnů od doručení návrhu pořizovatele. Nerozhodne-li Úřad ve stanovené lhůtě, může pořizovatel předložit zprávu o průběhu dohodovacího řízení spolu s návrhem řešení rozporu vládě, která o rozporu rozhodne bezodkladně.** {uc=A}

**(6) O rozporu mezi obcí nebo krajem a státním orgánem rozhodne Úřad rozhodnutím podle části druhé správního řádu; proti rozhodnutí Úřadu není přípustný rozklad.** {uc=A}

**(7) Rozhodnutí o rozporu zveřejní Úřad v národním geoportálu územního plánování.** {uc=A}

##### Díl 4

*Společná ustanovení*

#### § 56 — Územní rezerva  `[272 Čl.I/131]` {uc=A}

(1) Územní rezervou se v tomto zákoně rozumí plocha nebo koridor, které jsou vymezené v územně plánovací dokumentaci pro využití, jehož potřebu a plošné nároky je třeba následně prověřit.

(2) Při vymezení územní rezervy se v územně plánovací dokumentaci stanoví její uvažované budoucí využití, popřípadě podmínky pro jeho prověření.

(3) Změnit územní rezervu na plochu nebo koridor umožňující stanovené využití lze jen změnou územně plánovací dokumentace.

(4) Územní rezerva se neposuzuje z hlediska vlivů na udržitelný rozvoj území, na životní prostředí, na předmět ochrany nebo celistvost evropsky významné lokality nebo ptačí oblasti ani z hlediska předpokládaných důsledků navrhovaného řešení na zemědělský půdní fond a pozemky určené k plnění funkce lesa; uvedené vlivy se posuzují až při změně územně plánovací dokumentace, která má umožnit stanovené využití.

(5) V územní rezervě jsou zakázány změny v území, které by mohly stanovené využití podstatně ztížit nebo znemožnit.

~~(6) Účelnost dalšího trvání vymezení územní rezervy pořizovatel vždy vyhodnotí podle § 107 odst. 2 písm. a).~~ {uc=A}

##### Úplné znění a koordinační výkres

#### § 57  `[272 Čl.I/69; 272 Čl.I/133]` {uc=A}

(1) Úplným zněním územně plánovací dokumentace nebo vymezení ~~zastavěného~~ **zastavitelného** území (dále jen „úplné znění“) se rozumí účinné znění územně plánovací dokumentace nebo vymezení ~~zastavěného~~ **zastavitelného** území se zapracovanými pozdějšími změnami. Úplné znění obsahuje textovou a grafickou část. {uc=A}

(2) Zpracování úplného znění zajistí pořizovatel změny územně plánovací dokumentace nebo vymezení ~~zastavěného~~ **zastavitelného** území. {uc=A}

~~(3) Koordinačním výkresem se rozumí výkres zahrnující navržené řešení, neměněný současný stav a důležitá omezení v území, zejména limity využití území.~~ {uc=A}

~~(4) Úplné znění se po vydání změny územně plánovací dokumentace opatří záznamem o účinnosti, který obsahuje~~ {uc=A}

~~a) označení správního orgánu, který poslední změnu vydal,~~ {uc=A}

~~b) pořadové číslo poslední změny,~~ {uc=A}

~~c) datum nabytí účinnosti poslední změny,~~ {uc=A}

~~d) jméno, příjmení, funkci a podpis oprávněné úřední osoby pořizovatele a otisk úředního razítka.~~ {uc=A}

#### § 58

(1) Dojde-li při vyhotovení úplného znění k pochybení, pořizovatel chybu bezodkladně odstraní nebo zajistí její odstranění; případné vady při vyhotovení úplného znění nemají vliv na účinnost změny územně plánovací dokumentace.

(2) Za padělání nebo pozměňování úplného znění se nepovažuje změna způsobu grafického vyjádření.

#### ~~§ 59 — Jednotný standard~~

> **Nahrazuje se novým zněním (níže).**

~~(1) Územně plánovací dokumentace, její změna a úplné znění, územní studie, vymezení zastavěného území, jeho změna a úplné znění a územní opatření se vyhotovují v elektronické verzi ve strojově čitelném formátu10), včetně prostorových dat11), rovněž ve vektorové formě.~~

~~(2) Vybrané části územně plánovací dokumentace, její změny a úplné znění, vymezení zastavěného území, jeho změna a úplné znění a územní opatření se zpracovávají v jednotném standardu.~~

~~(3) Jednotný standard územně plánovací dokumentace, vymezení zastavěného území a územního opatření stanoví jejich standardizované části a požadavky na~~

~~a) geodetický referenční systém,~~

~~b) strukturu standardizovaných částí,~~

~~c) grafické vyjádření standardizovaných částí,~~

~~d) výměnný formát dat a~~

~~e) metadata.~~

~~(4) Podrobný obsah jednotného standardu včetně stanovení vybraných částí územně plánovací dokumentace, vymezení zastavěného území a územního opatření, které se zpracovávají v jednotném standardu, a požadavky na strojově čitelný formát stanoví prováděcí právní předpis.~~

#### § 59 — **Jednotný standard**  `[272 Čl.I/134]` {uc=A}

**(1) Územně plánovací dokumentace, její změna a úplné znění, územní studie, vymezení zastavitelného území, jeho změna a úplné znění a územní opatření se vyhotovují a vydávají v jednotném standardu jako digitální textová a prostorová data ve vektorové formě ve strojově čitelném formátu.** {uc=A}

**(2) Jednotný standard stanoví standardizované části a požadavky na** {uc=A}

**a) geodetický referenční systém,** {uc=A}

**b) strukturu standardizovaných částí,** {uc=A}

**c) výměnný formát dat a** {uc=A}

**d) metadata.** {uc=A}

**(3) Obsah jednotného standardu a požadavky na strojově čitelný formát stanoví prováděcí právní předpis.** {uc=A}

#### § 60 — Mapové a další podklady pro územně plánovací činnost

(1) Mapovými podklady pro územně plánovací činnost (dále jen „mapové podklady“) jsou katastrální mapa a základní státní mapová díla; mapovým podkladem pro pořízení regulačního plánu může být též polohopisné a výškopisné zaměření řešeného území.

(2) Mapovým podkladem jsou dále základní báze geografických dat a tematická státní mapová díla.

(3) Pro účely územního plánování je možné mapový podklad doplnit na základě skutečností zjištěných vlastním průzkumem území; záznam o provedeném doplnění se ukládá u pořizovatele.

(4) Při územně plánovací činnosti se jako další podklad používají digitální technická mapa kraje, digitální technická mapa obce, je-li k dispozici, a digitální mapa veřejné správy podle jiného právního předpisu14).

#### HLAVA III

*NÁSTROJE ÚZEMNÍHO PLÁNOVÁNÍ*

##### Díl 1

*Obecné ustanovení*

#### § 61 — Druhy nástrojů územního plánování  `[272 Čl.I/69]` {uc=A}

Nástroji územního plánování jsou

a) územně plánovací podklady, kterými jsou územně analytické podklady a územní studie,

b) politika územního rozvoje,

c) územně plánovací dokumentace, kterými jsou územní rozvojový plán, zásady územního rozvoje, územní plán a regulační plán,

d) vymezení ~~zastavěného~~ **zastavitelného** území, {uc=A}

e) územní opatření, kterými jsou územní opatření o stavební uzávěře, územní opatření o asanaci území a územní opatření o podmínkách a zmírňujících opatřeních podle zákona o urychlení využívání obnovitelných zdrojů energie.

##### Díl 2

*Územně plánovací podklady*

##### Oddíl 1

*Územně analytické podklady*

#### § 62  `[272 Čl.I/135; 272 Čl.I/136; 272 Čl.I/137]` {uc=A}

(1) Územně analytické podklady slouží zejména jako odborný podklad pro pořizování politiky územního rozvoje, územně plánovacích dokumentací, územních studií, územních opatření~~,~~ **a** vymezení ~~zastavěného území a pro rozhodování v~~ **zastavitelného** území. {uc=A}

(2) Územně analytické podklady **jsou tvořeny údaji o území, které** obsahují zjištění ~~a vyhodnocení~~ stavu ~~a vývoje~~ území, jeho hodnot~~,~~ **a** limitů využití území, **včetně známých** záměrů ~~na provedení změn~~ **a které vkládají do národního geoportálu územního plánování příslušní poskytovatelé. Územně analytické podklady jsou vedeny** v ~~území~~ **národním geoportálu územního plánování v jednotné databázi**, ~~zjišťování a vyhodnocování podmínek udržitelného rozvoje území a určení problémů k řešení v územně plánovací dokumentaci~~ **jejímž správcem je Úřad**. {uc=A}

(3) Náležitosti obsahu územně analytických podkladů**, obsah, rozsah a podrobnost údajů o území a způsob jejich poskytování Úřadu** stanoví prováděcí právní předpis. {uc=A}

#### § 63 — Údaje o území  `[272 Čl.I/138; 272 Čl.I/139; 272 Čl.I/140]` {uc=A}

(1) Údaji o území jsou informace nebo data o stavu území a omezeních, která se váží k určité části území, například **koridoru** ploše, pozemku, přírodnímu útvaru nebo stavbě, a která vznikla nebo byla zjištěna zejména na základě právních předpisů, a dále informace nebo data o záměrech na provedení změny v území; součástí údaje o území jsou také metadata. {uc=A}

(2) Údaje o území poskytuje ~~pořizovateli~~ poskytovatel údajů o území, kterým je {uc=A}

a) orgán veřejné správy, s jehož působností údaje o území souvisejí, nebo právnická osoba, jejímž zřizovatelem je stát nebo územní samosprávný celek,

b) vlastník dopravní nebo technické infrastruktury,

c) provozovatel staveb a zařízení, z jejichž provozu vznikají omezení v území podle jiného právního předpisu15).

**(3) Kraj zpracovává a poskytuje údaje o území v podrobnosti a rozsahu nezbytném pro územně plánovací činnost kraje a obcí v území kraje.** {uc=A}

#### § 64 — Poskytování údajů o území  `[272 Čl.I/141]` {uc=A}

(1) Poskytovatel údajů o území poskytuje údaje v digitální formě bezodkladně po jejich vzniku nebo po jejich zjištění, přitom odpovídá za jejich správnost, úplnost a aktuálnost, a to v rozsahu charakteristik přesnosti uvedených v rámci metadat. Údaje o území se poskytují ve formátech a za podmínek stanovených prováděcím právním předpisem. Povinnost poskytnutí údajů o území je splněna jejich vložením do digitální technické mapy kraje16), do národního geoportálu územního plánování nebo do registru územní identifikace, adres a nemovitostí17).

(2) Údaje o území mohou být použity pouze pro činnost orgánů veřejné správy a pro činnost projektanta územně plánovací dokumentace a územní studie.

~~(3) Vlastník dopravní nebo technické infrastruktury má nárok na úhradu účelně vynaložených nákladů spojených s poskytnutím údajů o území podle tohoto zákona, nejvýše však do výše nákladů na pořízení jejich kopií, nosičů dat a nákladů na doručení pořizovateli. Náklady hradí pořizovatel na základě žádosti vlastníka dopravní nebo technické infrastruktury.~~ {uc=A}

~~(4)~~ **(3)** Poskytovatel údajů o území, který nesplní povinnost podle odstavce 1, je povinen uhradit z toho vyplývající náklady na změny územně plánovací dokumentace, územní studie a na aktualizaci územně analytických podkladů a odpovídá za škodu vzniklou v důsledku toho, že údaje o území neposkytl nebo je poskytl nesprávné. {uc=A}

#### § 65 — ~~Pořizování a aktualizace územně analytických podkladů~~ **Aktualizace územně analytických podkladů**  `[272 Čl.I/142; 272 Čl.I/143; 272 Čl.I/144; 272 Čl.I/145]` {uc=A}

(1) Územně analytické podklady ~~a jejich aktualizace pořizuje pořizovatel~~ **aktualizují jednotliví poskytovatelé** na základě průzkumů území, údajů o území a dalších dostupných informací. ~~Pořizovatel zohledňuje také prognózy dalšího vývoje území, aby získal představu o jeho budoucím stavu a vývoji.~~ {uc=A}

(2) Podkladem pro ~~pořízení~~ **aktualizaci** územně analytických podkladů je i digitální technická mapa kraje nebo obce, je-li k dispozici. {uc=A}

~~(3) Pořizovatel průběžně aktualizuje územně analytické podklady a nejpozději do 4 let od jejich poslední úplné aktualizace pořídí návrh nové úplné aktualizace.~~ {uc=A}

#### ~~§ 66 — Projednání územně analytických podkladů~~  `[272 Čl.I/146]` {uc=A}

> **Zrušuje se celý paragraf.**

~~(1) Územně analytické podklady pro správní obvod obce s rozšířenou působností a jejich úplnou aktualizaci projedná pořizovatel v rozsahu určení problémů k řešení v územně plánovacích dokumentacích do 30 dnů po jejich vyhotovení s obcemi ve svém správním obvodu.~~

~~(2) Pořizovatel upraví územně analytické podklady pro správní obvod obce s rozšířenou působností podle výsledku projednání a bezodkladně je vloží do národního geoportálu územního plánování.~~

~~(3) Územně analytické podklady pro území kraje a jejich úplnou aktualizaci předkládá pořizovatel k projednání radě kraje v rozsahu a formě stanovené prováděcím právním předpisem.~~

~~(4) Krajský úřad vloží územně analytické podklady pro území kraje do národního geoportálu územního plánování do 10 dnů od jejich projednání podle odstavce 3.~~

##### Oddíl 2

*Územní studie*

#### § 67 — Účel

(1) Územní studie navrhuje, prověřuje a posuzuje možná řešení vybraných problémů v území, které by mohly významně ovlivňovat nebo podmiňovat jeho využití a uspořádání.

(2) Územní studie slouží jako odborný podklad pro

a) rozhodování v území, a to pouze v těch částech, v nichž je v souladu s územně plánovací dokumentací,

b) pořizování územně plánovací dokumentace, a to pouze v těch částech, v nichž není v rozporu s politikou územního rozvoje a nadřazenou územně plánovací dokumentací,

c) pořizování politiky územního rozvoje.

#### § 68 — Pořízení  `[272 Čl.I/147; 272 Čl.I/148]` {uc=A}

(1) Pořizovatel pořizuje územní studii

a) v případech, kdy je to požadováno územně plánovací dokumentací,

b) z vlastního podnětu, nebo

c) z jiného podnětu.

(2) Náklady na zpracování územní studie požadované územně plánovací dokumentací hradí orgán, který územně plánovací dokumentaci vydal. Pořízení územní studie z jiného podnětu může pořizovatel podmínit úhradou nákladů na zpracování územní studie od toho, kdo tento podnět podal.

(3) V zadání územní studie určí pořizovatel její obsah, rozsah, cíle a účel. Pořizovatel může stanovit, že ten, kdo hodlá změnu v území realizovat, zajistí zpracování územní studie na své náklady.

(4) ~~Jedná-li se o územní studii, jejíž pořízení je uloženo územním plánem jako podmínka pro rozhodování v území, předloží pořizovatel její návrh k projednání zastupitelstvu obce, které územní plán schválilo. Neprojedná-li zastupitelstvo obce~~ **Pořizovatel může projednat** návrh územní studie ~~ve lhůtě 90 dnů ode dne jeho předložení zastupitelstvu obce pořizovatelem~~ **s vlastníky dotčených nemovitostí**, ~~platí, že~~ s ~~návrhem souhlasí~~ **dotčenými orgány nebo s veřejností**. {uc=A}

(5) Je-li to nezbytné, zajistí pořizovatel úpravu územní studie a ~~vloží~~ **vydá** ji do 7 dnů ode dne, kdy schválil možnost jejího využití do národního geoportálu územního plánování; toto vložení je podmínkou využití územní studie. {uc=A}

#### § 69 — Prověření územní studie  `[272 Čl.I/149]` {uc=A}

(1) Pořizovatel nejpozději do 8 let od vložení územní studie do národního geoportálu územního plánování a následně vždy do 8 let prověří její aktuálnost a v případě kladného výsledku prověření zajistí vložení dat o této skutečnosti do národního geoportálu územního plánování, jinak územní studii z národního geoportálu územního plánování vypustí.

(2) Nedojde-li ke vložení dat o prověření aktuálnosti územní studie ani k vypuštění územní studie z národního geoportálu územního plánování pořizovatelem ve lhůtě podle odstavce 1, vypustí ~~ministerstvo, nebo jím pověřená organizační složka státu,~~ **Úřad** do 30 dnů ode dne uplynutí lhůty podle odstavce 1 územní studii z národního geoportálu územního plánování. {uc=A}

##### Díl 3

*Politika územního rozvoje*

#### § 70 — Politika územního rozvoje  `[272 Čl.I/102; 272 Čl.I/150]` {uc=A}

(1) Politika územního rozvoje je strategickým dokumentem, který určuje ve stanoveném období požadavky na konkretizaci **cílů a** úkolů územního plánování v celostátních, přeshraničních a mezinárodních souvislostech a určuje strategii a základní podmínky pro naplňování těchto **cílů a** úkolů. Politika územního rozvoje se zpracovává pro celé území státu. {uc=A}

(2) Politika územního rozvoje s ohledem na možnosti území koordinuje tvorbu a změny územního rozvojového plánu a zásad územního rozvoje, tvorbu koncepcí schvalovaných ministerstvy a jinými ústředními správními úřady a záměry na změny v území celostátního významu a stanoví úkoly zajišťující tuto koordinaci.

(3) ~~Ministerstvo~~ **Úřad** zajistí, aby ve Sbírce zákonů a mezinárodních smluv bylo uveřejněno sdělení o schválení politiky územního rozvoje, a její zveřejnění v národním geoportálu územního plánování. Politika územního rozvoje je závazná pro pořizování a vydávání územně plánovací dokumentace dnem následujícím po dni uveřejnění sdělení podle věty první. {uc=A}

#### § 71 — Obsah  `[272 Čl.I/61; 272 Čl.I/151; 272 Čl.I/152]` {uc=A}

(1) Politika územního rozvoje

a) stanoví celostátní priority územního plánování pro zajištění udržitelného rozvoje území České republiky,

b) stanoví koncepci sídelní struktury České republiky **a jejího rozvoje**, {uc=A}

c) vymezí oblasti ovlivněné rozvojovou dynamikou jednoho nebo více center osídlení se zvýšenými požadavky na změny v území, které jsou mezinárodního nebo celostátního významu nebo oblasti ovlivněné rozvojovou dynamikou jednoho nebo více center osídlení se zvýšenými požadavky na změny v území, které svým významem přesahují území jednoho kraje (dále jen „rozvojové oblasti“), a území s vazbou na kapacitní dopravní infrastrukturu propojující rozvojové oblasti a významná centra osídlení (dále jen „rozvojové osy“),

d) vymezí oblasti se **specifickým potenciálem,** specifickými hodnotami ~~a se specifickými problémy mezinárodního~~ nebo ~~celostátního významu nebo oblasti se specifickými hodnotami a~~ se specifickými problémy, ~~které svým významem~~ **mají-li mezinárodní nebo celostátní význam anebo** přesahují **-li** území jednoho kraje (dále jen „specifické oblasti“), {uc=A}

e) vymezí záměry dopravní a technické infrastruktury mezinárodního a celostátního významu nebo záměry dopravní a technické infrastruktury, které svým významem přesahují území jednoho kraje, a

f) stanoví úkoly podle § 70 odst. 2.

(2) K návrhu politiky územního rozvoje ~~ministerstvo~~ **Úřad** zajistí vyhodnocení vlivů, je-li to vyžadováno podle § 40. {uc=A}

(3) Obsah a struktura politiky územního rozvoje jsou stanoveny v příloze č. 5 k tomuto zákonu.

#### § 71a — Návrh  `[272 Čl.I/102; 272 Čl.I/153; 272 Čl.I/154; 272 Čl.I/155]` {uc=A}

(1) ~~Ministerstvo~~ **Úřad** pořizuje návrh politiky územního rozvoje ve spolupráci s ministerstvy, jinými ústředními správními úřady a kraji. {uc=A}

(2) Ministerstvo životního prostředí na žádost ~~ministerstva~~ **Úřadu** ve lhůtě 30 dnů ode dne obdržení návrhu obsahu politiky územního rozvoje stanoví požadavky na vyhodnocení vlivů na životní prostředí. Příslušný orgán ochrany přírody doručí stanovisko podle § 45i odst. 1 zákona o ochraně přírody a krajiny ~~ministerstvu~~ **Úřadu** a Ministerstvu životního prostředí nejpozději 10 dní před uplynutím lhůty podle věty první. {uc=A}

(3) Návrh politiky územního rozvoje pořizuje ~~ministerstvo~~ **Úřad zejména** na základě {uc=A}

**a) politiky architektury a stavební kultury,**

~~a)~~ **b)** územně plánovacích podkladů,

~~b)~~ **c)** dokumentů určených k podpoře regionálního rozvoje,

~~c)~~ **d)** podkladů a dokumentů veřejné správy, které mají v mezinárodních a celostátních souvislostech vliv na využívání území státu,

~~d)~~ **e)** zprávy o stavu životního prostředí a

~~e)~~ **f)** mezinárodních závazků České republiky vztahujících se k územnímu rozvoji.

#### § 71b — Projednání návrhu  `[272 Čl.I/61; 272 Čl.I/102]` {uc=A}

(1) ~~Ministerstvo~~ **Úřad** zveřejní návrh politiky územního rozvoje spolu s vyhodnocením vlivů v národním geoportálu územního plánování a současně návrh politiky územního rozvoje spolu s vyhodnocením vlivů zašle {uc=A}

a) ministerstvům,

b) jiným ústředním správním úřadům a

c) krajům.

(2) Ministerstva, jiné ústřední správní úřady, kraje, obce a veřejnost mohou písemně uplatnit své připomínky do 60 dnů od zveřejnění návrhu politiky územního rozvoje. K později uplatněným připomínkám se nepřihlíží.

(3) ~~Ministerstvo~~ **Úřad** ve spolupráci s Ministerstvem zahraničních věcí a Ministerstvem životního prostředí zašle návrh politiky územního rozvoje spolu s vyhodnocením vlivů sousedním státům, jejichž území může být uplatňováním politiky územního rozvoje významně ovlivněno a nabídne jim konzultace. Projeví-li sousední stát o konzultace zájem, ~~ministerstvo~~ **Úřad** se ve spolupráci s Ministerstvem zahraničních věcí a Ministerstvem životního prostředí konzultací účastní. {uc=A}

(4) ~~Ministerstvo~~ **Úřad** v návrhu politiky územního rozvoje zohlední připomínky, výsledky vyhodnocení vlivů a případná vyjádření sousedních států a výsledky konzultací. {uc=A}

#### § 71c — Stanovisko k návrhu koncepce  `[272 Čl.I/61; 272 Čl.I/102; 272 Čl.I/156; 272 Čl.I/157]` {uc=A}

(1) ~~Ministerstvo~~ **Úřad** zašle návrh vyhodnocení uplatněných připomínek, případných vyjádření sousedních států a výsledků konzultací Ministerstvu životního prostředí jako podklad pro vydání stanoviska k návrhu koncepce podle § 10g zákona o posuzování vlivů na životní prostředí. {uc=A}

(2) Ministerstvo životního prostředí stanovisko uplatní do 30 dnů od obdržení podkladů podle odstavce 1. Nejedná-li se o změnu politiky územního rozvoje, lze lhůtu pro uplatnění stanoviska ze závažných důvodů, které Ministerstvo životního prostředí sdělí ~~ministerstvu~~ **Úřadu** nejpozději do 30 dnů od obdržení podkladů, prodloužit, nejdéle však o 30 dnů. {uc=A}

(3) Neuplatní-li Ministerstvo životního prostředí stanovisko ve lhůtě podle odstavce 2, je možné politiku územního rozvoje schválit i bez tohoto stanoviska; v takovém případě ~~ministerstvo~~ **Úřad** zohlední závěry vyhodnocení vlivů, připomínky a výsledky konzultací. {uc=A}

(4) Vyplyne-li z posouzení vlivu na evropsky významnou lokalitu nebo ptačí oblast, že politika územního rozvoje má významný negativní vliv na předmět ochrany nebo celistvost evropsky významné lokality nebo ptačí oblasti, postupuje se podle § 45i zákona o ochraně přírody a krajiny. Kompenzační opatření uvede Ministerstvo životního prostředí ve stanovisku podle § 54 odst. ~~1~~ **2**. {uc=A}

#### § 71d — Schválení a uplatňování  `[272 Čl.I/61; 272 Čl.I/102; 272 Čl.I/158; 272 Čl.I/159; 272 Čl.I/160; 272 Čl.I/161]` {uc=A}

(1) ~~Ministerstvo~~ **Úřad** předkládá návrh politiky územního rozvoje **prostřednictvím Ministerstva hospodářství** ke schválení vládě. {uc=A}

(2) Ministerstvo nejpozději do 4 let od schválení politiky územního rozvoje a poté nejméně jednou za 4 roky vyhodnotí uplatňování politiky územního rozvoje.

(3) Za účelem vyhodnocení uplatňování politiky územního rozvoje zpracuje ~~ministerstvo~~ **Úřad** ve spolupráci s ministerstvy, jinými ústředními správními úřady a kraji zprávu o plnění politiky územního rozvoje (dále jen „zpráva o plnění“), která obsahuje zejména {uc=A}

a) vyhodnocení plnění úkolů politiky územního rozvoje,

b) problémy k řešení v politice územního rozvoje ~~vyplývající z územně analytických podkladů~~, {uc=A}

c) posouzení vlivu územního rozvojového plánu, zásad územního rozvoje, podkladů a dokumentů veřejné správy s celostátním zaměřením na uplatňování politiky územního rozvoje,

d) vyhodnocení vlivů na udržitelný rozvoj území vyplývajících z uplatňování politiky územního rozvoje z hlediska možných nepředvídaných dopadů, včetně potřeby opatření na jejich odvrácení, zmírnění nebo kompenzaci,

e) vyhodnocení potřeby pořízení změny politiky územního rozvoje nebo nové politiky územního rozvoje.

(4) Vyplyne-li z vyhodnocení podle odstavce 3 písm. e) potřeba pořízení změny politiky územního rozvoje nebo nové politiky územního rozvoje, obsahuje zpráva o plnění dále zejména

a) návrhy na změnu politiky územního rozvoje včetně jejich zdůvodnění, popřípadě návrh a důvody na pořízení nového návrhu politiky územního rozvoje,

b) stanovisko podle § 45i odst. 1 zákona o ochraně přírody a krajiny,

c) stanovisko Ministerstva životního prostředí zpracované na základě kritérií podle přílohy č. 8 k zákonu o posuzování vlivů na životní prostředí s uvedením, má-li být změna politiky územního rozvoje posouzena z hlediska vlivů na životní prostředí,

d) návrh opatření, která je nutné provést v územně plánovací činnosti krajů a obcí a v činnosti ministerstev a dalších ústředních správních úřadů.

(5) ~~Ministerstvo~~ **Úřad** zveřejní návrh zprávy o plnění v národním geoportálu územního plánování a stanoví lhůtu pro podání písemných připomínek obcí a veřejnosti, která nesmí být kratší než 30 dnů ode dne zveřejnění návrhu. Připomínky se podávají ~~ministerstvu~~ **Úřadu**. K později uplatněným připomínkám se nepřihlíží. {uc=A}

(6) Návrh zprávy o plnění předloží ~~ministerstvo~~ **Úřad prostřednictvím Ministerstva hospodářství** vládě, která {uc=A}

a) vezme zprávu o plnění na vědomí, není-li vyžadována změna nebo pořízení nové politiky územního rozvoje, nebo

b) schválí zprávu o plnění a rozhodne o změně politiky územního rozvoje nebo o pořízení návrhu nové politiky územního rozvoje.

#### § 71e — Změna  `[272 Čl.I/61; 272 Čl.I/102]` {uc=A}

(1) Změna politiky územního rozvoje se zpracovává, projednává a vydává v rozsahu měněných částí. Pro zpracování a projednání změny politiky územního rozvoje se § 71a až 71c použijí obdobně.

(2) Vyhodnocení vlivů změny politiky územního rozvoje se zpracovává pouze v případě, stanoví-li tak Ministerstvo životního prostředí ve svém stanovisku podle § 71d odst. 4 písm. c).

(3) ~~Ministerstvo~~ **Úřad** zajistí vyhotovení úplného znění politiky územního rozvoje po její změně. Změnu politiky územního rozvoje a úplné znění politiky územního rozvoje po její změně ~~ministerstvo~~ **Úřad** zveřejní v národním geoportálu územního plánování. {uc=A}

(4) Z důvodu naléhavého veřejného zájmu může vláda na návrh rozhodnout o změně politiky územního rozvoje a jejím obsahu bez předložení zprávy o plnění. V takovém případě vláda může rozhodnout o zkrácení lhůt uvedených v § 71b odst. 2 a § 71c odst. 2.

(5) Návrh na změnu politiky územního rozvoje z důvodu naléhavého veřejného zájmu může podat ústřední orgán státní správy nebo rada kraje a obsahuje

a) údaje umožňující identifikaci navrhovatele,

b) obsah změny politiky územního rozvoje,

c) důvody pro pořízení změny, včetně uvedení naléhavého veřejného zájmu,

d) stanovisko podle § 45i odst. 1 zákona o ochraně přírody a krajiny a

e) stanovisko Ministerstva životního prostředí s uvedením, má-li být změna politiky územního rozvoje posouzena z hlediska vlivů na životní prostředí.

(6) Vláda může v odůvodněných případech rozhodnout o souběžném pořízení změny politiky územního rozvoje a územního rozvojového plánu nebo jeho změny.

##### Díl 4

*Územně plánovací dokumentace*

##### Oddíl 1

*Účel a základní obsahové náležitosti územně plánovací dokumentace*

#### § 72 — Společná ustanovení  `[272 Čl.I/162; 272 Čl.I/163]` {uc=A}

(1) **Územně plánovací dokumentace naplňuje a rozvíjí cíle a úkoly územního plánování a vyjadřuje veřejný zájem na prostorovém uspořádání a způsobu využití území.** Územně plánovací dokumentace nesmí obsahovat podrobnosti, které náležejí svým obsahem navazující územně plánovací dokumentaci nebo rozhodnutí. {uc=A}

(2) Územně plánovací dokumentace a její odůvodnění obsahuje textovou část a grafickou část. Obsah a struktura územně plánovací dokumentace a obsah odůvodnění územně plánovací dokumentace jsou stanoveny v přílohách č. 6 až 9 k tomuto zákonu.

(3) Územně plánovací dokumentací se rozumí i změna územně plánovací dokumentace. **Vztah původní a nové, případně změněné územně plánovací dokumentace mohou upravit přechodná ustanovení.** {uc=A}

(4) Pro obsah územně plánovací dokumentace vojenského újezdu se ustanovení tohoto zákona použijí přiměřeně. Návrh územně plánovací dokumentace vojenského újezdu se podle tohoto zákona projednává jen v rozsahu vlivů přesahujících hranice vojenského újezdu.

#### § 73 — Forma a závaznost územně plánovací dokumentace  `[272 Čl.I/164; 272 Čl.I/165; 272 Čl.I/166]` {uc=A}

(1) Územně plánovací dokumentace se vydává formou opatření obecné povahy.

(2) Územně plánovací dokumentace je závazná pro rozhodování v území a další změny v území. Drobné stavby lze realizovat pouze v souladu s územně plánovací dokumentací**, nestanoví-li zákon jinak**. {uc=A}

(3) Nadřazená územně plánovací dokumentace je závazná pro obsah navazující územně plánovací dokumentace. K části navazující územně plánovací dokumentace, která je v rozporu s nadřazenou územně plánovací dokumentací, se nepřihlíží. **Za rozpor se nepovažuje, pokud navazující územně plánovací dokumentace obsahuje záležitosti, které nejsou vymezeny v nadřazené územně plánovací dokumentaci.** {uc=A}

(4) Je-li to účelné, navazující územně plánovací dokumentace zpřesňuje vymezení ploch a koridorů vymezených v nadřazené územně plánovací dokumentaci.

(5) Zpřesněním podle odstavce 4 se rozumí vymezení ploch a koridorů v území zahrnutém do plochy nebo koridoru vymezeného v nadřazené územně plánovací dokumentaci. Zpřesněním plochy nebo koridoru se upřesňuje také území, k němuž se vztahují podmínky stanovené v nadřazené územně plánovací dokumentaci pro zpřesňovanou plochu nebo koridor **Navazující územně plánovací dokumentace se může se souhlasem Úřadu a toho, kdo vydal nadřazenou územně plánovací dokumentaci, v rámci zpřesnění vymezení ploch a koridorů v nezbytném rozsahu odchýlit od jejich vymezení v nadřazené územně plánovací dokumentaci, pokud dodrží smysl a účel nadřazené územně plánovací dokumentace**. **Pro možnost odchýlení se od územního opatření, vymezení zastavitelného území a ochranného pásma platí možnost odchýlení se od jejich vymezení a podmínek při dodržení jejich smyslu a účelu obdobně.** {uc=A}

##### Územní rozvojový plán

#### § 74  `[272 Čl.I/167; 272 Čl.I/168]` {uc=A}

(1) Územní rozvojový plán zpřesňuje záměry vymezené v politice územního rozvoje v souladu s cíli a úkoly územního plánování, vymezuje další záměry, zohledňuje požadavky vyplývající ze strategických koncepcí České republiky a mezinárodních závazků a přispívá k jejich naplňování.

(2) Územní rozvojový plán vymezuje

a) zastavitelné plochy, transformační plochy a koridory určené pro umístění záměrů dopravní a technické infrastruktury mezinárodního nebo celostátního významu, nebo přesahující svým významem území jednoho kraje~~, vymezené politikou územního rozvoje~~ a stanovuje účel jejich vymezení, popřípadě podmínky pro **jejich využití a pro** rozhodování v území, {uc=A}

b) ~~zastavitelné plochy, transformační plochy,~~ plochy a koridory pro ~~další záměry mezinárodního nebo celostátního významu~~ **strategické investiční stavby**, ~~nebo přesahující svým významem území jednoho kraje, které nejsou vymezeny v politice územního rozvoje a o kterých tak rozhodne vláda, a stanovuje účel jejich vymezení, popřípadě podmínky pro rozhodování v území,~~ {uc=A}

c) akcelerační oblasti celostátního významu a stanovuje druh primární energie zdrojů, pro něž se oblast vymezuje,

d) územní systém ekologické stability nadregionálního významu a

e) veřejně prospěšné stavby, veřejně prospěšná opatření, stavby a opatření k zajišťování obrany a bezpečnosti státu a plochy pro asanaci, pro které lze práva k pozemkům a stavbám vyvlastnit.

#### § 75

(1) Územní rozvojový plán může vymezit plochu nebo koridor územní rezervy.

(2) Územní rozvojový plán může stanovit pořadí provádění změn v území.

(3) K podrobnějšímu prověření navrženého řešení může územní rozvojový plán ve vybraných plochách nebo koridorech uložit pořízení územní studie.

#### § 76  `[272 Čl.I/61; 272 Čl.I/169]` {uc=A}

(1) Územní rozvojový plán se pořizuje a vydává pro celé území státu.

(2) K návrhu územního rozvojového plánu ~~ministerstvo~~ **Úřad** zajistí vyhodnocení vlivů, je-li to vyžadováno podle § 40. {uc=A}

**(3) Do územního rozvojového plánu může pořizovatel převzít plochy a koridory pro záměry mezinárodního nebo celostátního významu anebo záměry přesahující svým významem území jednoho kraje, vymezené v zásadách územního rozvoje, u kterých marně uplynula lhůta pro jejich zrušení podle správního řádu a soudního řádu správního. Tento postup nepodléhá řízení podle § 87 až 111a ani posuzování vlivů na udržitelný rozvoj území podle § 40 a nabývá účinnosti dnem vyvěšení veřejné vyhlášky o zveřejnění úplného znění. Soulad s politikou územního rozvoje se neposuzuje.** {uc=A}

##### Zásady územního rozvoje

#### § 77  `[272 Čl.I/170]` {uc=A}

(1) Zásady územního rozvoje jsou základním koncepčním dokumentem kraje k usměrňování jeho územního rozvoje a ochrany hodnot jeho území.

(2) Zásady územního rozvoje

a) stanoví koncepci rozvoje území kraje a rozvoje a ochrany jeho hodnot, včetně koncepce sídelní struktury kraje, se zohledněním koncepce sídelní struktury státu obsažené v politice územního rozvoje,

b) zpřesňují vymezení rozvojových oblastí a rozvojových os obsažených v politice územního rozvoje a, je-li to účelné, vymezí rozvojové oblasti a rozvojové osy nadmístního významu,

c) zpřesňují vymezení specifických oblastí obsažených v politice územního rozvoje a, je-li to účelné, vymezí specifické oblasti nadmístního významu,

d) přebírají a, je-li to účelné, zpřesňují věcná řešení obsažená v územním rozvojovém plánu, zejména ~~zastavitelné plochy, transformační~~ plochy a koridory, akcelerační oblasti a územní systém ekologické stability nadregionálního významu, {uc=A}

e) vymezují ~~zastavitelné plochy, transformační~~ plochy a koridory nadmístního významu, včetně ploch a koridorů veřejné infrastruktury, ploch pro těžbu nerostů, územního systému ekologické stability regionálního významu, stanoví účel, pro který jsou vymezeny, a požadavky na jejich využití, {uc=A}

f) vymezují akcelerační oblasti nadmístního významu a stanovují druh primární energie zdrojů, pro něž se oblast vymezuje,

g) vymezují krajiny a stanoví jejich cílové kvality podle Evropské úmluvy o krajině18), včetně územních podmínek pro jejich zachování nebo dosažení,

h) přebírají a, je-li to účelné, zpřesňují veřejně prospěšné stavby, veřejně prospěšná opatření, stavby a opatření k zajišťování obrany a bezpečnosti státu a plochy pro asanaci, pro které lze práva k pozemkům a stavbám vyvlastnit, obsažené v územním rozvojovém plánu,

i) vymezují veřejně prospěšné stavby, veřejně prospěšná opatření, stavby a opatření k zajišťování obrany a bezpečnosti státu a plochy pro asanaci, pro které lze práva k pozemkům a stavbám vyvlastnit,

j) stanovují požadavky na koordinaci územně plánovací činnosti obcí a na řešení v územně plánovacích dokumentacích obcí, a to i s přihlédnutím ke stanovené sídelní struktuře a obnovitelným a druhotným zdrojům energie.

#### § 78

(1) Zásady územního rozvoje v nadmístních souvislostech zpřesňují a rozvíjejí cíle a úkoly územního plánování v souladu s politikou územního rozvoje a územním rozvojovým plánem a určují strategii pro jejich naplňování.

(2) Je-li to účelné, zásady územního rozvoje stanoví podrobnější řešení obsažené v politice územního rozvoje nebo územním rozvojovém plánu a řeší další záležitosti, které přesahují svým významem nebo rozsahem území obce; přitom mohou obsahovat řešení vybraného území, koridoru, plochy nebo akcelerační oblasti, v podrobnějším měřítku.

(3) Zásady územního rozvoje mohou vymezit plochu nebo koridor územní rezervy.

(4) Zásady územního rozvoje mohou stanovit pořadí provádění změn v území.

(5) K podrobnějšímu prověření navrženého řešení mohou zásady územního rozvoje ve vybraných územích nebo koridorech uložit pořízení územní studie.

#### § 79  `[272 Čl.I/171]` {uc=A}

(1) Zásady územního rozvoje se pořizují a vydávají pro celé území kraje.

(2) Záležitosti celostátního významu, které nejsou obsaženy v politice územního rozvoje nebo územním rozvojovém plánu, mohou být součástí zásad územního rozvoje, nevyloučí-li to nadřízený orgán ve stanovisku podle § 101 z důvodů potřeby jejich nadregionální koordinace.

(3) K návrhu zásad územního rozvoje pořizovatel zajistí vyhodnocení vlivů, je-li to vyžadováno podle § 40.

(4) Zásady územního rozvoje hlavního města Prahy řeší záležitosti celoměstského významu; přitom se ustanovení stanovící obsah zásad územního rozvoje týkající se rozvojových oblastí, rozvojových os, specifických oblastí a sídelní struktury použijí přiměřeně.

**(5) Do zásad územního rozvoje může pořizovatel se souhlasem příslušného úřadu rozvoje území kraje převzít plochy a koridory pro záměry nadmístního významu vymezené v územním plánu, u kterých marně uplynula lhůta pro jejich zrušení podle správního řádu a soudního řádu správního. Tento postup nepodléhá řízení podle § 87 až 111a ani posuzování vlivů na udržitelný rozvoj území podle § 40 a nabývá účinnosti dnem vyvěšení veřejné vyhlášky o zveřejnění úplného znění. Soulad s politikou územního rozvoje a s nadřazenou územně plánovací dokumentací se neposuzuje.** {uc=A}

##### Územní plán

#### § 80  `[272 Čl.I/172; 272 Čl.I/173; 272 Čl.I/174; 272 Čl.I/175; 272 Čl.I/176]` {uc=A}

(1) Územní plán je základním koncepčním dokumentem obce k usměrňování územního rozvoje a ochrany hodnot jejího území.

(2) Územní plán

a) vymezí ~~zastavěné~~ **zastavitelné** území ~~a stanoví datum~~, ~~k němuž je vymezeno,~~ {uc=A}

b) stanoví základní koncepci rozvoje území obce, vyjádřenou zejména v cílech zlepšování jeho dosavadního stavu a požadavcích na rozvoj a ochranu jeho hodnot,

c) stanoví urbanistickou koncepci~~, jejíž součástí je i urbanistická kompozice, vymezení ploch podle stávajícího nebo nově požadovaného způsobu využití (dále jen „plocha s rozdílným způsobem využití~~ “), vymezení zastavitelných ploch, transformačních ploch, systému veřejných prostranství a systému sídelní zeleně, {uc=A}

d) stanoví koncepci veřejné infrastruktury, jejíž součástí je i stanovení podmínek pro její umisťování, vymezení ploch**, koridorů** a ~~koridorů~~ **prvků** pro veřejnou infrastrukturu, včetně stanovení podmínek pro jejich využití a vymezení akceleračních oblastí, včetně stanovení druhu primární energie zdrojů, pro něž se oblast vymezuje, {uc=A}

e) stanoví koncepci uspořádání krajiny, jejíž součástí je ~~i vymezení ploch s rozdílným způsobem využití, ploch změn v krajině a~~ stanovení podmínek pro ~~jejich~~ **její** využití, vymezení a stanovení podmínek pro zelenou infrastrukturu včetně územního systému ekologické stability, prostupnost krajiny, protierozní opatření, ochranu před povodněmi a suchem, rekreaci a dobývání ložisek nerostných surovin, {uc=A}

f) stanoví podmínky **prostorového uspořádání a využití území, včetně požadavků na rozvoj, zachování nebo změnu charakteru území; plochy a koridory, podmínky pro jejich využití a podmínky prostorového uspořádání mohou být vymezeny vzájemně nezávisle; podmínky** pro využití ploch ~~s rozdílným způsobem využití s~~ **se stanovují** určením hlavního ~~využití, pokud je možné jej stanovit, přípustného~~ využití, nepřípustného využití, popřípadě ~~stanovení~~ podmíněně přípustného využití těchto ploch a ~~podmínky prostorového uspořádání, včetně základních podmínek ochrany krajinného rázu a charakteru území,~~ {uc=A}

g) vymezí veřejně prospěšné stavby, veřejně prospěšná opatření, stavby a opatření k zajišťování obrany a bezpečnosti státu a plochy pro asanaci, pro které lze práva k pozemkům a stavbám vyvlastnit.

(3) Územní plán přebírá věcná řešení zásad územního rozvoje, zejména plochy, koridory a akcelerační oblasti a, je-li to účelné, zpřesňuje je. Nezohlednily-li zásady územního rozvoje dosud věcná řešení obsažená v politice územního rozvoje nebo územním rozvojovém plánu, územní plán tato řešení přebírá a, je-li to účelné, zpřesňuje je.

#### § 81  `[272 Čl.I/177; 272 Čl.I/178]` {uc=A}

(1) Územní plán může vymezit plochy a koridory územních rezerv a členit území podle převažujícího charakteru na lokality.

~~(2) Územní plán může vymezit zastavitelné území. Do zastavitelného území se zahrne zastavěné území, zastavitelné plochy a transformační plochy.~~ {uc=A}

~~(3)~~ **(2)** V územním plánu lze vymezit plochu nebo koridor, v němž je rozhodování v území podmíněno uzavřením plánovací smlouvy. V takovém případě územní plán stanoví základní **podmínky pro** obsah plánovací smlouvy~~, podmínky~~ a lhůtu pro její uzavření, která nesmí být delší než 6 let od nabytí účinnosti územního plánu. Marným uplynutím stanovené lhůty pozbývá uvedená podmínka platnosti. {uc=A}

~~(4)~~ **(3)** Územní plán může ve vybraných plochách nebo koridorech uložit pořízení územní studie nebo vydání regulačního plánu jako podmínku pro rozhodování v území a stanoví základní podmínky pro pořízení územní studie a základní podmínky pro pořízení regulačního plánu nebo zadání regulačního plánu a lhůtu pro vložení územní studie do národního geoportálu územního plánování nebo pro nabytí účinnosti regulačního plánu, která nesmí být v obou případech delší než 6 let od nabytí účinnosti územního plánu. Marným uplynutím stanovené lhůty pozbývá uvedená podmínka platnosti. {uc=A}

~~(5)~~ **(4)** Územní plán může vymezit plochu nebo koridor, v nichž je rozhodování v území podmíněno architektonickou nebo urbanistickou soutěží. Architektonickou nebo urbanistickou soutěž zajistí na požádání stavebníka na své náklady obec, jejíž zastupitelstvo územní plán vydalo. Architektonickou nebo urbanistickou soutěž může namísto obce zajistit na své náklady ten, kdo hodlá v této ploše nebo koridoru záměr realizovat. {uc=A}

~~(6)~~ **(5)** Územní plán může stanovit pořadí provádění změn v území. {uc=A}

#### § 82  `[272 Čl.I/179; 272 Čl.I/180]` {uc=A}

(1) Územní plán se pořizuje a vydává, rozhodne-li tak zastupitelstvo obce, a to pro celé území obce, není-li v tomto zákoně stanoveno jinak.

(2) Územní plán může být pořízen a vydán i pro část území ~~hlavního města Prahy~~ **obce**. V takovém případě obsahuje územní plán vymezení řešeného území. Územní plán hlavního města Prahy se považuje za nadřazenou územně plánovací dokumentaci. {uc=A}

(3) Územní plán může pro celé území obce nebo pro jeho část obsahovat prvky regulačního plánu~~, stanoví-li tak zastupitelstvo obce v zadání územního plánu nebo v zadání změny územního plánu~~. {uc=A}

#### § 83  `[272 Čl.I/181]` {uc=A}

(1) K návrhu územního plánu pořizovatel zajistí vyhodnocení vlivů, je-li to vyžadováno podle § 40.

(2) Územní plán může vymezit architektonicky nebo urbanisticky významné stavby19).

~~(3) Poskytování veřejných prostředků podle jiných právních předpisů na provedení změn v území nesmí být v rozporu s vydaným územním plánem.~~ {uc=A}

#### § 84

Záležitosti nadmístního významu, které nejsou obsaženy v zásadách územního rozvoje, mohou být součástí územního plánu, nevyloučí-li to nadřízený orgán ve stanovisku podle § 101 z důvodů potřeby jejich nadmístní koordinace.

##### Regulační plán

#### § 85  `[272 Čl.I/182; 272 Čl.I/183; 272 Čl.I/184; 272 Čl.I/185; 272 Čl.I/186]` {uc=A}

(1) Regulační plán v řešeném území stanoví podrobné podmínky pro **vymezení a využití pozemků.** {uc=A}

~~a) vymezení a využití pozemků,~~

~~b) umístění a prostorové uspořádání staveb, včetně jejich napojení na veřejnou dopravní a technickou infrastrukturu, a urbanistických a architektonických podmínek,~~

~~c) umístění a prostorové uspořádání staveb veřejné infrastruktury,~~

~~d) ochranu hodnot, charakteru území a krajinného rázu.~~

(2) Regulační plán dále ~~zpravidla stanoví~~ **může stanovit zejména** {uc=A}

a) uliční a stavební čáry,

**b) umístění a prostorové uspořádání staveb, včetně jejich napojení na veřejnou dopravní a technickou infrastrukturu, a urbanistických a architektonických podmínek,**

~~b)~~ **c)** vzájemné odstupy staveb a odstupy staveb od hranice pozemku,

~~c)~~ **d)** půdorysnou velikost stavby, výšku, objem **nebo požadavky na vnější vzhled** a tvar stavby, {uc=A}

~~d)~~ **e)** základní údaje o kapacitě stavby,

~~e)~~ **f)** určení částí pozemku, které mohou být zastavěny, nebo zastavitelnost pozemku dalšími stavbami,

~~f)~~ **g)** základní podmínky pro požární ochranu,

~~g)~~ **h)** podmínky pro příznivé životní prostředí a zelenou infrastrukturu, včetně vymezení a využití pozemků územního systému ekologické stability~~.~~**,**

**i) podmínky pro ochranu hodnot, charakteru území nebo krajinného rázu.**

#### § 86  `[272 Čl.I/187; 272 Čl.I/188]` {uc=A}

(1) Regulační plán se pořizuje a vydává pro řešené území, rozhodne-li tak zastupitelstvo obce.

(2) Regulační plán může vymezit veřejně prospěšné stavby nebo veřejně prospěšná opatření, stavby a opatření k zajišťování obrany a bezpečnosti státu a pozemky pro asanaci, pro která lze práva k pozemkům a stavbám vyvlastnit.

(3) V regulačním plánu lze vymezit záměr, pro který je uzavření plánovací smlouvy podmínkou pro rozhodování v území. V takovém případě obsahuje základní **obsah plánovací smlouvy,** podmínky pro uzavření plánovací smlouvy a lhůtu pro uzavření plánovací smlouvy, která nesmí být delší než 4 roky. Marným uplynutím stanovené lhůty pozbývá uvedená podmínka platnosti. {uc=A}

(4) Regulační plán může vymezit záměr, pro který je provedení architektonické nebo urbanistické soutěže podmínkou pro rozhodování v území. Architektonickou nebo urbanistickou soutěž zajistí na požádání stavebníka na své náklady obec, jejíž zastupitelstvo regulační plán vydalo, není-li dohodnuto jinak. Architektonickou nebo urbanistickou soutěž může namísto obce zajistit na své náklady ten, kdo hodlá tento záměr realizovat.

~~(5) Regulační plán může vymezit stavbu domu pro dostupné nájemní bydlení, včetně stanovení podílu bytů určených pro dostupné nájemní bydlení.~~ {uc=A}

~~(6)~~ **(5)** Regulační plán může stanovit pořadí provádění změn v území nebo architektonicky nebo urbanisticky významné stavby19). {uc=A}

##### Oddíl 2

*Pořízení územně plánovací dokumentace*

#### § 87 — Rozhodnutí o pořízení a návrh zadání  `[272 Čl.I/189; 272 Čl.I/190; 272 Čl.I/191; 272 Čl.I/192; 272 Čl.I/193]` {uc=A}

(1) O pořízení územně plánovací dokumentace rozhoduje orgán příslušný k jejímu ~~vydání~~ **schválení** (dále jen „schvalující orgán“) z {uc=A}

a) vlastního podnětu, nebo

b) podnětu podle § 109 odst. 1, jedná-li se o regulační plán nebo změnu územně plánovací dokumentace.

(2) Pořizovatel v součinnosti s určeným zastupitelem**, je-li určen,** zpracuje návrh zadání územně plánovací dokumentace (dále jen „návrh zadání“) na základě rozhodnutí podle odstavce 1, a územně plánovacích podkladů. ~~Jako podklad pro zpracování návrhu zadání lze využít i doplňující průzkumy a rozbory.~~ {uc=A}

(3) V návrhu zadání se stanoví hlavní cíle a požadavky na zpracování návrhu územně plánovací dokumentace, v případě regulačního plánu a ~~územního plánu~~ **územních plánů** pro vymezenou část ~~území hlavního města Prahy~~ **obce** se vymezí řešené území. {uc=A}

(4) Náležitosti obsahu a strukturu zadání zásad územního rozvoje, zadání územního plánu a zadání regulačního plánu stanoví prováděcí právní předpis.

**(5) Rozhodnutí o pořízení regulačního plánu nebo územního plánu může zastupitelstvo kraje nebo obce nahradit schválením plánovací smlouvy, ve které se stavebník zaváže ke zpracování nebo převzetí nákladů na zpracování návrhu zadání regulačního plánu nebo územního plánu nebo návrhu regulačního plánu nebo územního plánu.** {uc=A}

##### Projednání a schválení návrhu zadání

#### § 88  `[272 Čl.I/194; 272 Čl.I/195; 272 Čl.I/196; 272 Čl.I/197; 272 Čl.I/198; 272 Čl.I/199]` {uc=A}

~~(1)~~ Pořizovatel bezodkladně zveřejní návrh zadání v národním geoportálu územního plánování a ~~toto~~ **adresu tohoto** zveřejnění oznámí veřejnou vyhláškou. Pořizovatel oznámí zveřejnění jednotlivě dotčeným orgánům a {uc=A}

**a) krajům v případě územního rozvojového plánu,** {uc=A}

~~a)~~ **b)** ~~ministerstvu~~ **nadřízenému orgánu**, územním samosprávným celkům v řešeném území a s řešeným územím přímo sousedícím v případě zásad územního rozvoje, {uc=A}

~~b)~~ **c)** nadřízenému orgánu ~~územního plánování~~ a ~~územním samosprávným celkům~~ **kraji, ve kterém se obec nachází, Ministerstvu obrany, je-li územní plán zpracováván pro obec sousedící** s ~~řešeným územím přímo sousedícím~~ **vojenským újezdem a sousedním obcím** v případě územního plánu~~.~~**,** {uc=A}

**d) nadřízenému orgánu a sousedním krajům a sousedním obcím v případě územního plánu hlavního města Prahy.** {uc=A}

~~(2) Územní samosprávný celek, pro který má být územně plánovací dokumentace pořizována, zveřejní návrh zadání na své úřední desce. Návrh zadání územního rozvojového plánu zveřejní na své úřední desce ministerstvo.~~ {uc=A}

#### § 89  `[272 Čl.I/200; 272 Čl.I/201]` {uc=A}

(1) Pořizovatel zašle bezodkladně návrh zadání územního rozvojového plánu, zpracovává-li se, zásad územního rozvoje a územního plánu příslušnému úřadu20) a současně orgánu ochrany přírody.

(2) Orgán ochrany přírody doručí pořizovateli a příslušnému úřadu do 20 dnů od obdržení návrhu zadání stanovisko podle § 45i zákona o ochraně přírody a krajiny, ve kterém uvede, zda je možné vyloučit významný vliv na předmět ochrany a celistvost evropsky významné lokality nebo ptačí oblasti.

(3) Příslušný úřad uplatní u pořizovatele do 30 dnů od obdržení návrhu zadání stanovisko, ve kterém i s přihlédnutím ke stanovisku orgánu ochrany přírody podle odstavce 2 uvede v případě

a) územního rozvojového plánu a zásad územního rozvoje podrobnější požadavky podle jiného právního předpisu21),

b) změny územního rozvojového plánu, změny zásad územního rozvoje a územního plánu a jeho změny, zda má být jejich návrh posuzován z hlediska vlivů na životní prostředí, popřípadě stanoví podrobnější požadavky podle jiného právního předpisu21).

(4) Požadavky podle odstavce 3 nesmí vyžadovat podrobnosti náležející svým obsahem navazující územně plánovací dokumentaci nebo rozhodnutí.

(5) Do 30 dnů od doručení oznámení podle § 88 ~~odst. 1~~ může pořizovateli písemně doručit {uc=A}

a) dotčený orgán a nadřízený orgán **a oprávněný investor** vyjádření, {uc=A}

b) každý podněty.

(6) Vyplyne-li ze stanoviska orgánu uvedeného v odstavci 3, že návrh územního rozvojového plánu, zásad územního rozvoje nebo územního plánu má být posuzován z hlediska vlivů na životní prostředí, doplní pořizovatel v souladu s § 40 do návrhu zadání požadavek na vyhodnocení vlivů.

#### § 90  `[272 Čl.I/190; 272 Čl.I/202]` {uc=A}

(1) Pořizovatel v součinnosti s určeným zastupitelem**, je-li určen,** upraví návrh zadání na základě výsledků projednání a předloží jej ke schválení schvalujícímu orgánu. {uc=A}

~~(2) Schvalující orgán v odůvodněných případech nebo z podnětu dotčeného orgánu uloží v zadání zpracování variantního řešení návrhu územně plánovací dokumentace. Nesouhlasí-li schvalující orgán s předloženým návrhem zadání, vrátí předložený návrh pořizovateli se svými pokyny k úpravě a k novému projednání, nebo návrh zamítne.~~ {uc=A}

~~(3)~~ **(2)** Schválené zadání pořizovatel do 7 dnů od jeho obdržení od schvalujícího orgánu zveřejní v národním geoportálu územního plánování. {uc=A}

##### Úhrada nákladů při pořizování územně plánovací dokumentace

#### ~~§ 91~~  `[272 Čl.I/203]` {uc=A}

> **Zrušuje se celý paragraf.**

~~(1) Náklady na mapové podklady, na zpracování územně plánovací dokumentace nebo její změny projektantem, na vyhodnocení vlivů, zpracovává-li se, na vyhotovení úplného znění územně plánovací dokumentace po její změně, na změnu navazující územně plánovací dokumentace a náklady na náhradu za změnu v území hradí u~~

~~a) územního rozvojového plánu ministerstvo,~~

~~b) zásad územního rozvoje kraj,~~

~~c) územního plánu a u regulačního plánu obec,~~

~~d) územně plánovací dokumentace pro území vojenského újezdu Ministerstvo obrany.~~

~~(2) Náklady spojené s pořizováním územně plánovací dokumentace neuvedené v odstavci 1 hradí pořizovatel.~~

#### § 92  `[272 Čl.I/205; 272 Čl.I/206]` {uc=A}

(1) Vyplývá-li pořízení změny územně plánovací dokumentace ze změny politiky územního rozvoje nebo nadřazené územně plánovací dokumentace, uhradí náklady ~~uvedené v § 91 odst. 1~~ **na pořízení změny** na žádost ~~ministerstvo~~ **pořizovatele ten**, ~~jedná-li se o politiku územního rozvoje nebo územní rozvojový plán, nebo územní samosprávný celek, který vydal nadřazenou územně plánovací dokumentaci~~ **kdo potřebu změny vyvolal**. {uc=A}

(2) Odstavec 1 se nepoužije, byla-li příslušná část politiky územního rozvoje nebo nadřazené územně plánovací dokumentace, která změnu vyvolala, vydána na základě výhradní potřeby obce nebo kraje, nebo je-li ve prospěch rozvoje obce nebo kraje příslušných ke schválení navazující územně plánovací dokumentace.

(3) Je-li pořízení změny územně plánovací dokumentace nebo pořízení regulačního plánu vyvoláno výhradní potřebou toho, kdo dal ke změně podnět, může ~~schvalující orgán~~ **pořizovatel** podmínit jejich pořízení částečnou nebo úplnou úhradou nákladů ~~uvedených v odstavci 1 a v § 91 odst. 1~~ tím, kdo podnět dal. {uc=A}

#### § 93 — Návrh územně plánovací dokumentace  `[272 Čl.I/190; 272 Čl.I/207; 272 Čl.I/208; 272 Čl.I/209; 272 Čl.I/210]` {uc=A}

(1) Schválené zadání předá pořizovatel bezodkladně projektantovi územně plánovací dokumentace, který zajistí zpracování návrhu územně plánovací dokumentace. Je-li vyžadováno zpracování vyhodnocení vlivů, zajistí jeho zpracování pořizovatel.

(2) Po obdržení návrhu územně plánovací dokumentace a vyhodnocení vlivů, zpracovává-li se, pořizovatel v součinnosti s určeným zastupitelem**, je-li určen,** bez zbytečného odkladu vyhodnotí zejména jejich úplnost, soulad s požadavky tohoto zákona a jeho prováděcích právních předpisů, soulad se zadáním a soulad s nadřazenou územně plánovací dokumentací. {uc=A}

(3) Nesplňuje-li návrh územně plánovací dokumentace požadavky uvedené v odstavci 2, zpracuje pořizovatel v součinnosti s určeným zastupitelem**, je-li určen,** pokyny k jeho dopracování. Pořizovatel pokyny předá projektantovi do 7 dnů od jejich zpracování a stanoví mu přiměřenou lhůtu k jejich zapracování. Po obdržení dopracovaného návrhu se postup podle odstavce 2 a tohoto odstavce použije přiměřeně. {uc=A}

(4) Pro vyhodnocení vlivů, zpracovává-li se, se postup podle odstavce 3 použije obdobně.

(5) Pořizovatel ~~do 7 dnů po kladném vyhodnocení podle odstavce 2~~ **bezodkladně** {uc=A}

a) zveřejní návrh územně plánovací dokumentace a vyhodnocení vlivů, zpracovává-li se, v národním geoportálu územního plánování a ~~vystaví je k nahlédnutí~~, {uc=A}

~~b) oznámí místo a dobu konání společného jednání a~~

~~c)~~ **b)** veřejnou vyhláškou oznámí místo a dobu konání veřejného projednání a ~~místa, kde je možné do návrhu územně plánovací dokumentace a vyhodnocení vlivů, zpracovává-li se, nahlédnout~~ **adresu zveřejnění v národním geoportálu územního plánování**. {uc=A}

#### ~~§ 94 — Společné jednání~~  `[272 Čl.I/211]` {uc=A}

> **Zrušuje se celý paragraf.**

~~(1) Pořizovatel oznámí místo, dobu konání společného jednání a adresu uložení návrhu územně plánovací dokumentace v národním geoportálu územního plánování jednotlivě dotčeným orgánům a dále v případě~~

~~a) územního rozvojového plánu krajům,~~

~~b) zásad územního rozvoje ministerstvu, sousedním krajům, a obcím v řešeném území a s řešeným územím sousedícím,~~

~~c) územního plánu obci, pro kterou je územní plán pořizován, krajskému úřadu, Ministerstvu obrany, je-li územní plán zpracováván pro obec sousedící s vojenským újezdem a sousedním obcím,~~

~~d) regulačního plánu obci, pro kterou je regulační plán pořizován.~~

~~(2) Společné jednání se koná nejdříve 15 dnů, nejpozději však 30 dnů od oznámení podle § 93 odst. 5.~~

~~(3) Dotčené orgány uplatní do 15 dnů ode dne konání společného jednání svá stanoviska k návrhu územně plánovací dokumentace a vyjádření k vyhodnocení vlivů. Ve stejné lhůtě mohou orgány a osoby uvedené v odstavci 1 uplatnit připomínky. Ke stanoviskům a připomínkám uplatněným po uvedené lhůtě nebo uplatněným ve věcech, o nichž bylo rozhodnuto v nadřazené územně plánovací dokumentaci, se nepřihlíží.~~

#### § 95 — Přeshraniční konzultace  `[272 Čl.I/61]` {uc=A}

(1) Je-li ve vyhodnocení vlivů zjištěn významný negativní vliv na území sousedního státu, pořizovatel prostřednictvím Ministerstva životního prostředí a Ministerstva zahraničních věcí zašle návrh územně plánovací dokumentace a vyhodnocení vlivů příslušnému orgánu sousedního státu22), jehož území může být uplatňováním územně plánovací dokumentace významně ovlivněno, a nabídne mu konzultace.

(2) Projeví-li příslušný orgán sousedního státu o konzultace zájem, pořizovatel přizve k účasti příslušný orgán sousedního státu, Ministerstvo zahraničních věcí, Ministerstvo životního prostředí, určeného zastupitele a ~~ministerstvo~~ **Úřad**, není-li pořizovatelem projednávané územně plánovací dokumentace. {uc=A}

#### § 96 — Veřejné projednání  `[272 Čl.I/212; 272 Čl.I/213; 272 Čl.I/214; 272 Čl.I/215; 272 Čl.I/216]` {uc=A}

(1) Veřejným projednáním se rozumí prezentace návrhu územně plánovací dokumentace a vyhodnocení vlivů, zpracovává-li se, veřejnosti**, dotčeným orgánům a územním samosprávným celkům** se zajištěním odborného výkladu, který zajistí pořizovatel ve spolupráci s projektantem, a umožnění dotazů ~~veřejnosti~~. {uc=A}

(2) Veřejné projednání nařizuje pořizovatel po dohodě s určeným zastupitelem ~~postupem podle § 93 odst. 5 písm. c)~~**, je-li určen**. Je-li to účelné, nařídí pořizovatel více veřejných projednání na jím určených místech nebo konání veřejného projednání formou dálkového přístupu. Pro počítání lhůt stanovených zákonem je rozhodný den konání posledního veřejného projednání. {uc=A}

(3) Veřejné projednání se koná **nejdříve 15 dnů a** nejpozději třicátý den ode dne doručení veřejné vyhlášky podle § 93 odst. 5. {uc=A}

**(4) Pořizovatel oznámí místo a dobu konání veřejného projednání a adresu uložení návrhu územně plánovací dokumentace v národním geoportálu územního plánování jednotlivě dotčeným orgánům a adresátům uvedeným v § 88.** {uc=A}

~~(4)~~ **(5)** Z průběhu veřejného projednání pořizovatel pořídí písemný záznam **a stanoviska**. {uc=A}

#### § 97 — Připomínky  `[272 Čl.I/218]` {uc=A}

(1) Do 15 dnů ode dne veřejného projednání může každý uplatnit písemně své připomínky k návrhu územně plánovací dokumentace a vyhodnocení vlivů, zpracovává-li se. K připomínkám uplatněným po stanovené lhůtě nebo uplatněným ve věcech, o kterých bylo rozhodnuto v nadřazené územně plánovací dokumentaci, se nepřihlíží.

(2) Připomínka musí kromě obecných náležitostí podání podle správního řádu obsahovat odůvodnění a vymezení území dotčeného připomínkou.

(3) Obsahuje-li návrh územně plánovací dokumentace varianty řešení, uplatňují se připomínky ke každé variantě samostatně.

(4) Proti návrhu územně plánovací dokumentace nelze podat námitky podle části šesté správního řádu.

**(5) Dotčené orgány uplatní do 15 dnů ode dne konání veřejného projednání svá stanoviska k návrhu územně plánovací dokumentace a vyjádření k vyhodnocení vlivů. Neuplatní-li dotčený orgán v této lhůtě stanovisko nebo vyjádření, platí, že s návrhem územně plánovací dokumentace souhlasí. Ke stanoviskům uplatněným po uvedené lhůtě nebo uplatněným ve věcech, o nichž bylo rozhodnuto v nadřazené územně plánovací dokumentaci, se nepřihlíží.** {uc=A}

#### § 98 — Vyhodnocení výsledků projednání  `[272 Čl.I/190; 272 Čl.I/219]` {uc=A}

(1) Pořizovatel v součinnosti s určeným zastupitelem**, je-li určen,** vyhodnotí uplatněná stanoviska a zajistí řešení případných rozporů. {uc=A}

(2) S ohledem na cíle a úkoly územního plánování zpracuje pořizovatel v součinnosti s určeným zastupitelem**, je-li určen,** návrh vyhodnocení připomínek uplatněných k návrhu územně plánovací dokumentace, včetně jeho odůvodnění, je-li navrženo připomínce nevyhovět nebo vyhovět pouze částečně. Věcně související připomínky lze vyhodnotit společně. {uc=A}

(3) Návrh vyhodnocení připomínek nesmí být v rozporu s právními předpisy, se stanovisky dotčených orgánů nebo s výsledkem řešení rozporů a s politikou územního rozvoje a nadřazenou územně plánovací dokumentací.

(4) Obsahuje-li návrh územně plánovací dokumentace varianty řešení, pořizovatel v součinnosti s projektantem a určeným zastupitelem**, je-li určen,** na základě uplatněných připomínek a stanovisek, vyhodnocení vlivů, zpracovává-li se, popřípadě na základě výsledků řešení rozporů, navrhne s ohledem na cíle a úkoly územního plánování výběr nejvhodnější varianty. {uc=A}

(5) Pořizovatel zašle bezodkladně návrh vyhodnocení připomínek a návrh výběru nejvhodnější varianty dotčeným orgánům a vyzve je, aby k nim ve lhůtě 30 dnů od obdržení uplatnily stanoviska. Neuplatní-li dotčený orgán stanovisko **a oprávněný investor vyjádření** v uvedené lhůtě, ~~má se za to~~ **platí**, že s návrhy pořizovatele souhlasí**; k později uplatněnému stanovisku nebo vyjádření se nepřihlíží**. {uc=A}

(6) Pořizovatel v součinnosti s určeným zastupitelem vyhodnotí uplatněná stanoviska podle odstavce 5 a, je-li to nezbytné, zajistí řešení případných rozporů.

#### ~~§ 99 — Informování zastupitelstva~~  `[272 Čl.I/220]` {uc=A}

> **Zrušuje se celý paragraf.**

~~(1) Určený zastupitel může předložit zastupitelstvu návrh výběru nejvhodnější varianty a návrh vyhodnocení připomínek uplatněných k návrhu územně plánovací dokumentace k projednání.~~

~~(2) Předloží-li určený zastupitel návrhy podle odstavce 1 na jednání zastupitelstva, zastupitelstvo je projedná ve lhůtě 60 dnů. Neprojedná-li zastupitelstvo návrhy ve lhůtě podle věty první, platí, že s nimi souhlasí.~~

~~(3) Nesouhlasí-li zastupitelstvo s návrhy podle odstavce 1, vrátí je určenému zastupiteli se svými pokyny k úpravě, v opačném případě je vezme na vědomí.~~

~~(4) Pokyny zastupitelstva nesmí být v rozporu s právními předpisy, se stanovisky dotčených orgánů nebo s výsledkem řešení rozporů a s nadřazenou územně plánovací dokumentací.~~

~~(5) Určený zastupitel předá pokyny k úpravě návrhů podle odstavce 1 bezodkladně pořizovateli. Pořizovatel v součinnosti s určeným zastupitelem zajistí úpravu návrhů podle pokynů zastupitelstva.~~

#### § 100 — Stanovisko k návrhu koncepce  `[272 Čl.I/221]` {uc=A}

(1) Zpracovává-li se vyhodnocení vlivů, pořizovatel bezodkladně zašle návrh vyhodnocení připomínek, výsledky konzultací a návrh vyhodnocení uplatněných stanovisek, popřípadě výsledky řešení rozporů a návrh výběru nejvhodnější varianty příslušnému úřadu jako podklad pro vydání stanoviska k návrhu koncepce podle § 10g zákona o posuzování vlivů na životní prostředí.

(2) Příslušný úřad uplatní stanovisko k návrhu územního rozvojového plánu, zásad územního rozvoje nebo územního plánu, je-li předmětem posuzování, do 30 dnů od obdržení podkladů podle odstavce 1. Stanovisko podle věty první není stanoviskem podle § 54 odst. ~~1~~ **2**. ~~Nejde-li o změnu územního plánu, lze lhůtu pro uplatnění stanoviska ze závažných důvodů usnesením, které se pouze poznamenává do spisu, prodloužit, nejdéle však o 30 dnů. Příslušný úřad vyrozumí bezodkladně pořizovatele o prodloužení lhůty.~~ {uc=A}

(3) Neuplatní-li příslušný úřad stanovisko ve lhůtě podle odstavce 2, je možné územní rozvojový plán, zásady územního rozvoje nebo územní plán vydat i bez jeho stanoviska; v takovém případě pořizovatel zohlední závěry vyhodnocení vlivů, připomínky a výsledky konzultací.

(4) Vyplyne-li z posouzení vlivu na evropsky významnou lokalitu nebo ptačí oblast, že územní rozvojový plán, zásady územního rozvoje nebo územní plán mají významný negativní vliv na předmět ochrany nebo celistvost některé evropsky významné lokality nebo ptačí oblasti, který nebyl předmětem posouzení nadřazené územně plánovací dokumentace z hlediska těchto vlivů, postupuje se podle § 45i zákona o ochraně přírody a krajiny. Kompenzační opatření uvede příslušný orgán ochrany přírody ve svém stanovisku.

#### § 101 — Stanovisko nadřízeného orgánu  `[272 Čl.I/222; 272 Čl.I/223]` {uc=A}

(1) Pořizovatel zásad územního rozvoje a územního plánu zašle návrh vyhodnocení připomínek, výsledky konzultací a návrh vyhodnocení stanovisek, popřípadě výsledky řešení rozporů a návrh výběru nejvhodnější varianty nadřízenému orgánu.

(2) Nadřízený orgán zašle pořizovateli stanovisko k návrhu zásad územního rozvoje nebo územního plánu z hledisek zajištění koordinace využívání území s ohledem na širší územní vztahy a souladu s politikou územního rozvoje a nadřazenou územně plánovací dokumentací ve lhůtě 30 dnů od obdržení podkladů podle odstavce 1. ~~Nejde-li o změnu územního plánu, lhůtu podle věty první lze ze závažných důvodů usnesením, které se pouze poznamenává do spisu, prodloužit, nejdéle však o 30 dnů. Nadřízený orgán vyrozumí bezodkladně pořizovatele o prodloužení lhůty.~~ {uc=A}

(3) Neuplatní-li nadřízený orgán stanovisko ve lhůtě podle odstavce 2 ~~věty první~~, ~~nebo ve lhůtě prodloužené~~ **platí**, ~~je možné zásady~~ **že s návrhem zásad** územního rozvoje nebo ~~územní plán vydat i bez jeho stanoviska~~ **územního plánu souhlasí**. **Ke stanovisku nadřízeného orgánu uplatněnému po uvedené lhůtě se nepřihlíží.** {uc=A}

(4) Upozorní-li nadřízený orgán ve svém stanovisku pořizovatele na nedostatky z hledisek uvedených v odstavci 2, lze návrh předložit schvalujícímu orgánu ke schválení až na základě potvrzení nadřízeného orgánu o odstranění nedostatků.

##### Úprava návrhu a opakované projednání

#### § 102  `[272 Čl.I/224; 272 Čl.I/225]` {uc=A}

(1) Pořizovatel v součinnosti s určeným zastupitelem ~~vypracuje pokyny pro~~**, je-li určen, zajistí** úpravu ~~návrhu~~ územně plánovací dokumentace v souladu s vyhodnocením výsledků projednání, stanoviskem k návrhu koncepce a se stanoviskem nadřízeného orgánu a předá je projektantovi. Obsahoval-li návrh varianty řešení, je součástí pokynů výběr nejvhodnější varianty. {uc=A}

(2) ~~Projektant na základě pokynů podle odstavce 1 upraví návrh~~ **Úprava návrhu** územně plánovací dokumentace **může obsahovat další drobné změny, které se podstatně nedotýkají práv dotčených osob ani veřejných zájmů chráněných dotčenými orgány, a změny odůvodnění**. **“. 226. Pod označení § 103 se vkládá nadpis, který zní: „Podstatná úprava** Obsahoval-li návrh varianty řešení, doplní odůvodnění o schéma variant a zdůvodnění výběru nejvhodnější varianty. {uc=A}

#### § 103  `[272 Čl.I/227; 272 Čl.I/228; 272 Čl.I/229]` {uc=A}

(1) Dojde-li na základě projednání k upravení návrhu územně plánovací dokumentace, při němž jsou nově **podstatně** negativně dotčeny veřejné zájmy nebo v případě územního plánu nebo regulačního plánu **podstatně** negativně dotčeno vlastnictví pozemků a staveb a dotčený orgán ~~ani~~**, nadřízený orgán, oprávněný investor nebo** vlastník neměli možnost k upravené dokumentaci uplatnit stanovisko nebo připomínku (dále jen „podstatná úprava“), nařídí pořizovatel bez zbytečného odkladu nové projednání v rozsahu podstatné úpravy**, ledaže dotčený orgán, nadřízený orgán, oprávněný investor nebo vlastník, kteří neměli možnost k upravené dokumentaci uplatnit stanovisko nebo připomínku, s takovou změnou souhlasí**. ~~Za podstatnou úpravu se nepovažuje~~ **Podstatnou úpravou není uvedení návrhu do souladu s nadřazenou územně plánovací dokumentací, zpřesnění návrhu podle § 73 odst. 4 a 5, omezení rozsahu nebo podmínek územní rezervy, přechodné ustanovení podle § 72 odst. 3,** zúžení návrhu na nejvhodnější variantu ~~ani~~**,** jiný způsob grafického vyjádření nebo vnitřního uspořádání prostorových dat**, a dále se souhlasem vlastníka pozemku a oprávněného investora úprava nebo zpřesnění hranic ploch nebo koridorů, etapizace, doplnění podmínky pro rozhodování v území, doplnění prvků regulačního plánu do územního plánu nebo změna objemu, výšky, koeficientu nebo kapacity nepřesahující 10 %**. {uc=A}

(2) Pořizovatel si k podstatné úpravě návrhu územního rozvojového plánu, zásad územního rozvoje a územního plánu vyžádá stanovisko orgánu ochrany přírody podle § 45i zákona o ochraně přírody a krajiny a stanovisko příslušného úřadu, ve kterém bude stanoveno, zda je nutné vyhodnocení vlivů upravit nebo zda vyžaduje podstatná úprava doplnit posouzení vlivů na životní prostředí. Stanovisko příslušný úřad vydá do 20 dnů od doručení žádosti pořizovatele. Příslušný orgán ochrany přírody doručí stanovisko pořizovateli a příslušnému úřadu nejpozději 7 dní před uplynutím lhůty podle věty druhé.

(3) Podstatná úprava se projednává v rozsahu měněných částí postupem podle ~~§~~ 93 odst. 5, § ~~94~~ **95** až ~~99~~ **98** a podle odstavců 1 a 2~~; společné jednání a veřejné projednání lze při splnění požadavků kladených na obě jednání spojit~~. Stanoviska, připomínky a vyjádření je možné uplatnit jen k podstatné úpravě, jinak se k nim nepřihlíží. {uc=A}

(4) Vyhodnocení vlivů, které sloužilo jako podklad pro projednání návrhu územně plánovací dokumentace, se s výjimkou případu, kdy tak stanoví příslušný úřad podle odstavce 2, neupravuje.

(5) ~~Do 15~~ **Stanovisko nadřízeného orgánu k podstatné úpravě návrhu zásad územního rozvoje a územního plánu uplatní nadřízený orgán do 30** dnů ode dne konání opakovaného ~~veřejného~~ projednání ~~uplatní stanovisko~~**; pro obsah stanoviska, postup při jeho nevydání ve stanovené lhůtě a pro případ upozornění na nedostatky se postupuje obdobně podle § 101 odst. 2 až 4.** {uc=A}

~~a) příslušný úřad k podstatné úpravě návrhu územního rozvojového plánu, zásad územního rozvoje a územního plánu; pro jeho obsah, postup při jeho nevydání ve stanovené lhůtě a pro stanovení kompenzačních opatření se postupuje podle § 100 odst. 2 až 4 obdobně, a~~

~~b) nadřízený orgán k podstatné úpravě návrhu zásad územního rozvoje a územního plánu; pro jeho obsah, postup při jeho nevydání ve stanovené lhůtě a pro případ upozornění na nedostatky se postupuje podle § 101 odst. 2 až 4 obdobně.~~

(6) Vyžaduje-li návrh územně plánovací dokumentace na základě výsledku projednání podstatné úpravy další úpravy, postupuje se přiměřeně podle § 102, a je-li to nezbytné, obdobně podle odstavců 1 až 5.

##### Vydání územně plánovací dokumentace

#### § 104  `[272 Čl.I/190; 272 Čl.I/230; 272 Čl.I/231; 272 Čl.I/232]` {uc=A}

(1) Pořizovatel v součinnosti s určeným zastupitelem**, je-li určen,** bezodkladně předloží schvalujícímu orgánu návrh územně plánovací dokumentace s odůvodněním. Obsahoval-li návrh územně plánovací dokumentace varianty řešení, je součástí předkládaného návrhu také návrh výběru nejvhodnější varianty podle § 98 odst. 4. ~~Návrh územně plánovací dokumentace musí být v souladu~~ {uc=A}

a) s požadavky tohoto zákona a jeho prováděcích právních předpisů,

b) se stanovisky dotčených orgánů, popřípadě s výsledkem řešení rozporů a

c) s politikou územního rozvoje a nadřazenou územně plánovací dokumentací.

(2) Schvalující orgán schválí výběr nejvhodnější varianty, obsahuje-li ji předložený návrh, a ~~vydá~~ **schválí** územně plánovací dokumentaci ~~po ověření, že není v rozporu s požadavky uvedenými v odstavci 1 písm. a) a b) a nadřazenou územně plánovací dokumentací~~. Nesouhlasí-li schvalující orgán s předloženým návrhem, **může jej sám změnit, nedojde-li tím k podstatné úpravě, nebo** schválí pokyny k úpravě územně plánovací dokumentace, které předá pořizovateli, ~~nebo~~ **anebo** návrh zamítne a ukončí tím její pořizování. {uc=A}

(3) Nevyvolají-li pokyny k úpravě podstatnou úpravu, pořizovatel zajistí úpravu návrhu územně plánovací dokumentace a poté jej předloží schvalujícímu orgánu ~~k vydání~~. Vyvolají-li pokyny k úpravě podstatnou úpravu, postupuje pořizovatel obdobně podle § 103. {uc=A}

#### § 105  `[272 Čl.I/233; 272 Čl.I/234; 272 Čl.I/235]` {uc=A}

(1) Pořizovatel po ~~vydání~~ **schválení** územně plánovací dokumentace zajistí její **vydání vložením do národního geoportálu územního plánování. Okamžikem** vložení do národního geoportálu územního plánování **je územně plánovací dokumentace platná**. {uc=A}

(2) ~~Územně~~ **Vydání územně** plánovací ~~dokumentaci~~ **dokumentace** a adresu jejího uložení v národním geoportálu územního plánování oznámí pořizovatel veřejnou vyhláškou; dnem doručení veřejné vyhlášky nabývá územně plánovací dokumentace účinnosti**, není-li v ní stanovena účinnost pozdější**. {uc=A}

(3) Územně plánovací ~~dokumentace se~~ **dokumentaci** opatří **pořizovatel** záznamem o účinnosti~~, který obsahuje~~**.** {uc=A}

~~a) označení orgánu, který územně plánovací dokumentaci vydal,~~

~~b) datum nabytí účinnosti územně plánovací dokumentace,~~

~~c) jméno, příjmení, funkci a podpis oprávněné úřední osoby pořizovatele a otisk úředního razítka.~~

##### ~~Oddíl 3~~

*~~Vyhodnocování územně plánovací dokumentace~~*

#### ~~§ 106 — Vyhodnocování uplatňování územně plánovací dokumentace~~  `[272 Čl.I/236]` {uc=A}

> **Zrušuje se celý paragraf.**

~~(1) Pořizovatel nejpozději do 4 let od vydání územně plánovací dokumentace, s výjimkou regulačního plánu, a poté pravidelně nejméně jednou za 4 roky vyhodnotí uplatňování územně plánovací dokumentace.~~

~~(2) Za účelem vyhodnocení uplatňování zásad územního rozvoje a územního plánu zastupitelstvo na žádost pořizovatele určí určeného zastupitele, není-li určen na celé volební období.~~

#### ~~§ 107 — Zpráva o uplatňování~~  `[272 Čl.I/236]` {uc=A}

> **Zrušuje se celý paragraf.**

~~(1) Pořizovatel v součinnosti s určeným zastupitelem zpracuje návrh zprávy o uplatňování územně plánovací dokumentace, s výjimkou regulačního plánu, (dále jen „zpráva o uplatňování“).~~

~~(2) Zpráva o uplatňování obsahuje zejména~~

~~a) vyhodnocení uplatňování územně plánovací dokumentace,~~

~~b) problémy k řešení v územně plánovací dokumentaci vyplývající z územně analytických podkladů,~~

~~c) vyhodnocení souladu územně plánovací dokumentace s politikou územního rozvoje a nadřazenou územně plánovací dokumentací,~~

~~d) vyhodnocení vlivů uplatňování územně plánovací dokumentace na udržitelný rozvoj území z hlediska jejich možných nepředvídaných dopadů, včetně potřeby opatření na jejich odvrácení, zmírnění nebo kompenzaci,~~

~~e) vyhodnocení potřeby pořízení změny územně plánovací dokumentace nebo nové územně plánovací dokumentace,~~

~~f) vyhodnocení podnětů na změnu územně plánovací dokumentace,~~

~~g) podnět na změnu nadřazené územně plánovací dokumentace nebo politiky územního rozvoje.~~

~~(3) Vyplyne-li z vyhodnocení podle odstavce 2 písm. e) potřeba pořízení změny územně plánovací dokumentace nebo nové územně plánovací dokumentace, je součástí zprávy o uplatňování návrh zadání změny územně plánovací dokumentace (dále jen „zadání změny“) nebo návrh zadání. Na projednání a schválení návrhu zprávy o uplatňování, návrhu zadání změny nebo návrhu zadání, jsou-li jejím obsahem, se použijí § 88 až 90 obdobně.~~

~~(4) Při pořizování nové územně plánovací dokumentace navazující na schválené zadání podle odstavce 3 se dále postupuje podle § 91 až 105.~~

~~(5) Při pořizování změny územně plánovací dokumentace navazující na schválené zadání změny podle odstavce 3 se postupuje podle § 111 odst. 5 obdobně.~~

##### Oddíl 3

*Změna územně plánovací dokumentace*

#### § 108 — Obecná ustanovení  `[272 Čl.I/237; 272 Čl.I/238; 272 Čl.I/239; 272 Čl.I/240]` {uc=A}

(1) Změna územně plánovací dokumentace se zpracovává, projednává**, schvaluje** a vydává v rozsahu měněných částí. {uc=A}

(2) Pořizovatel po ~~vydání~~ **schválení** změny územně plánovací dokumentace zajistí zpracování úplného znění a změnu územně plánovací dokumentace i její úplné znění ~~vloží~~ **vydá vložením** do národního geoportálu územního plánování. {uc=A}

(3) ~~Změnu~~ **Informaci o změně** územně plánovací dokumentace~~, úplné znění územně plánovací dokumentace po této změně~~ a ~~adresy jejich~~ **adresu jejího** uložení v národním geoportálu územního plánování oznámí pořizovatel veřejnou vyhláškou; dnem doručení veřejné vyhlášky nabývá změna účinnosti. {uc=A}

~~(4) Jedná-li se o změnu územního plánu, lze další zastavitelné plochy touto změnou vymezit pouze na základě prokázání potřeby vymezení nových zastavitelných ploch.~~ {uc=A}

#### § 109 — Rozhodnutí o změně  `[272 Čl.I/241; 272 Čl.I/242; 272 Čl.I/243; 272 Čl.I/244; 272 Čl.I/245; 272 Čl.I/246; 272 Čl.I/247; 272 Čl.I/248; 272 Čl.I/249]` {uc=A}

(1) Nejde-li o změnu územního rozvojového plánu pořizovanou na základě změny politiky územního rozvoje ~~nebo nejde-li o změnu pořizovanou na základě zprávy o uplatňování~~, schvalující orgán rozhoduje o pořízení změny z vlastního podnětu nebo z podnětu {uc=A}

a) oprávněného investora,

b) ~~ministerstva~~ **Úřadu**, jiného ústředního správního úřadu nebo rady kraje v případě územního rozvojového plánu, není-li změna podmíněna změnou politiky územního rozvoje, {uc=A}

c) orgánu veřejné správy v případě zásad územního rozvoje, územního plánu nebo regulačního plánu,

~~d) organizace podle horního zákona, v případě zásad územního rozvoje,~~

~~e)~~ **d)** občana obce nebo osoby, která má vlastnická nebo jiná věcná práva k pozemku nebo stavbě na území obce v případě územního plánu nebo regulačního plánu.

(2) Podnět na pořízení změny podle odstavce 1 se podává ~~v případě územního rozvojového plánu u ministerstva, v ostatních případech~~ u příslušného ~~schvalujícího orgánu~~ **pořizovatele** a obsahuje {uc=A}

a) údaje umožňující identifikaci navrhovatele podnětu, včetně uvedení skutečnosti prokazující, že je oprávněn podat podnět na pořízení změny územně plánovací dokumentace,

b) název územně plánovací dokumentace, kterou navrhuje změnit,

c) předmět změny a důvody pro její pořízení,

d) návrh úhrady nákladů ~~uvedených v § 91 odst~~. ~~1 a § 92.~~ {uc=A}

(3) ~~Podnět může dále obsahovat návrh zadání změny a nejde~~ **Nejde** -li o změnu regulačního plánu**, může podnět dále obsahovat** také {uc=A}

a) stanovisko příslušného orgánu ochrany přírody podle zákona o ochraně přírody a krajiny k navrhovanému obsahu změny územně plánovací dokumentace, ve kterém uvede, zda je možné vyloučit významný vliv na evropsky významnou lokalitu nebo ptačí oblast,

b) stanovisko příslušného úřadu k navrhovanému obsahu změny územně plánovací dokumentace, ve kterém i s přihlédnutím ke stanovisku orgánu ochrany přírody podle písmene a) uvede, zda má být návrh změny posuzován z hlediska vlivů na životní prostředí, popřípadě stanoví podrobnější požadavky podle § 10i zákona o posuzování vlivů na životní prostředí**; ustanovení § 89 odst**. **4 platí obdobně.** {uc=A}

(4) ~~Obsahové náležitosti zadání změny územně plánovací dokumentace stanoví prováděcí právní předpis~~ **Stanovisko podle odstavce 3 písm**. **a) doručí orgán ochrany přírody navrhovateli podnětu a příslušnému úřadu do 20 dnů od obdržení žádosti o jeho vydání. Stanovisko podle odstavce 3 písm. b) doručí příslušný úřad navrhovateli podnětu do 30 dnů od obdržení žádosti o jeho vydání.** {uc=A}

(5) ~~Obsahuje-li podnět~~ **Rozhodnutí o pořízení regulačního plánu nebo územního plánu může zastupitelstvo kraje nebo obce nahradit schválením plánovací smlouvy, ve které se stavebník zaváže ke zpracování nebo převzetí nákladů** na ~~pořízení změny náležitosti podle odstavce 3, předá jej schvalující orgán bezodkladně pořizovateli, v ostatních případech se podnět vyhodnotí postupem podle § 107 odst~~ **zpracování návrhu zadání regulačního plánu nebo územního plánu nebo návrhu regulačního plánu nebo územního plánu**. ~~2 písm. f).~~ {uc=A}

#### § 110 — Posouzení podnětu  `[272 Čl.I/250; 272 Čl.I/251; 272 Čl.I/252]` {uc=A}

(1) Pořizovatel posoudí nejpozději do 30 dnů od jeho obdržení podnět podle § 109 z hlediska jeho úplnosti a souladu ~~návrhu zadání změny~~ {uc=A}

a) s tímto zákonem a jeho prováděcími právními předpisy,

b) se stanovisky podle § 109 odst. 3, a

c) s politikou územního rozvoje a nadřazenou územně plánovací dokumentací.

(2) Není-li podnět úplný nebo vykazuje-li nedostatky z hledisek uvedených v odstavci 1 a ten, kdo podnět dal, ani na výzvu pořizovatele nedostatky neodstraní ve stanovené lhůtě, pořizovatel podnět odloží a informuje o tom toho, kdo podnět dal~~, a schvalující orgán~~. {uc=A}

**(3) Nejde-li o změnu regulačního plánu a podnět neobsahuje stanoviska podle § 109 odst. 3, zajistí tato stanoviska pořizovatel. Ustanovení § 109 odst. 4 platí obdobně.** {uc=A}

#### § 111 — Zpracování a projednání změny  `[272 Čl.I/253; 272 Čl.I/254; 272 Čl.I/255; 272 Čl.I/256; 272 Čl.I/257; 272 Čl.I/258; 272 Čl.I/259]` {uc=A}

~~(1) Je-li změna pořizována z vlastního podnětu a neobsahoval-li tento podnět návrh zadání změny, zpracuje návrh zadání změny pořizovatel v součinnosti s určeným zastupitelem obdobně podle § 87 odst. 2 a 3 a dále postupuje obdobně podle § 89 odst. 1 až 4 a 6.~~ {uc=A}

~~(2)~~ **(1)** Pořizovatel bez zbytečného odkladu předloží ~~návrh zadání~~ **podnět na pořízení** změny se svým vyjádřením k projednání schvalujícímu orgánu. {uc=A}

~~(3)~~ **(2)** Souhlasí-li schvalující orgán s ~~návrhem zadání~~ **podnětem na pořízení** změny, rozhodne o pořízení změny územně plánovací dokumentace a ~~schválí její zadání~~ **o jejím obsahu**. Nesouhlasí-li schvalující orgán s ~~návrhem~~ **podnětem**, ~~vrátí~~ **zamítne** jej ~~pořizovateli se svými pokyny k úpravě, nebo jej zamítne~~. {uc=A}

~~(4)~~ **(3)** ~~Schvalující orgán~~ **Pořizovatel** může podmínit pořízení změny územně plánovací dokumentace úhradou nákladů ~~podle § 91 odst. 1 a § 92~~ tím, kdo dal ke změně podnět. ~~Schvalující orgán může rozhodnout o sloučení společného jednání a veřejného projednání. Veřejné projednání musí v takovém případě splňovat také požadavky tohoto zákona na společné jednání.~~ {uc=A}

**(4) Vyplyne-li ze stanovisek podle § 109 odst. 3, že návrh změny územně plánovací dokumentace má být posuzován z hlediska vlivů na životní prostředí, doplní pořizovatel rozhodnutí o pořízení změny o požadavek na vyhodnocení vlivů.** {uc=A}

(5) Při pořizování změny územně plánovací dokumentace se dále postupuje podle § ~~90 odst. 3, §~~ 93 až ~~104, §~~ 105 ~~odst. 3 a § 108~~ obdobně. **Pokud se v těchto ustanoveních odkazuje na zadání, rozumí se tím pro účely pořizování změny rozhodnutí schvalujícího orgánu o pořízení změny a o jejím obsahu.** {uc=A}

**(6) Opravu chyb a zřejmých nesprávností územně plánovací dokumentace provede pořizovatel kdykoli bez řízení; pro vymezení zastavitelného území a pro územní opatření to platí obdobně.** {uc=A}

#### § 111a  `[272 Čl.I/260]` {uc=A}

**Nepodstatná změna v zastavitelném území Při změně územně plánovací dokumentace v zastavitelném území, která nevyžaduje posouzení vlivů a kterou dochází pouze k uvedení do souladu s nadřazenou územně plánovací dokumentací, zpřesnění podle § 73 odst. 4 a 5, omezení rozsahu nebo podmínek územní rezervy, úpravě hranic ploch nebo koridorů, doplnění, změně nebo vypuštění podmínky pro rozhodování v území, doplnění, změně nebo vypuštění prvků regulačního plánu v územním plánu, doplnění, zrušení nebo změně etapizace výstavby, změně podrobného využití plochy při zachování základního způsobu jejího využití, změně objemu, výšky, koeficientu nebo kapacity nepřesahující 25 % nebo ke změně v souvislosti s obnovou podle § 264 se postupuje podle ustanovení tohoto oddílu s tím, že obdobně se použijí pouze § 96 až 98, § 101, § 102, § 104 a § 105; lhůty uvedené v § 98 odst. 5, § 101 odst. 2 a § 110 odst. 1 se zkracují na polovinu.** {uc=A}

##### Oddíl 4

*Společná ustanovení*

#### § 112 — Zvláštní postupy  `[272 Čl.I/261]` {uc=A}

(1) Kraj a obec jsou povinny bez zbytečného odkladu územně plánovací dokumentaci, kterou vydaly, uvést do souladu s nadřazenou územně plánovací dokumentací. Do té doby nelze rozhodovat podle částí územně plánovací dokumentace, které jsou v rozporu s nadřazenou územně plánovací dokumentací. Vyhodnocení vlivů navazuje na vyhodnocení vlivů nadřazené územně plánovací dokumentace. Vlivy, které byly posouzeny v nadřazené územně plánovací dokumentaci, se v rozsahu a podrobnosti, v jaké byly v této dokumentaci posouzeny, znovu neposuzují**, ledaže jde o zpřesnění podle § 73 odst**. **4 a 5.** {uc=A}

(2) Znemožňuje-li územně plánovací dokumentace kraje nebo obce nebo její část realizaci záměru obsaženého v nadřazené územně plánovací dokumentaci, tato část navazující územně plánovací dokumentace se pro rozhodování v území ani pro pořizování navazující územně plánovací dokumentace nepoužije a rozhoduje se podle nadřazené územně plánovací dokumentace.

#### § 113 — Zrušení územně plánovací dokumentace schvalujícím orgánem  `[272 Čl.I/262; 272 Čl.I/263]` {uc=A}

(1) Územní rozvojový plán, zásady územního rozvoje a územní plán může schvalující orgán zrušit pouze současně s vydáním nového územního rozvojového plánu, zásad územního rozvoje nebo územního plánu.

(2) Zastupitelstvo může zrušit regulační plán v případě, že se změnily podstatně podmínky, za kterých byl pořízen a vydán a není-li řešení v něm obsažené již aktuální. **Tento postup nepodléhá řízení podle § 87 až 111a. Zrušení regulačního plánu pořizovatel oznámí veřejnou vyhláškou; dnem jejího doručení nabývá zrušení regulačního plánu účinnosti a pořizovatel zveřejní informaci o zrušení regulačního plánu v národním geoportálu územního plánování.** {uc=A}

~~(3) Návrh na zrušení regulačního plánu se projednává obdobně podle § 94, 96, 97 a § 98 odst. 1 až 3; ustanovení o vyhodnocení vlivů a variant řešení se nepoužijí.~~ {uc=A}

~~(4) Zastupitelstvo obce může zrušit regulační plán, je-li to v souladu se stanovisky dotčených orgánů nebo s výsledkem řešení rozporů. Odůvodnění opatření obecné povahy vždy obsahuje prokázání podmínky uvedené ve větě první a vyhodnocení připomínek.~~ {uc=A}

~~(5) Zrušení regulačního plánu pořizovatel oznámí veřejnou vyhláškou; dnem jejího doručení nabývá zrušení regulačního plánu účinnosti.~~ {uc=A}

~~(6) Do 7 dnů po nabytí účinnosti zrušení regulačního plánu pořizovatel v národním geoportálu územního plánování~~ {uc=A}

~~a) oznámí zrušení regulačního plánu,~~ {uc=A}

~~b) vypustí zrušený regulační plán.~~ {uc=A}

#### § 114 — Následky zrušení územně plánovací dokumentace  `[272 Čl.I/69; 272 Čl.I/102; 272 Čl.I/264; 272 Čl.I/265; 272 Čl.I/266; 272 Čl.I/267; 272 Čl.I/268]` {uc=A}

(1) Dojde-li ke zrušení územně plánovací dokumentace nebo její části nadřízeným orgánem územního plánování v přezkumném řízení nebo soudem, schvalující orgán bezodkladně rozhodne o

a) pokračování v pořizování územně plánovací dokumentace, přičemž pořizovatel naváže na poslední úkon, který nebyl zrušením dotčen,

b) pořízení nové územně plánovací dokumentace nebo její změny, nebo

c) zastavení pořizování v případě regulačního plánu nebo změny územně plánovací dokumentace.

(2) Při zrušení změny územně plánovací dokumentace platí územně plánovací dokumentace ve znění před touto změnou. Je-li to nezbytné, zajistí pořizovatel úpravu úplného znění.

(3) Obec nebo kraj zašlou ~~ministerstvu~~ **Úřadu** rozhodnutí soudu o tom, že byla zrušena jimi vydaná územně plánovací dokumentace nebo její část. ~~Ministerstvo~~ **Úřad** bezodkladně zajistí zveřejnění rozhodnutí soudu v národním geoportálu územního plánování. {uc=A}

(4) ~~Ministerstvo a krajský úřad~~ **Úřad** bezodkladně zajistí zveřejnění rozhodnutí o zrušení územně plánovací dokumentace nebo její části v přezkumném řízení v národním geoportálu územního plánování. {uc=A}

(5) Dojde-li ke zrušení územního plánu **nebo jeho části**, považuje se ~~zastavěné~~ **zastavitelné** území vymezené tímto územním plánem **nebo jeho částí** za ~~zastavěné~~ **zastavitelné** území vymezené podle tohoto zákona do doby vydání nového územního plánu nebo vymezení ~~zastavěného~~ **zastavitelného** území, nejdéle však po dobu 5 let. To neplatí, byla-li důvodem zrušení územního plánu také nezákonnost vymezení zastavěného území. Úřad ~~územního plánování~~ **rozvoje území kraje** ve lhůtě 3 měsíců vyhodnotí aktuálnost vymezení zastavěného území postupem podle § 121 a zajistí jeho vydání postupem podle § 120 **nebo jeho části**. {uc=A}

#### § 115 — Souběžné pořizování územně plánovací dokumentace

(1) Je-li k vydání různých územně plánovacích dokumentací příslušný tentýž schvalující orgán, může rozhodnout o souběžném pořízení navazující územně plánovací dokumentace a změny nadřazené územně plánovací dokumentace. Umožňuje-li to povaha projednávané územně plánovací dokumentace, může se projednání obou územně plánovacích dokumentací konat souběžně v jednom projednání.

(2) Při souběžném pořizování územně plánovacích dokumentací nemusí být navazující územně plánovací dokumentace v souladu s částmi nadřazené územně plánovací dokumentace, které mají být změněny souběžně pořizovanou změnou; vydání nadřazené územně plánovací dokumentace je podmínkou pro vydání navazující územně plánovací dokumentace.

(3) Je-li vyžadováno posouzení vlivů na životní prostředí, zpracovává se při postupu podle odstavců 1 a 2 vyhodnocení vlivů jen pro navazující územně plánovací dokumentaci a v podrobnosti, která této navazující dokumentaci odpovídá, je-li řešené území vyžadující posouzení shodné a byl-li stanoviskem orgánu ochrany přírody vyloučen vliv nadřazené a navazující územně plánovací dokumentace nebo její změny na předmět ochrany nebo celistvost evropsky významné lokality nebo ptačí oblasti.

(4) Ustanovení odstavce 3 se nepoužije, je-li navazující územně plánovací dokumentací regulační plán nebo jeho změna.

#### § 115a — **Společné pořizování územně plánovací dokumentace**  `[272 Čl.I/269]` {uc=A}

**(1) Schvalující orgány mohou rozhodnout o společném pořízení více územně plánovacích dokumentací stejného druhu a o jejich společném pořizovateli nebo o koordinaci pořizovatelů, pokud spolu souvisí.** {uc=A}

**(2) Podklady, návrhy a úkony ve společném pořizování lze sdružit a provádět společně. Změna společně pořizované územně plánovací dokumentace musí být schválena všemi schvalujícími orgány.** {uc=A}

##### Díl 5

*Vymezování ~~zastavěného~~ **zastavitelného** území*

##### ~~Oddíl 1~~

*~~Zastavěné území~~*

#### § 116  `[272 Čl.I/69; 272 Čl.I/272; 272 Čl.I/273; 272 Čl.I/274; 272 Čl.I/275; 272 Čl.I/276; 272 Čl.I/277; 272 Čl.I/278; 272 Čl.I/279]` {uc=A}

(1) Na území obce **bez účinného územního plánu** se vymezuje jedno, popřípadě více ~~zastavěných~~ **zastavitelných** území. Hranici jednoho ~~zastavěného~~ **zastavitelného** území tvoří čára vedená po hranici parcel, ve výjimečných případech ji tvoří spojnice lomových bodů stávajících hranic nebo bodů na těchto hranicích. {uc=A}

(2) Při vymezení ~~zastavěného~~ **zastavitelného** území se vychází z posledního účinného územního plánu. Nemá-li obec územní plán, je podkladem pro vymezení ~~zastavěného~~ **zastavitelného** území vymezení pozemků v zastavěné části obce ~~vymezené k 1. září 1966 vyznačené v mapách evidence nemovitostí (dále jen „intravilán~~ **podle územních analytických podkladů** “), ze kterého se vyjmou {uc=A}

a) vinice,

b) chmelnice,

c) lesní pozemky a

d) zemědělské pozemky přiléhající k hranici ~~intravilánu~~ **zastavěné části obce** netvořící stavební proluku. {uc=A}

(3) Do ~~zastavěného~~ **zastavitelného** území se dále ~~vždy~~ zahrnou {uc=A}

a) ~~zastavěné stavební~~ pozemky **zázemí stavby**, {uc=A}

b) stavební proluky,

c) další oplocené proluky mezi ~~zastavěnými stavebními~~ pozemky **zázemí stavby**, {uc=A}

d) veřejná prostranství,

e) pozemní komunikace nebo jejich části, ze kterých jsou vjezdy na ostatní pozemky zastavěného území a dráhy v části procházející ~~intravilánem~~ **zastavěnou částí obce** a ostatními pozemky zastavěného území, {uc=A}

f) další pozemky, které jsou obklopeny ostatními pozemky zastavěného území, s výjimkou pozemků vinic a chmelnic.

~~(4) Zastavěné území se vymezuje v územním plánu a aktualizuje se jeho změnou.~~ {uc=A}

##### ~~Oddíl 2~~

*~~Vymezení zastavěného území~~*

#### ~~§ 117 — Obecná ustanovení~~

> **Nahrazuje se novým zněním (níže).**

~~(1) Není-li vydán územní plán, pořizovatel zajistí bezodkladně v souladu s § 116 odst. 1 až 3 zpracování návrhu vymezení zastavěného území.~~

~~(2) Při vymezení zastavěného území se v něm vyznačí pozemky, které jsou nezastavitelné do doby vydání územního plánu (dále jen „nezastavitelný pozemek“), a to~~

~~a) pozemek veřejné zeleně a parku tvořící veřejné prostranství1),~~

~~b) v intravilánu lesní pozemek nebo soubor sousedících lesních pozemků o výměře větší než 0,5 ha,~~

~~c) pozemek zbořeniště, není-li obklopen zastavěnými stavebními pozemky.~~

~~(3) Na nezastavitelných pozemcích lze do doby vydání územního plánu povolit jen nezbytnou dopravní a technickou infrastrukturu neznemožňující jejich dosavadní využití.~~

~~(4) Vymezení zastavěného území vydává formou opatření obecné povahy úřad územního plánování pro celé území obce.~~

~~(5) Vymezení zastavěného území pozbývá platnosti vydáním územního plánu.~~

#### § 117 — **Vymezení zastavitelného území**  `[272 Čl.I/280]` {uc=A}

**(1) Není-li vydán územní plán, úřad rozvoje území kraje zajistí bezodkladně v souladu s § 116 odst. 1 až 3 zpracování návrhu vymezení zastavitelného území.** {uc=A}

**(2) Při vymezení zastavitelného území se v něm vyznačí nestavební plochy, a to** {uc=A}

**a) pozemek veřejné zeleně a parku tvořící veřejné prostranství1),** {uc=A}

**b) lesní pozemek nebo soubor sousedících lesních pozemků o výměře větší než 0,5 ha.** {uc=A}

**(3) Vymezení zastavitelného území vydává formou opatření obecné povahy úřad rozvoje území kraje.** {uc=A}

**(4) Vymezení zastavitelného území podle tohoto dílu pozbývá platnosti vydáním územního plánu.** {uc=A}

#### § 118 — Obsah  `[272 Čl.I/69; 272 Čl.I/281; 272 Čl.I/282]` {uc=A}

(1) Vymezení ~~zastavěného~~ **zastavitelného** území obsahuje textovou část a grafickou část. {uc=A}

(2) Textová část obsahuje zejména datum, k němuž je ~~zastavěné~~ **zastavitelné** území vymezeno. {uc=A}

(3) Grafická část obsahuje výkres vymezení ~~zastavěného~~ **zastavitelného** území, který se zpracovává nad mapovým podkladem v měřítku katastrální mapy a vydává se v měřítku katastrální mapy nebo 1: 5 000, a který obsahuje vyznačení hranic {uc=A}

a) zastavěného území a

b) ~~nezastavitelných pozemků~~ **nestavebních ploch**. {uc=A}

(4) Odůvodnění vymezení ~~zastavěného~~ **zastavitelného** území obsahuje zejména {uc=A}

a) stručný popis postupu pořízení vymezení zastavěného území,

b) vyhodnocení souladu s § 116 odst. 2 a 3 a vyhodnocení souladu se stanovisky dotčených orgánů nebo s výsledkem řešení rozporů,

c) vyhodnocení připomínek a

d) posouzení souladu vymezení zastavěného území s jednotným standardem.

#### § 119 — Pořízení  `[272 Čl.I/69; 272 Čl.I/284; 272 Čl.I/285]` {uc=A}

(1) Pořizovatel zajistí zpracování návrhu vymezení ~~zastavěného~~ **zastavitelného** území, který zveřejní v národním geoportálu územního plánování a vystaví jej u obce k nahlédnutí. Místa, kde je možné do návrhu vymezení ~~zastavěného~~ **zastavitelného** území nahlédnout, pořizovatel oznámí veřejnou vyhláškou. {uc=A}

(2) Do 15 dnů ode dne doručení veřejné vyhlášky může každý uplatnit k návrhu vymezení ~~zastavěného~~ **zastavitelného** území u pořizovatele písemně své připomínky. K připomínkám, kterými je požadována úprava ~~zastavěného~~ **vymezení zastavitelného** území na základě skutečností, které nastaly po datu, k němuž je ~~zastavěné~~ **zastavitelné** území vymezeno, se nepřihlíží. Proti návrhu vymezení ~~zastavěného~~ **zastavitelného** území nelze podat námitky podle části šesté správního řádu. {uc=A}

~~(3) Pořizovatel svolá místní šetření za účasti obce a dotčených orgánů hájících veřejné zájmy na úseku~~ {uc=A}

~~a) ochrany přírody,~~ {uc=A}

~~b) ochrany zemědělského půdního fondu,~~ {uc=A}

~~c) ochrany lesa,~~ {uc=A}

~~d) státní památkové péče, a~~ {uc=A}

~~e) pozemních komunikací.~~ {uc=A}

~~(4) Místo a dobu konání místního šetření oznámí pořizovatel nejméně 15 dnů předem. Dotčené orgány uplatní svá stanoviska a příslušná obec své připomínky nejpozději do 15 dnů ode dne místního šetření.~~ {uc=A}

~~(5) Pořizovatel bezodkladně vyhodnotí výsledky projednání návrhu vymezení zastavěného území, zpracuje návrh vyhodnocení připomínek a zajistí řešení případných rozporů. Je-li to nezbytné, zajistí pořizovatel úpravu návrhu vymezení zastavěného území v souladu s výsledky projednání.~~ {uc=A}

~~(6) Dojde-li na základě projednání k podstatné úpravě návrhu vymezení zastavěného území, pořizovatel zajistí zveřejnění, vystavení a oznámení upraveného návrhu obdobně podle odstavce 1; v rozsahu upravených částí se postupuje podle odstavců 2 až 5.~~ {uc=A}

#### § 120 — Vydání  `[272 Čl.I/69; 272 Čl.I/286; 272 Čl.I/287; 272 Čl.I/288]` {uc=A}

(1) ~~Vymezení zastavěného území lze vydat jen tehdy, je-li v souladu s výsledky projednání.~~ Pořizovatel zajistí vložení vymezení ~~zastavěného~~ **zastavitelného** území do národního geoportálu územního plánování do 7 dnů po jeho vydání. {uc=A}

(2) ~~Vymezení zastavěného~~ **Informaci o vymezení zastavitelného** území a adresu jeho uložení v národním geoportálu územního plánování pořizovatel bezodkladně oznámí veřejnou vyhláškou; dnem doručení veřejné vyhlášky nabývá vymezení ~~zastavěného~~ **zastavitelného** území účinnosti. {uc=A}

(3) Vymezení ~~zastavěného~~ **zastavitelného** území ~~se~~ opatří **pořizovatel** záznamem o účinnosti~~, který obsahuje~~**.** {uc=A}

~~a) označení správního orgánu, který vymezení zastavěného území vydal,~~

~~b) datum nabytí účinnosti vymezení zastavěného území,~~

~~c) jméno, příjmení, funkci a podpis oprávněné úřední osoby pořizovatele a otisk úředního razítka.~~

(4) Dojde-li ke zrušení vymezení ~~zastavěného~~ **zastavitelného** území nebo jeho části soudem, zveřejní pořizovatel rozsudek v národním geoportálu územního plánování. {uc=A}

#### § 121 — Změna  `[272 Čl.I/69; 272 Čl.I/289]` {uc=A}

(1) Pořizovatel nejpozději do 8 let od vydání vymezení ~~zastavěného~~ **zastavitelného** území a poté pravidelně nejméně jednou za 8 let vyhodnotí aktuálnost vymezení ~~zastavěného~~ **zastavitelného** území. {uc=A}

(2) Vymezení ~~zastavěného~~ **zastavitelného** území se aktualizuje jeho změnou. Je-li na území obce vymezeno více ~~zastavěných~~ **zastavitelných** území, aktualizují se jen ta, která aktualizaci vyžadují. {uc=A}

(3) Změnu vymezení ~~zastavěného~~ **zastavitelného** území lze pořídit také na základě podnětu dotčené obce. {uc=A}

(4) Pro pořízení změny vymezení ~~zastavěného~~ **zastavitelného** území se použijí § 117 až 120 v rozsahu měněných částí obdobně. Ke stanoviskům a připomínkám uplatněným k neměněným částem se nepřihlíží. {uc=A}

(5) Změnu vymezení ~~zastavěného~~ **zastavitelného** území, úplné znění vymezení ~~zastavěného~~ **zastavitelného** území a adresy jejich uložení v národním geoportálu územního plánování pořizovatel oznámí veřejnou vyhláškou. Dnem doručení veřejné vyhlášky nabývá změna vymezení ~~zastavěného~~ **zastavitelného** území účinnosti. {uc=A}

##### ~~Oddíl 3~~

*~~Nezastavěné území~~*

#### § 122  `[272 Čl.I/291; 272 Čl.I/292; 272 Čl.I/293; 272 Čl.I/294]` {uc=A}

(1) V ~~nezastavěném~~ **nezastavitelném** území lze ~~v souladu s jeho charakterem~~ povolovat **pouze** záměry pro {uc=A}

a) veřejnou dopravní a technickou infrastrukturu, přípojky a účelové komunikace,

b) vodní hospodářství,

c) vyhledávání, průzkum a těžbu nerostů a zvláštní zásahy do zemské kůry,

d) snižování nebezpečí havárií, ekologických a přírodních katastrof a pro odstraňování jejich důsledků,

e) zemědělství a lesnictví,

f) ochranu přírody a krajiny a

g) zlepšení podmínek jeho využití pro **sport,** rekreaci a cestovní ruch, například cyklistické stezky, hygienická zařízení, ekologická a informační centra, {uc=A}

h) zázemí lesních mateřských škol a výdejen lesních mateřských škol, jedná-li se o drobnou stavbu.

(2) U staveb a zařízení podle odstavce 1 není doplňková funkce bydlení nebo pobytové rekreace přípustná.

(3) Stavby a zařízení podle odstavce 1 lze v ~~nezastavěném~~ **nezastavitelném** území povolit pouze v případě, že je územně plánovací dokumentace výslovně nevylučuje z důvodu veřejného zájmu. {uc=A}

**(4) V nezastavitelném území lze povolovat stavby pro energetickou bezpečnost81) podle zákona o urychlení výstavby strategicky významné infrastruktury. Stavba pro energetickou bezpečnost se považuje za souladnou s charakterem území. _______________** {uc=A}

##### Díl 6

*Územní opatření*

##### Oddíl 1

*Územní opatření o stavební uzávěře*

#### § 123 — Podmínky vydání  `[272 Čl.I/295; 272 Čl.I/296]` {uc=A}

(1) Územním opatřením o stavební uzávěře se omezuje nebo zakazuje v nezbytném rozsahu stavební činnost ve vymezeném území, pokud by mohla ztížit nebo znemožnit jeho budoucí využití podle připravované územně plánovací dokumentace, jestliže bylo rozhodnuto o jejím pořízení nebo o pořízení její změny, nebo podle jiného rozhodnutí nebo opatření v území, jímž se upravuje využití území.

(2) Územní opatření o stavební uzávěře lze vydat také v případech, kdy je zrušena územně plánovací dokumentace nebo její část.

(3) Územní opatření o stavební uzávěře, kterým se omezuje nebo zakazuje stavební činnost, která by mohla ztížit nebo znemožnit budoucí využití území podle připravované územně plánovací dokumentace, se vydává na nezbytně nutnou dobu, která však nesmí být delší než ~~6 let~~ **4 roky**. {uc=A}

(4) Územní opatření o stavební uzávěře dále pozbývá účinnosti jeho zrušením.

(5) Územním opatřením o stavební uzávěře nelze omezit nebo zakázat udržovací práce. Územním opatřením o stavební uzávěře dále nelze omezit nebo zakázat realizaci ~~veřejně prospěšné~~ stavby dopravní nebo technické infrastruktury a stanovení dobývacího prostoru vymezené v územním rozvojovém plánu nebo v zásadách územního rozvoje **nebo realizaci stavby pro energetickou bezpečnost**. {uc=A}

#### § 124 — Obsah

(1) Územní opatření o stavební uzávěře obsahuje

a) vymezení území s uvedením katastrálního území a parcelních čísel pozemků podle katastru nemovitostí, pro které platí omezení nebo zákaz stavební činnosti,

b) rozsah a obsah omezení nebo zákazu stavební činnosti,

c) popřípadě další podmínky vyplývající ze stanovisek dotčených orgánů,

d) dobu trvání omezení nebo zákazu stavební činnosti,

e) stanovení podmínek pro povolování výjimek.

(2) Součástí územního opatření o stavební uzávěře je výkres na podkladu katastrální mapy s vyznačením území, pro které platí stavební uzávěra.

(3) Týká-li se územní opatření o stavební uzávěře zvlášť rozsáhlého území, nahradí se údaj podle odstavce 1 písm. a) popisem hranice dotčeného území, pro které platí omezení nebo zákaz stavební činnosti.

##### Oddíl 2

*Územní opatření o asanaci území*

#### § 125 — Podmínky vydání  `[272 Čl.I/297]` {uc=A}

(1) Územní opatření o asanaci území se vydává na území postiženém živelní pohromou nebo závažnou havárií, v jejichž důsledku došlo k podstatnému zásahu do využití území, je-li nezbytné pro postižené území stanovit podmínky pro odstranění jejich dopadů a pro další využití území.

(2) Územní opatření o asanaci území lze vydat i pro území, ve kterém jsou závadné stavby, kontaminovaná místa nebo staré ekologické zátěže, a to z důvodů hygienických, bezpečnostních, požárních, provozních a ochrany životního prostředí, a u nichž je ve veřejném zájmu nebo z důvodu ohrožení života nebo zdraví osob nebo hrozby značné újmy nutné nařídit úpravy, odstranění staveb, sanaci, rekultivaci kontaminovaných míst nebo starých ekologických zátěží.

(3) Dnem nabytí účinnosti územního opatření o asanaci území pozbývá v dotčeném území účinnosti vydaná územně plánovací dokumentace v rozsahu podle § 126 odst. 2 **a zrušení**. {uc=A}

(4) Územní opatření o asanaci území pozbývá účinnosti dnem vydání nové územně plánovací dokumentace nebo její změny pro dotčené území.

(5) Územní opatření o asanaci území dále pozbývá účinnosti jeho zrušením.

#### § 126 — Obsah

(1) Územní opatření o asanaci území obsahuje

a) vymezení území s uvedením katastrálního území a parcelních čísel pozemků a staveb na nich podle katastru nemovitostí, pro které platí územní opatření o asanaci území,

b) seznam pozemků, které musí být upraveny nebo zabezpečeny s uvedením způsobu provedení,

c) seznam staveb a zařízení, které musí být odstraněny, zabezpečeny nebo upraveny s uvedením způsobu provedení,

d) stanovení územních, stavebně technických a bezpečnostních podmínek pro provádění asanace, sanace nebo rekultivace území,

e) stanovení územních, architektonických a urbanistických podmínek pro budoucí využití území,

f) případné další podmínky vyplývající ze stanovisek dotčených orgánů.

(2) V územním opatření o asanaci území se označí územně plánovací dokumentace, která v dotčeném území pozbývá účinnosti, a vymezí území, ve kterém pozbývá účinnosti.

(3) Součástí územního opatření o asanaci území je výkres na kopii katastrální mapy nebo na kopii jiného státního mapového díla vhodného měřítka s vyznačením území, kterého se územní opatření o asanaci týká.

(4) Týká-li se územní opatření o asanaci území zvlášť rozsáhlého území, nahradí se údaj podle odstavce 1 písm. a) popisem hranice dotčeného území, kterého se opatření o asanaci území týká.

##### Oddíl 3

*Pořizování a vydávání územních opatření*

#### § 127 — Pořízení

(1) O pořízení územního opatření rozhodne vláda, rada kraje nebo rada obce z

a) vlastního podnětu,

b) podnětu oprávněného investora,

c) podnětu orgánu veřejné správy,

d) podnětu rady kraje, je-li příslušná k jeho vydání vláda, nebo

e) podnětu rady obce, je-li příslušná k jeho vydání rada kraje.

(2) Návrh územního opatření připraví pořizovatel na základě průzkumu a vyhodnocení dotčeného území, nástrojů územního plánování a v případě územního opatření o stavební uzávěře v souladu s cíli a úkoly územního plánování.

(3) V případě územního opatření o asanaci území postupuje pořizovatel bezodkladně a při přípravě návrhu zohlední rovněž vyhodnocení stavu staveb a pozemků z hlediska ohrožení života nebo zdraví osob nebo z hlediska požadavků na využití území v důsledku odstraňování živelní pohromy nebo havárie.

(4) Návrh územního opatření pořizovatel zveřejní v národním geoportálu územního plánování, zveřejnění oznámí veřejnou vyhláškou a návrh písemně projedná s dotčenými orgány, které mohou uplatnit svá stanoviska.

(5) Každý může k návrhu územního opatření uplatnit připomínky. Stanoviska a připomínky se uplatňují u pořizovatele písemně do 30 dnů ode dne zveřejnění návrhu. Na vyhodnocení připomínek uplatněných k návrhu se použije § 98 odst. 2 obdobně s tím, že návrh vyhodnocení připomínek zpracuje pořizovatel samostatně. Proti návrhu územního opatření nelze podat námitky podle části šesté správního řádu.

(6) Lhůtu podle odstavce 5 může pořizovatel v případě územního opatření o asanaci území z důležitých důvodů zkrátit.

#### § 128 — Vydání  `[272 Čl.I/102; 272 Čl.I/299; 272 Čl.I/300; 272 Čl.I/301; 272 Čl.I/302; 272 Čl.I/303]` {uc=A}

(1) Územní opatření se vydává formou opatření obecné povahy.

(2) Pořizovatel zajistí ~~vložení~~ **schválení** územního opatření **jeho vložením** do národního geoportálu územního plánování do 7 dnů po jeho **schválení. Informaci o** vydání~~. Územní~~ **územního** opatření a adresu jeho uložení v národním geoportálu územního plánování oznámí pořizovatel veřejnou vyhláškou; dnem doručení veřejné vyhlášky nabývá územní opatření účinnosti. {uc=A}

(3) Územní opatření ~~se~~ opatří **pořizovatel** záznamem o účinnosti~~, který obsahuje~~**.** {uc=A}

~~a) označení správního orgánu, který územní opatření vydal,~~ {uc=A}

~~b) datum nabytí účinnosti územního opatření,~~ {uc=A}

~~c) jméno, příjmení, funkci a podpis oprávněné úřední osoby pořizovatele a otisk úředního razítka.~~ {uc=A}

(4) Obec nebo kraj zašlou bezodkladně ~~ministerstvu~~ **Úřadu** rozhodnutí soudu o tom, že bylo zrušeno jimi vydané územní opatření nebo jeho část. ~~Ministerstvo~~ **Úřad** bezodkladně zajistí zveřejnění rozhodnutí soudu podle věty první v národním geoportálu územního plánování. {uc=A}

(5) ~~Ministerstvo a krajský úřad~~ **Úřad** bezodkladně zajistí zveřejnění rozhodnutí, kterým bylo rozhodnuto o zrušení územního opatření nebo jeho části v přezkumném řízení, v národním geoportálu územního plánování. {uc=A}

**(6) Orgán, který územní opatření schválil, je může bez řízení zrušit, pominuly-li jeho důvody; to neplatí v případě územního opatření o podmínkách a zmírňujících opatření podle zákona o urychlení využívání obnovitelných zdrojů energie. Zrušení nabývá účinnosti dnem zveřejnění informace o jeho zrušení v národním geoportálu územního plánování.** {uc=A}

#### § 129 — Výjimky  `[272 Čl.I/102]` {uc=A}

~~Ministerstvo~~ **Úřad**, rada obce a v obcích, kde se rada nevolí, zastupitelstvo obce, nebo rada kraje, které územní opatření o stavební uzávěře vydaly, mohou na žádost povolit výjimku z podmínek, omezení nebo zákazu stavební činnosti podle územního opatření o stavební uzávěře, jestliže povolení výjimky neohrožuje sledovaný účel stavební uzávěry. Proti rozhodnutí o žádosti o výjimku se nelze odvolat. {uc=A}

##### Díl 7

*Úprava vztahů v území*

##### Oddíl 1

*Plánovací smlouvy*

#### § 130 — Úvodní ustanovení  `[272 Čl.I/304; 272 Čl.I/305; 272 Čl.I/306]` {uc=A}

(1) Plánovací smlouvou je veřejnoprávní smlouva uzavřená mezi stavebníkem a obcí, městskou částí hlavního města Prahy nebo krajem nebo vlastníkem veřejné infrastruktury, **organizací podle horního zákona, případně i dalšími osobami,** jejímž obsahem je vzájemná povinnost stran poskytnout si součinnost při uskutečnění ve smlouvě uvedeného záměru a postupovat při jeho uskutečňování ujednaným způsobem. {uc=A}

(2) Plánovací smlouva může obsahovat i úpravu práv a povinností osob v oblasti soukromého práva. Se souhlasem všech stran může být plánovací smlouva postoupena; ustanovení občanského zákoníku o postoupení smlouvy se použijí přiměřeně.

(3) Obec, městská část hlavního města Prahy nebo kraj ~~zašlou bezodkladně~~ **zveřejní** uzavřenou plánovací smlouvu ~~příslušnému úřadu územního plánování, který zajistí~~ **a** její ~~vložení do národního~~ **změnu či zánik v národním** geoportálu územního plánování **nebo v něm oznámí její zveřejnění s uvedením adresy jejího uveřejnění v registru smluv**. ~~Dojde-li k zániku plánovací smlouvy, sdělí obec, městská část hlavního města Prahy nebo kraj tuto skutečnost úřadu územního plánování, který zajistí její vypuštění z národního geoportálu územního plánování.~~ {uc=A}

**(4) Plánovací smlouva není důvodem pro vyloučení z projednávání a rozhodování věci podle správního řádu.** {uc=A}

#### § 131 — Obsah plánovací smlouvy  `[272 Čl.I/307; 272 Čl.I/308]` {uc=A}

(1) V plánovací smlouvě se obec, městská část hlavního města Prahy, kraj nebo vlastník veřejné infrastruktury může zavázat k tomu, že

a) poskytne stavebníkovi součinnost k uskutečnění záměru,

b) obec nebo kraj učiní kroky k vydání územně plánovací dokumentace, v případě, že záměr nelze uskutečnit bez předchozího vydání územně plánovací dokumentace,

c) po sjednanou dobu nevydá nebo nezmění územně plánovací dokumentaci nebo neučiní jiný úkon, který by ztížil nebo vyloučil uskutečnění záměru,

d) po dobu trvání plánovací smlouvy nebude ve správních nebo soudních řízeních týkajících se povolení záměru uplatňovat návrhy, vyjádření a opravné prostředky, které by byly v rozporu s obsahem uzavřené plánovací smlouvy.

(2) V plánovací smlouvě se obec, městská část hlavního města Prahy, kraj nebo vlastník veřejné infrastruktury může dále zavázat k tomu, že

a) pozemky nebo stavby potřebné k realizaci záměru, k nimž vykonávají práva, ať již přímo, nebo prostřednictvím dalších osob, po sjednanou dobu nezatíží nebo nezcizí,

b) se bude podílet na přípravě, výstavbě nebo financování veřejné infrastruktury nebo veřejně prospěšných staveb nebo jiných opatření potřebných k uskutečnění záměru,

**c) zajistí společné řešení požadavků na výstavbu potřebných k uskutečnění záměru podle**

**§ 137 odst. 7,**

~~c)~~ **d)** od stavebníka převezme jím zhotovenou stavbu do svého vlastnictví,

~~d)~~ **e)** učiní jiné právní jednání v oblasti soukromého práva.

(3) Stavebník se může v plánovací smlouvě zavázat zejména k

a) účasti na výstavbě veřejné infrastruktury nebo jiných staveb nebo opatření vyvolaných záměrem,

b) převzetí nákladů na výstavbu veřejné infrastruktury nebo veřejně prospěšných staveb nebo opatření vyvolaných záměrem,

c) účasti na asanaci území dotčeného záměrem,

d) účasti na narovnání majetkových vztahů v území dotčeném záměrem,

e) poskytnutí peněžního nebo věcného plnění za zhodnocení pozemku vydáním územně plánovací dokumentace; v plánovací smlouvě lze sjednat i jeho účel~~.~~**,**

**f) poskytnutí příspěvku na společné řešení požadavků na výstavbu potřebných k uskutečnění záměru podle § 137 odst. 7,**

**g) poskytnutí peněžního nebo věcného plnění jako podílu na ekonomické aktivitě daného dokončeného záměru,**

**h) zpracování nebo převzetí nákladů na zpracování návrhu územně plánovací dokumentace nebo její části nebo její změny.**

#### § 132 — Uzavírání a přezkum plánovací smlouvy  `[272 Čl.I/309; 272 Čl.I/310; 272 Čl.I/311; 272 Čl.I/312]` {uc=A}

(1) Plánovací smlouvu uzavíranou obcí, krajem nebo hlavním městem Prahou schvaluje zastupitelstvo obce, zastupitelstvo kraje nebo zastupitelstvo hlavního města Prahy. Plánovací smlouvu uzavíranou městskou částí hlavního města Prahy schvaluje zastupitelstvo městské části. **Zastupitelstvo může přenést pravomoc schvalovat plánovací smlouvu na radu, není-li obsahem plánovací smlouvy takové ujednání, které je ze zákona vyhrazeno zastupitelstvu. O plánovací smlouvě a záměru, který je jejím předmětem, lze konat místní referendum pouze před uzavřením plánovací smlouvy.** {uc=A}

(2) K přezkumu souladu plánovací smlouvy uzavřené obcí ~~s právními předpisy a k rozhodování sporů z ní je příslušný krajský úřad. K přezkumu souladu plánovací smlouvy uzavřené~~ **nebo** městskou částí hlavního města Prahy s právními předpisy a k rozhodování sporů z ní je příslušný ~~Magistrát hlavního města Prahy~~ **úřad rozvoje území kraje**. {uc=A}

(3) K přezkumu souladu plánovací smlouvy uzavřené krajem nebo hlavním městem Prahou s právními předpisy a k rozhodování sporů z ní je ~~příslušné ministerstvo~~ **příslušný Úřad**. {uc=A}

**(4) Pokud obec, městská část hlavního města Prahy nebo kraj neuzavřou se stavebníkem v přiměřené době plánovací smlouvu, která je podmínkou pro povolení jeho záměru, i přesto, že stavebník jim předložil návrh na uzavření plánovací smlouvy splňující podmínky územního nebo regulačního plánu a plnění uvedená v návrhu plánovací smlouvy jsou přiměřená okolnostem a podmínkám konkrétního záměru, je stavebník oprávněn domáhat se nahrazení chybějícího souhlasu s uzavřením smlouvy rozhodnutím soudu.** {uc=A}

##### Oddíl 2

*Náhrady za změnu v území*

#### § 133 — Oprávněné osoby  `[272 Čl.I/313; 272 Čl.I/314]` {uc=A}

(1) Vlastníkovi pozemku nebo stavby a osobě, která má jiné věcné právo k pozemku nebo stavbě (dále jen „oprávněná osoba“) a které vznikla škoda v důsledku zrušení nebo významného omezení zastavitelnosti pozemku na základě změny územně plánovací dokumentace nebo vydáním nové územně plánovací dokumentace, náleží náhrada škody spočívající v nákladech vynaložených na přípravu výstavby v obvyklé výši, zejména na koupi pozemku, na projektovou přípravu výstavby nebo za snížení hodnoty pozemku~~, který slouží k zajištění dluhu~~. {uc=A}

(2) Oprávněné osobě náleží dále náhrada, byla-li její práva k pozemku nebo stavbě významně omezena územním opatřením o stavební uzávěře a byla-li jí tím způsobena škoda.

(3) Náhrada oprávněné osobě nenáleží, došlo-li ke zrušení nebo významnému omezení zastavitelnosti pozemku na základě jejího návrhu nebo po uplynutí doby ~~5~~ **6** let od nabytí účinnosti územně plánovací dokumentace, která zastavění dotčeného pozemku ke stanovenému účelu umožnila. Do této doby se nezapočítává doba, po kterou bylo zastavění pozemku znemožněno v důsledku stavební uzávěry nebo jiného dočasného omezení zastavitelnosti pozemku stanoveného územně plánovací dokumentací. {uc=A}

(4) Náhrada oprávněné osobě dále nenáleží, nabylo-li právní moci povolení záměru, pro který bylo zastavění příslušnou územně plánovací dokumentací určeno, a toto povolení je platné nebo pozbylo platnosti.

#### § 134 — Povinné osoby

(1) Povinnost poskytnout náhradu za změnu v území má obec, kraj nebo stát, jejichž orgány vydaly územně plánovací dokumentaci nebo její změnu nebo územní opatření o stavební uzávěře.

(2) Náhrada se poskytne na základě písemné žádosti oprávněné osoby obsahující prokázání škody.

#### § 135 — Způsob náhrady  `[272 Čl.I/315]` {uc=A}

(1) Náhrada se poskytuje v penězích. Místo peněžité náhrady lze na základě dohody poskytnout oprávněné osobě jiný pozemek nebo stavbu; právo na vyrovnání rozdílu mezi výší peněžité náhrady a hodnotou náhradního pozemku nebo stavby tím není dotčeno.

(2) Dojde-li k následné změně územního plánu anebo změně nebo zrušení regulačního plánu a pozemek, za který byla vyplacena náhrada, se vrátí do původního nebo jiného režimu umožňujícího zastavění, je ten, komu byla náhrada vyplacena, povinen vyplacenou náhradu ~~v plné~~ **ve** výši **odpovídající snížení škody** vrátit tomu, kdo ji poskytl, do 3 měsíců od vyrozumění o vzniku této povinnosti. Byl-li místo peněžité náhrady poskytnut oprávněné osobě jiný pozemek nebo stavba, je povinna vrátit náhradu v té výši, která by jí jinak náležela. {uc=A}

(3) Povinnost vrátit náhradu zaniká po 5 letech od nabytí účinnosti změny územního plánu anebo změny nebo zrušení regulačního plánu, na jejichž základě nárok na náhradu vznikl.

#### § 136 — Regresní náhrada

(1) Uhradí-li obec nebo kraj náhradu za změnu v důsledku územně plánovací činnosti, může požadovat regresní náhradu od správního orgánu, na základě jehož požadavku došlo k omezení vlastnického práva vlastníka, popřípadě od kraje nebo státu, pokud došlo ke změně územně plánovací dokumentace obce nebo kraje v důsledku jejího uvedení do souladu s nadřazenou územně plánovací dokumentací.

(2) Obec nebo kraj uplatní požadavek na regresní náhradu do 3 měsíců od uhrazení náhrady, jinak jejich právo zaniká. Regresní náhrada musí být uhrazena do 3 měsíců od doručení požadavku obce nebo kraje, který tuto náhradu uhradil.

#### ~~HLAVA IV~~

*~~POLITIKA ARCHITEKTURY A STAVEBNÍ KULTURY~~*

#### ~~§ 136a~~  `[272 Čl.I/316]` {uc=A}

> **Zrušuje se celý paragraf.**

~~(1) Politika architektury a stavební kultury je strategickým dokumentem s celostátní působností, který určuje vizi, cíle a opatření k dosažení kvality vystavěného prostředí.~~

~~(2) Politika architektury a stavební kultury rozvíjí cíle a úkoly územního plánování a je podkladem pro zpracování politiky územního rozvoje, který není závazný.~~

~~(3) Ministerstvo zajistí zveřejnění usnesení vlády, kterým byla schválena politika architektury a stavební kultury, ve Věstníku vlády pro orgány krajů a orgány obcí a v téže lhůtě zveřejní politiku architektury a stavební kultury způsobem umožňujícím dálkový přístup.~~

~~(4) Ministerstvo nejpozději do 6 let od schválení politiky architektury a stavební kultury a poté nejméně jednou za 6 let předloží vládě zprávu o plnění politiky architektury a stavební kultury. Vláda může na jejím základě uložit ministerstvu pořídit aktualizaci nebo novou politiku architektury a stavební kultury.~~

### ČÁST ČTVRTÁ

*STAVEBNÍ PRÁVO HMOTNÉ*

#### HLAVA I

*POŽADAVKY NA VÝSTAVBU*

##### Díl 1

*Obecná ustanovení*

#### § 137  `[272 Čl.I/317; 272 Čl.I/318; 272 Čl.I/319; 272 Čl.I/320]` {uc=A}

(1) Požadavky na výstavbu se rozumí

a) požadavky na vymezování pozemků,

b) požadavky na umisťování staveb,

c) technické požadavky na stavby.

(2) Při územně plánovací a projektové činnosti, při povolování, provádění, užívání a odstraňování staveb je každý povinen dodržovat cíle a úkoly územního plánování a dodržovat požadavky na výstavbu stanovené tímto zákonem, prováděcím právním předpisem nebo jinými právními předpisy. **Požadavky na výstavbu se používají s ohledem na jejich technickou, funkční a ekonomickou proveditelnost tak, aby jejich výklad a povinnost jejich použití nebyly zjevně nepřiměřené přínosům, které tyto požadavky sledují. Pokud je použití požadavků na výstavbu vyloučeno nebo omezeno v důsledku jiných právních předpisů, jiných požadavků na výstavbu nebo územního plánu nebo regulačního plánu, použijí se požadavky na výstavbu přiměřeně okolnostem a zásadám podle § 1a.** {uc=A}

(3) Požadavky na výstavbu se považují za splněné splněním požadavků, které stanoví tento zákon, jeho prováděcí právní předpisy a další právní předpisy. **Lze-li požadavky na výstavbu nebo požadavky na stavby podle § 167 splnit více způsoby, náleží jejich volba stavebníkovi nebo vlastníkovi stavby.** {uc=A}

(4) ~~V~~ **Požadavky na výstavbu, zejména požadavky na parkování, odstupy, denní osvětlení, zastínění, izolační vlastnosti, úsporu energie, přístupnost, schodiště, výtahy, plochy, výšky, šířky a další požadavky podle § 145 odst. 1 písm. c) až g), se v** rozsahu, v jakém to závažné územně technické nebo stavebně technické důvody nebo jiný veřejný zájem ~~nevylučují~~ **vylučují**, ~~uplatní se požadavky na výstavbu rovněž~~ **nebo pokud by jejich uplatnění bylo zjevně ekonomicky nepřiměřené vůči přínosům, neuplatní** u {uc=A}

a) změny dokončené stavby,

b) údržby dokončené stavby,

c) změny v užívání stavby,

d) dočasné stavby,

e) zařízení staveniště,

f) pozemku nebo stavby, které jsou kulturní památkou nebo se nacházejí v památkové rezervaci nebo památkové zóně~~.~~**,** {uc=A}

**g) stavby v proluce.** {uc=A}

**(5) Nelze-li u staveb uvedených v odstavci 4 ze závažného stavebně technického důvodu, nepřiměřených ekonomických nákladů nebo ochrany jiného převažujícího veřejného zájmu splnit požadavky na výstavbu podle § 145 odst. 1 písm. a) a b), tyto požadavky se nepoužijí, je-li v projektové dokumentaci zpracované autorizovanou osobou doloženo, že navržené řešení zajišťuje dosažení alespoň rovnocenného výsledku a úrovně bezpečnosti z hlediska mechanické odolnosti a stability a požární bezpečnosti stavby.** {uc=A}

**(6) U pozemků nebo staveb, které jsou kulturními památkami nebo se nacházejí v památkových rezervacích nebo památkových zónách, se požadavky na výstavbu uplatní přiměřeně s ohledem na zájmy státní památkové péče. U drobných staveb se požadavky na výstavbu uplatní přiměřeně s ohledem na charakter stavby.** {uc=A}

**(7) Požadavky na výstavbu, jejichž povaha to nevylučuje, zejména požadavky na parkování, napojení na sítě dopravní a technické infrastruktury, zelenou infrastrukturu, občanské vybavení, hygienická zařízení či nakládání s odpady a s vodou, lze splnit též poskytnutím příspěvku na jejich společné řešení na základě plánovací smlouvy uzavřené s obcí.** {uc=A}

**(8) Stanoví-li mírnější minimální úroveň určitého požadavku na výstavbu nebo požadavku na stavbu právní předpis Evropské unie, považuje se takový požadavek za splněný, je-li splněn v této úrovni. Umožňuje-li právní předpis Evropské unie výjimku z určitého požadavku na výstavbu nebo z požadavku na stavbu, považuje se takový požadavek stanovený ve vnitrostátním prováděcím právním předpisu za směrný.** {uc=A}

#### § 138 — Výjimky z požadavků na výstavbu a odchylné řešení  `[272 Čl.I/321; 272 Čl.I/322]` {uc=A}

(1) Výjimku z požadavků na výstavbu lze povolit pouze ~~z těch ustanovení prováděcího právního předpisu, ze kterých tento předpis povolení výjimky výslovně umožňuje, a jen~~ pokud se tím neohrozí bezpečnost, ochrana zdraví nebo života osob nebo zvířat, životní prostředí, sousední pozemky nebo stavby. Řešením podle povolené výjimky musí být dosaženo účelu sledovaného požadavky na výstavbu stanovenými tímto zákonem. {uc=A}

(2) V regulačním plánu nebo v územním plánu~~, který obsahuje prvky regulačního plánu,~~ lze stanovit požadavky na vymezování pozemků a požadavky na umisťování staveb odchylně od těch ustanovení prováděcího právního předpisu, která to umožňují, a to i pro část území; podmínky podle odstavce 1 se použijí přiměřeně. {uc=A}

##### Díl 2

*Požadavky na vymezování pozemků*

#### § 139 — Obecné požadavky  `[272 Čl.I/323]` {uc=A}

(1) Pozemky se vymezují a podmínky pro jejich využití se stanovují v souladu s územně plánovací dokumentací, a nebyla-li vydána, s cíli a úkoly územního plánování, s ohledem na charakter území, urbanistickou, architektonickou, kulturně historickou, přírodní a archeologickou hodnotu území a kvalitu vystavěného prostředí. Pozemky se vždy vymezují tak, aby svými vlastnostmi, zejména velikostí, polohou, plošným a prostorovým uspořádáním umožňovaly využití pro navrhovaný účel.

(2) V ~~zastavěném~~ **zastavitelném** území obce, která nemá územní plán, lze vymezovat pozemky a povolovat stavby pro bydlení, pro rodinnou rekreaci, stavby občanského vybavení souvisejícího a slučitelného s bydlením nebo rekreací, stavby pro dopravní a technickou infrastrukturu a pozemky veřejných prostranství. Vymezování jiných pozemků a umisťování dalších staveb na nich je možné, jen pokud jsou tyto stavby v souladu s charakterem území a nesnižují kvalitu životního prostředí stanovenou jinými právními předpisy. {uc=A}

(3) Při vymezování pozemků se dbá na vymezení veřejných prostranství odpovídajících charakteru území, zejména uličního prostranství.

#### § 140 — Požadavky na vymezování stavebních pozemků  `[272 Čl.I/324; 272 Čl.I/325; 272 Čl.I/326; 272 Čl.I/327]` {uc=A}

(1) Pozemky nesmí být děleny tak, aby bylo vyloučeno jejich účelné využití. Pozemky, jejichž součástí je stavba, nesmí být děleny tak, aby tím došlo k oddělení části stavby, kterou nelze samostatně užívat; obdobně se postupuje při dělení pozemků, které jsou zatíženy právem stavby.

(2) Stavební pozemek se ~~vždy~~ vymezuje tak, aby svými vlastnostmi, zejména velikostí, polohou, plošným a prostorovým uspořádáním, umožňoval umístění, realizaci a užívání stavby pro navrhovaný účel a aby byl dopravně napojen na kapacitně vyhovující veřejně přístupnou pozemní komunikaci23) **nebo k němu byl zajištěn přístup prostřednictvím věcného práva**. {uc=A}

(3) Stavební pozemek se ~~vždy~~ vymezuje tak, aby na něm bylo vyřešeno {uc=A}

a) umístění odstavných a parkovacích stání pro účel využití pozemku a užívání staveb na něm umístěných,

b) nakládání s odpady a zneškodňování odpadních vod podle jiných právních předpisů24), které na pozemku vznikají jeho užíváním nebo užíváním staveb na něm umístěných,

c) hospodaření se srážkovými vodami jejich

1. akumulací a následným využitím, vsakováním nebo výparem, pokud to hydrogeologické poměry, velikost pozemku a jeho výhledové využití umožňují a pokud nejsou vsakováním ohroženy okolní stavby nebo pozemky,

2. odváděním do vod povrchových prostřednictvím dešťové kanalizace, pokud jejich vsakování ani akumulace s následným využitím není možná, nebo

3. regulovaným odváděním do jednotné kanalizace, není-li možné odvádění do vod povrchových~~.~~**,**

**d) uplatnění základních ekosystémových funkcí prostřednictvím ploch nebo prvků zelené infrastruktury.**

(4) Při vymezování stavebního pozemku nebo při změně využití ~~zastavěného stavebního~~ pozemku lze prokázat splnění požadavků odstavců 2 a 3 regulačním plánem nebo dokumentací pro vydání povolení záměru též s využitím dalších pozemků. {uc=A}

#### § 141 — Veřejné prostranství  `[272 Čl.I/328; 272 Čl.I/329; 272 Čl.I/330]` {uc=A}

(1) Pozemky tvořící veřejné prostranství se vymezují tak, aby vytvářely prostupný spojitý systém odpovídající charakteru území a potřebám života lidí, přispívaly obytné kvalitě a významu místa a omezovaly dopady oteplování a sucha, zejména možností vsakování vody a výsadby stromů a další veřejné zeleně.

(2) Uspořádání veřejných prostranství musí zajistit dostupnost a obsluhu území a jeho prostupnost pro užití chodci a podle možností též **cyklisty a jinou** bezmotorovou dopravou. **Stavby a zařízení ve veřejném prostranství se přednostně sdružují, pokud tomu nebrání technické, funkční či ekonomické důvody.** {uc=A}

(3) Chodníky, nástupiště veřejné dopravy, úrovňové i mimoúrovňové přechody, chodníky v sadech i parcích a ostatní pochozí plochy jako součást veřejných prostranství musí splňovat požadavky na přístupnost**, pokud to místní podmínky nevylučují**. {uc=A}

**(4) Podél vodních toků a významných vodních ploch v zastavitelném území, kde je to technicky, funkčně a ekonomicky proveditelné, se preferují veřejně přístupná nábřeží, parkově upravené plochy nebo jiná veřejná prostranství. Stávající prostupnost pro pohyb chodců a cyklistů podél vodních toků a okolo významných vodních ploch musí být zachována.** {uc=A}

**(5) Při vymezování veřejných prostranství se dbá na jejich prostorové a funkční propojení do navazujících veřejných prostranství a do volné krajiny.** {uc=A}

**(6) Oplocení pozemku na hranici s veřejným prostranstvím musí vhodně navazovat na oplocení v místě obvyklé a nesmí zhoršovat spojitost a prostupnost veřejného prostranství a jeho kvalitu.** {uc=A}

#### § 142 — Uliční prostranství  `[272 Čl.I/331]` {uc=A}

(1) Uliční prostranství tvoří část veřejného prostranství a vytváří základní síť obsluhy a prostupnosti území; je vymezeno zejména uličními čarami.

(2) Pozemky tvořící uliční prostranství se vymezují tak, aby svými vlastnostmi, zejména svou šířkou, umožňovaly předpokládané využití v souladu s charakterem území.

(3) Je-li to technicky možné a není-li to v rozporu s charakterem území, vymezují se v nově zakládaných uličních prostranstvích a při celkových stavebních úpravách stávajících uličních prostranství pozemky tvořící výsadbový pás pro stromy nebo jinou veřejnou zeleň.

**(4) Ulice v územích se zvýšenými nároky na pobytovou kvalitu veřejných prostranství se přednostně vymezují tak, aby umožňovaly využití sdílené, cyklistické, obytné nebo pěší zóny82). ___________** {uc=A}

##### Díl 3

*Požadavky na umisťování staveb*

#### § 143 — Obecné požadavky  `[272 Čl.I/332; 272 Čl.I/333]` {uc=A}

(1) Stavby se umisťují v souladu s územně plánovací dokumentací, a nebyla-li vydána, s cíli územního plánování. Stavby se umisťují též s ohledem na charakter území, urbanistickou, architektonickou, kulturně historickou, přírodní a archeologickou hodnotu území a kvalitu vystavěného prostředí.

(2) Stavby se podle druhu a potřeby umisťují tak, aby bylo umožněno jejich napojení na sítě technické infrastruktury a pozemní komunikace a aby jejich umístění na pozemku umožňovalo přístup požární techniky a provedení jejího zásahu mimo ochranná pásma rozvodu energetických vedení. Připojení staveb na pozemní komunikace musí svými parametry, provedením a způsobem připojení vyhovovat požadavkům bezpečného užívání staveb a bezpečného a plynulého provozu na přilehlých pozemních komunikacích25). Podle druhu a charakteru stavby musí připojení splňovat též požadavky na dopravní obslužnost a parkování **vozidel a jízdních kol**. {uc=A}

(3) Změnou stavby nesmí být narušeny kulturně historické, přírodní, urbanistické a architektonické hodnoty daného místa nebo nesmí dojít k narušení architektonické jednoty celku.

(4) Mimo stavební pozemek lze umístit jen stavby **pro parkování,** zařízení staveniště a připojení staveb na sítě technické infrastruktury a pozemní komunikace. {uc=A}

#### § 144 — Odstupy staveb  `[272 Čl.I/334]` {uc=A}

(1) Vzájemné odstupy staveb musí splňovat požadavky urbanistické, architektonické a požadavky stanovené prováděcím právním předpisem a jinými právními předpisy.

(2) Vzájemné odstupy staveb musí umožňovat údržbu staveb.

**(3) Požadavky na odstupy staveb se neuplatní u spojité zástavby nebo v rámci jedné stavby, souboru staveb či společně řešeného celku.** {uc=A}

#### § 144a — ~~Zvláštní požadavky~~ **Fotovoltaické výrobny elektřiny a stavební úpravy pro instalaci využívající obnovitelný zdroj energie**  `[272 Čl.I/335; 272 Čl.I/336; 272 Čl.I/337; 272 Čl.I/338]` {uc=A}

(1) Zastavěná plocha stavby výrobny elektřiny využívající energii slunečního záření se nezahrnuje do celkové plochy určené k zastavění a do celkové plochy minimálního podílu zeleně, jsou-li územním plánem stanoveny, umisťuje-li se stavba pro výrobu elektřiny využívající energii slunečního záření

a) v **zastavitelných** plochách ~~s rozdílným způsobem využití plochy výroby~~ **hlavním využitím určeným pro výrobu nebo skladování** a ~~skladování nebo plochy smíšené výrobní a~~ {uc=A}

b) pod stavbou je zachována ~~zeleň~~ **vegetační plocha a jsou zajištěny podmínky pro její základní ekosystémové funkce**. {uc=A}

(2) Stavbu výrobny elektřiny využívající energii slunečního záření lze umístit na stávající stavby, nevylučuje-li to **z důvodu jiného převažujícího veřejného zájmu** regulační plán. {uc=A}

**(3) Má se za to, že stavební úprava pro instalaci využívající obnovitelný zdroj energie není v rozporu s charakterem území ani se zájmy státní památkové péče; možnost stanovení podmínek pro její vhodné umístění nebo vzhled tím není dotčena. Domněnka podle věty první se nepoužije pro nemovité kulturní památky a nemovité národní kulturní památky.** {uc=A}

#### § 144b — **Stavby pro reklamu a reklamní zařízení**  `[272 Čl.I/339]` {uc=A}

**(1) Stavbou pro reklamu a reklamním zařízením nesmí být narušen urbanistický, architektonický nebo pietní charakter území.** {uc=A}

**(2) Při umisťování staveb pro reklamu a reklamních zařízení v území musí být zajištěn jejich vzájemný soulad z hlediska jejich stavebně technického řešení.** {uc=A}

**(3) Stavby pro reklamu a reklamní zařízení umístěné na budovách musí odpovídat jejich architektonickému charakteru a nesmí narušovat užívání přilehlého veřejného prostranství, základní členění průčelí budov a jeho významné detaily a narušit stabilitu těchto budov.** {uc=A}

**(4) Reklamu a informace související se stavbou lze umístit též na oplocení staveniště.** {uc=A}

#### § 144c — **Pohoda bydlení**  `[272 Čl.I/339]` {uc=A}

**(1) Každý má právo na ochranu před nepřiměřenými zásahy do pohody svého bydlení. Pohodou bydlení se rozumí souhrn podmínek v území a v užívání staveb, který odpovídá obvyklým požadavkům na bydlení s přihlédnutím k místním poměrům.** {uc=A}

**(2) Za narušení pohody bydlení se nepovažuje architektonické ztvárnění záměru ani imise a účinky, které nejsou v rozporu s plánovaným charakterem území nebo které odpovídají běžné okolní zástavbě nebo běžnému využívání okolního území.** {uc=A}

**(3) K dodržení požadavků na ochranu pohody bydlení stavební úřad upřednostňuje uložení podmínek, kompenzačních nebo zmírňujících opatření před nepovolením, omezením či zákazem záměru.** {uc=A}

#### § 144d  `[272 Čl.I/339]` {uc=A}

**Účinky stávajících staveb a zařízení Má-li být stavba povolena nebo užívána v území, které může být dotčeno obvyklými účinky již dříve povolené dokončené stavby nebo zařízení nebo jejich provozu, musí nová stavba přijmout stav území, jaký je. Povolení nové stavby nebo změny v užívání pozdější stavby není samo o sobě důvodem pro omezení, změnu nebo dodatečné zpřísnění podmínek provozu stávající stavby nebo zařízení.** {uc=A}

##### Díl 4

*Technické požadavky na stavby*

#### § 145 — Základní požadavky na stavby

(1) Stavba musí být navržena a provedena tak, aby byla vhodná pro určené využití a po celou dobu trvání plnila při běžné údržbě a působení běžně předvídatelných vlivů základní požadavky na stavby, kterými jsou

a) mechanická odolnost a stabilita,

b) požární bezpečnost26),

c) ochrana zdraví27),

d) ochrana životního prostředí28),

e) bezpečnost a přístupnost při užívání, provozu a údržbě,

f) úspora energie29),

g) udržitelné využívání přírodních zdrojů30).

(2) Při projektové činnosti, při povolování, provádění a užívání staveb v působnosti jiných stavebních úřadů nebo u staveb jaderného zařízení a staveb v areálu jaderného zařízení, které jsou jaderným zařízením31), se technické požadavky na stavbu stanovené tímto zákonem nebo jinými právními předpisy použijí přiměřeně tak, aby nedošlo k ohrožení bezpečnosti, ochrany zdraví a života osob nebo zvířat a životního prostředí.

#### § 146 — Požadavky na mechanickou odolnost a stabilitu stavby

(1) Stavba musí být navržena a provedena tak, aby účinky zatížení a nepříznivé vlivy prostředí, kterým je vystavena během výstavby a užívání, neměly za následek

a) náhlé nebo postupné zřícení stavby nebo její části,

b) nepřípustné deformace, které mohou narušit stabilitu stavby, mechanickou odolnost a funkční způsobilost stavby nebo její části,

c) poškození částí stavby nebo technických zařízení anebo instalovaného vybavení v důsledku deformace nosné konstrukce,

d) poškození stavby v míře nepřiměřené původní příčině,

e) ohrožení provozuschopnosti dopravní a technické infrastruktury v dosahu stavby nebo staveniště,

f) poškození stavby vlivem nepříznivých účinků podzemních vod nebo dynamickými účinky povodňových průtoků, popřípadě hydrostatickým vztlakem při zaplavení,

g) ohrožení průtočnosti koryt vodních toků, popřípadě údolních profilů mostů a propustků.

(2) Stavby umístěné v dosahu účinků hlubinného dobývání nebo v dosahu seizmických účinků se navrhují též s ohledem na předpokládané deformace základové půdy, způsobené projevy důlní nebo seizmické činnosti na povrchu.

#### § 147 — Požadavky na požární bezpečnost

Stavba musí být navržena a provedena takovým způsobem, aby v případě požáru

a) byla po určenou dobu zachována nosnost konstrukcí,

b) byl uvnitř stavby omezen vznik a šíření ohně a kouře,

c) bylo omezeno šíření požáru na sousední stavby,

d) uživatelé mohli stavbu opustit nebo aby mohli být jinými prostředky zachráněni,

e) byla brána v úvahu bezpečnost záchranných jednotek.

#### § 148 — Požadavky na ochranu zdraví a životního prostředí  `[272 Čl.I/340; 272 Čl.I/341; 272 Čl.I/342; 272 Čl.I/343; 272 Čl.I/344]` {uc=A}

(1) Stavba musí být navržena a provedena takovým způsobem, aby neohrožovala bezpečnost, život nebo zdraví osob nebo zvířat, aby byl hluk v chráněném prostoru stavby udržován na úrovni, která neohrozí zdraví jejích uživatelů, zaručí noční klid a je vyhovující pro prostředí s pobytem osob nebo zvířat, a to i na sousedních pozemcích a stavbách, ani neměla nepřípustný negativní vliv na kvalitu životního prostředí nebo na klima, a to během výstavby, užívání i odstraňování, zejména následkem

a) nedostatečných tepelně izolačních, zvukoizolačních nebo světelně technických vlastností,

b) uvolňování toxických plynů, nebezpečných látek, těkavých organických sloučenin, skleníkových plynů nebo nebezpečných částic do vnitřního nebo venkovního prostředí,

c) výskytu vlhkosti ve stavebních konstrukcích nebo na povrchu stavebních konstrukcí uvnitř staveb,

d) emisí nebezpečného záření a světla,

e) uvolňování nebezpečných látek do vody nebo půdy,

f) vypouštění odpadních vod, emisí odpadních plynů, nebo

g) narušení podloží s následkem trvalé změny proudění podzemních vod nebo jiným nepřípustným dopadem na úroveň hladiny podzemní vody.

(2) Stavba musí být navržena a provedena takovým způsobem, aby ~~nezpůsobila~~ {uc=A}

a) **nezpůsobila** nadměrný úhyn rostlin a zranění nebo úhyn živočichů nebo ničení jejich biotopů, nebo {uc=A}

**b) předcházela, zmírňovala nebo kompenzovala poškozování nebo úhynu zvláště chráněných rostlin a rušení, ničení, zraňování nebo usmrcení či úhynu zvláště chráněných živočichů nebo poškozování a ničení jejich biotopu nebo jejich místní populace a jejího genofondu a** {uc=A}

~~b)~~ **c)** ~~zhoršení~~ **nevedla ke znemožnění** prostupnosti krajiny pro volně žijící živočichy. {uc=A}

**(3) Nelze-li zajistit splnění hygienických limitů hluku a vibrací, nebo je-li jejich splnění technicky, funkčně či ekonomicky zjevně nepřiměřené, považují se tyto limity za splněné, pokud se omezí na rozumně dosažitelnou míru nebo pokud imise záměru odpovídají běžnému stávajícímu využití okolního území. Rozumně dosažitelnou mírou se rozumí poměr mezi náklady na protihluková nebo antivibrační opatření a jejich přínosem ke snížení škodlivých účinků hluku nebo vibrací, který je stanovený i s ohledem na význam záměru z hlediska celkové hlukové zátěže a počet fyzických osob vystavených nadlimitnímu hluku nebo vibracím. K navýšení hluku o méně než o 2 dB se nepřihlíží.** {uc=A}

#### § 149 — Požadavky na bezpečnost a přístupnost při užívání, provozu a údržbě  `[272 Čl.I/345]` {uc=A}

Stavba musí být navržena a provedena takovým způsobem, aby při jejím užívání, údržbě nebo provozu

a) nevznikalo nebezpečí nehod nebo poškození zdraví osob nebo zvířat,

b) byla zohledněna přístupnost pro osoby ~~s omezenou schopností pohybu nebo orientace~~ **se zdravotním postižením**, zejména u {uc=A}

1. staveb pozemních komunikací a veřejných prostranství32),

2. staveb občanského vybavení v částech určených pro užívání veřejností,

3. společných prostor a domovního vybavení bytového domu,

4. bytu zvláštního určení,

5. staveb pro výkon práce více než 25 osob, pokud charakter provozu v těchto stavbách umožňuje zaměstnávat osoby se zdravotním postižením.

#### § 150 — Požadavky na úsporu energie  `[272 Čl.I/346]` {uc=A}

Stavba a její technické zařízení pro vytápění, chlazení, osvětlení a větrání musí být navrženy a provedeny takovým způsobem, aby při jejich užívání, údržbě nebo provozu byla spotřeba energie co nejnižší s ohledem na účel užívání a na místní klimatické podmínky. Stavba musí být rovněž energeticky účinná **a technickou, funkční a ekonomickou proveditelnost**. {uc=A}

#### § 151 — Požadavky na udržitelné využití přírodních zdrojů

(1) Stavba musí být navržena, provedena a odstraněna takovým způsobem, aby bylo zajištěno udržitelné využití přírodních zdrojů zejména opětovným využitím nebo recyklovatelností materiálů a konstrukcí z odstraněné stavby nebo použitím surovin nebo druhotných materiálů šetrných k životnímu prostředí při stavbě.

(2) Udržitelné využití přírodních zdrojů může být zajištěno opětovným použitím materiálů a konstrukcí nebo stavebních výrobků, které vznikly při realizaci nebo odstraňování záměru, nebo využitím vedlejších produktů nebo stavebních výrobků, které přestaly být odpadem.

##### Díl 5

*Společná ustanovení*

#### § 152 — Podrobné vymezení požadavků na výstavbu  `[272 Čl.I/347; 272 Čl.I/348]` {uc=A}

(1) Prováděcí právní předpis stanoví podrobné požadavky na výstavbu **a technická zařízení staveb**. **Prováděcí právní předpis může odkázat pouze na technické normy, které byly určeny postupem podle § 152a.** {uc=A}

(2) Územní samosprávné celky, které jsou k tomu tímto zákonem zmocněny, mohou stanovit prováděcím právním předpisem podrobné požadavky na výstavbu odchylně od prováděcího právního předpisu podle odstavce 1 s výjimkou požadavků na výstavbu staveb dálnic, silnic, drah a civilních leteckých staveb a technických požadavků na stavby technické infrastruktury.

(3) Prováděcí právní předpis podle odstavce 1 nebo jeho jednotlivá ustanovení se použijí, nestanoví-li prováděcí právní předpis podle odstavce 2 jinak.

(4) Určí-li prováděcí právní předpis územního samosprávného celku podle odstavce 2 závazné technické normy ve stavebnictví odchylně od prováděcího právního předpisu podle odstavce 1, zajistí územní samosprávný celek bezplatný přístup k těmto určeným technickým normám a vede jejich seznam. **Má-li prováděcí právní předpis územního samosprávného celku obsahovat požadavky na vymezování pozemků a umisťování staveb technické infrastruktury, projedná územní samosprávný celek jeho návrh s dotčenými vlastníky technické infrastruktury, kteří jsou subjekty kritické infrastruktury.** {uc=A}

#### § 152a — **Určené technické normy ve stavebnictví**  `[272 Čl.I/349]` {uc=A}

**(1) Prováděcí právní předpis může odkázat na podrobnější vymezení požadavků na stavby, zejména mezní hodnoty, návrhové metody, národně stanovené parametry, technické vlastnosti stavebních konstrukcí a technických zařízení, obsažené v českých technických normách nebo jejich částech, které byly určeny postupem podle tohoto ustanovení.** {uc=A}

**(2) Pro podrobnější vymezení požadavků na stavby Česká agentura pro standardizaci na návrh Úřadu a po odsouhlasení Úřadem určí konkrétní části české technické normy obsahující podrobnější požadavky na stavby (dále jen „určená technická norma ve stavebnictví“), které jsou v návaznosti na odkaz v právním předpisu závazné.** {uc=A}

**(3) Úřad pro technickou normalizaci, metrologii a státní zkušebnictví oznamuje ve Věstníku podle jiného právního předpisu34) určené technické normy ve stavebnictví. V oznámení uvede též požadavek prováděcího právního předpisu, k němuž jsou tyto normy určeny.** {uc=A}

**(4) Pro změnu nebo zrušení určené technické normy ve stavebnictví platí odstavce 2 a 3 obdobně.** {uc=A}

**(5) Jiné části norem nebo jiné normy než určené technické normy ve stavebnictví nejsou pro účely tohoto zákona závazné.** {uc=A}

**(6) Požadavky na stavby, které jsou podrobně vymezeny prostřednictvím určené technické normy ve stavebnictví, mohou být splněny i jiným technickým řešením, pokud takové řešení splňuje požadavek prováděcího právního předpisu, jako v případě řešení podle určených technických norem ve stavebnictví.** {uc=A}

#### HLAVA II

*POŽADAVKY NA VÝROBKY PRO STAVBY*

#### § 153

(1) Pro stavby mohou být navrženy a použity jen takové výrobky, materiály a konstrukce, jejichž vlastnosti z hlediska způsobilosti stavby pro navržený účel zaručují, že stavba při správném provedení a běžné údržbě po dobu předpokládané existence splní základní požadavky na stavby33).

(2) Výrobky pro stavby, které mají rozhodující význam pro výslednou kvalitu stavby a které by mohly ve zvýšené míře ohrozit život nebo zdraví osob nebo zvířat, bezpečnost anebo životní prostředí, popřípadě jiný veřejný zájem, jsou stanoveny a posuzovány podle jiných právních předpisů34).

#### HLAVA III

*SYSTÉM STAVEBNĚ TECHNICKÉ PREVENCE*

#### § 154  `[272 Čl.I/61]` {uc=A}

(1) V systému stavebně technické prevence se evidují závažné nebo opakující se vady nebo havárie staveb, a výsledky šetření jejich příčin, došlo-li při nich ke ztrátám na životech osob nebo zvířat, k ohrožení života a zdraví osob nebo zvířat, k ohrožení bezpečnosti stavby nebo ke značným škodám.

(2) Rozsah a obsah systému stavebně technické prevence stanoví prováděcí právní předpis.

(3) Veřejnoprávní smlouva může upravit spolupráci při předávání informací o skutečnostech, které mají vliv na stavebně technickou prevenci, majících souvislost s havárií nebo mimořádnou událostí, při nichž došlo ke ztrátám na životech, k ohrožení života osob nebo zvířat nebo ke značným škodám. Veřejnoprávní smlouvu může uzavřít ~~ministerstvo~~ **Úřad** s jiným ústředním orgánem státní správy, veřejnoprávní korporací nebo právnickou osobou zřízenou zákonem. Ve veřejnoprávní smlouvě se určí rozsah předávaných informací a četnost jejich poskytování a doba jejího trvání. {uc=A}

#### HLAVA IV

*ČINNOSTI VE VÝSTAVBĚ*

#### § 155 — Vybrané činnosti

Vybrané činnosti, jejichž výsledek ovlivňuje ochranu veřejných zájmů ve výstavbě, může vykonávat pouze fyzická osoba, která získala oprávnění k jejich výkonu podle jiného právního předpisu35). Vybranými činnostmi jsou

a) zpracování územně plánovací dokumentace, územní studie a projektové dokumentace,

b) odborné vedení provádění stavby nebo její změny anebo odstraňování stavby,

c) ověřování výsledků zeměměřických činností ve výstavbě36),

d) výkon dozoru projektanta.

#### § 156 — Projektová činnost  `[272 Čl.I/351; 272 Čl.I/352]` {uc=A}

(1) Územně plánovací dokumentace, územní studie a projektová dokumentace musí být zpracovány projektantem.

(2) Dokumentaci jednoduchých staveb, s výjimkou jednoduchých staveb pro bydlení a rodinnou rekreaci nebo vodních děl, a dokumentaci stávajícího stavu stavby (dále jen „pasport stavby“) může zpracovat též osoba, která má vysokoškolské vzdělání stavebního nebo architektonického směru anebo střední vzdělání stavebního směru **pro pozemní stavby** s maturitní zkouškou a alespoň ~~3 roky~~ **5 let** praxe v projektování staveb. {uc=A}

(3) Projektantovi **a osobě podle odstavce 2** se poskytují údaje z ~~neveřejné části~~ digitální technické mapy kraje v rozsahu nezbytném pro projektovou činnost. {uc=A}

#### § 157 — Projektová dokumentace a dokumentace pro povolení záměru  `[272 Čl.I/353; 272 Čl.I/355; 272 Čl.I/357]` {uc=A}

(1) Projektovou dokumentací se rozumí dokumentace pro

a) povolení stavby~~,~~ **nebo** zařízení ~~nebo udržovacích prací (dále jen „dokumentace pro povolení stavby~~ “) jednoduchých staveb pro bydlení a rodinnou rekreaci, vodních děl, vyhrazených a ostatních staveb, {uc=A}

b) rámcové povolení,

c) povolení změny využití území,

d) provádění stavby ~~jednoduchých staveb pro bydlení a rodinnou rekreaci,~~ vyhrazených a ostatních staveb, {uc=A}

e) odstranění stavby ~~jednoduchých staveb pro bydlení a rodinnou rekreaci,~~ jednoduchých staveb, v nichž je obsažen azbest, vodních děl, vyhrazených a ostatních staveb. {uc=A}

(2) Dokumentací pro povolení záměru se rozumí dokumentace pro

a) povolení stavby **nebo zařízení podle § 156 odst. 2 a § 157 odst. 1 písm. a) (dále jen „dokumentace pro povolení stavby**, {uc=A}

b) rámcové povolení,

c) povolení změny využití území.

#### § 158 — Obsah dokumentace  `[272 Čl.I/358; 272 Čl.I/359]` {uc=A}

(1) Dokumentace pro povolení stavby obsahuje průvodní list, souhrnnou technickou zprávu, situační výkresy a dokumentaci objektů. Dokumentace pro povolení změny využití území obsahuje průvodní list, souhrnnou technickou zprávu, situační výkresy a výkresovou dokumentaci. Dokumentace pro rámcové povolení obsahuje průvodní list, souhrnnou technickou zprávu a situační výkresy. Dokumentace pro povolení ~~záměru~~ **stavby** stanovená prováděcím právním předpisem musí obsahovat urbanistické a základní architektonické a technické řešení záměru umožňující posouzení jeho mechanické odolnosti a stability, požární bezpečnosti a vlivů na území a životní prostředí **a odůvodnění řešení, které využívá možnost odchylného použití požadavků na výstavbu podle § 137 odst**. **4 až 8 nebo které navrhuje udělit výjimku podle § 138 odst. 1.** {uc=A}

(2) Dokumentace pro provádění stavby a dokumentace pro odstranění stavby obsahuje průvodní list, souhrnnou technickou zprávu, situační výkresy, dokumentaci objektů a technických a technologických zařízení.

(3) Pasport stavby obsahuje průvodní list, souhrnnou technickou zprávu, situační výkresy a zjednodušenou výkresovou dokumentaci. V případě výrobku, který plní funkci stavby, lze příslušné části dokumentace nahradit dokladem podle jiného právního předpisu34) prokazujícím shodu vlastností výrobku plnícího funkci stavby s požadavky podle § 153, dokumentací výrobce nebo dovozce, popřípadě dalšími doklady, ze kterých je možné ověřit dodržení požadavků na stavby.

(4) K projektové dokumentaci a dokumentaci, která nemusí být zpracována projektantem, se přikládá dokladová část, která obsahuje doklady o splnění požadavků podle jiných právních předpisů, dokumentaci zpracovanou osobami oprávněnými podle jiných právních předpisů a závěry provedených průzkumů.

(5) Podrobnosti obsahu ~~projektové~~ dokumentace **pro povolení záměru**, dokumentace **pro provádění stavby**, ~~která nemusí být zpracována projektantem,~~ **dokumentace pro odstranění stavby a** pasportu stavby ~~a obsahové náležitosti průzkumů~~ stanoví prováděcí právní předpis. {uc=A}

(6) Obsah jednotlivých částí dokumentace musí odpovídat druhu a významu stavby, charakteru navrhované změny v území, charakteru navrhované změny vlivu užívání stavby na území, podmínkám v území, umístění stavby, stavebně technickému provedení, účelu využití, vlivu na životní prostředí a době trvání stavby. Části dokumentace, které nejsou předmětem navrhovaného záměru, se neuvádějí.

#### § 159 — Provádění a odstraňování staveb, zařízení a terénních úprav  `[272 Čl.I/360; 272 Čl.I/361; 272 Čl.I/362; 272 Čl.I/364]` {uc=A}

(1) Stavby, zařízení a terénní úpravy musí být prováděny a odstraňovány stavebním podnikatelem, který zabezpečí odborné vedení provádění nebo odstraňování stavby stavbyvedoucím, pokud v odstavcích 2 a 3 není stanoveno jinak.

(2) Svépomocí může stavebník provádět

a) drobné stavby uvedené v příloze č. 1 k tomuto zákonu, s výjimkou staveb ~~uvedených v odstavci 1 písm. a) bodu 11~~ **využívajících obnovitelné zdroje energie**, ~~12 a 25 a v odstavci 1 písm. f) této přílohy,~~ {uc=A}

b) jednoduché stavby uvedené v příloze č. 2 k tomuto zákonu, s výjimkou staveb uvedených v odstavci 1 písm. ~~m~~ **b**) **přílohy č. 2 k tomuto zákonu**, ~~r)~~ **staveb využívajících obnovitelné zdroje energie** a ~~s) této přílohy~~ **staveb vodních děl**, {uc=A}

pokud zajistí stavební dozor, není-li pro takovou činnost sám odborně způsobilý. Jde-li však o stavbu pro bydlení nebo změnu stavby, která je kulturní památkou, je stavebník povinen zajistit odborné vedení provádění stavby stavbyvedoucím.

(3) Svépomocí může stavebník odstraňovat drobné **a jednoduché** stavby, s výjimkou ~~drobných~~ staveb uvedených v odstavci 1 písm. ~~a) bodu 11, 12 a 25 a v odstavci 1 písm. f~~ **b**) přílohy ~~č. 1 k tomuto zákonu, a jednoduché stavby uvedené v příloze~~ č. 2 k tomuto zákonu, ~~s výjimkou jednoduchých~~ staveb ~~uvedených v odstavci 1 písm. m), r) a s) této přílohy~~ **využívajících obnovitelné zdroje energie**. U staveb, v nichž je obsažen azbest, zajistí odborné vedení odstraňování stavby stavbyvedoucím. {uc=A}

#### HLAVA V

*POVINNOSTI OSOB PŘI PŘÍPRAVĚ, PROVÁDĚNÍ, UŽÍVÁNÍ A ODSTRAŇOVÁNÍ STAVEB, ZAŘÍZENÍ A TERÉNNÍCH ÚPRAV*

##### Stavebník

#### § 160  `[272 Čl.I/365; 272 Čl.I/366; 272 Čl.I/367]` {uc=A}

(1) Stavebník je povinen pro účely projednání záměru podle tohoto zákona opatřit stanovenou dokumentaci. Vyžaduje-li zákon zpracování projektové dokumentace osobou k tomu oprávněnou, je stavebník povinen zajistit zpracování projektové dokumentace takovou osobou, pokud nemá potřebné oprávnění sám.

(2) Stavebník je v případě stavby, zařízení nebo terénní úpravy podléhající povolení podle tohoto zákona povinen

a) před zahájením stavby zajistit vypracování dokumentace pro provádění ~~stavby~~ jednoduché stavby ~~pro bydlení a rodinnou rekreaci~~ **bytového domu uvedeného v odstavci 1 písm. b) přílohy č. 2 k tomuto zákonu**, **stavby** vyhrazené a ostatní stavby **v rozsahu nezbytném pro průběh výstavby**, {uc=A}

b) před zahájením stavby opatřit souhlas orgánu státního požárního dozoru k dokumentaci pro provádění stavby, je-li vyžadován jiným právním předpisem26) **nebo ke každé změně dokumentace pro provádění stavby vypracované podle písmene a)**, **která má vliv na požární bezpečnost stavby,** {uc=A}

c) oznámit stavebnímu úřadu předem termín zahájení provádění nebo odstraňování stavby, zařízení nebo terénní úpravy, název a sídlo stavebního podnikatele, který je bude provádět nebo odstraňovat, u stavby prováděné nebo odstraňované svépomocí jméno a příjmení stavbyvedoucího, nebo osoby, která bude vykonávat stavební dozor, a změny v těchto skutečnostech oznámit neprodleně stavebnímu úřadu,

d) před zahájením provádění nebo odstraňování stavby umístit na viditelném místě u vstupu na staveniště štítek obsahující identifikační údaje o stavbě a ponechat jej tam až do dokončení stavby, popřípadě do vydání kolaudačního rozhodnutí, nebo do jejího odstranění; rozsáhlé stavby se mohou označit jiným vhodným způsobem s uvedením údajů ze štítku,

e) zajistit, aby na stavbě nebo na staveništi byla k dispozici ověřená dokumentace pro povolení stavby a dokumentace pro provádění stavby, je-li povinná, popřípadě ověřená dokumentace pro odstranění stavby, a všechny doklady týkající se prováděné nebo odstraňované stavby, popřípadě jejich kopie,

f) ohlašovat stavebnímu úřadu fáze výstavby stanovené v podmínkách povolení za účelem provedení kontrolních prohlídek stavby, umožnit provedení kontrolní prohlídky, a pokud tomu nebrání vážné důvody, této prohlídky se zúčastnit,

g) oznámit stavebnímu úřadu předem zahájení zkušebního provozu,

h) při výstavbě, nejpozději k žádosti o vydání kolaudačního rozhodnutí, pokud jiný právní předpis37) nestanoví jinak, opatřit průkaz energetické náročnosti budovy, je-li vyžadován jiným právním předpisem37).

#### § 161  `[272 Čl.I/368; 272 Čl.I/369]` {uc=A}

(1) Od zahájení stavby do jejího dokončení je stavebník povinen zabezpečit uchování všech povinných dokladů a dokumentací uvedených v § 167 **odst. 1** písm. c) a d), a není-li současně vlastníkem stavby, je povinen je předat vlastníku stavby nejpozději po dokončení nebo kolaudaci stavby. {uc=A}

(2) U stavby financované z veřejných prostředků, kterou provádí stavební podnikatel jako zhotovitel, je stavebník povinen zajistit technický dozor stavebníka nad prováděním stavby fyzickou osobou oprávněnou podle autorizačního zákona. Zpracoval-li projektovou dokumentaci pro tuto stavbu projektant, zajistí stavebník dozor projektanta; to neplatí pro stavby sítí technické infrastruktury.

(3) Při provádění vyhrazených staveb je stavebník povinen ~~vždy~~ zajistit dozor projektanta. {uc=A}

(4) Obsahové náležitosti štítku stanoví prováděcí právní předpis.

#### § 162 — Projektant  `[272 Čl.I/370]` {uc=A}

(1) Projektant je při projektové činnosti povinen respektovat veřejné zájmy chráněné na základě tohoto nebo jiného právního předpisu, požadavky vyplývající z cílů a úkolů územního plánování a požadavky na výstavbu a jednat v součinnosti s dotčenými orgány. Při zpracování územně plánovací dokumentace a územní studie je dále povinen jednat v součinnosti s orgánem územního plánování a při zpracování projektové dokumentace se stavebním úřadem.

(2) Projektant je povinen zpracovat

a) územně plánovací dokumentaci a územní studii v souladu s právními předpisy,

b) projektovou dokumentaci v souladu s právními předpisy; statické a jiné výpočty musí být vypracovány tak, aby byly přezkoumatelné.

(3) Není-li projektant způsobilý některou část projektové dokumentace zpracovat sám, je povinen k jejímu zpracování přizvat osobu s oprávněním pro příslušný obor nebo specializaci, která odpovídá za jí zpracovaný návrh.

(4) **Projektant odpovídá za soulad jím zpracované projektové dokumentace, územně plánovací dokumentace a územní studie s právními předpisy.** Projektant neodpovídá za odchylky od projektové dokumentace, ke kterým došlo při provádění stavby a které neschválil. {uc=A}

(5) Na zpracovatele dokumentace jednoduchých staveb, která nemusí být zpracována projektantem, se vztahují odstavce 1 až 4 obdobně.

(6) Projektant je povinen zajistit zpracování příslušných částí územně plánovací dokumentace nebo územní studie a podkladů pro zpracování projektové dokumentace prostřednictvím osob, které jsou k tomu oprávněny podle jiných právních předpisů38). Projektant územně plánovací dokumentaci zpracovává a pořizovateli ji předává v jednotném standardu.

#### § 163 — Zhotovitel  `[272 Čl.I/371]` {uc=A}

(1) Zhotovitel je povinen

a) dbát na řádnou přípravu a provádění stavby, zařízení nebo terénní úpravy; přitom musí mít na zřeteli zejména ochranu života a zdraví osob nebo zvířat, ochranu životního prostředí a majetku i šetrnost k sousedství,

b) zajistit vytyčení prostorové polohy stavby v souladu s ověřenou dokumentací pro povolení ~~záměru~~ **stavby** a dokumentací pro provádění stavby, {uc=A}

c) zajistit při provádění nebo odstraňování stavby, zařízení nebo terénní úpravy stavbyvedoucího nebo stavební dozor,

d) zajistit při provádění nebo odstraňování stavby, zařízení nebo terénní úpravy dodržení požadavků na výstavbu, popřípadě technických předpisů a technických norem, které souvisí s vlastním prováděním nebo odstraňováním stavby, zařízení nebo terénní úpravy,

e) ohlásit stavebnímu úřadu neprodleně po jejich zjištění závady na stavbě, zařízení nebo terénní úpravě, které ohrožují životy a zdraví osob nebo zvířat anebo bezpečnost stavby, zařízení nebo terénní úpravy,

f) zajistit při provádění nebo odstraňování stavby, zařízení nebo terénní úpravy provedení a vyhodnocení zkoušek a měření stanovených jinými právními předpisy.

(2) Zhotovitel je při provádění nebo odstraňování stavby, zařízení nebo terénní úpravy podléhajícím povolení podle tohoto zákona dále povinen

a) provádět nebo odstraňovat stavbu, zařízení nebo terénní úpravu v souladu s rozhodnutím stavebního úřadu, ověřenou dokumentací pro povolení ~~záměru~~ **stavby** a dokumentací pro provádění stavby nebo dokumentací pro odstranění stavby, {uc=A}

b) zajistit dodržování povinností k ochraně života, zdraví, životního prostředí a bezpečnosti práce vyplývajících z jiných právních předpisů,

c) zajistit, aby práce na stavbě, jejím odstranění nebo terénní úpravě, k jejichž provádění je předepsáno zvláštní oprávnění39), vykonávaly pouze osoby, které jsou držiteli takového oprávnění,

d) vést stavební deník nebo jednoduchý záznam o stavbě.

#### § 164 — Stavbyvedoucí  `[272 Čl.I/371]` {uc=A}

(1) Stavbyvedoucí je povinen

a) odborně vést provádění nebo odstraňování stavby, zařízení nebo terénní úpravy,

b) řídit provádění nebo odstraňování stavby, zařízení nebo terénní úpravy v souladu s rozhodnutím stavebního úřadu a s ověřenou dokumentací pro povolení ~~záměru~~ **stavby** a dokumentací pro provádění stavby nebo dokumentací pro odstranění stavby, {uc=A}

c) zajistit řádné uspořádání staveniště a provozu na něm,

d) zajistit dodržování povinností k ochraně života, zdraví, životního prostředí a bezpečnosti práce vyplývajících z jiných právních předpisů,

e) zajistit dodržení požadavků na výstavbu, popřípadě technických předpisů a technických norem, které souvisí s vlastním prováděním nebo odstraňováním stavby, zařízení nebo terénní úpravy,

f) zajistit vytyčení tras technické infrastruktury na staveništi.

(2) Stavbyvedoucí je dále povinen působit k odstranění závad vzniklých při provádění nebo odstraňování stavby nebo terénní úpravy a neprodleně oznámit stavebnímu úřadu závady, které se nepodařilo odstranit při vedení stavby, vytvářet podmínky pro kontrolní prohlídku stavby, spolupracovat s osobou vykonávající technický dozor stavebníka nebo dozor projektanta, pokud jsou určeny, a s koordinátorem bezpečnosti a ochrany zdraví při práci40), působí-li na staveništi.

#### § 165 — Stavební dozor  `[272 Čl.I/371; 272 Čl.I/372]` {uc=A}

(1) Stavební dozor může vykonávat pouze fyzická osoba, která má vysokoškolské vzdělání stavebního nebo architektonického směru nebo střední vzdělání stavebního směru s maturitní zkouškou a alespoň ~~3 roky~~ **5 let** praxe při provádění staveb. {uc=A}

(2) Osoba vykonávající stavební dozor zajistí spolu se stavebníkem

a) provádění nebo odstraňování stavby, zařízení nebo terénní úpravy v souladu s rozhodnutím stavebního úřadu a s ověřenou dokumentací pro povolení ~~záměru~~ **stavby** a dokumentací pro provádění stavby nebo dokumentací pro odstranění stavby, {uc=A}

b) dodržení požadavků na výstavbu, popřípadě jiných technických předpisů a technických norem, které souvisí s vlastním prováděním nebo odstraňováním stavby, zařízení nebo terénní úpravy.

(3) Osoba vykonávající stavební dozor sleduje způsob a postup provádění nebo odstraňování stavby, zejména bezpečnost provádění a provozu technických zařízení na staveništi, vhodnost použití a správnost ukládání stavebních výrobků, materiálů a konstrukcí na staveništi a způsob vedení stavebního deníku nebo jednoduchého záznamu o stavbě; působí k odstranění závad vzniklých při provádění stavby, a pokud se jí nepodaří takové závady v rámci vykonávání dozoru odstranit, oznámí je neprodleně stavebnímu úřadu.

#### § 166 — Stavební deník  `[272 Čl.I/373]` {uc=A}

(1) Při provádění nebo odstraňování stavby, zařízení nebo terénní úpravy, která vyžaduje povolení podle tohoto zákona, musí být veden stavební deník v českém jazyce. Do stavebního deníku se pravidelně zaznamenávají údaje týkající se provádění nebo odstraňování stavby, zařízení nebo terénní úpravy. Při provádění nebo odstraňování jednoduchých staveb, s výjimkou jednoduchých staveb pro bydlení a rodinnou rekreaci, postačí vedení jednoduchého záznamu o stavbě.

(2) Záznamy do stavebního deníku nebo jednoduchého záznamu o stavbě jsou oprávněni provádět stavebník, stavbyvedoucí, osoba vykonávající stavební dozor, osoba provádějící kontrolní prohlídku stavby a osoba odpovídající za provádění vybraných zeměměřických činností. Záznamy jsou dále oprávněny provádět osoby vykonávající technický dozor stavebníka nebo dozor projektanta, jsou-li takové dozory vykonávány, koordinátor bezpečnosti a ochrany zdraví při práci, působí-li na staveništi, a další osoby, které mohou vykonávat kontrolu podle jiných právních předpisů.

(3) Po dokončení nebo odstranění stavby předá zhotovitel originál stavebního deníku nebo jednoduchého záznamu o stavbě stavebníkovi; v případě jejich vedení v elektronické formě je zhotovitel předá ve strojově čitelném formátu nebo je uchová a zajistí k nim stavebníkovi a jím určeným osobám přístup po dobu 10 let od právní moci kolaudačního rozhodnutí, popřípadě od dokončení stavby, pokud se kolaudační rozhodnutí nevyžaduje.

(4) Obsahové náležitosti stavebního deníku a jednoduchého záznamu o stavbě a způsob jejich vedení stanoví prováděcí právní předpis.

(5) U stavby, která je předmětem **nadlimitní** veřejné zakázky ~~v nadlimitním režimu~~ **na stavební práce**, musí být stavební deník veden v elektronické formě. {uc=A}

#### § 167 — Vlastník stavby a zařízení  `[272 Čl.I/374; 272 Čl.I/375; 272 Čl.I/376]` {uc=A}

Vlastník stavby a zařízení je povinen

a) provádět údržbu stavby nebo zařízení po celou dobu jejich existence,

b) neprodleně ohlásit stavebnímu úřadu závady na stavbě nebo zařízení, které ohrožují životy, zdraví osob nebo zvířat,

c) uchovávat stavební deník nebo jednoduchý záznam o stavbě nebo zařízení po dobu 10 let ode dne právní moci kolaudačního rozhodnutí, popřípadě od dokončení stavby nebo zařízení, pokud se kolaudační rozhodnutí nevyžaduje,

d) uchovávat po celou dobu trvání stavby ověřenou ~~projektovou~~ dokumentaci **pro povolení stavby**, dokumentaci pro provádění stavby, dokumentaci ~~stavby, došlo-li k odchylce od dokumentace~~ pro povolení stavby~~, popřípadě dokumentaci skutečného provedení stavby, včetně její geodetické části~~ **s vyznačením odchylek**, nebo pasport stavby, rozhodnutí, osvědčení, souhlasy a jiné důležité doklady týkající se stavby nebo zařízení; dokumentaci lze uchovávat i v elektronické formě, {uc=A}

e) pokud je to technicky proveditelné, zajistit do 1. ledna 2027 za podmínek stanovených prováděcím právním předpisem instalaci alespoň 1 dobíjecího bodu na každých 10 parkovacích stání pro automobily nebo alespoň 50 % kabelovodů parkovacích stání pro automobily, pro jiné než obytné budovy, v nichž se používá energie k úpravě vnitřního prostředí za účelem vytápění nebo chlazení s více než 20 parkovacími stáními, tuto povinnost lze odložit do 1. ledna 2029, pokud vlastník instaloval alespoň 1 dobíjecí bod mezi 28. květnem 2022 a 28. květnem 2024,

f) zajistit do 1. ledna 2033 za podmínek stanovených prováděcím právním předpisem instalaci kabeláže pro alespoň 50 % stání pro automobily v jiné než obytné budově, v níž se používá energie k úpravě vnitřního prostředí za účelem vytápění nebo chlazení, a to pokud je vlastníkem nebo uživatelem této budovy veřejný subjekt,

g) pokud je to technicky **a ekonomicky** proveditelné, zajistit do 1. ledna 2025 instalaci automatizačního a řídícího systému budovy, za podmínek stanovených jiným právním předpisem67), pokud je vlastníkem jiné než obytné budovy se systémem {uc=A}

1. vytápění nebo kombinovaným systémem pro vytápění a větrání o jmenovitém výkonu vyšším než 290 kW nebo

2. klimatizace nebo kombinovaným systémem klimatizace a větrání o jmenovitém výkonu vyšším než 290 kW.

h) pokud je to technicky **a ekonomicky** proveditelné, zajistit do 1. ledna 2030 instalaci automatizačního a řídícího systému budovy, za podmínek stanovených jiným právním předpisem67), pokud je vlastníkem jiné než obytné budovy, v níž se používá energie k úpravě vnitřního prostředí za účelem vytápění nebo chlazení, se systémem {uc=A}

1. vytápění nebo kombinovaným systémem pro vytápění a větrání o jmenovitém výkonu vyšším než 70 kW nebo

2. klimatizace nebo kombinovaným systémem klimatizace a větrání o jmenovitém výkonu vyšším než 70 kW,

i) pokud je to technicky a ekonomicky proveditelné, vybavit budovu, v níž se používá energie k úpravě vnitřního prostředí za účelem vytápění nebo chlazení, automatickými ovladači osvětlení, je-li vlastníkem jiné než obytné budovy se systémem vytápění nebo systémem klimatizace, nebo kombinovaným systémem vytápění a větrání nebo kombinovaným systémem klimatizace a větrání o jmenovitém výkonu vyšším než

1. 290 kW do 1. ledna 2028,

2. 70 kW do 1. ledna 2030,

j) za podmínek stanovených prováděcím právním předpisem zajistit instalaci dobíjecí infrastruktury u nových jiných než obytných budov, v nichž se používá energie k úpravě vnitřního prostředí za účelem vytápění nebo chlazení, nebo u změn jiných než obytných dokončených budov na více než 25 % celkové plochy obálky budovy, v nichž se používá energie k úpravě vnitřního prostředí za účelem vytápění nebo chlazení; povinnost se nevztahuje na změnu dokončené budovy, pokud náklady na instalaci dobíjecí infrastruktury překročí alespoň 10 % celkových nákladů na danou změnu dokončené budovy,

k) za podmínek stanovených prováděcím právním předpisem zajistit instalaci dobíjecí infrastruktury u nových bytových domů nebo u změn dokončených staveb bytových domů na více než 25 % celkové plochy obálky budovy; povinnost se nevztahuje na změnu dokončené budovy, pokud náklady na instalaci dobíjecí infrastruktury překročí alespoň 10 % celkových nákladů na danou změnu dokončené budovy.

**(1) Pro účely zajištění dobíjecí infrastruktury pro elektrická vozidla a výpočtu povinného množství dobíjecích bodů se jeden stejnosměrný dobíjecí bod s výkonem 50 až 150 kW považuje za deset běžných dobíjecích bodů a jeden ultrarychlý stejnosměrný dobíjecí bod s výkonem nad 150 kW za dvacet běžných dobíjecích bodů.** {uc=A}

#### § 168 — Vlastník technické infrastruktury

Vlastník technické infrastruktury je povinen

a) vést evidenci technické infrastruktury, která musí obsahovat polohové umístění a ochranu, a v odůvodněných případech, s ohledem na charakter technické infrastruktury, i výškové umístění,

b) sdělit bezplatně každému na žádost údaje o podmínkách napojení, o ochranných a bezpečnostních pásmech a o základních podmínkách provádění činnosti v nich, pokud nejde o technickou infrastrukturu, s níž je příslušné hospodařit Ministerstvo obrany nebo Ministerstvo vnitra.

#### § 169 — Oznámení závad a havárií staveb

(1) Stavebník, zhotovitel, stavbyvedoucí, osoba vykonávající stavební dozor, dozor projektanta, technický dozor stavebníka, autorizovaný inspektor a vlastník stavby jsou povinni bezodkladně oznamovat stavebnímu úřadu prostřednictvím systému stavebně technické prevence výskyt závažné a opakující se závady nebo havárie stavby a výsledky šetření jejich příčin, došlo-li při nich ke ztrátám na životech, k ohrožení života osob nebo zvířat nebo ke značným škodám. Oznámení musí obsahovat místo, čas, popis oznamované události a jejích důsledků, povahu stavby, popřípadě další okolnosti důležité pro správné posouzení příčin.

(2) Obsahové náležitosti oznámení výskytu závady nebo havárie a výsledku šetření jejich příčin stanoví prováděcí právní předpis.

### ČÁST PÁTÁ

*VYVLASTNĚNÍ*

#### § 170 — Účely vyvlastnění  `[272 Čl.I/377; 272 Čl.I/378; 272 Čl.I/379; 272 Čl.I/380]` {uc=A}

(1) Práva k pozemkům a stavbám lze odejmout nebo omezit **pouze tehdy**, jsou-li vymezeny v územně plánovací dokumentaci a jde-li o {uc=A}

a) uskutečnění veřejně prospěšné stavby **podle § 11 odst. 1**, {uc=A}

b) uskutečnění veřejně prospěšného opatření **podle § 11 odst. 2**, {uc=A}

c) realizaci stavby a opatření k zajišťování bezpečnosti státu, nebo

d) asanaci území.

(2) Právo k pozemku nebo stavbě lze odejmout nebo omezit též k vytvoření podmínek pro nezbytný přístup k pozemku nebo stavbě **nebo připojení na dopravní a technickou infrastrukturu**, a pro řádné užívání veřejně prospěšné stavby nebo veřejně prospěšného opatření. {uc=A}

(3) Odejmutí nebo omezení práva podle odstavce 1 se vztahuje také na plochy nezbytné k zajištění výstavby nebo k uskutečnění veřejně prospěšného opatření a vytvoření ochranného pásma, jde-li o ochranné pásmo podle zákona.

### ČÁST ŠESTÁ

*STAVEBNÍ ŘÁD*

#### HLAVA I

*OBECNÁ A SPOLEČNÁ USTANOVENÍ*

#### § 171  `[272 Čl.I/381]` {uc=A}

Záměr vyžaduje povolení s výjimkou drobných staveb a změn využití území, u kterých tak stanoví tento zákon.

**(1) Při postupech podle této části se znovu neposuzují veřejné zájmy v rozsahu, ve kterém již byly nebo podle § 2 odst. 1 měly být posouzeny při vydání územně plánovací dokumentace.** {uc=A}

#### § 172 — Způsob a forma podání a žádosti  `[272 Čl.I/382; 272 Čl.I/383; 272 Čl.I/384]` {uc=A}

(1) Podání podle této části je možné učinit také prostřednictvím portálu stavebníka. **Je-li součástí podání dokumentace pro povolení záměru nebo jde-li o podání osoby, která má zpřístupněnu datovou schránku bez žádosti, lze podání včetně jeho příloh učinit jen jako digitální úkon; to neplatí pro stavby v areálu jaderného zařízení a v případě podání směřujícímu vůči jinému stavebnímu úřadu.** {uc=A}

(2) Žádost nebo návrh podle této části se podává na stanoveném formuláři ~~elektronicky prostřednictvím portálu stavebníka nebo v listinné podobě~~. Formulář žádosti a formulář návrhu stanoví prováděcí právní předpis. {uc=A}

(3) Na elektronický dokument vedený v evidenci elektronických dokumentací nebo v evidenci řízení a jiných postupů stavebních úřadů a dotčených orgánů (dále jen „evidence stavebních postupů“) může žadatel v žádosti odkázat namísto jeho přiložení k žádosti jako její součást.

~~(4) Nejpozději s podáním žádosti vloží stavebník projektovou dokumentaci nebo dokumentaci pro povolení záměru do evidence elektronických dokumentací. Dokumentaci pro povolení záměru, která nemusí být zpracovaná projektantem, vloží do evidence elektronických dokumentací stavební úřad, neučiní-li tak spolu s podáním žádosti stavebník.~~ {uc=A}

#### § 173 — Evidence a doručování  `[272 Čl.I/385]` {uc=A}

(1) Stavební úřad eviduje veškeré úkony a vkládá veškeré písemnosti do evidence stavebních postupů.

(2) Stavební úřad a dotčený orgán si doručují písemnosti navzájem prostřednictvím evidence stavebních postupů. Písemnost je doručena dnem, kdy ji stavební úřad nebo dotčený orgán vloží do evidence stavebních postupů.

~~(3) Je-li žádost o vyjádření nebo závazné stanovisko podána žadatelem před zahájením řízení podle této části, vloží dotčený orgán vyjádření nebo závazné stanovisko do evidence stavebních postupů a doručí jej žadateli.~~ {uc=A}

#### HLAVA II

*ÚKONY PŘED ZAHÁJENÍM ŘÍZENÍ*

##### Díl 1

*~~Předběžná~~ **Konzultace a předběžné** informace*

#### § 174  `[272 Čl.I/387; 272 Čl.I/388; 272 Čl.I/389; 272 Čl.I/390; 272 Čl.I/391; 272 Čl.I/392; 272 Čl.I/393; 272 Čl.I/394; 272 Čl.I/395]` {uc=A}

**(1) Stavební úřady, dotčené orgány, pořizovatelé, obce a kraje poskytují stavebníkům a dalším žadatelům neformální konzultace v oblasti jejich působnosti, zejména o procesních postupech a uplatňování jejich požadavků podle tohoto zákona a dalších právních předpisů souvisejících s výstavbou.** {uc=A}

~~(1)~~ **(2)** Stavební úřad poskytne tomu, kdo požádá, v rámci své působnosti do 30 dnů od požádání předběžnou informaci {uc=A}

a) o podmínkách využívání území a změn jeho využití, zejména na základě územně plánovacích podkladů a územně plánovací dokumentace **a o souladu záměru s územně plánovací dokumentací**, {uc=A}

b) o nezbytnosti povolení záměru a jeho kolaudace **nebo rekolaudace**, {uc=A}

c) o tom, podle jakých hledisek bude posuzovat žádost ~~o vydání rozhodnutí o povolení záměru~~ a za jakých předpokladů lze žádosti vyhovět, {uc=A}

d) o **účastnících a** dotčených orgánech ve vztahu k záměru. {uc=A}

~~(2)~~ **(3)** Dotčený orgán poskytne tomu, kdo požádá, v rámci své působnosti do 30 dnů od požádání předběžnou informaci {uc=A}

a) o nezbytnosti vyjádření nebo závazného stanoviska dotčeného orgánu,

b) o tom, podle jakých hledisek bude posuzovat žádost o vydání vyjádření nebo závazného stanoviska a za jakých předpokladů lze žádosti vyhovět~~.~~**,** {uc=A}

**c) o rozsahu nezbytné dokumentace a podkladů pro vydání vyjádření nebo závazného stanoviska dotčeného orgánu.** {uc=A}

**(4) Obec a kraj poskytnou tomu, kdo požádá, v rámci své působnosti do 30 dnů od požádání předběžnou informaci o svém stanovisku k záměru, případně o požadavcích, po jejichž splnění vydá obec či kraj se záměrem souhlas, případně o možnostech společného řešení požadavků na výstavbu podle § 137 odst. 7.** {uc=A}

**(5) Pořizovatel poskytne tomu, kdo požádá, v rámci své působnosti do 30 dnů od požádání předběžnou informaci o požadavcích vyplývajících z nástrojů územního plánování, které pořídil.** {uc=A}

~~(3)~~ **(6)** Ten, kdo o předběžnou informaci žádá, kromě obecných náležitostí podle správního řádu uvede konkrétní požadavky na předběžnou informaci a konkrétní údaje o záměru, zejména jeho umístění, účel a technické provedení záměru. {uc=A}

**(7) Od předběžné informace nebo její části se lze odchýlit pouze v rozsahu nově zjištěných skutečností nebo na základě změny okolností nebo právních předpisů, anebo pokud je předběžná informace v rozporu s právními předpisy nebo je nesprávná. Ustanovení § 3 platí obdobně.** {uc=A}

##### Díl 2

*Vyjádření a závazné stanovisko dotčeného orgánu*

#### § 175 — Vyjádření  `[272 Čl.I/396]` {uc=A}

**(1) Vyjádření k záměru vydává dotčený orgán, pouze pokud tak stanoví zákon. Dbá přitom § 1a, 2 a 3.** {uc=A}

~~(1)~~ **(2)** Vyjádření dotčeného orgánu obsahuje závěr a odůvodnění. V závěru dotčený orgán uvede, zda je záměr z hlediska jím chráněných veřejných zájmů přípustný. V odůvodnění dotčený orgán stručně uvede důvody, o které opírá svůj závěr, podklady pro jeho vydání a úvahy, kterými se řídil při jejich hodnocení a při výkladu právních předpisů, na kterých je závěr založen. {uc=A}

~~(2)~~ **(3)** Je-li to nezbytné pro ochranu jím chráněných veřejných zájmů, dotčený orgán uvede v závěru též podmínky přípustnosti záměru. Dotčený orgán je povinen dbát, aby podmínky byly ve vzájemném souladu. {uc=A}

#### ~~§ 176 — Koordinované vyjádření a koordinované závazné stanovisko~~

> **Nahrazuje se novým zněním (níže).**

~~(1) Je-li dotčeným orgánem podle jiného právního předpisu tentýž orgán veřejné správy, vydá namísto jednotlivých vyjádření koordinované vyjádření a namísto jednotlivých závazných stanovisek koordinované závazné stanovisko. Ustanovení správního řádu o společném řízení a ustanovení o řešení rozporů se použijí přiměřeně.~~

~~(2) Koordinované vyjádření nebo koordinované závazné stanovisko zahrnuje požadavky na ochranu všech dotčených veřejných zájmů, které orgán veřejné správy hájí podle jiných právních předpisů.~~

~~(3) Koordinované závazné stanovisko nezahrnuje~~

~~a) závazné stanovisko k posouzení vlivů provedení záměru na životní prostředí podle zákona o posuzování vlivů na životní prostředí a~~

~~b) jednotné environmentální stanovisko podle zákona o jednotném environmentálním stanovisku, vydává-li se současně jako závazné stanovisko k posouzení vlivů provedení záměru na životní prostředí podle zákona o posuzování vlivů na životní prostředí.~~

~~(4) V závěru koordinovaného vyjádření nebo koordinovaného závazného stanoviska orgán veřejné správy souhrnně uvede, zda je záměr z hlediska všech jím chráněných veřejných zájmů přípustný. Ustanovení § 175 odst. 2 se použije obdobně.~~

~~(5) Koordinované závazné stanovisko je platné 5 let ode dne jeho vydání. Zahrnuje-li koordinované závazné stanovisko jednotné environmentální závazné stanovisko, použijí se ustanovení o platnosti jednotného environmentálního závazného stanoviska podle zákona o jednotném environmentálním stanovisku pro koordinované závazné stanovisko obdobně.~~

#### § 176 — **Závazné stanovisko**  `[272 Čl.I/397]` {uc=A}

**(1) Závazné stanovisko k záměru vydává dotčený orgán, pouze pokud tak stanoví zákon. Dbá přitom § 1a, 2 a 3.** {uc=A}

**(2) Je-li to nezbytné pro ochranu jím chráněných veřejných zájmů, dotčený orgán uvede v závazném stanovisku též podmínky přípustnosti záměru. Dotčený orgán je povinen dbát, aby podmínky byly ve vzájemném souladu.** {uc=A}

#### § 177 — Žádost  `[272 Čl.I/398]` {uc=A}

(1) Žádost o vyjádření nebo závazné stanovisko obsahuje kromě obecných náležitostí podle správního řádu dokumentaci **pro povolení záměru v rozsahu nezbytném pro vydání vyjádření nebo závazného stanoviska**, identifikační údaje o záměru a popřípadě další náležitosti podle jiných právních předpisů. {uc=A}

(2) Nemá-li žádost o vyjádření nebo závazné stanovisko stanovené náležitosti nebo trpí-li jinými vadami, vyzve dotčený orgán žadatele k jejich odstranění nejpozději do 10 dnů od jejího podání, poskytne mu k tomu přiměřenou lhůtu a poučí jej o následcích neodstranění nedostatků žádosti.

(3) Neodstraní-li žadatel vady žádosti, dotčený orgán písemně sdělí žadateli, že vyjádření nebo závazné stanovisko nemůže být vydáno. Po dobu odstraňování vad žádosti lhůta pro vydání vyjádření nebo závazného stanoviska neběží. Ode dne odstranění vad žádosti počne běžet nová lhůta pro jejich vydání.

#### § 178 — Lhůta pro vydání  `[272 Čl.I/399; 272 Čl.I/400; 272 Čl.I/401; 272 Čl.I/402]` {uc=A}

(1) Dotčený orgán vydá do 30 dnů ode dne doručení žádosti nebo vyžádání stavebním úřadem vyjádření nebo závazné stanovisko k záměru z hlediska jím chráněných veřejných zájmů. **V případě zrušení vyjádření nebo závazného stanoviska dotčený orgán vydá nové vyjádření nebo závazné stanovisko do 30 dnů ode dne, kdy mu bylo doručeno rozhodnutí o jeho zrušení. Nevydá-li dotčený orgán vyjádření nebo závazné stanovisko ve lhůtě pro jeho vydání, považuje se za souhlasné a bez podmínek.** {uc=A}

(2) ~~Lhůtu~~ **Při přezkumu závazného stanoviska** podle ~~odstavce 1 může~~ **§ 149 odst. 7 správního řádu nadřízený** dotčený orgán ~~prodloužit až o~~ **závazné stanovisko potvrdí nebo změní do** 30 dnů **ode dne vyžádání jeho potvrzení nebo změny; zrušit jej může pouze v případě**, ~~jestliže je zapotřebí nařídit ohledání na místě nebo jde~~ **že nemělo být vůbec vydáno. Nevydá** -li ~~o zvlášť složitý případ. Lhůtu podle odstavce 1 může~~ **nadřízený** dotčený orgán ~~prodloužit také z důvodu,~~ **závazné stanovisko ve lhůtě** pro ~~který lze prodloužit lhůtu pro~~ **jeho** vydání ~~jednotného environmentálního stanoviska podle zákona o jednotném environmentálním stanovisku, jde~~ **a přezkoumává** -li ~~o koordinované~~ **souhlasné** závazné stanovisko, ~~které zahrnuje jednotné environmentální stanovisko~~ **platí, že jej dnem uplynutí lhůty k přezkumu potvrdil**. ~~O prodloužení lhůty vydá dotčený orgán usnesení, které se pouze poznamená do spisu.~~ {uc=A}

(3) ~~Nevydá-li dotčený orgán vyjádření nebo závazné stanovisko ve lhůtě pro jeho vydání, považuje se za souhlasné~~ **Lhůty podle odstavců 1** a ~~bez podmínek~~ **2 nelze prodloužit**. {uc=A}

(4) Ustanovení odstavce ~~3~~ **1 věty třetí** se nepoužije na {uc=A}

a) závazné stanovisko k posouzení vlivů provedení záměru na životní prostředí podle zákona o posuzování vlivů na životní prostředí,

b) ~~jednotné environmentální~~ **závazné** stanovisko ~~vydané podle zákona o jednotném environmentálním stanovisku namísto závazného stanoviska k posouzení vlivů provedení záměru na životní prostředí podle zákona o posuzování vlivů na životní prostředí nebo správního úkonu orgánu ochrany přírody~~ podle zákona o ochraně přírody a krajiny, kterým se {uc=A}

1. posuzuje splnění podmínek pro stanovení odchylného postupu při ochraně ptáků,

2. vyslovuje souhlas k zásahům, které by mohly vést k závažnému nebo nevratnému poškození nebo ke zničení evropského stanoviště nebo stanoviště evropsky významných druhů,

3. uděluje souhlas k činnostem v ptačích oblastech,

4. posuzuje splnění podmínek pro povolení výjimky ze zákazů u zvláště chráněných druhů rostlin a živočichů, které jsou předmětem ochrany podle práva Evropské unie,

5. uděluje souhlas k činnostem vymezeným v bližších ochranných podmínkách zvláště chráněných území, která byla vyhlášena k zajištění udržení příznivého stavu evropských stanovišť nebo stanovišť evropsky významných druhů, které jsou předmětem ochrany evropsky významných lokalit.

#### § 179 — Nové vyjádření a závazné stanovisko dotčeného orgánu  `[272 Čl.I/403; 272 Čl.I/404]` {uc=AB}

(1) Nebyly-li v případě uvedeném v § 178 odst. ~~3~~ **1** splněny předpoklady pro vydání souhlasného vyjádření nebo závazného stanoviska bez podmínek, vydá nadřízený správní orgán nové vyjádření nebo závazné stanovisko, kterým ~~se~~ vyjádření nebo závazné stanovisko ~~ruší~~ **změní**. {uc=A}

(2) Nové vyjádření nebo závazné stanovisko lze vydat do ~~6 měsíců ode dne~~ právní moci rozhodnutí, pro které bylo vyjádření nebo závazné stanovisko podkladem. {uc=B}

#### ~~§ 179a — Přezkum závazného stanoviska v přezkumném řízení~~

> **Nahrazuje se novým zněním (níže).**

~~Zahájit přezkumné řízení, jehož předmětem je závazné stanovisko sloužící jako podklad pro řízení podle tohoto zákona, lze do 6 měsíců od právní moci rozhodnutí, jehož bylo závazné stanovisko podkladem. Závazné stanovisko nelze v přezkumném řízení zrušit nebo změnit po uplynutí 9 měsíců od právní moci rozhodnutí, jehož bylo závazné stanovisko podkladem.~~

#### § 179a  `[272 Čl.I/405]` {uc=B}

**Přezkum vyjádření a závazného stanoviska v přezkumném řízení Vyjádření a závazné stanovisko nelze v přezkumném řízení zrušit nebo změnit po právní moci rozhodnutí, jehož bylo vyjádření nebo závazné stanovisko podkladem.** {uc=B}

##### Díl 3

*Vyjádření vlastníka veřejné dopravní nebo technické infrastruktury*

#### § 180 — Žádost  `[272 Čl.I/406]` {uc=A}

(1) Žádost o vyjádření vlastníka veřejné dopravní nebo technické infrastruktury z hlediska možnosti a způsobu napojení záměru nebo k podmínkám dotčených ochranných a bezpečnostních pásem musí obsahovat identifikační údaje žadatele a identifikační údaje o záměru.

(2) Žádost o vyjádření lze podat prostřednictvím portálu stavebníka, pokud má vlastník veřejné dopravní nebo technické infrastruktury zřízenu datovou schránku nebo přístup k datovému rozhraní portálu stavebníka.

(3) Součástí žádosti je ~~vždy~~ dokumentace pro povolení záměru **v rozsahu nezbytném pro vydání vyjádření**. {uc=A}

#### § 181 — Lhůta a způsob doručení  `[272 Čl.I/407; 272 Čl.I/408; 272 Čl.I/409]` {uc=A}

(1) Vlastník veřejné dopravní nebo technické infrastruktury vydá vyjádření k záměru do 30 dnů~~, ve zvlášť složitých případech do 60 dnů~~ ode dne doručení úplné žádosti. **Pro stanovení podmínek záměru v případě energetické technické infrastruktury může její vlastník prodloužit lhůtu před jejím uplynutím o 15 dnů, je- li to nezbytné.** {uc=A}

(2) ~~Má se za to, že žádost~~ **Žádost** podaná prostřednictvím portálu stavebníka je vlastníkovi veřejné dopravní nebo technické infrastruktury, který má zřízen přístup k datovému rozhraní portálu stavebníka, doručena okamžikem jejího odeslání. {uc=A}

(3) Vlastník veřejné dopravní nebo technické infrastruktury, který má zřízen přístup k datovému rozhraní portálu stavebníka, doručí své vyjádření jeho vložením do evidence stavebních postupů. Vyjádření je doručeno okamžikem jeho vložení do evidence stavebních postupů.

(4) Za vlastníka veřejné dopravní nebo technické infrastruktury činí úkony její správce nebo provozovatel v rozsahu, v jakém plní editační povinnost správce technické infrastruktury podle seznamu editorů digitálních technických map krajů vedeného na základě zákona o zeměměřictví.

**(5) Nevydá-li vlastník veřejné dopravní nebo technické infrastruktury vyjádření k záměru ve lhůtě pro jeho vydání, považuje se za souhlasné a bez podmínek.** {uc=A}

#### HLAVA III

*ŘÍZENÍ O POVOLENÍ ZÁMĚRU*

##### Díl 1

*Obecná ustanovení o řízení*

#### § 182 — Účastníci řízení  `[272 Čl.I/410]` {uc=B}

Účastníky řízení jsou

a) stavebník,

b) obec, na jejímž území má být záměr uskutečněn,

c) vlastník pozemku nebo stavby, na kterých má být záměr uskutečněn, nebo ten, kdo má jiné věcné právo k tomuto pozemku nebo stavbě,

d) osoby, jejichž vlastnické nebo jiné věcné právo k sousedním stavbám nebo sousedním pozemkům může být rozhodnutím o povolení záměru přímo dotčeno,

e) osoby, o kterých tak stanoví jiný zákon.

**(1) Zemřela-li osoba, která byla nebo by měla být účastníkem řízení, jemuž má být doručena písemnost jednotlivě, a stavebnímu úřadu se do 30 dnů ode dne, kdy zjistil, že zemřela, nepodaří zjistit osoby, které by se v důsledku její smrti staly účastníky řízení, ustanoví jim opatrovníka.** {uc=B}

#### § 183 — Společenství vlastníků jednotek  `[272 Čl.I/411]` {uc=B}

~~Je~~ **Jsou** -li ~~stavebníkem~~ **účastníkem řízení vlastníci jednotek, je** společenství vlastníků jednotek41)~~, je~~ **jejich** zástupcem ~~vlastníků jednotek, kteří jsou účastníky řízení~~. Oznámí-li zastoupený vlastník jednotky stavebnímu úřadu, že nadále nechce být zastupován společenstvím vlastníků jednotek, jeho zastoupení zaniká okamžikem, kdy toto oznámení dojde stavebnímu úřadu. {uc=B}

#### § 184 — Žádost  `[272 Čl.I/412; 272 Čl.I/413; 272 Čl.I/414; 272 Čl.I/415; 272 Čl.I/416; 272 Čl.I/417]` {uc=AB}

(1) Žádost o povolení záměru obsahuje kromě obecných náležitostí podle správního řádu

a) základní údaje o záměru, jeho rozsahu a účelu, způsobu a době provádění,

b) identifikační údaje o pozemku nebo stavbě, na nichž se má záměr uskutečnit,

c) dobu trvání u dočasné stavby a návrh úpravy pozemku po jejím odstranění.

(2) Součástí žádosti je

a) dokumentace pro povolení záměru,

b) plánovací smlouva, je-li uzavřena,

c) souhlas vlastníka,

d) souhlas účastníků řízení se záměrem, pokud stavebník žádá o vydání povolení ve zrychleném řízení,

e) vyjádření, závazné stanovisko nebo rozhodnutí dotčeného orgánu, **týká-li se záměr jím chráněných veřejných zájmů a** je-li vyžadováno tímto zákonem nebo jiným právním předpisem, nebo náležitosti žádosti podle § 177, není-li vyjádření nebo závazné stanovisko součástí žádosti, {uc=A}

f) vyjádření vlastníků veřejné dopravní nebo technické infrastruktury uvedených v digitální technické mapě, **týká-li se záměr této infrastruktury,** {uc=A}

g) závěr zjišťovacího řízení, že záměr nepodléhá posouzení vlivů na životní prostředí podle zákona o posuzování vlivů na životní prostředí, byl-li vydán,

h) **odůvodnění odchylného použití požadavků na výstavbu podle § 137 odst. 4 až 8 nebo** specifikace výjimky z obecných požadavků na výstavbu požadované k realizaci záměru a její odůvodnění a vyjádření nebo závazné stanovisko dotčeného orgánu, který hájí zájmy podle jiných právních předpisů, kterých se výjimka z obecných požadavků týká, {uc=A}

i) další podklad vyžadovaný jinými právními předpisy.

(3) Není-li součástí žádosti vyjádření nebo závazné stanovisko vyžadované tímto zákonem nebo jiným právním předpisem, stavební úřad si je vyžádá u dotčeného orgánu; to neplatí pro závazné stanovisko k ~~ověření změn~~ **posouzení vlivů provedení** záměru **na životní prostředí** podle ~~§ 9a odst. 6~~ zákona o posuzování vlivů na životní prostředí **a pro vyhrazené stavby**. {uc=A}

(4) Vyžádáním podle odstavce 3 se běh lhůty pro vydání rozhodnutí staví do doby vydání vyjádření nebo závazného stanoviska, nejpozději však do dne, kdy nastane skutečnost podle § 178 odst. ~~3~~ **1**. {uc=A}

**(5) K žádosti lze připojit nebo doplnit návrh rozhodnutí o žádosti.** {uc=B}

#### § 185 — Vady žádosti  `[272 Čl.I/418; 272 Čl.I/419; 272 Čl.I/420]` {uc=A}

(1) Při výzvě k odstranění vad žádosti postupuje stavební úřad tak, aby mohly být všechny vady odstraněny najednou, je-li to možné.

(2) Stavební úřad vyzve stavebníka k doplnění žádosti a odstranění vad žádosti nejpozději do 10 dnů od zahájení řízení ~~a řízení usnesením přeruší~~; usnesení se doručuje pouze stavebníkovi a nelze se proti němu odvolat. {uc=A}

(3) Stavební úřad žádost neprojedná a usnesením ji odloží, **není-li součástí žádosti dokumentace pro povolení záměru.** {uc=A}

~~a) není-li součástí žádosti dokumentace pro povolení záměru,~~

~~b) není-li projektová dokumentace nebo její část zpracována projektantem, nebo~~

~~c) nevloží-li stavebník projektovou dokumentaci nebo dokumentaci pro povolení záměru do evidence elektronických dokumentací.~~

(4) Usnesení o odložení žádosti **a usnesení o zastavení řízení z důvodu neodstranění vad žádosti nebo nezaplacení správního poplatku** se oznamuje pouze stavebníkovi. {uc=A}

#### § 186 — Závěr zjišťovacího řízení  `[272 Čl.I/421]` {uc=A}

(1) V případě záměru, pro který byl vydán závěr zjišťovacího řízení podle jiného právního předpisu42), že záměr nepodléhá posouzení vlivů na životní prostředí, stavební úřad ověří, zda nedošlo ke změnám záměru, které by mohly mít významný negativní vliv na životní prostředí. Stavební úřad zejména ověří, zda nedošlo ke zvýšení kapacity a rozsahu záměru nebo ke změně jeho technologie, řízení provozu nebo způsobu užívání43).

(2) Dojde-li stavební úřad na základě ověření podle odstavce 1 k závěru, že došlo ke změnám záměru, které by mohly mít významný negativní vliv na životní prostředí, vyzve stavebníka k předložení závěru zjišťovacího řízení podle odstavce 1 k takto změněnému záměru. V takovém případě stavební úřad řízení přeruší ~~a postupuje podle ustanovení jiného právního předpisu~~. {uc=A}

#### § 187 — Souhlas vlastníka  `[272 Čl.I/422; 272 Čl.I/423; 272 Čl.I/424; 272 Čl.I/425; 272 Čl.I/426]` {uc=B}

(1) Je-li stavebník vlastníkem pozemku nebo stavby, na nichž má být záměr uskutečněn, nebo je-li oprávněn k realizaci záměru z práva stavby nebo ze služebnosti, ověří stavební úřad tuto skutečnost v katastru nemovitostí. Vlastnické právo ke stavbě, která není předmětem evidence v katastru nemovitostí, doloží stavebník čestným prohlášením. **V případě zákonné služebnosti, která není předmětem evidence v katastru nemovitostí, doloží stavebník naplnění podmínek pro její vznik čestným prohlášením; obdobně se postupuje v případech, kdy má zákonné věcné břemeno podle jiného právního předpisu vzniknout na základě pravomocného rozhodnutí o povolení záměru83).** {uc=B}

(2) Není-li stavebník vlastníkem pozemku, na němž má být záměr uskutečněn, a není-li ani oprávněn k realizaci záměru z práva stavby nebo ze služebnosti, dokládá stavebník souhlas vlastníka pozemku, který je zapsán v katastru nemovitostí ke dni podání žádosti. To platí obdobně i v případě, že stavebník není vlastníkem stavby, která není součástí pozemku. Souhlas vlastníka pozemku nebo stavby nelze vzít zpět po podání žádosti o povolení záměru. Dojde-li po podání žádosti k podstatné změně záměru, **která se týká vlastníka,** lze záměr povolit, jen doloží-li stavebník souhlas vlastníka pozemku nebo stavby s upraveným záměrem. {uc=B}

(3) Souhlas musí být vyznačen na situačním výkresu dokumentace **nebo k němu být připojen** a musí obsahovat identifikační údaje a podpis vlastníka pozemku nebo stavby, na nichž má být záměr povolen, nebo oprávněného k realizaci záměru z práva stavby nebo ze služebnosti. ~~Identifikačními údaji jsou u~~ {uc=B}

a) fyzické osoby jméno, příjmení, datum narození, adresa místa trvalého pobytu, a nemá-li ji, adresa bydliště,

b) právnické osoby název, sídlo a identifikační číslo osoby, bylo-li přiděleno.

(4) K souhlasu vlastníka pozemku nebo stavby, které jsou v podílovém spoluvlastnictví, je třeba souhlas dvoutřetinové většiny spoluvlastníků podle výše jejich podílů; v případě bytového spoluvlastnictví postačí pouze souhlas společenství vlastníků jednotek, nebo správce, pokud společenství vlastníků jednotek nevzniklo.

(5) Souhlas není potřeba, je-li pro získání potřebných práv k pozemku nebo stavbě pro záměr stanoven zákonem účel vyvlastnění. **a doručování** {uc=B}

#### § 188 — Vyrozumění o zahájení řízení  `[272 Čl.I/428; 272 Čl.I/429; 272 Čl.I/430; 272 Čl.I/431]` {uc=B}

(1) Bezodkladně, nejpozději do ~~7~~ **10** dnů od zahájení řízení doručením bezvadné žádosti nebo od odstranění vad žádosti vyrozumí stavební úřad účastníky řízení~~,~~ **a** dotčené orgány**, pokud jsou záměrem dotčeny jimi chráněné veřejné zájmy** a ~~hlavního projektanta~~ **pokud se již k záměru nevyjádřily,** o zahájení řízení. Ve vyrozumění **vyzve k podání námitek ve lhůtě 10 dnů od doručení výzvy a** uvede, jakým způsobem se mohou účastníci řízení se záměrem seznámit a zda, popřípadě kdy bude ve věci nařízeno ústní jednání anebo veřejné ústní jednání, a zda bude ústní jednání spojeno s ohledáním na místě. {uc=B}

(2) Vyrozumění o zahájení řízení obsahuje také poučení o podmínkách pro uplatňování námitek účastníků řízení, popřípadě připomínek veřejnosti.

(3) Účastníci řízení podle § 182 **odst. 1** písm. d) se ve vyrozumění o zahájení řízení s velkým počtem účastníků a v dalších písemnostech v řízení identifikují označením pozemků a staveb evidovaných v katastru nemovitostí. {uc=B}

(4) V řízení s velkým počtem účastníků se vyrozumění o zahájení řízení doručuje účastníkům řízení podle § 182 písm. a), b) a c) jednotlivě. Ostatní písemnosti se doručují jednotlivě pouze žadateli, obci, na jejímž území má být záměr uskutečněn, a dotčeným orgánům; ostatním účastníkům řízení se doručují veřejnou vyhláškou, o čemž se tito účastníci poučí ve vyrozumění o zahájení řízení. ~~Při doručování do ciziny se písemnost doručuje na adresu uvedenou v katastru nemovitostí a za den doručení se považuje třicátý den od předání písemnosti k poštovní přepravě.~~ {uc=B}

(5) ~~U záměru zasahujícího~~ **Při doručování** do ~~území několika obcí~~ **ciziny** se ~~vyrozumění o zahájení řízení~~ **písemnost doručuje na adresu uvedenou v katastru nemovitostí** a ~~další úkony v řízení oznamují rovněž vyvěšením na úředních deskách všech těchto obcí~~ **za den doručení se považuje patnáctý den od předání písemnosti k poštovní přepravě, neprokáže-li se doručení dříve**. {uc=B}

#### § 189 — Ústní jednání  `[272 Čl.I/432; 272 Čl.I/433]` {uc=B}

(1) Nařídí-li stavební úřad ústní jednání, vyrozumí účastníky řízení a dotčené orgány o termínu jeho konání nejméně ~~15~~ **10** dnů předem. ~~Nebude-li nařízeno ústní jednání, stavební úřad ve vyrozumění o zahájení řízení určí lhůtu, která nesmí být kratší než 15 dnů, do kdy mohou účastníci řízení podat námitky.~~ {uc=B}

(2) V případě záměru v území, ve kterém nebyl vydán územní plán, nařídí stavební úřad vždy veřejné ústní jednání. V případech záměrů EIA v území, ve kterém byl vydán územní plán, může stavební úřad nařídit veřejné ústní jednání. Konání veřejného ústního jednání se veřejnosti oznamuje veřejnou vyhláškou a může být stanoveno nejdříve po uplynutí ~~30~~ **15** dnů ode dne doručení veřejnou vyhláškou; po tuto dobu stavební úřad umožní každému nahlédnout do podkladů pro vydání rozhodnutí. {uc=B}

#### § 190 — Námitky účastníků řízení  `[272 Čl.I/434; 272 Čl.I/435; 272 Čl.I/436; 272 Čl.I/437; 272 Čl.I/438]` {uc=A}

(1) Námitky účastníků řízení musí být uplatněny nejpozději při ústním jednání, popřípadě při veřejném ústním jednání, a nebylo-li nařízeno, ve lhůtě stanovené ve vyrozumění o zahájení řízení. K později uplatněným námitkám stavební úřad přihlédne a vypořádá je pouze tehdy, týkají-li se nově doplněných podkladů pro rozhodnutí, k nimž nebylo možné uplatnit námitku dříve. K námitkám o věcech, o kterých bylo rozhodnuto při vydání územně plánovací dokumentace, se nepřihlíží**, jinak se k nim nepřihlíží**. {uc=A}

(2) Účastníci řízení mohou uplatňovat námitky směřující k hájení jejich procesních práv; další námitky pouze v rozsahu uvedeném v odstavci 3. K námitkám, které přesahují rozsah odstavce 3, stavební úřad nepřihlíží. Stavební úřad dále nepřihlíží k námitkám účastníka řízení, které **směřují proti tomu, s čím účastník řízení souhlasil, k námitkám účastníka řízení, které přesahují působnost stavebního úřadu podle § 193, a k námitkám účastníka řízení, které** jsou v rozporu s uzavřenou plánovací smlouvou, jejíž smluvní stranou je tento účastník řízení. {uc=A}

(3) Obec jako účastník řízení může uplatňovat námitky pouze v rozsahu ~~své~~ **územně plánovací dokumentace, kterou schválila, a ochrany dalších hodnot v její** samostatné působnosti. Účastník řízení podle § 182 **odst. 1** písm. c) a d) může uplatňovat námitky pouze v rozsahu možného přímého dotčení ~~svých práv~~ **svého vlastnického nebo jiného věcného práva**. Účastník řízení podle § 182 **odst. 1** písm. e) může uplatňovat námitky pouze v rozsahu, v jakém se projednávaný záměr dotýká zájmů chráněných jiným právním předpisem, který zakládá jeho účastenství v řízení podle tohoto zákona. ~~Účastník řízení je povinen v námitce uvést důvody podání námitky.~~ {uc=A}

**(4) Účastník řízení je povinen v námitce uvést důvody podání námitky a rozsah, v jakém jsou dotčeny jeho práva nebo zájmy, které jsou chráněny podle odstavce 3, jinak k ní stavební úřad nepřihlíží.** {uc=A}

~~(4)~~ **(5)** Shledá-li stavební úřad námitku důvodnou, umožní stavebníkovi se k ní vyjádřit, k čemuž mu poskytne přiměřenou lhůtu. Výzvu k vyjádření stavebníka může stavební úřad spojit s jiným úkonem v řízení. {uc=A}

**(6) Souhlas účastníka řízení se záměrem nelze vzít po podání žádosti o povolení záměru zpět ani jej změnit, nedojde-li k podstatné změně záměru.** {uc=A}

#### § 190a — **Námitka podjatosti úřední osoby**  `[272 Čl.I/439]` {uc=B}

**(1) Námitku podjatosti musí účastník řízení uplatnit do jednoho týdne ode dne, kdy se o podjatosti dozvěděl; zjistí-li důvod podjatosti při ústním jednání, musí ji uplatnit při tomto jednání. K později uplatněným námitkám se nepřihlíží. Námitka podjatosti musí být zdůvodněna a musí v ní být uvedeny konkrétní skutečnosti a navrženy důkazy, z nichž je dovozována, jinak se k ní nepřihlíží.** {uc=B}

**(2) Proti rozhodnutí o námitce podjatosti není odvolání ani přezkumné řízení přípustné.** {uc=B}

#### § 191 — Námitky o existenci nebo rozsahu věcných práv

(1) Námitky týkající se existence nebo rozsahu vlastnických nebo jiných věcných práv posoudí stavební úřad podle údajů v katastru nemovitostí. Svědčí-li vlastnické nebo jiné věcné právo stavebníkovi, stavební úřad k námitce nepřihlíží.

(2) Zakládají-li údaje v katastru nemovitostí pochybnosti o existenci nebo rozsahu vlastnického nebo jiného věcného práva, stavební úřad řízení přeruší a vyzve účastníka řízení, který takovou námitku uplatnil, aby ji uplatnil ve stanovené lhůtě u soudu.

(3) Nebylo-li ve stanovené lhůtě zahájeno soudní řízení, návrh byl soudem odmítnut nebo bylo řízení zastaveno, stavební úřad k námitce nepřihlíží.

#### § 191a — **Smír**  `[272 Čl.I/440]` {uc=A}

**(1) Na žádost stavebníka stavební úřad nařídí ústní jednání k projednání námitek a dosažení smíru. Obsahem smíru může být zejména změna žádosti, zpětvzetí námitek, poskytnutí finanční náhrady nebo provedení kompenzačních nebo zmírňujících opatření. Ustanovení § 141 odst. 8 správního řádu se použije obdobně. Je-li součástí schváleného smíru provedení kompenzačních nebo zmírňujících opatření, stavební úřad je zahrne do podmínek v rozhodnutí o povolení záměru podle § 195.** {uc=A}

**(2) Nezúčastní-li se účastník řízení bez důvodné omluvy nařízeného jednání o smíru, k jeho námitkám se nepřihlíží.** {uc=A}

#### § 192 — Připomínky veřejnosti

(1) Je-li nařízeno veřejné ústní jednání, může každý uplatnit připomínky, a to nejpozději na tomto jednání. K připomínkám o věcech, o kterých bylo rozhodnuto při vydání územně plánovací dokumentace, se nepřihlíží.

(2) K později uplatněným připomínkám stavební úřad přihlédne a vyhodnotí je pouze tehdy, týkají-li se nově doplněných podkladů pro rozhodnutí, k nimž nebylo možné uplatnit připomínku dříve.

(3) Vyhodnocení připomínek veřejnosti se uvede jako součást odůvodnění rozhodnutí o povolení záměru.

#### § 193 — Posuzování záměru  `[272 Čl.I/69; 272 Čl.I/441; 272 Čl.I/442; 272 Čl.I/443; 272 Čl.I/444; 272 Čl.I/445; 272 Čl.I/446]` {uc=AB}

(1) Stavební úřad posuzuje, zda je záměr v souladu s **podle zásad uvedených v § 1a. Soulad záměru s požadavky jiných právních předpisů chránících dotčené veřejné zájmy posoudí oprávněná úřední osoba splňující příslušné kvalifikační požadavky podle § 37 odst. 3** {uc=A}

a) územně plánovací dokumentací, územními opatřeními a vymezením ~~zastavěného~~ **zastavitelného** území, {uc=A}

b) cíli a úkoly územního plánování, zejména s charakterem území a s požadavky na ochranu kulturně historických, architektonických a urbanistických hodnot v území, nemá-li obec ~~vydán~~ **pro dané území** územní plán **nebo regulační plán**, {uc=A}

c) požadavky tohoto zákona a jeho prováděcích právních předpisů, **s výjimkou technických požadavků na stavby, za jejichž splnění v dokumentaci pro povolení záměru odpovídá projektant nebo osoba uvedená v § 156 odst. 2,** {uc=A}

d) požadavky jiných právních předpisů chránících dotčené veřejné zájmy,

e) požadavky na veřejnou dopravní nebo technickou infrastrukturu,

f) ochranou práv a právem chráněných zájmů účastníků řízení,

**(2) Se souhlasem toho, kdo územně plánovací dokumentaci, územní opatření nebo vymezení zastavitelného území vydal, a se souhlasem vlastníka pozemku, pokud by se jinak vyžadoval podle § 187, se záměr může odchýlit od územně plánovací dokumentace, územního opatření nebo vymezení zastavitelného území, pokud nenaruší veřejné zájmy a nedotkne se jiných osob, ochranných pásem nebo koridorů. Pro ochranná pásma platí možnost odchýlení se od jejich vymezení se souhlasem toho, v jehož zájmu jsou vymezena, přiměřeně. Záměr vyhrazené stavby v zastavitelném území, o kterém je uzavřena plánovací smlouva mezi stavebníkem a tím, kdo územně plánovací dokumentaci, územní opatření nebo vymezení zastavitelného území vydal, ve které se stavebník zaváže podat podnět k pořízení změny územně plánovací dokumentace tak, aby s ní byl záměr v souladu, a uhradit náklady uvedené v** {uc=AB}

**§ 91 odst. 1, nenarušuje veřejné zájmy.** {uc=AB}

které hodnotí a poměřuje ve vzájemných souvislostech.

~~(2)~~ **(3)** Při posuzování souladu záměru s požadavky jiných právních předpisů vychází stavební úřad z vyjádření nebo závazného stanoviska dotčeného orgánu nebo z výsledků řešení rozporů**. Stavební úřad nepřihlíží k vyjádřením a závazným stanoviskům dotčených orgánů v částech, v nichž překračují jejich působnost, a ve věcech, o nichž bylo rozhodnuto již při vydání územně plánovací dokumentace**. Na vyžádání stavebního úřadu vydá dotčený orgán do 5 dnů sdělení k návrhům, námitkám, vyjádřením nebo návrhům důkazů účastníků řízení, které se týkají jím chráněného veřejného zájmu. {uc=A}

**(4) Při posuzování souladu záměru s požadavky vlastníků veřejné dopravní a technické infrastruktury, s výjimkou technické infrastruktury, s níž je příslušné hospodařit Ministerstvo obrany, Ministerstvo vnitra nebo Vězeňská služba České republiky, stavební úřad vychází z jimi vydaných vyjádření a z údajů uvedených v digitální technické mapě týkajících se existence sítí a vlastníků této infrastruktury. Má se za to, že sítě, které nejsou uvedeny v digitální technické mapě, neexistují, a případné následky jdou k tíži vlastníka veřejné dopravní a technické infrastruktury.** {uc=AB}

**(5) Při posuzování ochrany práv a právem chráněných zájmů účastníků řízení stavební úřad vychází z jejich vlastních včasných a přípustných námitek podle § 190 až 191. Nepřípustné jsou námitky účastníka, k nimž se podle zákona nepřihlíží. Nepřípustné námitky stavební úřad nevypořádává. Námitky, které nespočívají v porušení právních předpisů, nejsou důvodné.** {uc=AB}

**(6) Splnění podmínek podle odstavce 1 se posuzuje ke dni podání žádosti; to platí i v odvolacím, přezkumném, soudním a opakovaném řízení. Pokud o to stavebník požádá, posuzuje se splnění podmínek podle odstavce 1 ke dni rozhodnutí.** {uc=AB}

#### § 194 — **Posuzování záměru v zastavitelném území**  `[272 Čl.I/447]` {uc=B}

**(1) Má se za to, že stavební záměr umisťovaný v zastavitelném území nebo v koridoru pro stavební záměr v souladu s územně plánovací dokumentací a v souladu s požadavky na výstavbu je přípustný, a to i z hlediska jiných zákonů, jejichž požadavky byly zohledněny v územně plánovací dokumentaci. Je-li to potřebné, stavební úřad stanoví podmínky k zajištění ochrany veřejných zájmů a práv účastníků řízení.** {uc=B}

**(2) Má se za to, že povolení záměru v zastavitelném území nebo v koridoru pro stavební záměr je v souladu s ochranou práv a právem chráněných zájmů účastníků řízení, pokud záměr splňuje požadavky na výstavbu a odpovídá plánovanému charakteru území, běžné okolní zástavbě nebo běžnému využívání okolního území.** {uc=B}

**(3) Při rozhodování v území, které již bylo v souladu se stanoviskem orgánu ochrany přírody vymezeno v územně plánovací dokumentaci jako zastavitelné území, koridor pro stavební záměr nebo plocha těžby, se při povolení záměru neposuzuje krajinný ráz.** {uc=B}

**(4) Při rozhodování v území, které bylo v souladu se stanoviskem orgánu ochrany zemědělského půdního fondu vymezeno v územně plánovací dokumentaci jako zastavitelné území, koridor pro stavební záměr nebo plocha těžby, se při povolení záměru neposuzují zásady plošné ochrany podle § 4 odst. 1 až 5 zákona o ochraně zemědělského půdního fondu.** {uc=B}

#### § 194a — **Vyjádření stavebníka**  `[272 Čl.I/447]` {uc=B}

**(1) Dojde-li stavební úřad po projednání a posouzení žádosti k předběžnému závěru, že žádosti o povolení záměru nelze vyhovět, vyrozumí o tomto předběžném závěru a jeho důvodech stavebníka, podle okolností jej poučí o možnostech řešení a vyzve jej, aby se k němu ve stanovené lhůtě vyjádřil; za tímto účelem může řízení přerušit. Obdobně postupuje stavební úřad i v případě, že z projednání žádosti vyplývá nezbytnost uložení podmínek, které nejsou v souladu s podklady předloženými stavebníkem.** {uc=B}

**(2) Nelze-li žádosti vyhovět i přes vyjádření nebo jiný úkon stavebníka, nebo se stavebník ve stanovené lhůtě nevyjádřil nebo neprovedl jiný úkon, neprovádí stavební úřad další úkony a žádost zamítne. Pokud stavební úřad dosud nevyrozuměl další účastníky o zahájení řízení, doručí rozhodnutí o zamítnutí žádosti pouze stavebníkovi.** {uc=B}

**(3) Vyrozumění podle odstavce 1 může stavební úřad spojit s jiným úkonem v řízení.** {uc=B}

#### § 195 — Rozhodnutí o záměru  `[272 Čl.I/448]` {uc=A}

Jsou-li splněny podmínky podle § 193 nebo lze-li jejich splnění zajistit stanovením podmínek v rozhodnutí o povolení záměru, stavební úřad vydá povolení záměru; v opačném případě žádost o povolení záměru zamítne.

**(1) V rozhodnutí o záměru stavební úřad rozhodne též o ochraně veřejných zájmů podle** {uc=A}

**§ 1b. Vyžaduje-li ochrana veřejných zájmů podle § 1b stanovení podmínek rozhodnutí, je jejich stanovení součástí výroku rozhodnutí. V ostatních případech se ochrana veřejných zájmů podle** {uc=A}

**§ 1b projeví přímo v povolení, nebo v zamítnutí žádosti a v odůvodnění rozhodnutí, v souladu s požadavky § 1a.** {uc=A}

#### § 195a — **Přezkum rozhodnutí v přezkumném řízení**  `[272 Čl.I/449]` {uc=A}

**(1) Usnesení o zahájení přezkumného řízení lze vydat do 1 měsíce ode dne, kdy se příslušný správní orgán o důvodu zahájení přezkumného řízení dozvěděl, nejpozději však do 3 měsíců od právní moci rozhodnutí ve věci.** {uc=A}

**(2) Rozhodnutí v přezkumném řízení v prvním stupni nelze vydat po uplynutí 6 měsíců od právní moci rozhodnutí ve věci.** {uc=A}

#### § 195b — **Obnova řízení**  `[272 Čl.I/449]` {uc=A}

**(1) Účastník řízení může podat žádost o obnovu řízení do 1 měsíce ode dne, kdy se o důvodu obnovy řízení dozvěděl, nejpozději však do 3 měsíců od právní moci rozhodnutí ve věci.** {uc=A}

**(2) Rozhodnutí o obnově řízení v prvním stupni nelze vydat po uplynutí 6 měsíců od právní moci rozhodnutí ve věci. Bylo-li rozhodnutí dosaženo trestným činem, začíná tato lhůta běžet dnem nabytí právní moci rozsudku.** {uc=A}

#### § 196 — Lhůta pro vydání rozhodnutí  `[272 Čl.I/450; 272 Čl.I/451]` {uc=A}

(1) Stavební úřad rozhodne o žádosti nejpozději do

a) 30 dnů ode dne zahájení řízení v případě jednoduché stavby **a v případech**, **kdy je rozhodnutí prvním úkonem stavebního úřadu v řízení,** {uc=A}

b) 60 dnů ode dne zahájení řízení v ostatních případech.

(2) Lhůty podle odstavce 1 může stavební úřad před jejich uplynutím usnesením prodloužit

a) až o 30 dnů ve zvlášť složitých případech nebo je-li nařízeno ústní jednání, nebo

b) až o 60 dnů v řízení s velkým počtem účastníků, nebo je-li třeba doručovat veřejnou vyhláškou osobám, jimž se prokazatelně nedaří doručovat, nebo je-li třeba doručovat do ciziny.

(3) V usnesení o prodloužení lhůty stavební úřad uvede, z jakých důvodů nelze rozhodnout ve lhůtách podle odstavce 1 ~~nebo 2~~; toto usnesení stavební úřad pouze poznamená do spisu a vyrozumí o prodloužení lhůty pouze stavebníka. {uc=A}

(4) Lhůta pro vydání rozhodnutí se v případě přerušení řízení z důvodu vad žádosti přerušuje a začne znovu běžet od počátku po jejich odstranění.

#### § 197 — Povolení  `[272 Čl.I/452; 272 Čl.I/453; 272 Čl.I/454; 272 Čl.I/455]` {uc=A}

(1) Ve výrokové části povolení záměru stavební úřad

a) povolí záměr,

b) vymezí pozemky pro realizaci záměru~~, popřípadě stanoví podmínky pro dělení nebo scelování pozemků,~~ a stanoví podmínky pro jeho umístění a provedení, a pokud je to třeba, i pro jeho užívání, {uc=A}

c) stanoví podmínky, kterými bude zabezpečeno dodržování požadavků podle § 193 odst. 1, zejména podmínky k zabezpečení ochrany veřejných zájmů, dodržení ~~obecných~~ požadavků na výstavbu, popřípadě technických norem, a požadavky na veřejnou dopravní nebo technickou infrastrukturu. {uc=A}

(2) V případě záměru na kulturní památce ~~nebo záměru na nemovité věci, která není kulturní památkou, ale nachází se v památkové rezervaci nebo památkové zóně,~~ může stavební úřad ve výrokové části povolení záměru stanovit okruh dílčích prací, jejichž provedení bude podmíněno rozhodnutím orgánu státní památkové péče. {uc=A}

(3) Po nabytí právní moci povolení stavební úřad zašle stavebníkovi oznámení o ověření ~~projektové~~ dokumentace **pro povolení stavby** spolu se štítkem obsahujícím identifikační údaje o povolené stavbě. Oznámení o ověření ~~projektové~~ dokumentace **pro povolení stavby** zašle stavební úřad také vlastníkovi stavby, pokud není stavebníkem. Současně o vydání povolení vyrozumí hlavního projektanta. {uc=A}

#### § 198 — Platnost povolení  `[272 Čl.I/456; 272 Čl.I/457; 272 Čl.I/458; 272 Čl.I/459]` {uc=B}

(1) Povolení platí 2 **roky a pro stavby dopravní a technické infrastruktury 4** roky ode dne nabytí právní moci, nestanoví-li stavební úřad v odůvodněných případech dobu delší, nejdéle však ~~5~~ **7** let. Bylo-li provádění záměru zahájeno v době jeho platnosti, prodlužuje se doba platnosti na 10 let ode dne právní moci povolení nebo rozhodnutí o prodloužení platnosti povolení. {uc=B}

(2) Povolení pozbývá platnosti také dnem, kdy stavební úřad obdrží oznámení stavebníka o tom, že od provedení svého záměru upouští. ~~Jde-li o vyhrazené stavby, včetně staveb souvisejících,~~ **Upustit lze i od oddělitelné části záměru; v takovém případě pozbývá platnosti jen příslušná část** povolení ~~nepozbývá platnosti, bylo-li provádění stavby zahájeno v době jeho platnosti~~. {uc=B}

**(3) Jde-li o veřejně prospěšné stavby a vyhrazené stavby, včetně staveb souvisejících, povolení nepozbývá platnosti, bylo-li provádění stavby zahájeno v době jeho platnosti.** {uc=B}

~~(3)~~ **(4)** Dobu platnosti povolení může stavební úřad prodloužit na základě žádosti stavebníka podané před jejím uplynutím, a to i opakovaně, nejdéle však vždy o další 2 roky. Platnost povolení nezanikne, dokud o žádosti není pravomocně rozhodnuto**; u vyhrazených staveb nejdéle však vždy o dalších 5 let**. {uc=B}

~~(4)~~ **(5)** Stavební úřad v řízení o prodloužení platnosti povolení zkoumá, zda nedošlo ke změně podmínek, za kterých bylo povolení vydáno. Doplnění podkladů si stavební úřad vyžádá od stavebníka pouze v rozsahu změněných podmínek. Dojde-li stavební úřad k závěru, že od vydání povolení nedošlo k takové změně podmínek, která by vyžadovala doplnění podkladů, může prodloužit dobu platnosti povolení rozhodnutím jako prvním úkonem stavebního úřadu v řízení. {uc=B}

~~(5)~~ **(6)** Na řízení o prodloužení platnosti povolení se použijí ustanovení o řízení o povolení záměru přiměřeně. {uc=B}

#### § 199 — Přechod povolení

(1) O přechodu práv a povinností z povolení vyrozumí právní nástupce stavebníka stavební úřad.

(2) Na žádost právního nástupce stavebníka vydá stavební úřad nový štítek obsahující identifikační údaje o stavbě.

#### § 200 — Změna a zrušení povolení  `[272 Čl.I/460; 272 Čl.I/461; 272 Čl.I/462]` {uc=A}

(1) Povolení lze změnit na základě žádosti stavebníka nebo vlastníka stavby. ~~Platnost povolení není dotčena, pokud není současně na žádost stavebníka rozhodnuto o změně doby jeho platnosti.~~ {uc=A}

(2) Povolení lze změnit nebo zrušit na žádost stavebníka nebo z moci úřední v řízení o povolení veřejně prospěšné stavby nebo veřejně prospěšného opatření. ~~Povolení nelze změnit nebo zrušit, pokud bylo se stavbou započato.~~ {uc=A}

**(3) Na žádost stavebníka nebo vlastníka stavby lze změnit povolení části nebo etapy záměru společně s povolením jiné části či etapy tohoto záměru. V takovém případě stavebník nebo vlastník stavby předloží dokumentaci pro povolení části nebo etapy záměru a popis změn jiné části či etapy záměru.** {uc=A}

~~(3)~~ **(4)** Na řízení o změně nebo zrušení povolení se přiměřeně použijí ustanovení o řízení o povolení záměru. Změnu povolení projedná stavební úřad v rozsahu této změny. {uc=A}

#### § 200a  `[272 Čl.I/463]` {uc=A}

**Ustanovení tohoto dílu a dílu 6 a hlavy IV se použijí i pro řízení podle hlav IV až IX, nevylučuje-li to jejich povaha nebo není-li v hlavách IV až IX uvedeno jinak.** {uc=A}

##### ~~Díl 2~~

*~~Zvláštní ustanovení o řízení o povolení záměru domu pro dostupné nájemní bydlení~~*

#### ~~§ 201 — Žádost o povolení záměru domu pro dostupné nájemní bydlení~~  `[272 Čl.I/464]` {uc=B}

> **Zrušuje se celý paragraf.**

~~(1) Není-li stavebníkem obec, je součástí žádosti o povolení záměru domu pro dostupné nájemní bydlení také plánovací smlouva o dostupném nájemním bydlení, jejíž stranou je obec, na jejímž území má být záměr uskutečněn, a která obsahuje~~

~~a) závazek stavebníka poskytovat od právní moci kolaudačního rozhodnutí, kterým se povoluje užívání domu pro dostupné nájemní bydlení, nejméně 20 let alespoň 80 % podlahové plochy sloužící bydlení pro dostupné nájemní bydlení podle zákona o Státním fondu podpory investic,~~

~~b) závazek stavebníka, že po dobu trvání plánovací smlouvy o dostupném nájemním bydlení bez souhlasu obce bytový dům nezatíží ani nezcizí,~~

~~c) sjednání výše dostupného nájemného a způsob jeho navyšování v souladu se zákonem o Státním fondu podpory investic,~~

~~d) ujednání o době trvání plánovací smlouvy, která nesmí skončit před uplynutím 20 let od právní moci kolaudačního rozhodnutí, kterým se povoluje užívání domu pro dostupné nájemní bydlení,~~

~~e) závazek stavebníka umožnit kontrolu povinností vyplývajících z plánovací smlouvy o dostupném nájemním bydlení,~~

~~f) závazek stavebníka uhradit smluvní pokutu ve výši dvanáctinásobku maximálního měsíčního dostupného nájemného za 1 m2 vynásobeného počtem m2 podlahové plochy domu pro dostupné nájemní bydlení, za porušení jakéhokoli závazku vyplývajícího z plánovací smlouvy ve vztahu k poskytování dostupného nájemního bydlení, a to za každé jednotlivé porušení, nesjednají-li si smluvní strany smluvní pokutu vyšší.~~

~~(2) Stavební úřad při povolení záměru domu pro dostupné nájemní bydlení ověří, zda plánovací smlouva obsahuje ujednání podle odstavce 1 písm. a), b) a d).~~

#### ~~§ 202 — Posuzování záměru domu pro dostupné nájemní bydlení~~  `[272 Čl.I/464]` {uc=B}

> **Zrušuje se celý paragraf.**

~~Pro záměr domu pro dostupné nájemní bydlení není potřeba souhlas vlastníka podle § 187.~~

##### Díl 2

*Povolení stavby nebo zařízení a zrychlené řízení*

#### § 211 — Povolení stavby nebo zařízení  `[272 Čl.I/465; 272 Čl.I/466; 272 Čl.I/467; 272 Čl.I/468; 272 Čl.I/469]` {uc=B}

(1) Povolení stavby nebo zařízení obsahuje ve výrokové části kromě obecných náležitostí podle správního řádu a náležitostí podle § 197 odst. 1 ~~a 2~~ také {uc=B}

a) druh a účel povolované stavby nebo zařízení,

b) katastrální území, parcelní čísla a druh pozemků podle katastru nemovitostí, na nichž se stavba nebo zařízení umisťuje,

c) umístění stavby nebo zařízení na pozemku, zejména minimální vzdálenosti od hranic pozemku a sousedních staveb,

d) určení prostorového řešení stavby nebo zařízení, zejména půdorysnou velikost, maximální výšku a tvar a základní údaje o kapacitě,

e) podmínky pro provedení**, a případně pro užívání** stavby nebo zařízení~~,~~**.** {uc=B}

~~f) vymezení území dotčeného vlivem stavby nebo zařízení.~~ {uc=B}

(2) Stavební úřad v povolení stanoví podle okolností také

a) u dočasné stavby dobu trvání, lhůtu pro její odstranění a způsob jejího odstranění a následné úpravy území,

b) u jednoduché stavby účel užívání a případné další podmínky užívání,

c) opatření na sousedním pozemku z důvodů realizace stavby nebo zařízení,

d) fáze výstavby za účelem provedení kontrolních prohlídek stavby,

e) další požadavky podle jiných právních předpisů.

(3) K ověření funkčnosti stavby nebo zařízení může stavební úřad zároveň s povolením uložit provedení zkušebního provozu na dobu nejvýše ~~1 roku~~ **3 let**. {uc=B}

**(4) Při povolení stavby nebo zařízení se pro stejný záměr nevydává povolení změny využití území.** {uc=B}

#### § 212 — Zrychlené řízení  `[272 Čl.I/470; 272 Čl.I/471; 272 Čl.I/472]` {uc=B}

(1) Povolení stavby nebo zařízení je vydáno jako první úkon stavebního úřadu v řízení, pokud stavebník o vydání rozhodnutí ve zrychleném řízení požádal a

a) obec, na jejímž území má být stavba nebo zařízení uskutečněna, má vydán územní plán,

b) nejde o záměr EIA,

~~c) nejde o záměr vyžadující povolení výjimky nebo stanovení odchylného postupu podle zákona o ochraně přírody a krajiny,~~ {uc=B}

~~d)~~ **c)** stavba splňuje požadavky uvedené v § 193 a {uc=B}

~~e)~~ **d)** stavebník doložil souhlasy všech účastníků řízení se záměrem~~, vyznačené na situačním výkresu dokumentace~~. {uc=B}

~~(2) Povolení stavby nebo zařízení vydané ve zrychleném řízení se vedle oznámení účastníkům řízení zveřejňuje také na úřední desce stavebního úřadu po dobu 15 dnů ode dne vydání.~~ {uc=B}

~~(3)~~ **(2)** Nejsou-li splněny podmínky pro vydání povolení ve zrychleném řízení, stavební úřad postupuje podle obecných ustanovení o řízení o povolení záměru. {uc=B}

#### § 212a — **Povolení záměru uplynutím lhůty**  `[272 Čl.I/473]` {uc=A}

**(1) Nevydá-li stavební úřad ve lhůtě podle § 196 rozhodnutí o povolení záměru jednoduché stavby nebo stavby sítě technické infrastruktury, o jehož vydání požádal stavebník ve zrychleném řízení podle § 212, považuje se záměr za povolený dnem uplynutí této lhůty.** {uc=A}

**(2) Považuje-li se záměr za povolený, stavební úřad o tom vydá osvědčení, a to ve lhůtě 15 dnů ode dne, kdy se záměr považuje za povolený. V osvědčení uvede popis záměru, označí pozemky dotčené záměrem, pozemky, na kterých vzniklo věcné břemeno podle jiného právního předpisu80), a den, od kdy se záměr považuje za povolený; vztahuje-li se na záměr zákon o urychlení výstavby strategicky významné infrastruktury, uvede rovněž tuto skutečnost. Osvědčení stavební úřad zveřejní na své úřední desce po dobu 15 dnů a současně ho zašle nadřízenému stavebnímu úřadu, dotčeným orgánům a stavebníkovi.** {uc=A}

**(3) Nadřízený stavební úřad na základě podnětu účastníka řízení nebo z moci úřední, pokud nebyly splněny podmínky pro povolení záměru, rozhodne v přezkumném řízení podle správního řádu, že se záměr nepovažuje za povolený a věc vrátí stavebnímu úřadu k pokračování v řízení o povolení záměru podle § 212.** {uc=A}

**(4) Účastník řízení může podat podnět podle odstavce 3 do 15 dnů ode dne zveřejnění osvědčení podle odstavce 2.** {uc=A}

**(5) Rozhodnutí v přezkumném řízení o tom, zda se záměr nepovažuje za povolený, nelze vydat po uplynutí 3 měsíců ode dne zveřejnění osvědčení podle odstavce 2.** {uc=A}

**(6) Proti rozhodnutí vydaném v přezkumném řízení o tom, zda se záměr nepovažuje za povolený, se nelze odvolat a nelze jej přezkoumat v přezkumném řízení.** {uc=A}

**(7) Osvědčení podle odstavce 2 pozbývá právních účinků dnem nabytí právní moci rozhodnutí podle odstavce 3.** {uc=A}

##### Díl 3

*Nestavební záměr*

##### Oddíl 1

*Změna využití území*

#### § 213 — Změny vyžadující povolení

Povolení změny využití území vyžadují

a) terénní úprava,

b) stanovení prostoru pro dobývání ložisek nerostů, pro která se nestanoví dobývací prostor podle horního zákona,

c) odstavná, manipulační, prodejní, skladová nebo výstavní plocha,

d) pohřebiště,

e) změna druhu pozemku48), nebo způsobu využití pozemku49), pokud podmínky nejsou stanoveny schválenými pozemkovými úpravami,

f) úprava pozemku, která má vliv na schopnost vsakování vody.

#### ~~§ 214 — Změny nevyžadující povolení~~  `[272 Čl.I/474]` {uc=B}

> **Zrušuje se celý paragraf.**

~~(1) Povolení změny využití území nevyžadují~~

~~a) terénní úprava do 1,5 m výšky nebo hloubky o výměře do 300 m2 na pozemku, který nemá společnou hranici s veřejnou pozemní komunikací nebo veřejným prostranstvím,~~

~~b) odstavná, manipulační, prodejní, skladová nebo výstavní plocha do 300 m2, která neslouží pro skladování hořlavých látek nebo manipulaci s hořlavými látkami nebo látkami, které mohou způsobit znečištění životního prostředí, nebo se zvláště nebezpečnými a nebezpečnými látkami podle vodního zákona,~~

~~c) změna druhu pozemku48) nebo způsobu využití pozemků49) o výměře do 300 m2,~~

~~d) terénní úprava v přirozeném korytu vodního toku a na pozemcích sousedících s ním, kterou se podstatně nemění přirozené koryto vodního toku, pokud se neprovádí ve stanoveném záplavovém území,~~

~~e) úprava pozemku, která má vliv na schopnost vsakování vody, provedená na pozemku stavby pro bydlení nebo rodinnou rekreaci, která souvisí nebo podmiňuje bydlení nebo rodinnou rekreaci, neslouží ke skladování hořlavých látek nebo výbušnin, není v rozporu s územně plánovací dokumentací a plocha části pozemku schopného vsakovat dešťové vody po jejím provedení bude nejméně 50 % z celkové plochy pozemku stavby pro bydlení nebo rodinnou rekreaci,~~

~~f) plocha určená k ničení výbušnin, pokud není stavbou.~~

~~(2) Ustanovení odstavce 1 se nepoužije, pokud jde o~~

~~a) území, pro které je vydán plán území s archeologickými nálezy,~~

~~b) záměry EIA,~~

~~c) záměr ve zvláště chráněném území, evropsky významné lokalitě nebo ptačí oblasti,~~

~~d) záměr v chráněném ložiskovém území.~~

#### § 215 — Povolení změny využití území  `[272 Čl.I/475]` {uc=B}

(1) V povolení změny využití území stavební úřad určí nový způsob užívání pozemku a stanoví podmínky jeho využití.

(2) Povolení změny využití území obsahuje ve výrokové části kromě obecných náležitostí podle správního řádu a náležitostí podle § 197 odst. 1 ~~a 2~~ také {uc=B}

a) katastrální území, parcelní čísla a druh pozemku podle katastru nemovitostí, kterého se změna využití týká,

b) plošné vymezení a určení nového využití území.

(3) Povolení změny využití území lze vydat jako první úkon stavebního úřadu v řízení. Ustanovení § 212 se použije obdobně.

##### ~~Oddíl 2~~

*~~Dělení nebo scelení pozemků~~*

#### ~~§ 216 — Podmínky~~  `[272 Čl.I/476]` {uc=A}

> **Zrušuje se celý paragraf.**

~~(1) Povolení dělení nebo scelení pozemků může stavební úřad vydat pouze na základě žádosti podané vlastníky všech dotčených pozemků, které mají být předmětem povolení nebo alespoň jedním z vlastníků s doložením souhlasu ostatních vlastníků dotčených pozemků. Ustanovení § 187 se na souhlas vlastníků dotčených pozemků použije obdobně. V případě veřejně prospěšné stavby nebo veřejně prospěšného opatření lze povolení dělení nebo scelení pozemků vydat i na základě žádosti stavebníka; v takovém případě se vždy nařídí veřejné ústní jednání.~~

~~(2) K žádosti o povolení dělení nebo scelení pozemků se namísto projektové dokumentace přikládá celková situace v měřítku katastrální mapy, včetně parcelních čísel, se zakreslením požadovaného dělení nebo scelení pozemků s vyznačením přímého přístupu z veřejné komunikace ke všem pozemkům, nebo přes pozemek nebo stavbu stejného vlastníka, anebo na základě jiného věcného práva k cizímu pozemku nebo stavbě.~~

~~(3) Vydání povolení dělení nebo scelení pozemků je prvním úkonem stavebního úřadu v řízení, pokud jsou podmínky pro dělení nebo scelení pozemků dány územním plánem, regulačním plánem nebo rozhodnutím podle jiného právního předpisu. Povolení dělení nebo scelování pozemků se nevydává, pokud je dělení nebo scelování schváleno pozemkovými úpravami.~~

~~(4) K žádosti o dělení nebo scelení pozemků pro stavby dálnic, silnic I. třídy, drah, leteckých staveb a staveb s nimi souvisejících se nedokládá dopravní napojení na veřejně přístupnou komunikaci. V rozhodnutí o dělení nebo scelování pozemků pro stavby dálnic, silnic I. třídy, drah, leteckých staveb a staveb s nimi souvisejících stanoví stavební úřad podmínku zřízení napojení nově vzniklých pozemků na veřejně přístupnou komunikaci.~~

#### ~~§ 217 — Povolení dělení nebo scelování pozemků~~  `[272 Čl.I/476]` {uc=A}

> **Zrušuje se celý paragraf.**

~~(1) V povolení dělení nebo scelování pozemků stavební úřad stanoví podmínky pro dělení nebo scelení pozemků.~~

~~(2) Není-li třeba stanovit podmínky pro dělení nebo scelení pozemků, je vydání povolení dělení nebo scelení pozemků prvním úkonem stavebního úřadu v řízení.~~

~~(3) Povolení dělení nebo scelení pozemků obsahuje ve výrokové části kromě obecných náležitostí podle správního řádu také~~

~~a) katastrální území, parcelní čísla a druh pozemků podle katastru nemovitostí, jichž se dělení nebo scelení týká,~~

~~b) určení nových hranic pozemků s vyznačením přístupu z veřejně přístupné pozemní komunikace ke každému pozemku.~~

~~(4) Povolení dělení nebo scelení pozemků platí na dobu neurčitou. Povolení pozbývá platnosti dnem, kdy stavební úřad obdrží oznámení stavebníka o tom, že od provedení svého záměru upouští.~~

##### Oddíl 2

*Stanovení ochranného pásma*

#### § 218 — Podmínky

(1) K ochraně stavby nebo zařízení před negativními účinky okolí nebo k ochraně okolí stavby nebo zařízení před negativními účinky stavby nebo zařízení může stavební úřad stanovit ochranné pásmo rozhodnutím nebo opatřením obecné povahy, týká-li se ochranné pásmo blíže neurčeného okruhu osob.

(2) Stavební úřad ochranné pásmo nestanoví, jestliže podmínky ochrany jsou stanoveny jiným právním předpisem nebo na jeho základě. Vznik ochranného pásma podle jiného právního předpisu tím není dotčen.

(3) Stavební úřad na návrh stavebníka nebo vlastníka stavby v zájmu ochrany povolované nebo dokončené stavby nebo zařízení stanoví ochranné pásmo stavby nebo zařízení.

(4) Stavební úřad z moci úřední stanoví ochranné pásmo dokončené nebo povolované stavby nebo zařízení, pokud je to nezbytné k ochraně okolí před negativními účinky stavby nebo zařízení.

(5) V ochranném pásmu stavební úřad zakáže nebo omezí podle charakteru nebo negativních účinků chráněné stavby nebo zařízení povolování a provádění některých staveb nebo některé činnosti. Zakázat nebo omezit povolování a provádění některých staveb nebo některé činnosti lze z důvodů ochrany života a zdraví osob nebo zvířat nebo ochrany životního prostředí před negativními účinky staveb nebo zařízení na okolí nebo z důvodu ochrany staveb nebo zařízení před negativními vlivy okolí.

#### § 219 — Návrh opatření obecné povahy o stanovení ochranného pásma  `[272 Čl.I/477; 272 Čl.I/478; 272 Čl.I/479]` {uc=A}

(1) K návrhu opatření obecné povahy o stanovení ochranného pásma uplatňují dotčené orgány, které hájí veřejné zájmy podle jiných právních předpisů, kterých se ochrana stavby nebo zařízení nebo jejich okolí dotýká, **a dotčený oprávněný investor podle evidence v digitální technické mapě,** vyjádření do 30 dnů ode dne doručení návrhu. K později uplatněným vyjádřením se nepřihlíží. {uc=A}

(2) Připomínky ~~a námitky~~ k návrhu opatření obecné povahy o stanovení ochranného pásma lze uplatnit ve lhůtě 30 dnů od jeho zveřejnění, koná-li se veřejné projednání, lze uplatnit připomínky ~~a námitky~~ nejpozději na tomto veřejném projednání. {uc=A}

(3) ~~Námitky proti návrhu opatření obecné povahy mohou podat, kromě osob uvedených v § 172 odst. 5 správního řádu, také osoby, kterým jsou v~~ **Proti** návrhu opatření obecné povahy o stanovení ochranného pásma ~~stanoveny povinnosti~~ **nelze podat námitky podle části šesté správního řádu**. {uc=A}

(4) Stavební úřad vydá opatření obecné povahy o stanovení ochranného pásma ve lhůtě 90 dnů ode dne zveřejnění návrhu ochranného pásma.

#### § 220 — Opatření obecné povahy nebo rozhodnutí o stanovení ochranného pásma  `[272 Čl.I/480; 272 Čl.I/481]` {uc=A}

(1) Opatření obecné povahy nebo výroková část rozhodnutí o stanovení ochranného pásma obsahuje kromě obecných náležitostí podle správního řádu také

a) označení chráněné stavby nebo zařízení, anebo označení stavby nebo zařízení, před jejichž negativními účinky ochranné pásmo chrání okolí,

b) katastrální území, parcelní čísla a druh pozemků podle katastru nemovitostí, na nichž se ochranné pásmo zřizuje,

c) stanovení zákazů nebo omezení povolování a provádění staveb nebo činností,

d) dobu platnosti opatření obecné povahy nebo rozhodnutí, pokud je možno ji předem stanovit,

e) grafickou přílohu obsahující celkovou situaci v měřítku katastrální mapy s vyznačením hranic ochranného pásma a chráněných staveb, zařízení a pozemků; u ochranných pásem liniových staveb delších než 1 000 m a staveb zvlášť rozsáhlých se doplní uvedené údaje na mapovém podkladě v měřítku 1 : 10 000 až 1 : 50 000.

(2) Opatření obecné povahy o stanovení ochranného pásma nabývá účinnosti nejdříve dnem právní moci kolaudačního rozhodnutí, jde-li o stavbu, která jej vyžaduje. U stavby, která nevyžaduje kolaudační rozhodnutí, nebo v případě zařízení stanoví den nabytí účinnosti opatření obecné povahy o stanovení ochranného pásma stavební úřad.

(3) Zřizuje-li se ochranné pásmo k povolované stavbě nebo zařízení, je povolení vykonatelné nejdříve dnem vydání opatření obecné povahy o ochranném pásmu této stavby **nebo zařízení**. {uc=A}

(4) Nestanoví-li stavební úřad dobu platnosti opatření obecné povahy o stanovení ochranného pásma, platí po dobu trvání stavby nebo zařízení.

(5) Ustanovení odstavců 2 až 4 se na rozhodnutí o stanovení ochranného pásma použijí obdobně.

(6) Opatření obecné povahy o stanovení ochranného pásma lze změnit nebo zrušit na podnět toho, komu z něj vyplývá ochrana nebo povinnost, nebo vyžaduje-li to veřejný zájem; rozhodnutí o stanovení ochranného pásma lze změnit nebo zrušit na žádost toho, komu z něj vyplývá ochrana nebo povinnost, nebo z moci úřední, vyžaduje-li to veřejný zájem. Z opatření obecné povahy nebo rozhodnutí o stanovení ochranného pásma může stavební úřad na žádost toho, komu z něj vyplývá povinnost, povolit **rozhodnutím** časově omezenou výjimku za účelem uskutečnění jednorázové činnosti, pokud tato činnost není v rozporu s účelem ochranného pásma. {uc=A}

##### Díl 4

*Rámcové povolení*

#### § 221 — Obecná ustanovení  `[272 Čl.I/482; 272 Čl.I/483]` {uc=A}

(1) Stavební úřad vydá na žádost stavebníka rámcové povolení

a) v případě staveb jaderného zařízení a staveb souvisejících, nacházejících se uvnitř i vně areálu jaderného zařízení, nebo

b) u záměrů v působnosti jiného stavebního úřadu.

(2) Není-li stanoveno jinak, použijí se pro řízení o vydání rámcového povolení ustanovení této hlavy s výjimkou ustanovení dílů ~~3~~ **2**, ~~6~~ **5** a ~~8~~ **7** a ustanovení hlav I, II, IV a V této části. Při posuzování záměru se ochrana veřejných zájmů uplatní pouze v rozsahu rámcového povolení. {uc=A}

(3) Rámcové povolení neumožňuje provedení záměru. Požadavky tohoto zákona související s provedením a provozem záměru se pro rámcové povolení nepoužijí. Provedení záměru se povolí povolením záměru, které lze vydat jen za podmínek a v souladu s rámcovým povolením stavebního úřadu. Jiný stavební úřad může povolit stavbu pouze na základě rámcového povolení ~~vydaného krajským úřadem~~. Stavby podle odstavce 1 písm. a) ~~může Dopravní a energetický stavební úřad~~ **lze** povolit i bez předchozího rámcového povolení. Rámcové povolení pro záměry na území vojenských újezdů se nevydává. {uc=A}

(4) Účastníky řízení o povolení záměru, pro který bylo vydáno rámcové povolení, a který slouží nebo má sloužit k zajišťování obrany a bezpečnosti státu nebo pro účely Vězeňské služby České republiky a jejích organizačních složek, jsou osoby uvedené v § 182 odst. 1 písm. a), c) a d).

(5) Záměry, které se nacházejí v areálech dokončených staveb a nepřekračují stávající prostorové parametry, zejména výškovou hladinu stávajících staveb nebo odstupové vzdálenosti od hranic pozemků a sousedních staveb, lze povolit i bez předchozího rámcového povolení. Účastníky řízení o povolení záměru pro záměry podle věty první jsou osoby uvedené v § 182 odst. 1 písm. a), c) a d).

(6) Na stanovení doby platnosti rámcového povolení se použije přiměřeně § 198. Platnost rámcového povolení nezaniká, pokud je v době jeho platnosti vydáno povolení záměru.

#### § 222 — Rozsah povolení

(1) Rámcovým povolením stavební úřad pouze vymezí stavební pozemek a v jeho rámci stanoví skladbu, druh a účel staveb a rámcové podmínky pro jejich umístění v maximálních nebo minimálních prostorových parametrech, zejména vnější půdorysné a výškové ohraničení, odstupové vzdálenosti staveb od hranic pozemků a sousedních staveb a napojení na dopravní a technickou infrastrukturu a limitní hodnoty pro vstupy a výstupy.

(2) Rámcovým povolením pro záměry v působnosti jiného stavebního úřadu, které slouží nebo mají sloužit k zajišťování obrany a bezpečnosti státu a nenachází se v areálech dokončených staveb, stavební úřad pouze vymezí stavební pozemek a stanoví účel staveb.

#### § 223 — Obsah rámcového povolení  `[272 Čl.I/484]` {uc=A}

(1) Rámcové povolení pro stavby jaderného zařízení a stavby související, nacházející se uvnitř i vně areálu jaderného zařízení, a pro záměry v působnosti jiného stavebního úřadu ve výrokové části obsahuje kromě obecných náležitostí podle správního řádu

a) vymezení areálu jako stavebního pozemku,

b) katastrální území, parcelní čísla a druh pozemků podle katastru nemovitostí, na nichž se soubor staveb umisťuje,

c) stanovení skladby, druhu a účelu staveb,

d) stanovení minimálních odstupových vzdáleností staveb umisťovaných od hranice areálu, popřípadě od sousedních staveb mimo areál,

e) vymezení maximální výměry ~~zastavěných~~ **zastavitelných** ploch pro umístění staveb v areálu jaderného zařízení a maximálního výškového omezení staveb uvnitř areálu jaderného zařízení, {uc=A}

f) stanovení rámcových podmínek napojení stavby na dopravní a technickou infrastrukturu, zejména míst napojení a kapacit, limitních požadavků na vstupy a výstupy nezbytné pro realizaci a provoz areálu, a to kapacitních a časových maxim povolených vstupů, například vody, energie a skladovaného paliva, a kapacitních a časových maxim povolených výstupů, například odpadních vod, odpadů, emisí a imisí,

g) vymezení území dotčeného vlivy stavby,

h) podle potřeby stanovení dalších podmínek pro projektovou přípravu stavby,

i) u dočasných staveb stanovení lhůty pro jejich odstranění.

(2) U záměrů v působnosti jiného stavebního úřadu, které slouží nebo mají sloužit k zajišťování obrany a bezpečnosti státu, obsahuje rámcové povolení ve výrokové části kromě obecných náležitostí podle správního řádu

a) vymezení stavebního pozemku,

b) katastrální území, parcelní čísla a druh pozemků podle katastru nemovitostí,

c) stanovení účelu staveb.

##### Díl 5

*Změna záměru před dokončením*

#### § 224  `[272 Čl.I/485; 272 Čl.I/486; 272 Čl.I/487; 272 Čl.I/488; 272 Čl.I/489]` {uc=AB}

(1) Změna záměru před jeho dokončením je změna v záměru oproti jeho povolení nebo oproti dokumentaci pro povolení stavby ověřené stavebním úřadem.

(2) Změnu záměru před dokončením lze realizovat jen na základě **změny** povolení. O žádosti stavebníka o změnu záměru před dokončením rozhodne stavební úřad, který záměr povolil. **Změnu záměru před dokončením stavební úřad posuzuje pouze v rozsahu požadované změny.** {uc=A}

(3) Nepodstatné odchylky od ověřené ~~projektové~~ dokumentace ~~podle § 157 písm. a), c) a d)~~ **pro povolení stavby**, při kterých se nemění půdorysný ani výškový rozsah stavby, ~~nezasahuje do nosných konstrukcí~~ **nemění se mechanická odolnost a stabilita** stavby, nemění se ~~způsob~~ **účel** užívání stavby a nedochází k ovlivnění požární bezpečnosti, **nebo jiné nepodstatné změny** se nepovažují za změnu stavby a ~~projednávají~~ **projednají** se v kolaudačním řízení. {uc=A}

(4) V žádosti o změnu záměru před dokončením stavebník kromě obecných náležitostí podle správního řádu uvede popis změn a **je-li to nezbytné,** připojí dokumentaci pro povolení ~~záměru~~ **stavby** s vyznačením zamýšlených změn a připojí vyjádření, závazná stanoviska a rozhodnutí dotčených orgánů v rozsahu, v jakém se změna záměru dotýká zájmů chráněných jiným právním předpisem. {uc=A}

(5) Nedotýká-li se změna záměru práv účastníků řízení, s výjimkou stavebníka, ani chráněných veřejných zájmů a nepodléhá-li posouzení vlivu na životní prostředí, ~~může~~ stavební úřad ~~vydat~~ **vydá** povolení jako první úkon stavebního úřadu v řízení. {uc=A}

**(6) Pro změnu záměru před dokončením se uplatní požadavky na výstavbu a stav územně plánovací dokumentace účinné ke dni podání žádosti o povolení původního záměru. Pokud o to stavebník požádá, uplatní se pro změnu záměru před dokončením požadavky na výstavbu a stav územně plánovací dokumentace účinné ke dni podání žádosti o změnu záměru před dokončením nebo ke dni rozhodnutí.** {uc=B}

##### Díl 6

*Řízení o odvolání*

#### § 225  `[272 Čl.I/490; 272 Čl.I/491]` {uc=A}

(1) Dojde-li odvolací správní orgán k závěru, že napadené rozhodnutí vydané v řízení o žádosti je v rozporu s právními předpisy nebo že je nesprávné **anebo že trpí jinou vadou**, napadené rozhodnutí nebo jeho část změní. **Zrušení napadeného rozhodnutí a vrácení věci stavebnímu úřadu prvního stupně k novému projednání podle věty první je nepřípustné.** {uc=A}

(2) Rozhodnutí v odvolacím řízení vydá odvolací správní orgán ve lhůtě podle § 196.

(3) Není-li v tomto díle stanoveno jinak, na řízení o odvolání se použijí ustanovení dílu 1 ~~s výjimkou ustanovení o zrychleném řízení~~. {uc=A}

#### ~~§ 226 — Postup odvolacího orgánu~~

> **Nahrazuje se novým zněním (níže).**

~~(1) Je-li odvolání podáno účastníkem řízení, který udělil souhlas s povolením záměru, odvolací správní orgán nepřihlíží k části obsahu odvolání, která směřuje proti tomu, s čím účastník řízení souhlasil.~~

~~(2) Odvolací správní orgán nepřihlíží k odvolacím námitkám, které mohl odvolatel uplatnit dříve. Odvolací správní orgán dále nepřihlíží k části obsahu odvolání, které bylo podáno odvolatelem, který je stranou plánovací smlouvy, pokud je obsah odvolání v rozporu s tím, k čemu se odvolatel v plánovací smlouvě zavázal. Odvolací správní orgán dále nepřihlíží k části obsahu odvolání, které bylo podáno odvolatelem, který je účastníkem řízení podle § 182 písm. e), v rozsahu, v jakém se projednávaný záměr nedotýká zájmů chráněných jiným právním předpisem, který zakládá jeho účastenství v řízení podle tohoto zákona.~~

~~(3) Podkladem pro vydání rozhodnutí o odvolání proti rozhodnutí Dopravního a energetického stavebního úřadu je také vyjádření Ministerstva zdravotnictví a v případě vyhrazených staveb uvedených v písmenech m) a n) přílohy č. 3 k tomuto zákonu i Českého báňského úřadu, ve kterém posoudí splnění podmínek pro ochranu veřejných zájmů v jejich působnosti v rozhodnutí Dopravního a energetického stavebního úřadu.~~

#### § 226 — **Postup odvolacího orgánu**  `[272 Čl.I/492]` {uc=A}

**(1) Neobsahuje-li odvolání proti rozhodnutí stavebního úřadu odůvodnění, v čem je spatřován rozpor s právními předpisy nebo nesprávnost rozhodnutí nebo řízení, jež mu předcházelo, k odstranění tohoto nedostatku se odvolatel nevyzývá. Neodstranil-li odvolatel tento nedostatek před uplynutím lhůty pro podání odvolání, přezkoumává odvolací správní orgán pouze soulad napadeného rozhodnutí a řízení, které vydání rozhodnutí předcházelo, s právními předpisy. K doplnění důvodů odvolání po lhůtě stanovené pro jeho podání se nepřihlíží.** {uc=A}

**(2) Odvolací správní orgán nepřihlíží k odvolacím námitkám, k nimž se nepřihlíží podle** {uc=A}

**§ 190 až 191.** {uc=A}

##### Díl 7

*Kontrolní prohlídka*

#### § 227

(1) Stavební úřad může v povolení záměru, povolení odstranění stavby, rozhodnutí o nařízení odstranění stavby, v zakazujícím opatření nebo v opatření k nápravě stanovit povinnost strpět provedení kontrolních prohlídek, pokud je to nezbytné pro zjištění, zda stavebník při výstavbě nebo odstraňování postupuje v souladu s povolením nebo rozhodnutím.

(2) Na výzvu stavebního úřadu jsou povinny se kontrolní prohlídky zúčastnit též další osoby uvedené v § 292 odst. 3; ustanovení § 292 odst. 4 a 5 se použije obdobně.

(3) O průběhu kontrolní prohlídky pořídí stavební úřad protokol, který kromě obecných náležitostí podle správního řádu obsahuje též skutková zjištění. Protokol obdrží všichni účastníci kontrolní prohlídky.

(4) Ustanovení § 62 správního řádu platí obdobně. Při kontrolní prohlídce se nepostupuje podle kontrolního řádu, pro vstup na pozemek a do stavby při kontrolní prohlídce platí ustanovení § 293 obdobně.

(5) Podrobnosti rozsahu kontrolní prohlídky stanoví prováděcí právní předpis.

#### HLAVA IV

*ŘÍZENÍ O VÝJIMCE Z POŽADAVKŮ NA VÝSTAVBU*

#### § 228 — Rozhodování o výjimce a žádost

(1) Je-li k povolení záměru nezbytná výjimka z požadavků na výstavbu, rozhoduje o výjimce stavební úřad v řízení o povolení záměru.

(2) Žádost o výjimku z požadavků na výstavbu je součástí žádosti o povolení záměru a obsahuje uvedení, o jakou výjimku se žádá, a její odůvodnění.

#### HLAVA V

*NÁHRADA ZA ŠKODU*

#### § 229  `[272 Čl.I/493]` {uc=A}

(1) Vlastníkovi pozemku, stavby nebo zařízení, jehož práva k pozemku, stavbě nebo zařízení byla stanovením ochranného pásma omezena a byla mu tím způsobena škoda, náleží náhrada.

(2) Náhradu za omezení práv k pozemku, stavbě nebo zařízení stanovením ochranného pásma je povinen poskytnout vlastník stavby nebo zařízení, pro kterou bylo ochranné pásmo stanoveno.

(3) Vlastníkovi pozemku, stavby nebo zařízení, kterému vznikla škoda v důsledku zrušení nebo změny rozhodnutí o povolení záměru stavebním úřadem z moci úřední v řízení o povolení veřejně prospěšné stavby nebo veřejně prospěšného opatření, náleží náhrada vynaložených nákladů na přípravu záměru v obvyklé výši, zejména na koupi pozemku, na projektovou přípravu výstavby nebo v souvislosti se snížením hodnoty pozemku, který slouží k zajištění dluhu.

(4) Povinnost poskytnout náhradu podle odstavce 3 má obec, kraj nebo stát, jejichž orgány daly podnět ke zrušení nebo změně rozhodnutí o povolení záměru z moci úřední postupem podle § 200 odst. 2 ~~a 3~~ **až 4**. {uc=A}

(5) Náhrada se poskytuje v penězích. Místo peněžité náhrady lze na základě dohody poskytnout vlastníkovi jiný pozemek nebo stavbu; právo na vyrovnání rozdílu mezi výší peněžité náhrady a hodnotou náhradního pozemku nebo stavby tím není dotčeno.

#### HLAVA VI

*ŘÍZENÍ O UŽÍVÁNÍ*

##### Díl 1

*~~Kolaudační řízení~~ **Kolaudace***

#### § 230 — ~~Kolaudace~~ **Základní ustanovení**  `[272 Čl.I/495; 272 Čl.I/496; 272 Čl.I/497; 272 Čl.I/498; 272 Čl.I/499]` {uc=B}

(1) Stavbu, která vyžaduje povolení, lze užívat jen na základě kolaudačního rozhodnutí a jen k účelu vymezenému v tomto rozhodnutí. **Kolaudační rozhodnutí vydává na základě žádosti stavebníka nebo vlastníka stavby stavební úřad, nebo autorizovaný inspektor.** {uc=B}

(2) Kolaudační rozhodnutí nevyžadují jednoduché stavby s výjimkou jednoduchých staveb pro bydlení a rodinnou rekreaci **a bytových domů uvedených v odstavci 1 písm**. **b) přílohy č. 2 k tomuto zákonu uvedených v odstavci 1 písm. a) přílohy č. 2 k tomuto zákonu. Kolaudační rozhodnutí dále nevyžadují stavby zařízení staveniště, a to bez ohledu na to, zda se jedná o jednoduché stavby či nikoliv.** {uc=B}

(3) Stavbu, která nevyžaduje kolaudační rozhodnutí, lze užívat ihned po dokončení, a to pouze v souladu s účelem vymezeným v povolení stavby. Dokončení stavby je stavebník povinen neprodleně oznámit stavebnímu úřadu. V oznámení stavebník uvede

a) číslo geometrického plánu, pokud je stavba předmětem evidence v katastru nemovitostí nebo její výstavbou dochází k rozdělení pozemku,

b) identifikátor záznamu, ve kterém byly zapsány změny týkající se obsahu digitální technické mapy kraje nebo předány podklady pro jejich zápis, pokud jsou údaje o stavbě obsahem digitální technické mapy kraje50).

(4) Drobnou stavbu lze užívat **ihned po jejím dokončení a** jen k účelu, ke kterému je určena svým charakterem. {uc=B}

(5) Vznikla-li stavba, která nevyžaduje kolaudační rozhodnutí a která musí být podle jiného právního předpisu označena číslem, stavební úřad po oznámení dokončení stavby podle odstavce 3 vyzve příslušnou obec k přidělení čísla.

**(6) Pokud byly splněny podmínky pro vznik věcného břemene podle jiného právního předpisu80), vydá o tom po dokončení stavby stavební úřad nebo autorizovaný inspektor vlastníku sítě technické infrastruktury na jeho žádost osvědčení. Je-li to potřebné, přiloží k žádosti vlastník sítě dokumentaci podle § 167 písm. d). Osvědčení podle věty první obsahuje alespoň** {uc=B}

**a) údaj o tom, jaké věcné břemeno vzniklo a že byly splněny podmínky pro jeho vznik,** {uc=B}

**b) ustanovení jiného právního předpisu, podle kterého věcné břemeno vzniklo,** {uc=B}

**c) označení osoby, pro kterou věcné břemeno vzniklo,** {uc=B}

**d) identifikaci stavby, které věcné břemeno svědčí,** {uc=B}

**e) označení zatíženého pozemku údaji podle katastrálního zákona a f) datum vzniku věcného břemene.** {uc=B}

**(7) Pokud je zatížena pouze část pozemku nebo je toho potřeba z jiného důvodu, obsahuje osvědčení i odkaz na geometrický plán předložený žadatelem, kterým je zatížená část pozemku vymezena.** {uc=B}

**(8) Katastrální úřad zapíše věcné břemeno na základě osvědčení podle odstavce 6 na návrh oprávněného do katastru nemovitostí; souhlas vlastníka pozemku se nevyžaduje.** {uc=B}

#### § 231 — Účastníci řízení

Účastníky kolaudačního řízení jsou stavebník a vlastník stavby.

#### § 232 — Žádost  `[272 Čl.I/500]` {uc=B}

(1) Žádost o vydání kolaudačního rozhodnutí obsahuje kromě obecných náležitostí podle správního řádu identifikační číslo stavby, předpokládaný termín dokončení stavby a popis odchylek od dokumentace pro povolení stavby.

(2) ~~Součástí~~ **Součástmi** žádosti**, které** je **třeba předložit stavebnímu úřadu nebo autorizovanému inspektorovi nejpozději k závěrečné kontrolní prohlídce dokončené stavby, případně ke kolaudaci, pokud se od závěrečné kontrolní prohlídky upouští, jsou** {uc=B}

a) dokumentace pro povolení stavby s vyznačením odchylek, došlo-li k nepodstatné odchylce oproti ověřené projektové dokumentaci,

b) údaj o poloze definičního bodu stavby, a jde-li o budovu51), údaj o adresním místě17),

c) číslo geometrického plánu, pokud je stavba předmětem evidence v katastru nemovitostí nebo její výstavbou dochází k rozdělení nebo scelení pozemku,

d) vyjádření, závazné stanovisko nebo rozhodnutí dotčeného orgánu, je-li vyžadováno tímto zákonem nebo jiným právním předpisem,

e) vyhodnocení zkoušek a měření stanovených jinými právními předpisy,

f) vyhodnocení zkušebního provozu, pokud byl nařízen nebo povolen,

g) identifikátor záznamu, ve kterém byly zapsány změny týkající se obsahu digitální technické mapy kraje, nebo předány podklady způsobilé pro jejich zápis, pokud jsou údaje o stavbě obsahem digitální technické mapy kraje,

h) průkaz energetické náročnosti budovy, je-li vyžadován jiným právním předpisem29).

#### § 233 — Posuzování žádosti  `[272 Čl.I/501; 272 Čl.I/502; 272 Čl.I/503]` {uc=B}

(1) ~~V kolaudačním řízení stavební~~ **Stavební** úřad **nebo autorizovaný inspektor** posoudí, **zda je žádost úplná a** zda skutečné provedení stavby, popřípadě její části, kterou lze užívat samostatně, je v souladu s povolením. {uc=B}

(2) Stavební úřad **nebo autorizovaný inspektor** posoudí nepodstatné odchylky od ~~ověřené~~ projektové dokumentace pro povolení stavby. ~~Nemění-li se jimi půdorysný ani výškový rozsah stavby, nezasahuje-li se do nosných konstrukcí stavby, nemění-li se způsob užívání stavby a nedochází-li k negativnímu ovlivnění požární bezpečnosti, stavební úřad k těmto odchylkám nepřihlíží.~~ {uc=B}

(3) Dojde-li během provádění stavby ke změně ~~technických~~ **požadavků na výstavbu nebo** norem ~~nebo jiných technických předpisů~~, posuzuje se stavba podle ~~technických~~ **požadavků na výstavbu a** norem ~~nebo jiných technických předpisů~~, které platily v době~~, kdy byla dokumentace pro~~ **podání žádosti o** povolení ~~stavby ověřena stavebním úřadem~~ **záměru stavebnímu úřadu**. {uc=B}

#### § 234 — Závěrečná kontrolní prohlídka  `[272 Čl.I/504; 272 Čl.I/505; 272 Čl.I/506]` {uc=B}

(1) ~~V kolaudačním řízení stavební~~ **Stavební** úřad **nebo autorizovaný inspektor** provede závěrečnou kontrolní prohlídku dokončené stavby, je-li to nezbytné pro ověření skutečného provedení stavby. Závěrečná kontrolní prohlídka se neprovádí u podzemní stavby energetických sítí technické infrastruktury s výjimkou kolektorů a rozvodného tepelného zařízení podle energetického zákona52). Závěrečná kontrolní prohlídka musí být provedena do ~~30~~ **15** dnů od podání úplné žádosti nebo ode dne doplnění nebo odstranění vad žádosti, neobsahovala-li žádost všechny povinné náležitosti nebo trpěla-li vadami. O termínu závěrečné kontrolní prohlídky musí být účastníci řízení vyrozuměni nejméně ~~10~~ **5** dnů přede dnem jejího konání. ~~O konání závěrečné kontrolní prohlídky vyrozumí stavební úřad i hlavního projektanta.~~ {uc=B}

(2) Je-li k žádosti o vydání kolaudačního rozhodnutí přiložen odborný posudek autorizovaného inspektora o ověření souladu skutečného provedení stavby s jejím povolením ~~a její způsobilosti k užívání~~, stavební úřad může upustit od závěrečné kontrolní prohlídky. {uc=B}

~~(3) Vznikla-li realizací stavba, která musí být podle jiného zákona54) označena číslem, stavební úřad po provedení závěrečné kontrolní prohlídky vyzve příslušnou obec k přidělení čísla.~~ {uc=B}

#### § 235 — Kolaudační rozhodnutí  `[272 Čl.I/507; 272 Čl.I/508; 272 Čl.I/509; 272 Čl.I/510]` {uc=B}

(1) Jsou-li splněny podmínky podle § 233, stavební úřad **nebo autorizovaný inspektor** ve lhůtě 15 dnů ode dne provedení závěrečné kontrolní prohlídky vydá kolaudační rozhodnutí, kterým povolí užívání stavby k určenému účelu. {uc=B}

(2) Kolaudační rozhodnutí obsahuje ve výrokové části kromě obecných náležitostí podle správního řádu ~~a náležitostí podle § 197 odst. 1 a 2~~ {uc=B}

a) druh, účel stavby, číslo popisné nebo evidenční,

b) místo stavby s uvedením parcelního čísla pozemku a katastrálního území podle katastru nemovitostí,

c) datum a číslo jednací povolení stavby, na základě kterého byla stavba provedena,

d) údaje o zkušebním provozu, pokud byl prováděn, popřípadě o předčasném užívání stavby,

e) datum konání a výsledek závěrečné kontrolní prohlídky,

f) vymezení účelu užívání stavby.

(3) Je-li to nezbytné, kolaudační rozhodnutí ve výrokové části dále obsahuje

a) podmínky pro užívání stavby,

b) podmínky pro odstranění drobných nedostatků zjištěných při kolaudačním řízení, včetně určení přiměřené lhůty k jejich odstranění, nebo

c) podmínky k zajištění ochrany veřejných zájmů.

(4) Neprovádí-li stavební úřad závěrečnou kontrolní prohlídku, vydá kolaudační rozhodnutí jako první úkon stavebního úřadu v řízení do 15 dnů od podání žádosti. ~~Kolaudační rozhodnutí se doručuje účastníkům řízení a dotčeným orgánům.~~ {uc=B}

(5) Kolaudační rozhodnutí lze vydat i pro část stavby, lze-li ji užívat samostatně, pokud to neohrozí bezpečnost a zdraví osob nebo zvířat anebo životní prostředí.

**(6) Odvolání proti kolaudačnímu rozhodnutí nemá odkladný účinek.** {uc=B}

##### Díl 2

*Předčasné užívání a zkušební provoz*

#### § 236 — Předčasné užívání  `[272 Čl.I/511; 272 Čl.I/512; 272 Čl.I/513; 272 Čl.I/514]` {uc=B}

(1) Před dokončením stavby může stavební úřad **nebo autorizovaný inspektor** povolit **prvním úkonem stavebního úřadu v řízení** předčasné užívání stavby ~~nejdéle na dobu 1 roku~~, lze-li ji užívat a pokud to neohrozí bezpečnost a zdraví osob nebo zvířat anebo životní prostředí. {uc=B}

(2) O předčasném užívání stavby **se** rozhoduje ~~stavební úřad~~ na žádost stavebníka, ve které stavebník doloží, že nedokončená stavba je předčasně uživatelná. {uc=B}

(3) Žádost o povolení předčasného užívání stavby obsahuje kromě obecných náležitostí podle správního řádu identifikační údaje stavby a odůvodnění žádosti. Součástí žádosti jsou podklady podle § 232 odst. 2 v rozsahu podle charakteru stavby. ~~U~~ **Povoluje-li předčasné užívání stavební úřad, u** stavby prováděné dodavatelsky stavebník k žádosti připojí ~~dohodu se zhotovitelem~~ **vyjádření zhotovitele** stavby~~, obsahující jeho souhlas, popřípadě sjednané podmínky předčasného užívání stavby; u ostatních staveb navrhne stavebník podmínky předčasného užívání stavby v žádosti~~ **nebo autorizovaného inspektora ke splnění podmínek podle odstavce 1**. {uc=B}

(4) Účastníkem řízení o povolení předčasného užívání stavby je stavebník a vlastník stavby.

(5) Po dokončení stavby se postupuje podle § 230 až 235 a 237 obdobně.

**(6) Stavby přenosové, přepravní a distribuční soustavy lze užívat ihned po jejich zprovoznění na základě platné revizní zprávy.** {uc=B}

**(7) Je-li žádost o vydání kolaudačního rozhodnutí podána před uplynutím doby trvání předčasného užívání, prodlužuje se předčasné užívání do vykonatelnosti kolaudačního rozhodnutí.** {uc=B}

#### § 237 — Zkušební provoz  `[272 Čl.I/515; 272 Čl.I/516]` {uc=B}

(1) Zkušebním provozem se ověřuje funkčnost dokončené stavby.

(2) Zkušební provoz **povolí** stavební úřad ~~povolí~~ **nebo autorizovaný inspektor** na žádost stavebníka nebo nařídí **stavební úřad** z moci úřední **jako první úkon stavebního úřadu v řízení**. {uc=B}

(3) Žádost o povolení zkušebního provozu obsahuje kromě obecných náležitostí podle správního řádu identifikační údaje stavby a odůvodnění. Součástí žádosti je vyjádření, závazné stanovisko nebo rozhodnutí dotčeného orgánu, je-li vyžadováno tímto zákonem nebo jiným právním předpisem.

(4) Stavební úřad nařídí zkušební provoz, pokud byla tato podmínka stanovena v povolení. Stavebník je povinen písemně oznámit stavebnímu úřadu dokončení stavby; součástí oznámení je vyjádření, závazné stanovisko nebo rozhodnutí dotčeného orgánu, je-li vyžadováno tímto zákonem nebo jiným právním předpisem.

(5) Účastníkem řízení o povolení nebo nařízení zkušebního provozu je stavebník a vlastník stavby.

(6) ~~Po ukončení~~ **Je-li žádost o kolaudační rozhodnutí podána před ukončením** zkušebního provozu ~~podá stavebník žádost o vydání~~**, prodlužuje se zkušební provoz do vykonatelnosti** kolaudačního rozhodnutí. {uc=B}

#### § 238 — Povolení předčasného užívání a zkušebního provozu  `[272 Čl.I/517; 272 Čl.I/518; 272 Čl.I/519; 272 Čl.I/520; 272 Čl.I/521]` {uc=B}

(1) Rozhodnutí o povolení předčasného užívání a zkušebního provozu obsahuje ve výrokové části kromě obecných náležitostí podle správního řádu ~~a náležitostí podle § 197 odst. 1 a 2~~ {uc=B}

a) druh, účel stavby, číslo popisné nebo evidenční,

b) místo stavby s uvedením parcelního čísla pozemku a katastrálního území podle katastru nemovitostí,

c) datum a číslo jednací povolení stavby, na základě kterého byla stavba provedena,

d) dobu trvání předčasného užívání nebo zkušebního provozu,

e) podmínky pro předčasné užívání stavby, nebo podmínky pro plynulý přechod zkušebního provozu do běžného užívání,

f) další podmínky podle zvláštních právních předpisů.

(2) ~~V rozhodnutí~~ **Rozhodnutí** o **povolení předčasného užívání nebo** zkušebním provozu ~~stavební úřad~~ určí dobu trvání **předčasného užívání nebo** zkušebního provozu, nejdéle na dobu ~~1 roku~~ **3 let**. {uc=B}

(3) Stavební úřad **nebo autorizovaný inspektor**, který předčasné užívání nebo zkušební provoz povolil, může na žádost stavebníka, **a** v případě zkušebního provozu **stavební úřad** i z moci úřední, rozhodnutím, které je prvním úkonem stavebního úřadu v řízení, stanovenou dobu předčasného užívání, nebo dobu trvání zkušebního provozu, prodloužit před jejím uplynutím i opakovaně, v takovém případě nesmí doba předčasného užívání nebo zkušebního provozu přesáhnout 3 roky. V případě vyhrazených staveb **a veřejně prospěšných staveb** nesmí doba předčasného užívání nebo zkušebního provozu přesáhnout 10 let **nebo 5 let od dokončení výstavby všech staveb v rámci souboru staveb, pokud by jinak 10 let uplynulo dříve**. {uc=B}

**(4) Odvolání proti rozhodnutí o předčasném užívání nebo zkušebním provozu nemá odkladný účinek.** {uc=B}

##### Díl 3

*Rekolaudace*

#### § 239 — Změna v užívání stavby  `[272 Čl.I/522; 272 Čl.I/523]` {uc=B}

(1) Změnu v užívání stavby nebo její části lze na žádost **vlastníka stavby nebo stavebníka se souhlasem** vlastníka stavby povolit povolením změny v užívání stavby, pokud taková změna není podmíněna úpravou stavby vyžadující povolení. {uc=B}

(2) Žádost o povolení změny v užívání stavby obsahuje kromě obecných náležitostí podle správního řádu identifikační údaje stavby a odůvodnění zamýšlené změny, její rozsah a důsledky.

(3) Součástí žádosti je

a) dokumentace stavby s vyznačením změn vyvolaných změnou v užívání a

b) vyjádření, závazné stanovisko nebo rozhodnutí dotčeného orgánu, je-li vyžadováno tímto zákonem nebo jiným právním předpisem.

(4) Účastníky řízení jsou vlastník stavby, vlastník pozemku, na němž se nachází stavba, u které bude prováděna změna v užívání, osoby, jejichž jiné věcné právo ke stavbě může být přímo dotčeno, a osoby, jejichž vlastnické nebo jiné věcné právo k sousedním stavbám nebo sousedním pozemkům může být povolením změny užívání přímo dotčeno.

**(5) V řízení o změně v užívání stavby spočívající jen ve změně trvání dočasné stavby se soulad s podmínkami podle § 193 posoudí pouze v případě, že od povolení stavby nebo od posledního povolení prodloužení doby trvání této stavby došlo ke změně těchto podmínek. Povolení změny v užívání stavby se nevyžaduje, pokud se změnily jen požadavky právních předpisů.** {uc=B}

#### § 240 — Povolení změny v užívání stavby  `[272 Čl.I/524]` {uc=B}

Povolení změny v užívání stavby obsahuje ve výrokové části kromě náležitosti kolaudačního rozhodnutí také

a) dosavadní účel užívání **nebo dobu trvání** stavby, {uc=B}

b) nový účel užívání **nebo dobu trvání** stavby. {uc=B}

#### § 241 — Zrychlené řízení o změně v užívání stavby  `[272 Čl.I/525]` {uc=B}

(1) Stavební úřad ~~může vydat~~ **nebo autorizovaný inspektor vydá** povolení změny v užívání stavby jako první úkon stavebního úřadu v řízení, jde-li o změnu v užívání stavby, která {uc=B}

a) se nedotýká práv třetích osob,

b) nevyžaduje vydání integrovaného povolení,

c) nevyžaduje podrobnější posouzení účinků na okolí,

d) nevyžaduje zkušební provoz,

e) nevyžaduje stanovení podmínek pro užívání nebo podmínek k zajištění ochrany veřejných zájmů, nebo

f) nezpůsobí změnu kategorie stavby z hlediska požární bezpečnosti a ochrany obyvatelstva stavby podle jiného právního předpisu.

(2) Součástí žádosti je dokumentace stavby s vyznačením změn vyvolaných změnou v užívání a vyjádření, závazné stanovisko nebo rozhodnutí dotčeného orgánu, je-li vyžadováno tímto zákonem nebo jiným právním předpisem.

(3) Účastníkem řízení je vlastník stavby.

#### § 242  `[272 Čl.I/526]` {uc=B}

(1) Dnem nabytí právní moci povolení o změně v užívání stavby se kolaudační rozhodnutí v rozsahu povolené změny ruší.

(2) Je-li změna v užívání stavby podmíněna stavební úpravou vyžadující povolení, **projedná stavební úřad stavební úpravu v řízení o povolení záměru. Je-li užívání dokončené stavební úpravy podmíněno kolaudací,** postupuje se **dále** podle § ~~172~~ **230** až ~~181~~ **235. Nevyžaduje-li se k užívání stavby a provedené stavební úpravy kolaudace**, ~~189 až 193, 196, 225 a 226 obdobně a podle § 185, 188 a 194 přiměřeně~~ **stanoví nový účel užívání stavby stavební úřad v povolení záměru stavební úpravy**. {uc=B}

#### ~~§ 243 — Změna v užívání drobné a jednoduché stavby~~  `[272 Čl.I/527]` {uc=B}

> **Zrušuje se celý paragraf.**

~~(1) Změnit užívání jednoduché stavby nebo její části s výjimkou jednoduchých staveb pro bydlení a rodinnou rekreaci nebo jejich části lze jen na žádost vlastníka stavby povolením o změně v užívání jednoduché stavby, pokud taková změna není podmíněna stavební úpravou záměru vyžadující povolení. To platí také pro drobné stavby, pokud změnou v užívání pozbývají charakteru drobné stavby.~~

~~(2) Při povolení změny v užívání drobné a jednoduché stavby se použije § 239 a 241 obdobně.~~

#### ~~§ 244 — Povolení změny v užívání drobné a jednoduché stavby~~  `[272 Čl.I/527]` {uc=B}

> **Zrušuje se celý paragraf.**

~~Povolení změny v užívání drobné a jednoduché stavby obsahuje ve výrokové části kromě obecných náležitostí podle správního řádu a náležitostí podle § 197 odst. 1 a 2~~

~~a) druh, účel stavby, číslo popisné nebo evidenční,~~

~~b) místo stavby s uvedením parcelního čísla pozemku a katastrálního území podle katastru nemovitostí,~~

~~c) dosavadní účel užívání stavby,~~

~~d) nový účel užívání stavby,~~

~~e) podmínky pro užívání stavby.~~

#### § 245 — Pasport stavby  `[272 Čl.I/528; 272 Čl.I/529; 272 Čl.I/530]` {uc=B}

(1) Vlastník stavby je povinen uchovávat po celou dobu trvání stavby ověřenou dokumentaci odpovídající jejímu skutečnému provedení podle vydaných povolení. V případech, kdy se dokumentace nedochovala nebo není v náležitém stavu a stavba byla povolena, je vlastník stavby povinen pořídit pasport stavby. **V případě podzemní stavby sítí technické infrastruktury může být pasport stavby nahrazen dokumentací zaměření prostorové polohy, rozměru a tvaru dokončené stavby nebo její části anebo technologického zařízení.** {uc=B}

(2) Nejsou-li zachovány doklady, z nichž by bylo možné zjistit účel, pro který byla stavba povolena, platí, že stavba je určena k účelu, pro který je svým stavebně technickým uspořádáním určena.

(3) Neplní-li vlastník stavby povinnost podle odstavce 1, stavební úřad mu nařídí, aby pořídil pasport stavby. Rozhodnutí o nařízení pořízení pasportu stavby se vydává jako první úkon stavebního úřadu v řízení. ~~Není-li třeba pasport stavby doplnit, změnit nebo jinak přepracovat, stavební úřad jej ověří.~~ {uc=B}

**(4) Není-li třeba pasport stavby doplnit, změnit nebo jinak přepracovat, stavební úřad nebo autorizovaný inspektor jej ověří.** {uc=B}

##### Díl 4

*Společná ustanovení*

#### ~~§ 246~~

> **Nahrazuje se novým zněním (níže).**

~~Není-li v této hlavě stanoveno jinak, postupuje se při vydání kolaudačního rozhodnutí podle § 172 až 181, 225 a 226 obdobně a podle § 185, 188, 190 a 194 přiměřeně, při vydání povolení změny v užívání stavby nebo povolení změny v užívání drobné a jednoduché stavby podle § 172 až 181, 189 až 193, 196, 225 a 226 obdobně a podle § 185, 188 a 194 přiměřeně.~~

#### § 246  `[272 Čl.I/531]` {uc=A}

**Vznikla-li realizací stavba, která musí být podle jiného zákona54) označena číslem, stavební úřad nebo autorizovaný inspektor vyzve příslušnou obec k přidělení čísla.** {uc=A}

#### HLAVA VII

*ODSTRAŇOVÁNÍ STAVEB A TERÉNNÍCH ÚPRAV*

##### Díl 1

*Řízení o povolení odstranění*

#### § 247 — Podmínky odstraňování staveb  `[272 Čl.I/532; 272 Čl.I/533; 272 Čl.I/534]` {uc=A}

(1) Stavbu, která podléhá povolení nebo obsahuje azbest, je možné odstranit pouze na základě povolení odstranění stavby. **Rozhodnutí o povolení odstranění stavby vydává stavební úřad nebo v případě jednoduchých staveb, u nichž lze povolení odstranění vydat jako první úkon stavebního úřadu v řízení, autorizovaný inspektor.** {uc=A}

(2) Účastníkem řízení o povolení odstranění je vlastník pozemku, na němž se odstraňovaná stavba nachází, vlastník stavby**, nebo ten, kdo má jiné věcné právo k pozemku nebo stavbě,** a další osoby, jejichž vlastnická nebo jiná věcná práva k sousednímu pozemku nebo stavbě mohou být odstraňováním stavby přímo dotčena. {uc=A}

(3) Nejde-li o stavbu v památkové rezervaci, památkové zóně nebo o stavbu, v níž je obsažen azbest**, nebo o vyhrazenou stavbu**, a zároveň se žádost nedotýká vlastnických nebo jiných věcných práv k pozemku, na němž se nachází stavba, která má být odstraněna, nebo stavbám na něm, a vlastnických nebo jiných věcných práv k sousedním pozemkům nebo sousedním stavbám, které by mohly být odstraňováním nebo odstraněním stavby přímo dotčeny a není třeba stanovit podmínky pro odstranění stavby nebo podmínky k zajištění ochrany veřejných zájmů, stavební úřad **nebo autorizovaný inspektor** na základě úplné žádosti vydá povolení odstranění jako první úkon stavebního úřadu v řízení. {uc=A}

#### § 248 — Žádost o povolení odstranění stavby  `[272 Čl.I/535; 272 Čl.I/536]` {uc=A}

**(1) Žádost o povolení odstranění stavby může podat vlastník stavby nebo se souhlasem vlastníka stavby stavebník. Je-li pro realizaci záměru, pro který je stanoven účel vyvlastnění v zákoně, třeba odstranění cizí stavby, může žádost o povolení odstranění takové stavby podat i stavebník stavby, pro kterou je stanoven účel vyvlastnění v zákoně; souhlas vlastníka odstraňované stavby se nevyžaduje.** {uc=A}

~~(1)~~ **(2)** Žádost o povolení odstranění stavby kromě obecných náležitostí podle správního řádu obsahuje {uc=A}

a) předpokládaný termín započetí a ukončení bouracích prací a způsob jejich provádění,

b) identifikaci sousedních pozemků a staveb nezbytných k provedení bouracích prací a

c) informaci o tom, zda jde o stavbu, v níž je obsažen azbest nebo lze přítomnost azbestu očekávat.

~~(2)~~ **(3)** Součástí žádosti je dokumentace pro odstranění stavby a vyjádření, závazné stanovisko nebo rozhodnutí dotčeného orgánu, je-li vyžadováno tímto zákonem nebo jiným právním předpisem. {uc=A}

**(4) Žádost o povolení odstranění stavby lze podat jako součást žádosti o povolení záměru.** {uc=A}

**(5) V případě stavby obsahující azbest je součástí žádosti také návrh opatření k předcházení a omezení rizik souvisejících s expozicí azbestu a doklad o splnění dalších požadavků pro práci s azbestem podle jiného právního předpisu84).** {uc=A}

#### § 249 — Povolení odstranění stavby  `[272 Čl.I/537; 272 Čl.I/538]` {uc=A}

(1) Povolení odstranění stavby obsahuje ve výrokové části kromě obecných náležitostí podle správního řádu

a) druh, účel stavby, parcelní číslo a katastrální území, ve kterém se stavba nachází, číslo popisné nebo evidenční, pokud bylo přiděleno,

b) lhůtu pro odstranění stavby,

c) postup a způsob provedení bouracích prací, zejména zajištění stability a bezpečného užívání sousedních staveb, včetně staveb technické infrastruktury, a provozu na přilehlých komunikacích,

d) podmínky, kterými se podle potřeby zajistí dodržení technických předpisů a ochrana veřejných zájmů,

e) povinnost oznámit před zahájením bouracích prací název a sídlo stavebního podnikatele, který bude práce provádět, nebo jméno, příjmení, datum narození a adresu místa trvalého pobytu, a nemá-li ji, adresu bydliště osoby, která bude vykonávat stavební dozor při svépomocném provádění bouracích prací u stavby, která nevyžaduje povolení,

f) povinnost oznámit určité stadium bouracích prací stavebnímu úřadu pro provedení kontrolní prohlídky,

g) úpravu pozemku po odstranění stavby, nezávadné odvádění povrchových vod a vysázení zeleně~~.~~**,** {uc=A}

**h) v případě stavby obsahující azbest podmínky zajišťující splnění požadavků pro práci s azbestem podle jiného právního předpisu84).** {uc=A}

(2) Rozhodnutí o povolení odstranění stavby může být součástí rozhodnutí o povolení záměru.

**(3) Po nabytí právní moci povolení odstranění stavby stavební úřad zašle stavebníkovi oznámení o ověření dokumentace pro odstranění stavby spolu se štítkem obsahujícím identifikační údaje o odstraňované stavbě.** {uc=A}

##### Díl 2

*Nařízení odstranění*

##### Oddíl 1

*Řízení o nařízení odstranění stavby*

#### § 250 — Obecné ustanovení  `[272 Čl.I/539; 272 Čl.I/540; 272 Čl.I/541; 272 Čl.I/542; 272 Čl.I/543]` {uc=A}

(1) Stavební úřad nařídí stavebníkovi nebo vlastníkovi stavby**, případně vlastníkovi pozemku** odstranit stavbu, pokud {uc=A}

a) svým závadným stavem ohrožuje život nebo zdraví osob nebo zvířat, bezpečnost, životní prostředí anebo majetek třetích osob a její vlastník přes rozhodnutí stavebního úřadu ve stanovené lhůtě neodstranil závadný stav, nejde-li o kulturní památku,

b) je prováděna nebo byla provedena bez povolení ~~podle tohoto zákona~~**, které měla mít,** anebo v rozporu s ním, {uc=A}

c) je prováděna nebo byla provedena na základě povolení ~~podle tohoto zákona~~, které bylo zrušeno, {uc=A}

d) nevyžaduje povolení, ale je prováděna nebo byla provedena v rozporu s právními předpisy,

e) jde o stavbu, u které uplynula stanovená doba trvání, aniž byla ~~do skončení této doby~~ podána žádost o prodloužení doby trvání stavby, {uc=A}

f) jde o stavbu, která nebyla dokončena v době platnosti povolení,

g) jde o stavbu, která nebyla obnovena do 10 let ode dne oznámení stavebnímu úřadu nebo do 10 let ode dne nabytí právní moci povolení obnovy stavby,

h) je prováděna nebo byla provedena v rozporu s platnou územně plánovací dokumentací nebo s platným územním opatřením.

(2) Účastníkem řízení o nařízení odstranění je vlastník stavby ~~a stavebník (dále jen „povinný~~ “), vlastník pozemku, na němž se nachází stavba, která má být odstraněna, **a stavebník (dále jen „povinný** osoba, která má jiná věcná práva k pozemku, na němž se nachází stavba, která má být odstraněna, nebo ke stavbám na něm, obec, na jejímž území se stavba, která má být odstraňována, nachází, a další osoby, jejichž vlastnická nebo jiná věcná práva k sousednímu pozemku nebo stavbě mohou být odstraňováním nebo odstraněním stavby přímo dotčena. {uc=A}

#### § 251 — Oznámení o zahájení řízení

(1) Stavební úřad oznámí zahájení řízení o odstranění stavby a vyzve povinného k předložení dokumentace pro odstranění stavby a vyjádření, závazného stanoviska nebo rozhodnutí dotčeného orgánu, jsou-li vyžadována tímto zákonem nebo jiným právním předpisem, a stanoví mu k tomu přiměřenou lhůtu, nejde-li o opakované řízení a nové povolení stavby.

(2) Nepředloží-li povinný ve stanovené lhůtě dokumentaci pro odstranění stavby, stavební úřad ji opatří na jeho náklady; o tom musí být povinný poučen. Po předložení dokumentace pro odstranění stavby, včetně vyjádření, závazného stanoviska a rozhodnutí dotčeného orgánu, nebo po jejím opatření stavebním úřadem, stavební úřad oznámí zahájení řízení o nařízení odstranění stavby ostatním účastníkům řízení a stanoví lhůtu pro podání námitek.

#### § 252 — Rozhodnutí o nařízení odstranění stavby  `[272 Čl.I/544; 272 Čl.I/545]` {uc=A}

(1) Rozhodnutí o nařízení odstranění stavby ve výrokové části kromě obecných náležitostí podle správního řádu ~~a náležitostí podle § 197 odst. 1 a 2~~ obsahuje {uc=A}

a) druh, účel stavby, číslo popisné nebo evidenční,

b) místo stavby s uvedením parcelního čísla pozemku a katastrálního území podle katastru nemovitostí,

c) postup a způsob provedení bouracích prací, zejména zajištění stability a bezpečného užívání sousedních staveb, včetně staveb technické infrastruktury, a provozu na přilehlých komunikacích,

d) podmínky, kterými se podle potřeby zajistí dodržení technických předpisů a ochrana veřejných zájmů,

e) povinnost oznámit před zahájením bouracích prací název a sídlo stavebního podnikatele, který bude práce provádět,

f) povinnost oznámit určité stadium bouracích prací stavebnímu úřadu pro provedení kontrolní prohlídky,

g) povinnost zajistit úpravu pozemku po odstranění stavby podle jeho původního účelového určení, nezávadné odvádění povrchových vod a vysázení zeleně,

h) lhůtu pro odstranění stavby~~.~~**,**

**i) v případě stavby obsahující azbest podmínky zajišťující splnění požadavků pro práci s azbestem podle jiného právního předpisu84).**

(2) V rozhodnutí může stavební úřad též uložit povinnému předložit návrh technologického postupu prací při odstraňování stavby, včetně nutných opatření k vyloučení, omezení nebo ke kompenzaci případných negativních důsledků na zájmy chráněné podle zákona nebo jiných právních předpisů. Nepředloží-li povinný ve stanovené lhůtě návrh technologického postupu prací při odstraňování stavby, stavební úřad jej opatří na náklady povinného; o tom musí být povinný poučen.

(3) O nařízení odstranění stavební úřad vyrozumí nájemce bytů a nebytových prostor informací umístěnou na místě stavby před provedením odstranění.

#### § 253 — Obnovení předcházejícího stavu stavby a odstranění stavby na základě rozhodnutí soudu

(1) Je-li třeba nařídit obnovení předcházejícího stavu stavby, u které byly bez povolení anebo v rozporu s ním provedeny stavební úpravy, postupuje stavební úřad podle tohoto dílu přiměřeně.

(2) Rozhodl-li o odstranění stavby soud, může stavební úřad z moci úřední nebo na žádost toho, komu soud odstranění stavby uložil, stanovit podmínky pro odstranění stavby; rozhodnutí, kterým se podmínky stanoví, je prvním úkonem stavebního úřadu v řízení.

(3) Náklady na odstranění nese povinný nebo ten, komu soud odstranění stavby uložil.

##### Oddíl 2

*Postupy související s řízením o nařízení odstranění stavby*

#### § 254 — Obecné ustanovení  `[272 Čl.I/546; 272 Čl.I/547; 272 Čl.I/548]` {uc=A}

(1) Stavbu **prováděnou nebo** provedenou bez povolení nebo v rozporu s ním může stavební úřad dodatečně povolit v případě, že povinný o dodatečné povolení požádal a splnil podmínky pro jeho vydání. {uc=A}

(2) Stavbu provedenou na základě povolení podle tohoto zákona, které bylo zrušeno, stavební úřad povolí novým rozhodnutím v opakovaném řízení v případě, že povinný splní podmínky pro jeho vydání.

(3) Stavbu nevyžadující povolení, ale prováděnou nebo provedenou v rozporu s právními předpisy stavební úřad nenařídí odstranit, pokud povinný uvedl stavbu do souladu s právními předpisy.

(4) U stavby, u které uplynula stanovená doba trvání, může stavební úřad prodloužit dobu trvání stavby, pokud do ~~skončení doby trvání stavby nebo do~~ 30 dnů od zahájení řízení o odstranění stavby byla podána žádost o ~~prodloužení doby trvání stavby~~ **změnu povolení** a povinný splní podmínky pro vydání povolení ~~prodloužení doby trvání stavby~~ **změnu povolení**. {uc=A}

~~(5) Účastníkem řízení podle odstavců 1, 2 a 4 je povinný, osoba, která má vlastnické nebo jiné věcné právo k pozemku, na němž se nachází stavba, která má být odstraněna, nebo stavbám na něm, a další osoby, jejichž vlastnická nebo jiná věcná práva k sousednímu pozemku nebo stavbě mohou být rozhodnutím přímo dotčena.~~ {uc=A}

##### Dodatečné povolení

#### § 255  `[272 Čl.I/549; 272 Čl.I/550; 272 Čl.I/551]` {uc=A}

(1) V oznámení o zahájení řízení o odstranění stavby stavební úřad poučí povinného o možnosti podat ve lhůtě 30 dnů od zahájení řízení žádost o dodatečné povolení stavby~~. V případě, že ve stanovené lhůtě nebude žádost podána, nelze stavbu dodatečně povolit~~. Byla-li žádost o dodatečné povolení podána před zahájením řízení o odstranění stavby, platí, že byla podána v okamžiku zahájení řízení o odstranění stavby. Byla-li žádost o dodatečné povolení zamítnuta, nelze podat žádost o vydání nového rozhodnutí. {uc=A}

(2) Žádost o dodatečné povolení stavby obsahuje kromě obecných náležitostí podle správního řádu náležitosti stanovené v § 184 odst. 1 a 2 v rozsahu jako k povolení stavby. **Ustanovení § 185 odst. 3 se nepoužije.** {uc=A}

~~(3) V řízení o dodatečném povolení se ustanovení § 172 až 181, 183 až 220 a 225 až 227 použijí obdobně.~~ {uc=A}

~~(4)~~ **(3)** Řízení o dodatečném povolení stavby je součástí řízení o nařízení odstranění stavby. {uc=A}

#### § 256  `[272 Čl.I/552]` {uc=A}

(1) Stavbu lze dodatečně povolit, pokud povinný prokáže splnění podmínek podle § 193 a

a) stavba nevyžaduje rozhodnutí o povolení výjimky ze zákazů podle jiného právního předpisu,

b) stavba nevyžaduje povolení výjimky z požadavků na výstavbu a

c) povinný uhradil ve stanovené lhůtě pokutu za přestupek podle tohoto zákona spočívající v tom, že provedl stavbu bez povolení nebo v rozporu s ním, byla-li uložena.

(2) Vyžaduje-li stavba pouze výjimku z požadavků na umisťování staveb a stavebník doloží stavebnímu úřadu souhlas účastníků řízení, jejichž vlastnické nebo jiné věcné právo k sousedním stavbám nebo sousedním pozemkům může být povolením výjimky přímo dotčeno, považuje se podmínka podle odstavce 1 písm. b) za splněnou. Ustanovení § 187 odst. 2 až 4 se použije obdobně.

**(3) Stavební úřad nenařídí odstranění stavby a stavbu, která vyžaduje povolení, dodatečně povolí i bez splnění podmínek podle odstavce 1, pokud by nařízení odstranění stavby představovalo pro povinného nebo pro jiné osoby nebo pro veřejný zájem zcela zjevně zásah nepřiměřený přínosům a zároveň ponecháním stavby nejsou dotčeny veřejné zájmy ani práva třetích osob. Odpovědnost povinného za přestupek tím není dotčena.** {uc=A}

~~(3)~~ **(4)** Dodatečné povolení obsahuje náležitosti povolení stavby nebo zařízení. Je-li předmětem dodatečného povolení rozestavěná stavba, stavební úřad stanoví v povolení podmínky pro její dokončení. {uc=A}

~~(4)~~ **(5)** Je-li předmětem dodatečného povolení dokončená stavba, může stavební úřad po ověření splnění podmínek podle § 232 a 233 na žádost povinného podanou společně se žádostí o dodatečné povolení současně vydat kolaudační rozhodnutí, pokud stavba takové rozhodnutí vyžaduje. Stavební úřad vydá dodatečné povolení a kolaudační rozhodnutí jako společné rozhodnutí. {uc=A}

#### § 257

Nelze-li stavbu dodatečně povolit, stavební úřad žádost o dodatečné povolení zamítne a nařídí odstranění stavby.

##### Opakované řízení a nové povolení

#### § 258  `[272 Čl.I/553]` {uc=A}

(1) Za žádost o nové povolení stavby se považuje žádost, na základě které bylo vydáno následně zrušené povolení; doplnění podkladů stavební úřad požaduje pouze v rozsahu nezbytném pro opakované projednání stavby.

~~(2) V opakovaném řízení se ustanovení § 172 až 181, 183 až 220 a 225 až 227 použijí obdobně.~~ {uc=A}

~~(3)~~ **(2)** Lhůta pro vydání rozhodnutí v opakovaném řízení začíná běžet dnem následujícím po nabytí právní moci zrušujícího rozhodnutí. Stavební úřad, který rozhodl v posledním stupni, uvědomí stavební úřad, který rozhodl v prvním stupni, o zrušení rozhodnutí o povolení stavby. {uc=A}

~~(4)~~ **(3)** Nebude-li v opakovaném stavebním řízení stavba povolena, stavební úřad žádost zamítne a nařídí odstranění stavby. {uc=A}

#### § 259  `[272 Čl.I/554]` {uc=A}

(1) Stavba se v opakovaném řízení povolí~~, pokud povinný prokáže~~ **při** splnění podmínek podle § 193. Nejsou-li tyto podmínky splněny, povolí se stavba, pokud povinný jednal v dobré víře a pokud by nařízením odstranění stavby vznikla třetím osobám nebo veřejnému zájmu újma, která by byla ve zjevném nepoměru k újmě vzniklé nenařízením odstranění stavby. {uc=A}

(2) Nové povolení obsahuje náležitosti povolení stavby.

(3) Je-li předmětem nového povolení rozestavěná stavba, stavební úřad stanoví podmínky pro její dokončení.

(4) Je-li předmětem nového povolení dokončená stavba, může stavební úřad po ověření splnění podmínek podle § 232 a 233 na žádost povinného současně vydat kolaudační rozhodnutí, pokud stavba takové rozhodnutí vyžaduje.

(5) Je-li předmětem nového povolení dokončená stavba, pro kterou bylo před zrušením povolení vydáno kolaudační rozhodnutí, vydá stavební úřad současně po ověření splnění podmínek podle § 232 a 233 na žádost povinného nové kolaudační rozhodnutí; původní kolaudační rozhodnutí pozbývá platnosti dnem nabytí právní moci nového kolaudačního rozhodnutí nebo dnem nabytí právní moci rozhodnutí o nařízení odstranění stavby v případě, že nové povolení nelze vydat.

#### ~~§ 260 — Povolení prodloužení doby trvání stavby~~  `[272 Čl.I/555]` {uc=A}

> **Zrušuje se celý paragraf.**

~~(1) Žádost o povolení prodloužení doby trvání stavby obsahuje kromě obecných náležitostí podle správního řádu náležitosti stanovené v § 184 odst. 1 a 2.~~

~~(2) V řízení o povolení prodloužení doby trvání stavby se ustanovení § 172 až 181, 183 až 220 a 225 až 227 použijí obdobně.~~

~~(3) Prodloužení doby trvání stavby lze povolit, pokud povinný prokáže, že splnil podmínky podle § 193.~~

~~(4) Povolení prodloužení doby trvání stavby obsahuje náležitosti povolení stavby.~~

~~(5) Nelze-li vydat povolení o prodloužení doby trvání stavby, stavební úřad žádost o povolení zamítne a nařídí odstranění stavby.~~

##### Díl 3

*~~Společná~~ **Společné** ustanovení*

#### § 261  `[272 Čl.I/557]` {uc=A}

~~(1)~~ Pro terénní úpravy a zařízení se ustanovení této hlavy použijí obdobně. {uc=A}

~~(2) Ministerstvo může na žádost stavebního úřadu uhradit účelně vynaložené náklady vzniklé při provedení náhradního výkonu rozhodnutí o nařízení odstranění stavby nebo terénní úpravy, pokud stavební úřad usnesením podle § 119 odst. 4 správního řádu uložil povinnému zaplatit předem potřebné náklady na provedení exekuce a povinný tyto náklady nezaplatil.~~ {uc=A}

~~(3) Žádost podle odstavce 2 obsahuje~~ {uc=A}

~~a) rozhodnutí o nařízení odstranění stavby,~~ {uc=A}

~~b) exekuční příkaz, na jehož základě stavební úřad pověřil jinou osobu odstraněním stavby nebo terénní úpravy,~~ {uc=A}

~~c) usnesení podle § 119 odst. 4 správního řádu, kterým stavební úřad uložil povinnému zaplatit potřebné náklady na provedení exekuce, a~~ {uc=A}

~~d) daňový doklad o výši nákladů na odstranění stavby nebo terénní úpravy.~~ {uc=A}

~~(4) Uhradilo-li ministerstvo účelně vynaložené náklady podle odstavce 2, uloží po provedení náhradního výkonu rozhodnutí povinnému zaplatit ministerstvu úhradu těchto nákladů.~~ {uc=A}

#### ~~§ 262~~  `[272 Čl.I/558]` {uc=A}

> **Zrušuje se celý paragraf.**

~~Není-li v této hlavě stanoveno jinak, postupuje se v řízení o povolení odstranění stavby podle § 172, 174, 185, 188, 189, 191, 192, 194, 196, 225 a 226 obdobně a podle § 190 a 200 přiměřeně. V řízení o nařízení odstranění stavby se postupuje podle § 173, 175, 176, 178 až 181, 189, 191, 192, 225 a 226 obdobně a podle § 190 přiměřeně.~~

#### HLAVA VIII

*MIMOŘÁDNÉ POSTUPY*

#### § 263 — Mimořádné opatření

(1) Je-li při bezprostředně hrozící živelní pohromě nebo závažné havárii (dále jen „mimořádná událost“) třeba bezodkladně provést opatření k odvrácení nebo zmírnění možných dopadů mimořádné události, lze se od postupů stanovených tímto zákonem odchýlit v mezích ustanovení této hlavy.

(2) Mimořádné opatření na stavbě nebo pozemku spočívající podle okolností i v provádění staveb, terénních úprav nebo odstraňování staveb, jimiž se předchází bezprostředně hrozícím důsledkům mimořádné události, čelí jejím účinkům a zabraňuje ohrožení života nebo zdraví osob, popřípadě jiným škodám, může být zahájeno bez předchozího povolení podle tohoto zákona.

(3) Stavebník neprodleně oznámí stavebnímu úřadu, že provádí mimořádné opatření.

(4) Je-li nutné pro zmírnění následků nebo odvrácení dopadů mimořádné události provést nebo odstranit stavbu nebo terénní úpravu, může stavební úřad na základě oznámení podle odstavce 3 rozhodnout o tom, že

a) upouští od vydání povolení stavby nebo zařízení, povolení změny využití území nebo povolení odstranění,

b) omezuje obsah žádosti o povolení stavby nebo zařízení, povolení změny využití území nebo povolení odstranění a jejích příloh na nejnutnější míru nezbytnou pro povolení,

c) lze některé podklady pro vydání povolení o povolení stavby nebo zařízení, povolení změny využití území nebo povolení odstranění předložit dodatečně, a to ve lhůtě stanovené stavebním úřadem.

(5) Rozhodnutí podle odstavce 4 může stavební úřad vydat jako první úkon stavebního úřadu v řízení. Odvolání proti tomuto rozhodnutí nemá odkladný účinek.

#### § 264 — Obnova  `[272 Čl.I/559; 272 Čl.I/560]` {uc=B}

(1) Stavbu nebo terénní úpravu zničenou nebo poškozenou mimořádnou událostí lze obnovit podle původního povolení a dokumentace, podle níž byla provedena, na základě oznámení stavebníka nebo na základě povolení obnovy stavby nebo terénní úpravy. Pokud o to stavebník nebo vlastník stavby nebo pozemku požádá, stavební úřad mu kopii původního povolení a dokumentace bezodkladně poskytne, má-li ji k dispozici.

(2) Stavebník oznámí stavebnímu úřadu obnovu stavby nebo terénní úpravy podle původního povolení a dokumentace, podle níž byla provedena, do 6 měsíců ode dne, kdy došlo ke zničení nebo poškození stavby nebo terénní úpravy. V oznámení stavebník uvede údaje o stavbě nebo terénní úpravě, která má být obnovena, jednoduchý technický popis prací a osobu, která bude činnost provádět. Po oznámení obnovy stavby nebo terénní úpravy může stavebník započít s pracemi směřujícími k obnově stavby nebo terénní úpravy.

(3) Vyžaduje-li obnovení stavby nebo terénní úpravy stanovení podmínek k ochraně veřejných zájmů, vyrozumí stavební úřad stavebníka do 15 dnů ode dne oznámení o tom, že obnova vyžaduje povolení. V takovém případě se oznámení považuje za žádost o povolení obnovy. Stavební úřad vydá povolení obnovy stavby nebo zařízení do 30 dnů od oznámení stavebníka, jinak lze obnovu provést na základě oznámení, pokud s ní bude započato do 2 let ode dne oznámení; obnova musí být provedena do 10 let ode dne oznámení stavebnímu úřadu. Odvolání proti povolení nemá odkladný účinek.

(4) Je-li obnova v rozporu s požadavky jiných právních předpisů, stavební úřad zakáže stavebníkovi obnovu provést.

(5) Povolení obnovy stavby nebo terénní úpravy platí 2 roky ode dne nabytí jeho právní moci. Bylo-li s prováděním obnovy stavby nebo terénní úpravy započato v době platnosti povolení obnovy stavby nebo terénní úpravy, prodlužuje se doba platnosti povolení na 10 let ode dne právní moci povolení nebo rozhodnutí o prodloužení platnosti povolení, byla-li doba platnosti povolení prodloužena. Ustanovení § 198 odst. ~~3~~ **4** se na prodloužení doby platnosti povolení obnovy použije obdobně. {uc=B}

**(6) Ustanovení odstavců 1 až 5 platí přiměřeně pro provedení stavby rodinného domu nebo bytového domu anebo veřejné infrastruktury, pokud je tato stavba prováděna místo stavby zničené nebo poškozené mimořádnou událostí, její podstatné parametry odpovídají zničené nebo poškozené stavbě a vzhledem k okolnostem, zejména riziku opakování mimořádné události, nelze požadovat, aby došlo k obnově zničené nebo poškozené stavby na původním místě.** {uc=B}

**(7) Stavbu podle odstavce 6 lze umístit na pozemku vhodném pro provedení takové stavby, v souladu s územně plánovací dokumentací, případně s územními opařeními a vymezením zastavitelného území. Ustanovení § 187 platí obdobně.** {uc=B}

**(8) Pokud stavbu podle odstavce 6 není možné provést na pozemku uvedeném v odstavci 7, neboť takový pozemek není pro stavebníka dostupný, lze se souhlasem vlastníka pozemku pořídit a vydat změnu územního nebo regulačního plánu podle § 111a.** {uc=B}

#### § 265 — Společná ustanovení

(1) Podle ustanovení o mimořádných postupech nelze postupovat v případě, kdy má mimořádná událost původ v zaviněném konání nebo opomenutí stavebníka nebo vlastníka pozemku nebo stavby.

(2) Dokončení staveb, terénních úprav a prací provedených podle této hlavy je stavebník povinen bezodkladně oznámit stavebnímu úřadu; ustanovení o užívání staveb tím nejsou dotčena.

#### HLAVA IX

*NÁLEZ*

#### § 266  `[272 Čl.I/561]` {uc=A}

(1) Nepředvídaný archeologický nebo paleontologický nález nebo nález kulturně cenného předmětu, detailu stavby nebo chráněné části přírody je stavebník povinen neprodleně oznámit stavebnímu úřadu a zároveň učinit opatření nezbytná k tomu, aby nález nebyl poškozen nebo zničen, práce v místě nálezu přerušit a zaznamenat do stavebního deníku čas a okolnosti nálezu, datum oznámení stavebnímu úřadu a popis provedených opatření.

(2) Stavební úřad do 30 dnů od oznámení nálezu a v dohodě s dotčeným orgánem rozhodnutím vydaným na místě nebo rozhodnutím vydaným jako první úkon **stavebního úřadu** v řízení stanoví podmínky k ochraně nálezu. Současně může stavební úřad provést ohledání na místě. {uc=A}

(3) Na základě oznámení nálezu může stavební úřad v součinnosti s dotčeným orgánem ve veřejném zájmu provést nové řízení a vydat nové povolení záměru.

(4) Ministerstvo kultury může z podnětu dotčeného orgánu státní památkové péče rozhodnout, že jde o nález mimořádného významu, a z moci úřední jej prohlásí za kulturní památku. Ministerstvo kultury do 30 dnů od podání podnětu informuje stavební úřad o svém postupu, a popřípadě stanoví požadavky na změnu nebo zrušení vydaného rozhodnutí o povolení stavby.

(5) Stavebník může uplatnit nárok na náhradu nákladů, které mu vznikly v důsledku postupu podle odstavce 3 u dotčeného orgánu nebo v důsledku postupu podle odstavce 4 u Ministerstva kultury, a to ve lhůtě 6 měsíců ode dne nabytí právní moci povolení, na jehož základě mu tyto náklady vznikly; jinak nárok na jejich náhradu zaniká.

### ČÁST SEDMÁ

*INFORMAČNÍ SYSTÉMY VEŘEJNÉ SPRÁVY*

#### § 267 — Základní ustanovení  `[272 Čl.I/102; 272 Čl.I/562; 272 Čl.I/563]` {uc=A}

(1) ~~Ministerstvo~~ **Úřad** je správcem informačních systémů veřejné správy55), které umožňují dálkový přístup a slouží k poskytování digitálních služeb56) podle tohoto zákona. {uc=A}

(2) Informačními systémy veřejné správy ve věcech územního plánování a stavebního řádu (dále jen „informační systém ~~stavební správy~~ “) jsou {uc=A}

a) portál stavebníka,

b) národní geoportál územního plánování,

c) evidence stavebních postupů,

d) evidence elektronických dokumentací,

e) informační systém identifikačního čísla stavby a

f) informační systém stavebního řízení.

(3) Informační systémy ~~stavební správy~~ neslouží k výkonu působnosti jiného stavebního úřadu s výjimkou působnosti Ministerstva obrany a Ministerstva vnitra jako dotčených orgánů. Dotčené orgány v případě záměrů v působnosti jiných stavebních úřadů nevyužívají k výkonu své působnosti informační systémy stavební správy. Údaje o stavbách v areálu jaderného zařízení a záměrech v působnosti jiného stavebního úřadu a řízeních s nimi souvisejících se s výjimkou národního geoportálu územního plánování v informačních systémech **neevidují; § 172 odst. 1 se pro jiné** stavební ~~správy neevidují~~ **úřady nepoužije**. {uc=A}

(4) V národním geoportálu územního plánování se údaje podle odstavce 3 vedou a zobrazují v rozsahu údajů poskytnutých Ministerstvem vnitra, Ministerstvem obrany, Ministerstvem spravedlnosti, zpravodajskými službami České republiky, Policií České republiky, Hasičským záchranným sborem České republiky, Národním bezpečnostním úřadem, Národním úřadem pro kybernetickou bezpečnost a Generální inspekcí bezpečnostních sborů, s ohledem na zajištění obrany, bezpečnosti a utajení jejich činnosti.

(5) Informační systémy ~~stavební správy~~ zajišťují informování účastníků řízení podle části šesté a dotčených osob při vydávání opatření obecné povahy podle tohoto zákona o změně údajů v nich vedených. Způsob a podmínky informování účastníků řízení a dotčených osob při vydávání opatření obecné povahy podle tohoto zákona stanoví prováděcí právní předpis. {uc=A}

#### § 268 — Portál stavebníka  `[272 Čl.I/102; 272 Čl.I/564]` {uc=A}

(1) Portál stavebníka umožňuje zejména

a) činit digitální úkony vůči stavebnímu úřadu a dotčenému orgánu, který činí úkony podle jiného právního předpisu sloužící jako podklad pro vydání rozhodnutí v řízení podle tohoto zákona,

b) podávat žádosti vlastníku veřejné dopravní nebo technické infrastruktury a poskytovat vyjádření vlastníka veřejné dopravní nebo technické infrastruktury,

c) vkládat údaje a dokumenty do národního geoportálu územního plánování, do evidence stavebních postupů, do evidence elektronických dokumentací a do digitální mapy veřejné správy57), poskytovat je a odkazovat na ně.

(2) ~~Ministerstvo~~ **Úřad** zřídí vlastníku veřejné dopravní a technické infrastruktury přístup k datovému rozhraní portálu stavebníka na základě jeho žádosti. {uc=A}

**(3) Portál stavebníka poskytuje účastníkům řízení službu sledování stavu řízení.** {uc=A}

~~(3)~~ **(4)** Podrobnosti provozu a datového rozhraní portálu stavebníka stanoví prováděcí právní předpis. {uc=A}

#### § 269 — Národní geoportál územního plánování  `[272 Čl.I/61; 272 Čl.I/565; 272 Čl.I/566; 272 Čl.I/567]` {uc=A}

(1) Národní geoportál územního plánování, který je agendovým informačním systémem, slouží pro

a) zveřejnění výstupů z územně plánovací činnosti,

b) zabezpečení přístupu k evidenci územně plánovací činnosti,

c) sledování postupu pořizování územně plánovací dokumentace,

d) poskytování prostorových dat k plánovanému využití území,

e) zpřístupňování a poskytování dalších dat, která souvisí s územním plánováním a územním rozvojem a která určí ~~ministerstvo~~ **Úřad**, a {uc=A}

f) další činnosti vyplývající z tohoto zákona nebo jeho prováděcích právních předpisů.

(2) Při výkonu územně plánovací činnosti lze na elektronický dokument vedený v národním geoportálu územního plánování odkázat namísto jeho přiložení.

(3) V národním geoportálu územního plánování ~~jsou v jednotných standardech zveřejňovány vybrané části~~ **se zveřejňují** územně ~~plánovacích dokumentací~~ **plánovací podklady, územně plánovací dokumentace, vymezení zastavitelného území** a ~~vymezení zastavěného území, popřípadě dalších nástrojů územního plánování~~ **územní opatření**. {uc=A}

~~(4) Ministerstvo obrany vkládá do národního geoportálu územního plánování data vztahující se k jeho působnosti v elektronické podobě ve strojově čitelném formátu.~~ {uc=A}

~~(5)~~ **(4)** Orgán územního plánování ~~eviduje jednotlivé úkony~~ **vkládá do národního geoportálu územního plánování písemnosti, údaje a prostorová data, které mají být zveřejněny** v národním geoportálu územního plánování**.“** a ~~vkládá~~ **na konci odstavce se doplňuje věta „Orgán územního plánování může vložit** do ~~něj veškeré~~ **národního geoportálu územního plánování i další** písemnosti **vzniklé při územně plánovací činnosti**. Data z vlastní územně plánovací činnosti vkládá v elektronické podobě i ve strojově čitelném formátu, včetně prostorových dat ve vektorové formě, a to bezodkladně po jejich vzniku. {uc=A}

~~(6)~~ **(5)** Přístup k datům zveřejněným v národním geoportálu územního plánování lze omezit nebo odepřít, pokud je to v zájmu veřejné bezpečnosti, zajištění obrany státu nebo ochrany mezinárodních vztahů nebo by jejich zpřístupněním byla porušena ochrana práv třetích osob plynoucích z jiných právních předpisů; pro omezení nebo odepření přístupu k datům zveřejněným v národním geoportálu územního plánování se použije obdobně § 11d zákona č. 123/1998 Sb., o právu na informace o životním prostředí, ve znění pozdějších předpisů. {uc=A}

~~(7)~~ **(6)** Náležitosti obsahu národního geoportálu územního plánování, podrobnosti formy a způsobu vkládání a poskytování údajů v něm vedených stanoví prováděcí právní předpis. {uc=A}

#### § 270 — Evidence stavebních postupů

(1) Evidence stavebních postupů slouží stavebnímu úřadu a dotčenému orgánu, který činí úkony podle jiného právního předpisu sloužící jako podklad pro vydání rozhodnutí v řízení podle tohoto zákona, k ukládání

a) podání a jiných písemností,

b) rozhodnutí a jiných úkonů stavebního úřadu nebo dotčeného orgánu,

c) informací o oprávněné úřední osobě nebo osobách.

(2) Evidence stavebních postupů dále slouží vlastníkovi dopravní nebo technické infrastruktury k doručování vyjádření z hlediska možnosti a způsobu napojení záměru nebo k podmínkám dotčených ochranných a bezpečnostních pásem.

(3) Prováděcí právní předpis stanoví

a) údaje, které se vkládají do evidence stavebních postupů,

b) způsob zaznamenávání úkonů a vkládání písemností, včetně přípustných formátů,

c) metadata náležející k úkonu nebo písemnosti a

d) dobu uchování údajů v evidenci stavebních postupů.

#### § 271 — Evidence elektronických dokumentací  `[272 Čl.I/569; 272 Čl.I/570]` {uc=A}

(1) Do evidence elektronických dokumentací se vkládá dokumentace pro povolení záměru, projektová dokumentace s výjimkou projektové dokumentace pro provádění stavby a výsledky zeměměřických činností, včetně souvisejících informací, za účelem plnění povinností podle tohoto zákona. **Dále se do evidence elektronických dokumentací vkládá informační kontejner pro povolení stavby a informační kontejner pro kolaudaci stavby ve strojově čitelném formátu, stanoví-li tak jiný právní předpis85).** {uc=A}

(2) Žadatel vloží projektovou dokumentaci nebo dokumentaci pro povolení záměru do evidence elektronických dokumentací prostřednictvím portálu stavebníka. ~~Není-li elektronické podání, jehož přílohou je dokumentace pro povolení záměru, která nemusí být zpracována projektantem, učiněno prostřednictvím portálu stavebníka, vloží dokumentaci pro povolení záměru do evidence elektronických dokumentací stavební úřad nebo dotčený orgán, vůči kterému bylo podání učiněno.~~ {uc=A}

(3) Stavební úřad dále vkládá do evidence elektronických dokumentací projektovou dokumentaci nebo dokumentaci pro povolení záměru ověřenou stavebním úřadem po nabytí právní moci rozhodnutí.

(4) Podrobnosti formy a způsobu vkládání projektové dokumentace a dokumentace pro povolení záměru, vedení evidence elektronických dokumentací, datovou strukturu, požadované formáty projektové dokumentace, formy a podmínky poskytování údajů z evidence elektronických dokumentací, dobu uchovávání údajů v evidenci elektronických dokumentací a datové rozhraní pro přístup do ní stanoví prováděcí právní předpis.

#### § 272 — Přístup do evidencí  `[272 Čl.I/571; 272 Čl.I/572]` {uc=A}

(1) Právo na přístup k údajům a elektronickým dokumentům v evidenci stavebních postupů a v evidenci elektronických dokumentací má ten, kdo má podle správního řádu právo nahlížet do spisu.

(2) Právo na přístup k projektové dokumentaci **a dokumentaci pro povolení záměru** má dále ten, kdo se k ní má vyjádřit podle tohoto zákona nebo jiného právního předpisu, a projektant**; jiné osoby jen se souhlasem stavebníka nebo vlastníka stavby, které se tato dokumentace týká**. {uc=A}

(3) Právo na přístup k projektové dokumentaci **a dokumentaci pro povolení záměru** ve strojově čitelném formátu má ten, kdo předloží souhlas stavebníka nebo vlastníka stavby, které se tato dokumentace týká. {uc=A}

(4) Právo na přístup k vyjádření vlastníka veřejné dopravní nebo technické infrastruktury v evidenci stavebních postupů má rovněž ten, kdo prostřednictvím portálu stavebníka o vyjádření požádal.

(5) Osoba oprávněná k přístupu do evidencí má právo na dálkový přístup, včetně strojového vyhledávání informací, a pořizování výpisů a kopií.

#### § 273 — Informační systém identifikačního čísla stavby  `[272 Čl.I/562]` {uc=A}

(1) Informační systém identifikačního čísla stavby slouží k evidenci popisných údajů o stavbách a zařízeních a přidělování jedinečného identifikátoru stavby nebo zařízení, který umožňuje identifikovat stavbu nebo zařízení v informačních systémech ~~stavební správy~~. {uc=A}

(2) Stavební úřad bez zbytečného odkladu po zahájení řízení přidělí stavbě nebo zařízení identifikační číslo stavby a vloží údaje o stavbě nebo zařízení do informačního systému identifikačního čísla stavby; po vydání rozhodnutí ve věci stavební úřad bez zbytečného odkladu aktualizuje údaje vedené o stavbě nebo zařízení v informačním systému identifikačního čísla stavby.

(3) Způsob členění staveb a zařízení pro účely jejich evidence v informačním systému identifikačního čísla stavby, zapisované údaje o nich a způsob přidělování identifikačního čísla stavby nebo zařízení stanoví prováděcí právní předpis.

#### § 274 — Informační systém stavebního řízení  `[272 Čl.I/573]` {uc=A}

Informační systém stavebního řízení je agendový informační systém, který slouží k výkonu působnosti

a) stavebních úřadů,

b) dotčených orgánů, činí-li úkony podle jiného právního předpisu sloužící jako podklad pro vydání rozhodnutí v řízení podle tohoto zákona,

c) ústředních správních úřadů při výkonu kontroly působnosti ~~orgánů stavební správy~~ **stavebních úřadů**. {uc=A}

#### § 275 — Spisová služba a nahlížení do spisu  `[272 Čl.I/562; 272 Čl.I/574]` {uc=A}

(1) Orgány územního plánování ~~a stavební správy~~ vykonávají spisovou službu v elektronické podobě v elektronických systémech spisové služby. Při výkonu spisové služby mohou odkazovat na údaje a dokumenty uložené v národním geoportálu územního plánování~~, evidenci stavebních postupů a evidenci elektronických dokumentací~~. {uc=A}

(2) U staveb v působnosti jiného stavebního úřadu lze z důvodů ochrany zájmů podle jiných právních předpisů odepřít nahlížení do části spisu, která obsahuje projektovou dokumentaci a dokumentaci pro povolení záměru.

(3) Informační systém ~~stavební správy~~ je samostatnou evidencí dokumentů. Povinnost vykonávat spisovou službu se považuje ve vztahu k dokumentům uchovávaným v informačním systému ~~stavební správy~~ za splněnou. {uc=A}

### ČÁST OSMÁ

*VÝKON ČINNOSTI AUTORIZOVANÝCH INSPEKTORŮ*

#### § 276  `[272 Čl.I/575]` {uc=B}

(1) Autorizovaný inspektor **vede správní řízení podle tohoto zákona obdobně jako stavební úřad, za podmínek podle tohoto zákona vydává kolaudační rozhodnutí, rozhodnutí o povolení zkušebního provozu, rozhodnutí o předčasném užívání stavby, rozhodnutí ve zrychleném řízení o změně v užívání stavby nebo rozhodnutí o povolení odstranění stavby, vydává vyjádření pro předčasné užívání stavby a ověřuje pasport stavby místo stavebního úřadu, pokud jej o to stavebník nebo vlastník stavby požádá, a** vydává odborné posudky pro účely kolaudace staveb. {uc=B}

(2) Autorizovaný inspektor vydává na žádost stavebníka posudek pro účely posouzení souladu projektové dokumentace pro provádění stavby s dokumentací pro povolení stavby a s jejími změnami a s požadavky na výstavbu, popřípadě s technickými předpisy a technickými normami.

#### § 277 — Podmínky výkonu činnosti  `[272 Čl.I/61; 272 Čl.I/576; 272 Čl.I/577]` {uc=AB}

(1) Oprávnění k výkonu činnosti autorizovaného inspektora udělí ~~ministerstvo~~ **Úřad** fyzické osobě, která {uc=A}

a) je plně svéprávná,

b) dosáhla magisterského vzdělání architektonického nebo stavebního směru,

c) je autorizovanou osobou,

d) má nejméně ~~15~~ **7** let praxe v projektové činnosti nebo v odborném vedení provádění staveb anebo na stavebním úřadu, ~~má-li osvědčení o zvláštní odborné způsobilosti podle jiného právního předpisu58),~~ {uc=B}

**e) má osvědčení o zvláštní odborné způsobilosti podle jiného právního předpisu58) nebo osvědčení o úspěšném vykonání úřednické zkoušky pro obor specializace, jehož součástí je stavební řád,**

~~e)~~ **f)** je bezúhonná,

~~f)~~ **g)** prokázala odborné znalosti a zkušenosti potřebné pro výkon funkce při zkoušce před odbornou komisí, jejíž členy jmenuje a odvolává ~~ministerstvo~~ **Úřad**. {uc=A}

(2) Za splnění podmínek stanovených v odstavci 1 písm. a), b), c), e) a f) a po vyjádření České komory architektů nebo České komory autorizovaných inženýrů a techniků činných ve výstavbě (dále jen „Komora“) může být oprávnění k činnosti autorizovaného inspektora uděleno i odborníkovi z vysoké školy, výzkumného pracoviště nebo vědeckého ústavu, i když nesplňuje stanovenou praxi.

#### § 278 — Žádost o udělení oprávnění

Žádost o udělení oprávnění k výkonu činnosti autorizovaného inspektora obsahuje kromě obecných náležitostí podle správního řádu údaje a doklady osvědčující splnění podmínek pro výkon činnosti autorizovaného inspektora. Podrobnosti žádosti stanoví prováděcí právní předpis.

#### § 279 — Bezúhonnost  `[272 Čl.I/61; 272 Čl.I/578]` {uc=A}

(1) Za bezúhonnou se pro účely udělení oprávnění k výkonu činnosti autorizovaného inspektora nepovažuje osoba,

a) která byla pravomocně odsouzena za trestný čin spáchaný úmyslně, pokud se na ni nehledí, jako by nebyla odsouzena, a

b) které bylo Komorou pravomocně uloženo disciplinární opatření ve formě pozastavení nebo odnětí autorizace, nebylo-li na návrh autorizované osoby zrušeno.

~~(2) Ustanovení § 51 odst. 2 a 3 se použije obdobně.~~ {uc=A}

~~(3)~~ **(2)** Komora bezodkladně uvědomí ~~ministerstvo~~ **Úřad** o pravomocném uložení disciplinárního opatření autorizovanému inspektorovi spočívajícího v pozastavení nebo odnětí autorizace. {uc=A}

#### § 280 — Doba platnosti a zánik oprávnění  `[272 Čl.I/579]` {uc=A}

(1) Oprávnění k výkonu činnosti autorizovaného inspektora se uděluje s působností pro celé území České republiky na dobu 10 let. Tato doba bude na žádost prodloužena bez vykonání zkoušky nejvýše o 10 let, a to i opakovaně, jestliže autorizovaný inspektor svou činnost soustavně vykonával.

(2) Oprávnění k výkonu činnosti autorizovaného inspektora zaniká

a) dnem doručení písemného prohlášení autorizovaného inspektora o ukončení činnosti ~~ministerstvu~~ **Úřadu**, {uc=A}

b) uplynutím doby podle odstavce 1,

c) dnem právní moci rozhodnutí soudu, kterým byla omezena jeho svéprávnost, nebo

d) ztrátou bezúhonnosti.

#### § 281 — Zrušení oprávnění  `[272 Čl.I/102; 272 Čl.I/580; 272 Čl.I/581]` {uc=A}

(1) ~~Ministerstvo~~ **Úřad** rozhodne o zrušení oprávnění k výkonu činnosti autorizovaného inspektora, jestliže {uc=A}

a) při své činnosti opakovaně ~~nebo~~ závažně porušil veřejné zájmy, které měl chránit, ~~nebo~~ {uc=A}

**b) při své činnosti závažně porušil své povinnosti stanovené tímto zákonem a jinými právními předpisy, nebo**

~~b)~~ **c)** se dopustil jednání neslučitelného s postavením autorizovaného inspektora.

(2) ~~Ministerstvo~~ **Úřad** může rozhodnout o zrušení oprávnění k výkonu činnosti autorizovaného inspektora též pro jeho nečinnost trvající déle než 3 roky. {uc=A}

##### Výkon činnosti autorizovaného inspektora

#### § 282  `[272 Čl.I/582]` {uc=A}

(1) Právnická osoba může se souhlasem ~~ministerstva~~ **Úřadu** vykonávat činnost autorizovaného inspektora, pokud je bezúhonná a zabezpečí výkon činnosti autorizovaným inspektorem~~; ustanovení § 51 odst. 2 a 3 se použije obdobně~~. Veřejná obchodní společnost, jejímiž společníky jsou výlučně autorizovaní inspektoři, může činnost autorizovaného inspektora vykonávat bez souhlasu ~~ministerstva~~ **Úřadu**. {uc=A}

(2) Vykonávají-li autorizovaní inspektoři činnost ve společnosti, upraví si vzájemné vztahy písemnou smlouvou. Společníky společnosti mohou být výlučně autorizovaní inspektoři. Společníci společnosti jsou povinni vykonávat činnost ve společném sídle podnikání.

#### § 283  `[272 Čl.I/583]` {uc=B}

(1) Autorizovaný inspektor vykonává svoji činnost za úplatu, která se sjednává písemnou smlouvou.

(2) Autorizovaný inspektor odpovídá za škodu způsobenou výkonem své činnosti. Před započetím činnosti a po celou dobu jejího trvání musí být pojištěn pro případ odpovědnosti za škodu. Pojištěním musí být kryta škoda, která může být způsobena výkonem činnosti autorizovaného inspektora. Na požádání osoby, se kterou autorizovaný inspektor uzavírá smlouvu podle odstavce 1, je povinen sdělit výši částky, na kterou je pojištěn.

(3) Autorizovaný inspektor je povinen vést o svých úkonech evidenci a uchovávat ji po dobu nejméně 5 let. **Vydal-li autorizovaný inspektor rozhodnutí místo stavebního úřadu, doručí jej vždy také stavebnímu úřadu, a to společně se žádostí žadatele včetně jejích příloh.** {uc=B}

(4) Autorizovaný inspektor nesmí svoji činnost vykonávat u staveb, na kterých se podílel, podílí nebo má podílet při jejich přípravě anebo provádění sám nebo osoba jemu blízká, kterou se pro účely tohoto zákona rozumí

a) příbuzný v řadě přímé, sourozenec, manžel nebo partner,

b) obchodní společnost, ve které je společníkem,

c) družstvo, jehož je členem,

d) osoba, se kterou je ve vztahu pracovním nebo služebním.

#### § 284 — Práva a povinnosti autorizovaného inspektora  `[272 Čl.I/584]` {uc=B}

(1) Autorizovaný inspektor je v rozsahu oboru, popřípadě specializace své autorizace, oprávněn **na celém území České republiky ověřovat pasport stavby, vést správní řízení a** vydávat **kolaudační rozhodnutí, rozhodnutí o povolení zkušebního provozu, rozhodnutí o předčasném užívání stavby, rozhodnutí ve zrychleném řízení o změně v užívání stavby, rozhodnutí o povolení odstranění stavby a vyjádření pro předčasné užívání stavby a** odborné posudky autorizovaného inspektora. Odborný posudek autorizovaného inspektora pro účely kolaudace musí obsahovat minimálně {uc=B}

a) identifikační údaje stavebníka,

b) druh, účel stavby, číslo popisné nebo evidenční u změny dokončené stavby,

c) údaje o oprávnění provést stavbu,

d) údaje o zkušebním provozu, pokud byl prováděn, popřípadě o předčasném užívání stavby,

e) datum ověření splnění podmínek vydání odborného posudku,

f) výsledek ověření splnění podmínek vydání odborného posudku,

g) jméno a příjmení, podpis, otisk razítka autorizovaného inspektora a datum vystavení odborného posudku.

(2) Odborný posudek autorizovaného inspektora pro účely kolaudace dokládá, že skutečné provedení stavby nebo její části, kterou lze samostatně užívat, je v souladu s ověřenou dokumentací nebo jejími povolenými změnami, umožňuje povolený účel užívání a splňuje požadavky na výstavbu.

(3) Odborný posudek pro účely kolaudace je autorizovaný inspektor oprávněn vydat pouze tehdy, pokud ověřil splnění podmínek uvedených v odstavci 2.

(4) Odborný posudek autorizovaného inspektora k dokumentaci pro provádění stavby dokládá, že dokumentace pro provádění stavby je v souladu s ověřenou dokumentací pro povolení stavby nebo s jejími povolenými změnami a s požadavky na výstavbu, popřípadě technickými předpisy a technickými normami.

(5) Odborný posudek k dokumentaci pro provádění stavby je autorizovaný inspektor oprávněn vydat pouze tehdy, pokud ověřil splnění podmínek uvedených v odstavci 4.

(6) Odborný posudek autorizovaného inspektora nemůže být vydán pro stavby sloužící přípravě, otvírce a dobývání ložisek, jakož i úpravě a zušlechťování nerostů prováděné v souvislosti s jejich dobýváním, stavby sloužící jako sklady výbušnin a pro stavby vodních děl.

(7) Autorizovaný inspektor je povinen na výzvu stavebního úřadu a na jeho náklad poskytnout v rozsahu své odborné kvalifikace expertní součinnost.

#### § 285 — Příprava a provádění zkoušek  `[272 Čl.I/585]` {uc=A}

(1) Provádění přípravy a zkoušek uchazečů, vedení evidence autorizovaných inspektorů a další úkony s tím související organizačně zajišťuje Komora. K zabezpečení jednotného postupu podle věty první zřizují komory společný koordinační orgán schvalovaný na jejich návrh ~~ministerstvem~~ **Úřadem**. Náklady spojené s přípravou na zkoušku a s jejím vykonáním nese uchazeč. {uc=A}

(2) Koordinační orgán na základě pověření Komory zajišťuje koordinační, organizační a administrativní záležitosti a odborné vzdělávání potřebné k jednotnému postupu při výkonu činnosti autorizovaných inspektorů.

(3) Komora shromažďuje, eviduje, aktualizuje a poskytuje informace nezbytné pro činnost autorizovaného inspektora. Na úhradě nákladů spojených s touto činností se autorizovaný inspektor každoročně podílí příspěvkem ve prospěch Komory. Výše příspěvku je shodná s příspěvkem určeným členům Komory.

(4) Postup při jmenování členů koordinačního orgánu, jeho činnost, přípravu, provádění a obsah zkoušek a náležitosti a způsob vedení evidence autorizovaných inspektorů stanoví prováděcí právní předpis.

#### § 286 — ~~Působnost ministerstva~~ **Působnost Úřadu**  `[272 Čl.I/102; 272 Čl.I/586]` {uc=A}

~~Ministerstvo~~ **Úřad** kontroluje přípravu ke zkoušce, osnovy a postup při provádění zkoušek, spočívající v ověření odborných znalostí autorizovaného inspektora, podklady pro jmenování a odvolávání autorizovaných inspektorů, činnost Komory a výkon agendy s tím související. V součinnosti se stavebními úřady vykonává též kontrolu činnosti autorizovaných inspektorů. {uc=A}

### ČÁST DEVÁTÁ

*KONTROLA A OPATŘENÍ K NÁPRAVĚ*

#### HLAVA I

*KONTROLA VE VĚCECH ÚZEMNÍHO PLÁNOVÁNÍ*

#### § 287 — Působnost  `[272 Čl.I/102; 272 Čl.I/587; 272 Čl.I/588]` {uc=A}

(1) Kontrolu ve věcech územního plánování vykonávají ~~ministerstvo~~ **Úřad** a ~~krajský úřad~~ **úřady rozvoje území krajů**. {uc=A}

(2) ~~Ministerstvo~~ **Úřad** vykonává kontrolu {uc=A}

a) orgánů krajů,

b) orgánů hlavního města Prahy a

c) zástupců pořizovatele.

(3) ~~Krajský úřad~~ **Úřad rozvoje území kraje** vykonává kontrolu {uc=A}

a) orgánů obcí a

b) zástupců pořizovatele.

(4) Kontrola ve věcech územního plánování zahrnuje v případě orgánů obcí, hlavního města Prahy a krajů kontrolu nad výkonem přenesené i samostatné působnosti.

#### § 288 — Předmět kontroly  `[272 Čl.I/589; 272 Čl.I/590]` {uc=A}

(1) Při výkonu kontroly ve věcech územního plánování ~~ministerstvo a krajský úřad~~ **příslušné úřady rozvoje území** kontrolují dodržování tohoto zákona, právních předpisů vydaných k jeho provedení, opatření obecné povahy a rozhodnutí vydaných na základě tohoto zákona~~, jakož i dodržování usnesení vlády, směrnic ústředních správních úřadů, jakož i opatření příslušných orgánů veřejné správy přijatých při kontrole výkonu přenesené působnosti~~. {uc=A}

(2) Kontrola se vztahuje i na usnesení, rozhodnutí a jiná opatření přijatá v samostatné ~~i přenesené~~ působnosti. {uc=A}

(3) Kontrola může být vykonána i v průběhu pořizování územně plánovací dokumentace.

#### § 289 — Nápravná opatření  `[272 Čl.I/591]` {uc=A}

(1) Byly-li při kontrole zjištěny nedostatky, vyzve ~~ministerstvo nebo krajský~~ **příslušný** úřad **rozvoje území**, se zřetelem na jejich charakter a následky, nebo možné následky, ke zjednání nápravy v přiměřené lhůtě; přitom může do doby zjednání nápravy zcela nebo zčásti pozastavit výkon činnosti, při níž dochází k porušování povinností. {uc=A}

(2) Je-li podle odstavce 1 pozastaveno pořizování územně plánovací dokumentace, může námitky proti kontrolním zjištěním podat i kraj nebo obec, pro které je územně plánovací dokumentace pořizována.

(3) Bylo-li pozastaveno pořizování územně plánovací dokumentace, lze v jejím pořizování pokračovat až po potvrzení kontrolního orgánu o zjednání nápravy.

(4) Je-li pořizovatel nečinný, stanoví mu kontrolní orgán přiměřenou lhůtu, ve které má úkon učinit.

#### § 290 — Kontrola výkonu samostatné působnosti

Při kontrole usnesení, rozhodnutí a jiných opatření orgánů obcí, hlavního města Prahy a krajů v samostatné působnosti ve věcech územního plánování se ustanovení hlavy šesté a hlavy sedmé části první zákona o obcích, hlavy desáté a hlavy jedenácté části první zákona o hlavním městě Praze a hlav šesté a sedmé zákona o krajích použijí obdobně.

#### HLAVA II

*KONTROLA VE VĚCECH STAVEBNÍHO ŘÁDU*

##### Díl 1

*Stavební kontrola*

#### § 291 — Obecné ustanovení

Stavební úřady kontrolují plnění povinností vyplývajících z tohoto zákona, jiných právních předpisů v mezích jejich působnosti a z rozhodnutí a opatření obecné povahy vydaných podle tohoto zákona.

#### § 292 — Kontrola

(1) Stavební úřad provádí kontrolu za účelem zajištění ochrany veřejných zájmů chráněných tímto zákonem. Na podnět dotčeného orgánu zahájí stavební úřad kontrolu vždy. Obsahuje-li povolení záměru podmínky k ochraně veřejných zájmů stanovené na základě vyjádření nebo závazného stanoviska dotčeného orgánu, je dotčený orgán příslušný ke kontrole jejich dodržování; stavební úřad poskytne součinnost potřebnou ke kontrole těchto podmínek.

(2) Je-li na základě kontroly zahájeno správní řízení, doručuje se stejnopis protokolu účastníkům řízení a dotčeným orgánům spolu s oznámením o zahájení řízení nebo s rozhodnutím, které je prvním úkonem stavebního úřadu v řízení.

(3) Na výzvu stavebního úřadu je povinen se kontroly zúčastnit stavebník, a je-li to nezbytné, též vlastník stavby, hlavní projektant, projektant, zhotovitel, stavbyvedoucí a osoba vykonávající stavební dozor. Výzva musí být písemná a doručuje se do vlastních rukou s nejméně pětidenním předstihem. Ve výzvě musí být uvedeno, kdo, kdy, kam, v jaké věci a z jakého důvodu se má dostavit a jaké jsou právní následky v případě, že se nedostaví.

(4) Stavební úřad může v rámci kontroly ústně vyzvat kontrolovanou osobu k odstranění zjištěných nedostatků a stanovit jí k tomu přiměřenou lhůtu, což zaznamená v protokolu. Nebudou-li nedostatky odstraněny ve stanovené lhůtě, postupuje stavební úřad podle § 294 nebo 295. Výzva obsahuje poučení o následcích spojených s neodstraněním zjištěných nedostatků.

(5) Pověření ke kontrole podle tohoto zákona lze vydat i ve formě průkazu, jehož vzor stanoví prováděcí právní předpis.

#### § 293 — Vstup na pozemek a do stavby

(1) Kontrolující může při výkonu kontroly vstupovat v nezbytné míře na pozemek, na stavbu a do stavby pouze s vědomím jejich vlastníků; uvědomění vlastníka nevyžaduje písemnou formu.

(2) Kontrolující může vstoupit na pozemek nebo do stavby i bez vědomí jejich vlastníka v případě důvodného podezření na

a) bezprostřední ohrožení života nebo zdraví osob nebo zvířat, nebo

b) porušení povinností vyplývajících ze zákona za podmínky, že se kontrolujícímu nepodařilo vlastníka pozemku nebo stavby uvědomit.

(3) O vstupu podle odstavce 2 a jeho důvodech musí kontrolující vlastníka bez zbytečného odkladu písemně informovat.

(4) Kontrolující může vstoupit do obydlí bez souhlasu vlastníka nebo uživatele, jen pokud je to nezbytné pro ochranu života, zdraví nebo bezpečnosti osob. Je-li obydlí užíváno také pro podnikání nebo provozování jiné hospodářské činnosti, může kontrolující za účelem kontroly podle tohoto zákona vstoupit do obydlí vždy. Vlastník a uživatel obydlí jsou v uvedených případech povinni kontrolujícímu vstup do obydlí umožnit. Vlastník je povinen umožnit vykonání nezbytných zkoušek a měření použitím nezbytných technických zařízení či prostředků. Pokud je to třeba, přizve kontrolující i další osoby, postup podle odstavce 3 se použije přiměřeně.

(5) Hrozí-li nebezpečí z prodlení a jde-li o některý z důvodů podle odstavce 2 nebo 4, může si stavební úřad zjednat přístup na pozemek nebo do stavby. Policie České republiky poskytne stavebnímu úřadu na jeho žádost ochranu a součinnost podle zákona o Policii České republiky.

(6) Pokud vlastník pozemku nebo stavby brání vstupu kontrolujícímu nebo jím přizvané osobě, může mu stavební úřad rozhodnutím, které je prvním úkonem stavebního úřadu v řízení, umožnění vstupu nařídit. Odvolání proti rozhodnutí nemá odkladný účinek.

#### § 294 — Zakazující opatření

(1) Stavební úřad může i bez provedené kontroly zakázat

a) stavební nebo montážní činnost, je-li prováděna v rozporu s tímto zákonem nebo jinými právními předpisy,

b) odstraňování záměru, pokud je odstraňován v rozporu s tímto zákonem nebo jinými právními předpisy,

c) užívání záměru, je-li užíván v rozporu s tímto zákonem nebo jinými právními předpisy.

(2) Stavební úřad může postupovat v řízení na místě. Vydání rozhodnutí může být prvním úkonem stavebního úřadu v řízení; odvolání proti rozhodnutí nemá odkladný účinek.

(3) V rozhodnutí o zakazujícím opatření může stavební úřad uložit další opatření, je-li to vzhledem k povaze a následkům činnosti, která se zakazuje, nezbytné, a stanovit lhůtu k jejich provedení.

#### § 295 — Opatření k nápravě  `[272 Čl.I/592]` {uc=A}

(1) Je-li to nezbytné k ochraně zákonem chráněného veřejného zájmu, stavební úřad může i bez provedené kontroly nařídit opatření k nápravě, které spočívá v povinnosti

a) provést udržovací práce, zejména v případě nedostatečné údržby stavby,

b) provést nezbytné úpravy stavby, zejména

1. při výskytu hygienických, bezpečnostních, požárních, provozních nebo jiných závad, včetně nesplnění požadavků na přístupnost,

2. v případě, že stavba nebo její užívání ohrožuje životní prostředí,

3. pro ochranu kulturně historických, archeologických, architektonických a urbanistických hodnot,

4. v zájmu bezpečnosti a plynulosti provozu na pozemních komunikacích,

5. za účelem vyhovění požadavkům obrany a bezpečnosti státu uplatněným Ministerstvem obrany nebo Ministerstvem vnitra,

6. pro připojení stavby na technickou infrastrukturu, nebo vybavení sociálním nebo jiným hygienickým zařízením,

7. pro zajištění účinného odvádění a zneškodňování odpadních vod v souladu s právními předpisy, k usnadnění průtoku přívalových vod, k zamezení vnikání povrchových vod do staveb a na přilehlé pozemky,

8. zakonzervování rozestavěné stavby, jejíž provádění bylo přerušeno,

c) provést nutné zabezpečovací práce, zejména v případě, že jsou záměrem ohroženy životy nebo zdraví osob nebo zvířat,

d) neodkladně odstranit záměr, zejména v případě, že jsou záměrem ohroženy životy nebo zdraví osob nebo zvířat, a záměr hrozí zřícením nebo sesuvem nebo

e) vyklidit stavbu v případě, že **je užívána bez povolení nebo** jsou závadami na stavbě ohroženy životy nebo zdraví osob nebo zvířat, anebo má být nařízeno opatření k nápravě podle písmene c) nebo d). {uc=A}

(2) Opatření k nápravě podle odstavce 1 se nařizuje vlastníku stavby nebo pozemku, na němž se záměr nachází. Opatření k nápravě podle odstavce 1 písm. e) se nařizuje též všem osobám, které stavbu užívají nebo se ve stavbě zdržují.

(3) V rozhodnutí o nařízení opatření k nápravě stavební úřad stanoví zejména rozsah, způsob a podmínky jeho provedení a lhůtu k jeho provedení.

(4) Vyžaduje-li provedení opatření k nápravě projektovou dokumentaci nebo jiné podklady, stavební úřad nařídí jejich obstarání vlastníku záměru nebo pozemku, na němž se záměr nachází, a stanoví lhůtu k jejich předložení. Nesplní-li vlastník nařízenou povinnost, obstará tyto podklady stavební úřad, který následně rozhodnutím uloží vlastníku povinnost uhradit náklady na jejich obstarání; na tuto povinnost stavební úřad vlastníka předem písemně upozorní.

(5) Při nařízení opatření k nápravě podle odstavce 1 písm. c), d) a e) může stavební úřad postupovat v řízení na místě. Vydání rozhodnutí může být prvním úkonem stavebního úřadu v řízení; odvolání proti rozhodnutí nemá odkladný účinek. V případě ústního vyhlášení rozhodnutí se písemné potvrzení uvede jako součást protokolu o kontrole. Písemné potvrzení obsahuje náležitosti rozhodnutí podle § 68 správního řádu; ustanovení § 67 odst. 3 správního řádu se nepoužije.

(6) Rozhodnutí o nařízení opatření k nápravě podle odstavce 1 písm. e) doručí stavební úřad vyklizovaným osobám, vlastníkovi stavby, vyklizující osobě a obci; v případě ústního vyhlášení rozhodnutí písemné potvrzení o vydání tohoto rozhodnutí doručí stavební úřad vyklizovaným osobám, vlastníkovi stavby, vyklizující osobě a obci bez zbytečného odkladu. Osoby, které se ve stavbě zdržují, ale nejsou stavebnímu úřadu známy, se o vydaném rozhodnutí vyrozumí informací umístěnou na místě stavby před provedením vyklizení.

(7) U nařízení opatření k nápravě podle odstavce 1 písm. a) až d) jsou nájemci bytů a nebytových prostor účastníky řízení, pokud jejich práva vyplývající z nájmu mohou být přímo dotčena plněním povinností nařízených stavebním úřadem.

#### § 296 — Provedení opatření k nápravě

(1) Hrozí-li u provedení opatření k nápravě podle § 295 odst. 1 písm. c), d) nebo e) nebezpečí z prodlení, zajistí provedení nařízeného opatření k nápravě stavební úřad prostřednictvím osoby, která je podle jiného právního předpisu oprávněna k provedení nařízených prací; při stanovení této osoby se zákon o zadávání veřejných zakázek nepoužije. Této osobě může stavební úřad provedení opatření k nápravě nařídit rozhodnutím, které může být vydáno jako první úkon stavebního úřadu v řízení.

(2) Náklady na provedení opatření k nápravě je povinen uhradit vlastník stavby nebo pozemku, na němž se záměr nachází. Nedošlo-li mezi osobou, prostřednictvím které stavební úřad zajišťuje provedení nařízeného opatření k nápravě, a vlastníkem k dohodě o zaplacení, stavební úřad uhradí náklady na provedení opatření k nápravě a rozhodnutím uloží vlastníkovi povinnost náklady uhradit stavebnímu úřadu.

#### § 297 — Opatření na sousedním pozemku nebo stavbě  `[272 Čl.I/593]` {uc=A}

(1) Je-li nezbytné pro **vytvoření podmínek pro provedení stavby nebo její změny, nutných zabezpečovacích prací, nezbytných úprav, udržovacích prací nebo k odstranění stavby nebo zařízení,** provedení nařízeného opatření k nápravě, aby vlastník sousedního pozemku nebo stavby, nebo osoba, která má k sousednímu pozemku nebo stavbě jiné věcné právo, strpěli nezbytné omezení, a nedošlo-li mezi dotčenými osobami k dohodě, stavební úřad může z moci úřední nebo na žádost vlastníka stavby nebo pozemku, na němž se záměr nachází, uložit opatření na sousedním pozemku nebo stavbě přiměřené okolnostem. {uc=A}

(2) Stavební úřad v rozhodnutí o opatření na sousedním pozemku nebo stavbě stanoví

a) účel uloženého opatření,

b) jakého pozemku nebo stavby nebo jejich části se opatření týká,

c) vymezení prováděné činnosti na sousedním pozemku nebo stavbě a

d) podmínky omezení, zejména časové rozmezí provádění činnosti.

(3) Účastníkem řízení o opatření na sousedním pozemku nebo stavbě je ten, o jehož povinnosti je řízení vedeno, a ten, jehož právo má být opatřením na sousedním pozemku nebo stavbě založeno nebo jehož konání nebo opomenutí bylo důvodem pro zahájení řízení o uložení opatření k nápravě.

(4) Nerozhodne-li stavební úřad jinak, odvolání proti rozhodnutí o opatření na sousedním pozemku nebo stavbě nemá odkladný účinek.

(5) Při postupu podle uloženého opatření na sousedním pozemku nebo stavbě je každý povinen dbát, aby co nejméně rušil užívání sousedního pozemku nebo stavby a aby prováděnými pracemi nevznikla škoda, které je možno zabránit.

(6) Po skončení prací je povinen ten, jehož právo bylo opatřením na sousedním pozemku nebo stavbě založeno, uvést sousední pozemek nebo stavbu do předchozího stavu.

##### Díl 2

*Kontrola výkonu působnosti stavebních úřadů*

#### ~~§ 298 — Působnost~~

> **Nahrazuje se novým zněním (níže).**

~~(1) Kontrolu výkonu působnosti~~

~~a) Dopravního a energetického stavebního úřadu ve věcech staveb dálnic, silnic, místních komunikací a veřejně přístupných účelových komunikací, staveb drah a civilních leteckých staveb a staveb souvisejících vykonává Ministerstvo dopravy,~~

~~b) Dopravního a energetického stavebního úřadu ve věcech vyhrazených staveb, u nichž vykonává působnost nadřízeného správního orgánu Ministerstvo průmyslu a obchodu, a ve věcech staveb technické infrastruktury pro energetiku a elektronické komunikace, výroben obnovitelných zdrojů energie a staveb souvisejících vykonává Ministerstvo průmyslu a obchodu,~~

~~c) krajských stavebních úřadů ve věcech staveb silnic, místních komunikací a veřejně přístupných účelových komunikací, staveb technické infrastruktury pro energetiku a elektronické komunikace a staveb obnovitelných zdrojů energie vykonává Dopravní a energetický stavební úřad,~~

~~d) krajských stavebních úřadů s výjimkou staveb uvedených v písmenu c) a obecních stavebních úřadů vykonává ministerstvo,~~

~~e) obecních stavebních úřadů vykonává krajský stavební úřad.~~

~~(2) Ministerstvo, Ministerstvo dopravy, Ministerstvo průmyslu a obchodu, Dopravní a energetický stavební úřad a krajský stavební úřad kontrolují dodržování tohoto zákona, právních předpisů vydaných k jeho provedení a rozhodnutí a opatření obecné povahy vydaných na základě tohoto zákona, jakož i dodržování usnesení vlády a směrnic ústředních správních úřadů.~~

#### § 298 — **Působnost**  `[272 Čl.I/594]` {uc=A}

**(1) Úřad kontroluje výkon působnosti úřadů rozvoje území krajů a autorizovaných inspektorů. Úřady rozvoje území krajů kontrolují výkon působnosti svých územních pracovišť.** {uc=A}

**(2) Úřad a věcně příslušné ústřední orgány státní správy kontrolují dodržování jiných právních předpisů při postupech podle tohoto zákona, jakož i dodržování usnesení vlády a směrnic ústředních správních úřadů.** {uc=A}

#### § 299 — Nápravná opatření  `[272 Čl.I/595]` {uc=A}

~~Ministerstvo, Ministerstvo dopravy, Ministerstvo průmyslu~~ **Úřad** a ~~obchodu, Dopravní a energetický stavební úřad a krajský stavební úřad~~ **věcně příslušné ústřední orgány státní správy** mohou při výkonu kontroly ukládat opatření k odstranění nebo prevenci zjištěných nedostatků v přiměřené lhůtě; ~~do doby zjednání nápravy mohou pozastavit nebo omezit výkon činnosti~~ **nesouhlasí-li Úřad s opatřením uloženým jiným ústředním orgánem státní správy**, ~~při níž dochází~~ **předloží věc** k ~~porušování právní povinnosti~~ **rozhodnutí vládě**. {uc=A}

#### HLAVA III

*KONTROLA VÝKONU PŘENESENÉ PŮSOBNOSTI PŘI VYDÁVÁNÍ PROVÁDĚCÍHO PRÁVNÍHO PŘEDPISU*

#### § 300  `[272 Čl.I/61]` {uc=A}

Při kontrole vydávání a obsahu prováděcího právního předpisu vydaného územním samosprávným celkem se ustanovení hlavy šesté části první zákona o obcích použijí obdobně s tím, že namísto krajského úřadu provede kontrolu ~~ministerstvo~~ **Úřad**. {uc=A}

### ČÁST DESÁTÁ

*PŘESTUPKY*

#### § 301 — Přestupky osob  `[272 Čl.I/596; 272 Čl.I/597; 272 Čl.I/598; 272 Čl.I/599; 272 Čl.I/600]` {uc=A}

(1) Přestupku se dopustí ten, kdo

**a) provede záměr bez povolení, které je podle tohoto zákona vyžadováno, nebo v rozporu s ním,**

**b) provede jednoduchou stavbu bez povolení, které je podle tohoto zákona vyžadováno, nebo v rozporu s ním,**

**c) užívá záměr vyžadující povolení bez tohoto povolení, nebo v rozporu s ním,**

**d) odstraní stavbu, která podléhá povolení, bez povolení odstranění stavby, nebo v rozporu s ním, nebo**

**e) odstraní stavbu, která obsahuje azbest, bez povolení odstranění stavby nebo v rozporu s ním.**

(2) Přestupku se dopustí ten, kdo ~~poruší zakazující opatření podle § 294 nebo neplní uložená opatření k nápravě podle § 295.~~ {uc=A}

**a) poruší zakazující opatření podle § 294 nebo neplní uložená opatření k nápravě podle § 295 nebo**

**b) užívá záměr vyžadující povolení bez tohoto povolení za účelem zisku nebo kdo umožní takové užívání jiným osobám.**

(3) Za přestupek lze uložit pokutu

a) do 400 000 Kč, jde-li o přestupek podle odstavce 1 písm. c) ~~nebo d)~~, {uc=A}

b) do 1 000 000 Kč, jde-li o přestupek podle odstavce 1 písm. ~~f), g), h), i), j), k), l~~ **b**) nebo ~~n~~ **d**), nebo odstavce 2, {uc=A}

c) do 2 000 000 Kč, jde-li o přestupek podle odstavce 1 písm. a), ~~b),~~ **nebo** e) nebo ~~m), nebo~~ {uc=A}

d) do 4 000 000 Kč, jde-li o přestupek podle odstavce 1 písm. a~~) nebo b~~), jestliže se jedná o záměr ve zvláště chráněném území podle zákona o ochraně přírody a krajiny, v ochranném pásmu, na ~~nezastavitelném pozemku~~ **nestavební ploše**, v ~~nezastavěném~~ **nezastavitelném** území, o záměr EIA nebo o záměr vyžadující vydání integrovaného povolení. {uc=A}

#### § 302 — ~~Přestupky vybraných osob~~  `[272 Čl.I/602; 272 Čl.I/603; 272 Čl.I/604; 272 Čl.I/605]` {uc=A}

(1) Stavebník se dopustí přestupku tím, že

a) poruší některou z povinností podle § 160 odst. 1 a 2 nebo podle § 161 odst. 1 až 3,

b) poruší některou z povinností v souvislosti s nálezem podle § 266 odst. 1 nebo 2, nebo

c) nesplní oznamovací povinnost podle § 263 odst. 3.

(2) Zhotovitel se dopustí přestupku tím, že

a) provede nebo odstraní stavbu v rozporu § 163 odst. 2 písm. a),

b) poruší některou z povinností podle § 163 odst. 1 nebo § 163 odst. 2 písm. b) nebo c), nebo

c) v rozporu s § 163 odst. 2 písm. d) nevede stavební deník nebo jednoduchý záznam o stavbě.

(3) Vlastník stavby nebo zařízení se dopustí přestupku tím, že poruší některou z povinností podle § 167 písm. a) až k).

(4) Vlastník technické nebo dopravní infrastruktury nebo provozovatel staveb a zařízení, z jejichž provozu vznikají omezení v území podle jiného právního předpisu, se dopustí přestupku tím, že nesplní povinnost podle § 63 odst. 2 písm. b) nebo c).

(5) Vlastník technické infrastruktury se dopustí přestupku tím, že nesplní některou z povinností podle § 168 písm. a) nebo b) nebo § 181 odst. 1.

(6) Zhotovitel, stavbyvedoucí, osoba vykonávající stavební dozor, dozor projektanta, technický dozor stavebníka, stavebník, autorizovaný inspektor nebo vlastník stavby se dopustí přestupku tím, že poruší oznamovací povinnost podle § 169.

(7) Za přestupek lze uložit pokutu

a) do 400 000 Kč, jde-li o přestupek podle odstavce 1 písm. a) nebo c), nebo odstavce 2 písm. c) anebo odstavců 3 až 6,

b) do 1 000 000 Kč, jde-li o přestupek podle odstavce **1 písm. b) nebo odstavce** 2 písm. b), {uc=A}

c) do 2 000 000 Kč, jde-li o přestupek podle odstavce ~~1 písm. b) nebo odstavce~~ 2 písm. a), nebo {uc=A}

d) do 4 000 000 Kč, jde-li o přestupek podle odstavce 2 písm. a), jestliže jde o záměr v chráněném území podle zvláštních právních předpisů, v ochranném pásmu, na ~~nezastavitelném pozemku~~ **nestavební ploše**, v ~~nezastavěném~~ **nezastavitelném** území, o záměr EIA nebo o záměr vyžadující vydání integrovaného povolení. {uc=A}

#### § 303 — ~~Přestupky fyzických osob~~  `[272 Čl.I/606]` {uc=A}

(1) Fyzická osoba se dopustí přestupku tím, že v rozporu s § 155 provádí vybrané činnosti ve výstavbě bez oprávnění podle autorizačního zákona.

(2) Fyzická osoba se jako stavbyvedoucí dopustí přestupku tím, že poruší některou z povinností podle § 164.

(3) Fyzická osoba vykonávající stavební dozor se dopustí přestupku tím, že nevykonává řádně odborný dozor nad prováděním stavby svépomocí tím, že poruší některou z povinností podle § 165.

(4) Fyzická osoba se jako projektant územně plánovací dokumentace dopustí přestupku tím, že neodevzdá územně plánovací dokumentaci v jednotném standardu podle § 162 odst. 6.

(5) Za přestupek podle odstavců 1 až 4 lze uložit pokutu do 400 000 Kč.

#### § 304 — Společná ustanovení  `[272 Čl.I/607; 272 Čl.I/608]` {uc=A}

(1) Přestupky podle tohoto zákona projednává úřad příslušný podle § 32 až 35~~;~~ **a** přestupky ~~podle § 302 odst~~ **na úseku územního plánování Úřad**. ~~4 a § 303 odst. 4 projednává krajský úřad.~~ {uc=A}

~~(2) Přestupkem podle tohoto zákona není porušení takových podmínek rozhodnutí, které stavební úřad převzal do svého rozhodnutí na základě jednotného environmentálního stanoviska.~~ {uc=A}

~~(3)~~ **(2)** Stavbou se pro účely této části rozumí též terénní úprava. {uc=A}

### ČÁST JEDENÁCTÁ

*SOUDNÍ PŘEZKUM*

#### § 305 — Postavení stavebníka a vlastníka stavby

Není-li stavebník nebo vlastník stavby v řízení o žalobě proti rozhodnutí stavebního úřadu žalobcem, je osobou zúčastněnou na řízení.

#### § 306 — Lhůta pro podání žaloby  `[272 Čl.I/609]` {uc=B}

~~(1)~~ Žalobu proti rozhodnutí stavebního úřadu, s výjimkou rozhodnutí o přestupku, lze podat do 1 měsíce poté, kdy bylo rozhodnutí žalobci oznámeno. {uc=B}

~~(2) Rozšířit žalobu na dosud nenapadené výroky nebo ji rozšířit o další žalobní body může žalobce jen ve lhůtě 2 měsíců poté, kdy mu bylo rozhodnutí oznámeno.~~ {uc=B}

#### § 307 — Nepřípustnost  `[272 Čl.I/610; 272 Čl.I/611; 272 Čl.I/612]` {uc=B}

(1) Žaloba proti rozhodnutí stavebního úřadu ~~je nepřípustná~~ **nebo jednotlivé žalobní body jsou nepřípustné**, ~~obsahuje~~ **směřují** -li ~~pouze~~ **k řešení nepřípustných námitek nebo obsahují-li** skutkové a právní důvody, které žalobce neuplatnil v řízení o odvolání, ač tak učinit mohl; to neplatí, jde-li o žalobu proti rozhodnutí, které bylo vydáno v řízení zahájeném z moci úřední, anebo kterým byla povolena stavba podléhající posouzení vlivů na životní prostředí. {uc=B}

(2) Návrh na zrušení opatření obecné povahy nebo jeho části ~~je také nepřípustný~~ **i jednotlivé body tohoto návrhu jsou nepřípustné**, ~~obsahuje~~ **obsahují** -li pouze důvody, které navrhovatel neuplatnil v řízení o vydání opatření obecné povahy, ač tak učinit mohl; to neplatí, jde-li o opatření obecné povahy podléhající posouzení vlivů na životní prostředí. {uc=B}

**(3) Nepřípustné žalobní body soud nevypořádává.** {uc=B}

#### ~~§ 308 — Odkladný účinek~~

> **Nahrazuje se novým zněním (níže).**

~~Přizná-li soud žalobě odkladný účinek, projedná žalobu a rozhodne o ní přednostně s nejvyšším urychlením.~~

#### § 308 — **Odkladný účinek**  `[272 Čl.I/613]` {uc=B}

**(1) Návrh na přiznání odkladného účinku žaloby proti rozhodnutí stavebního úřadu o povolení záměru lze podat pouze společně s žalobou. Návrh na přiznání odkladného účinku v řízení o kasační stížnosti lze podat pouze společně s touto kasační stížností.** {uc=B}

**(2) Přizná-li soud žalobě nebo kasační stížnosti odkladný účinek nebo nařídí-li předběžné opatření, rozhodne ve věci přednostně s nejvyšším urychlením, nejpozději do 90 dnů od přiznání odkladného účinku nebo od nařízení předběžného opatření.** {uc=B}

#### § 308a  `[272 Čl.I/614]` {uc=B}

**Soudní smír Připouští-li to povaha věci, mohou účastníci řízení a osoby zúčastněné na řízení skončit řízení soudním smírem; ustanovení § 99 občanského soudního řádu se použije obdobně. Obsahem smíru může být zejména netrvání na návrhu a poskytnutí finanční náhrady nebo provedení kompenzačních nebo zmírňujících opatření.** {uc=B}

#### ~~§ 309 — Rozhodnutí o žalobě~~

> **Nahrazuje se novým zněním (níže).**

~~(1) Nebrání-li tomu vady napadeného rozhodnutí nebo řízení, které předcházelo jeho vydání, přezkoumá soud všechny přípustné žalobní body.~~

~~(2) Je-li žaloba důvodná, bez dalšího dokazování je zcela zřejmé, jak by v případě jeho zrušení a vrácení stavebnímu úřadu k dalšímu řízení musel stavební úřad rozhodnout a navrhl-li takový postup žalobce nebo osoba zúčastněná na řízení, může soud rozsudkem napadené rozhodnutí změnit.~~

~~(3) Proti částem rozhodnutí stavebního úřadu, která byla změněna rozsudkem, není přípustné vést přezkumné řízení podle správního řádu. Obnova řízení podle správního řádu je přípustná pouze tehdy, bylo-li rozhodnutí stavebního úřadu dosaženo trestným činem.~~

#### § 309 — **Rozhodnutí o návrhu**  `[272 Čl.I/615]` {uc=B}

**(1) Soud přezkoumá pouze všechny přípustné žalobní nebo návrhové body. Nerozhodne- li soud bez jednání, sdělí před rozhodnutím účastníkům řízení svůj právní názor na věc a umožní jim na něj reagovat.** {uc=B}

**(2) Soud nezruší rozhodnutí ani opatření obecné povahy pouze pro nepřezkoumatelnost a přezkoumá je z hlediska zákonnosti jejich výroku, je-li to na základě správního spisu nebo doplnění podkladů nebo důvodů rozhodnutí v řízení před soudem možné; přitom vychází i z vyjádření žalovaného, odpůrce nebo dotčeného orgánu v řízení před soudem, kteří mohou chybějící podklady a důvody doplnit, k čemuž je soud vyzve. To platí i v případech, je-li žalobou napadeno rozhodnutí, které neobsahuje odůvodnění podle § 311 odst. 4 nebo které je založeno na závazném stanovisku bez odůvodnění podle § 178 odst. 1 nebo 2.** {uc=B}

**(3) O žalobách ve věcech vyhrazených staveb rozhodne soud ve lhůtě 90 dnů.** {uc=B}

**(4) Je-li žaloba důvodná a bez dalšího dokazování je zcela zřejmé, jak by v případě jeho zrušení a vrácení stavebnímu úřadu k dalšímu řízení musel stavební úřad rozhodnout nebo souhlasí-li s tím všichni účastníci řízení a taková změna by nemohla vést k zásahu do práv třetích osob ani k zásahu do veřejných zájmů, může soud rozsudkem napadené rozhodnutí změnit. Proti částem rozhodnutí stavebního úřadu, která byla změněna rozsudkem, není přípustné vést přezkumné řízení podle správního řádu.** {uc=B}

**(5) Soud nezruší napadené rozhodnutí nebo opatření obecné povahy a návrh zamítne, pokud by jeho zrušení představovalo pro jiné osoby nebo pro veřejný zájem nepoměrně větší újmu v porovnání s újmou vzniklou navrhovateli zamítnutím návrhu.** {uc=B}

**(6) Odstavce 1 až 5 platí obdobně i pro řízení o kasační stížnosti.** {uc=B}

#### § 310 — ~~Přezkum územního rozvojového plánu~~ **Příslušnost**  `[272 Čl.I/616; 272 Čl.I/617]` {uc=AB}

K řízení o zrušení územního rozvojového plánu nebo jeho části **a k řízení o zrušení územního opatření vydaného vládou** je příslušný Nejvyšší správní soud. {uc=AB}

### ČÁST DVANÁCTÁ

*USTANOVENÍ SPOLEČNÁ, PŘECHODNÁ A ZÁVĚREČNÁ*

#### HLAVA I

*SPOLEČNÁ USTANOVENÍ*

#### § 311 — ~~Vztah ke správnímu řádu~~  `[272 Čl.I/618; 272 Čl.I/619; 272 Čl.I/620; 272 Čl.I/621]` {uc=AB}

(1) K přezkumu opatření obecné povahy podle správního řádu vydaného ~~orgány obce~~ **obcí** je příslušný ~~krajský~~ úřad **rozvoje území kraje**. K přezkumu opatření obecné povahy podle správního řádu vydaného ~~orgány kraje~~ **krajem** je ~~příslušné ministerstvo~~ **příslušný Úřad**. {uc=A}

(2) Územně plánovací dokumentaci **ani územní opatření** nelze změnit rozhodnutím podle § 97 odst. 3 správního řádu. {uc=A}

(3) Územní rozvojový plán nebo územní opatření vydané vládou nelze přezkoumat v přezkumném řízení podle správního řádu.

**(4) Povolení vydané podle tohoto zákona jako první úkon stavebního úřadu v řízení obsahuje pouze výrok a poučení o opravném prostředku. Proti tomuto rozhodnutí není odvolání přípustné. Rozhodnutí lze přezkoumat v přezkumném řízení, které lze zahájit do 1 měsíce ode dne, kdy se stavební úřad o důvodu zahájení přezkumného řízení dozvěděl, nejpozději však do 2 měsíců od právní moci rozhodnutí. Rozhodnutí v přezkumném řízení v prvním stupni nelze vydat po uplynutí 3 měsíců od právní moci přezkoumávaného rozhodnutí.** {uc=AB}

**(5) Rozhodnutí nebo usnesení podle tohoto zákona, proti kterému se nelze odvolat, nabývá právní moci dnem doručení stavebníkovi nebo povinnému.** {uc=AB}

**(6) Na návrh účastníka nebo je-li to účelné, lze provést ústní jednání podle tohoto zákona s využitím technického zařízení pro přenos obrazu a zvuku (videokonferenční zařízení).** {uc=AB}

**(7) Nevyžaduje-li úkon správního orgánu podle tohoto zákona správní uvážení, lze jej provést automatizovaně bez účasti úřední osoby, pokud tím nebude ohrožena ochrana práv dotčených osob nebo ochrana veřejného zájmu. Místo údaje o úřední osobě se na úkonu podle věty první uvede, že byl proveden automatizovaně bez účasti úřední osoby, a její podpis se nahradí kvalifikovanou elektronickou pečetí.** {uc=AB}

**(8) Vede-li se spis nebo jeho část v elektronické podobě, předává se spis nebo jeho část všem orgánům výhradně v elektronické podobě.** {uc=AB}

**(9) Postoupení spisu není důvodem pro přerušení řízení o žádosti.** {uc=AB}

#### HLAVA II

*PŘECHODNÁ USTANOVENÍ*

##### Díl 1

*Přechodná ustanovení k úřadům a úředníkům*

#### § 312

(1) Na Dopravní a energetický stavební úřad přechází výkon práv a povinností ze služebního poměru a z pracovněprávních vztahů státních zaměstnanců a zaměstnanců v pracovním poměru, zařazených nebo jmenovaných na služební nebo pracovní místo v ministerstvech a jiných správních úřadech a zajišťujících podle dosavadních právních předpisů výkon úkolů a činností spadajících podle tohoto nebo jiného zákona do působnosti Dopravního a energetického stavebního úřadu. Přechodem státních zaměstnanců ve služebním poměru na dobu neurčitou podle tohoto odstavce platí, že úspěšně vykonali úřednickou zkoušku pro příslušný obor státní služby, v němž budou úkoly a činnosti vykonávat v Dopravním a energetickém stavebním úřadu.

(2) Podle odstavce 1 se však nepostupuje, pokud dotčení zaměstnanci zajišťují v ministerstvech a jiných správních úřadech v převažujícím rozsahu výkon úkolů a činností, které nespadají do působnosti Dopravního a energetického stavebního úřadu podle tohoto nebo jiného zákona.

(3) Práva a povinnosti z pracovního poměru zaměstnanců krajů zařazených k výkonu práce do krajských úřadů přecházejí z těchto krajů na stát v případech, kdy činnosti zajišťované těmito zaměstnanci přecházejí do působnosti Dopravního a energetického stavebního úřadu podle tohoto nebo jiného zákona. Obdobně se postupuje v případě zaměstnanců hlavního města Prahy.

(4) Podmínkou přechodu práv a povinností z pracovního poměru zaměstnanců podle odstavce 3 na stát je předchozí písemná dohoda mezi Dopravním a energetickým stavebním úřadem, zaměstnancem a územním samosprávným celkem.

(5) Dosavadní zaměstnanci krajů podle odstavce 3 se stávají zaměstnanci státu zařazenými k výkonu práce do Dopravního a energetického stavebního úřadu.

(6) Dosavadní zaměstnanci Magistrátu hlavního města Prahy podle odstavce 3 se stávají zaměstnanci státu zařazenými k výkonu práce do Dopravního a energetického stavebního úřadu.

(7) První systemizace služebních míst a první systemizace pracovních míst v Dopravním a energetickém stavebním úřadu se stanoví s účinností od 1. července 2023.

#### § 313

(1) Na služební místo ředitele sekce obsazené zaměstnancem podle § 312 odst. 5 a 6 vyhlásí služební orgán výběrové řízení nejpozději do 18 měsíců od účinnosti systemizace podle § 312 odst. 7. Na služební místo ředitele odboru a vedoucího oddělení obsazené zaměstnanci podle § 312 odst. 5 a 6 vyhlásí služební orgán výběrové řízení nejpozději do 24 měsíců od účinnosti systemizace podle § 312 odst. 7. K výběrovému řízení se mohou přihlásit státní zaměstnanci ve služebním poměru na dobu neurčitou, kteří vykonávají státní službu na služebním místě ve stejném oboru státní služby, který je stanoven pro služební místo představeného, které má být obsazeno. Osoba, která byla jmenována na služební místo představeného na dobu určitou, se po dobu 3 let od uplynutí této doby považuje za osobu splňující předpoklady pro účast ve výběrovém řízení na služební místo představeného na stejný nebo nižší stupeň řízení.

(2) Pro vznik služebního poměru zaměstnanců podle § 312 odst. 5 a 6 se použijí § 190 až 197, s výjimkou § 190 odst. 1 písm. d), § 191, 195a a 196 zákona o státní službě a dále § 200 a 201 zákona o státní službě obdobně s tím, že lhůty a doby tam stanovené se počítají ode dne nabytí účinnosti systemizace podle § 312 odst. 7. Ke dni vzniku služebního poměru rozhodne příslušný služební orgán o výši platu podle části deváté zákona o státní službě. Dnem vzniku služebního poměru těmto zaměstnancům platí, že úspěšně vykonali úřednickou zkoušku; služební orgán jim o tom vystaví osvědčení.

(3) Ztratí-li zaměstnanec podle odstavce 1 a § 312 odst. 5 a 6 přechodem funkci vedoucího zaměstnance, má po dobu 12 měsíců od vzniku služebního poměru nárok na výplatu zadostiučinění ve výši příplatku za vedení, která mu byla naposledy určena jako vedoucímu zaměstnanci, v pravidelných výplatních termínech. Pokud však byl dotčený zaměstnanec na základě výběrového řízení jmenován na služební místo představeného a začal opět pobírat příplatek za vedení ještě před uplynutím doby 12 měsíců od vzniku služebního poměru, vyplatí se mu zadostiučinění snížené o částku příplatku za vedení, který mu nově náleží.

(4) Kvalifikační požadavky pro výkon činnosti stavebního úřadu na úseku stavebního řádu podle § 30a splňuje úředník, který ke dni nabytí účinnosti tohoto zákona vykonává činnost obecného nebo speciálního stavebního úřadu a splňuje kvalifikační požadavky pro výkon činnosti na obecném nebo speciálním stavebním úřadu podle dosavadní právní úpravy.

#### § 314  `[272 Čl.I/623]` {uc=A}

Při provedení spisové rozluky v souvislosti s činnostmi, které přecházejí na orgány státní stavební správy podle tohoto nebo jiného zákona, se postupuje obdobně podle § 68a zákona č. 499/2004 Sb., o archivnictví a spisové službě a o změně některých zákonů, ve znění pozdějších předpisů. Nevyřízené dokumenty a neuzavřené spisy předají správní orgány, které vykonávaly působnost podle dosavadních **právních** předpisů, u vyhrazených staveb uvedených v příloze č. 3 k tomuto zákonu, staveb s nimi souvisejících a staveb tvořících s nimi soubor staveb do 1. února 2024, v ostatních případech do 1. srpna 2024. Ustanovení tohoto odstavce se nevztahuje na jiné stavební úřady. {uc=A}

#### § 315

(1) Příslušnost k hospodaření s majetkem státu užívaným organizačními složkami státu přechází ke dni nabytí účinnosti tohoto zákona na Dopravní a energetický stavební úřad, pokud byl tento majetek užíván výhradně k zajišťování úkolů a činností, které přecházejí podle tohoto nebo jiného zákona na Dopravní a energetický stavební úřad.

(2) Rozpočtované prostředky v rozpočtech organizačních složek, které souvisejí s výkonem působnosti, která ke dni nabytí účinnosti tohoto zákona přechází na Dopravní a energetický stavební úřad, se přesouvají ke dni nabytí účinnosti tohoto zákona na Dopravní a energetický stavební úřad.

(3) Nároky z nespotřebovaných výdajů vzniklé za roky předcházející roku nabytí účinnosti tohoto zákona, které souvisejí s výkonem působnosti, která ke dni nabytí účinnosti tohoto zákona přechází na Dopravní a energetický stavební úřad, se stávají ke dni nabytí účinnosti tohoto zákona nároky z nespotřebovaných výdajů Dopravního a energetického stavebního úřadu.

##### Díl 2

*Přechodná ustanovení k územnímu plánování*

#### § 316 — Obecná ustanovení  `[272 Čl.I/624]` {uc=A}

(1) Ústav územního rozvoje zřízený podle zákona č. 183/2006 Sb. se považuje za Ústav územního rozvoje zřízený podle tohoto zákona.

(2) Bylo-li přede dnem nabytí účinnosti tohoto zákona rozhodnuto o pořízení územního plánu, regulačního plánu, nebo jejich změny nebo vymezení zastavěného území, nebo zahájeno zpracování územní studie a pořizovatelem je obecní úřad podle § 6 odst. 2 zákona č. 183/2006 Sb. na základě smluvního vztahu s osobou splňující kvalifikační požadavky pro výkon územně plánovací činnosti podle dosavadních právních předpisů, pohlíží se na tuto osobu do doby vydání této územně plánovací dokumentace nebo vymezení zastavěného území jako na zástupce pořizovatele. Jedná-li se o územní studii, považuje se za rozhodný moment vložení dat o ní do evidence územně plánovací činnosti.

(3) Výjimka z kvalifikačních požadavků vzdělání udělená podle dosavadních právních předpisů se považuje za výjimku z kvalifikačních požadavků vzdělání udělenou podle tohoto zákona.

(4) Kvalifikační požadavky pro výkon územně plánovací činnosti splňuje státní zaměstnanec nebo úředník, který vykonává ke dni nabytí účinnosti tohoto zákona územně plánovací činnost na ministerstvu, krajském úřadu, úřadu územního plánování nebo na obecním úřadu podle § 6 odst. 2 zákona č. 183/2006 Sb. a má osvědčení **o** zvláštní odborné způsobilosti podle zvláštního právního předpisu vydané přede dnem 1. ledna 2007. {uc=A}

(5) Seznam oprávněných investorů, který vede příslušný krajský úřad podle § 23a zákona č. 183/2006 Sb., se považuje za seznam oprávněných investorů podle tohoto zákona. Ministerstvo ve spolupráci s příslušným krajským úřadem a Magistrátem hlavního města Prahy zajistí zveřejnění seznamu oprávněných investorů na národním geoportálu územního plánování do 6 měsíců ode dne nabytí účinnosti tohoto zákona.

#### § 317 — Územně plánovací podklady

(1) Územně analytické podklady pořízené přede dnem nabytí účinnosti tohoto zákona se považují za územně analytické podklady podle tohoto zákona.

(2) Území vymezená Ministerstvem obrany nebo Ministerstvem vnitra podle dřívějších právních předpisů v zájmu zajišťování obrany a bezpečnosti státu přede dnem nabytí účinnosti tohoto zákona se považují za vymezená území podle tohoto zákona do doby jejich nového vymezení postupem podle § 36.

(3) Údaje o urbanistických studiích, územních generelech a územních prognózách, které jsou ke dni nabytí účinnosti tohoto zákona uvedeny v evidenci územně plánovací činnosti, ministerstvo nebo jím pověřená organizační složka státu z této evidence vypustí do 3 měsíců po nabytí účinnosti tohoto zákona.

(4) Územní studie, o nichž byly údaje ke dni nabytí účinnosti tohoto zákona uvedeny v evidenci územně plánovací činnosti, se považují za územní studie podle tohoto zákona.

(5) U územních studií, o nichž byly údaje ke dni nabytí účinnosti tohoto zákona uvedeny v evidenci územně plánovací činnosti, běží lhůta pro prověření aktuálnosti jejich řešení ode dne nabytí účinnosti tohoto zákona a činí 4 roky.

(6) Činnosti při pořizování územně plánovacích podkladů ukončené přede dnem nabytí účinnosti tohoto zákona se posuzují podle dosavadních právních předpisů.

#### § 318 — Politika územního rozvoje a politika architektury a stavební kultury

(1) Politika územního rozvoje schválená přede dnem nabytí účinnosti tohoto zákona se považuje za politiku územního rozvoje podle tohoto zákona.

(2) Části politiky územního rozvoje schválené podle zákona č. 183/2006 Sb., které nemohou být podle tohoto zákona její součástí, se nepoužijí a při nejbližší změně musí být z politiky územního rozvoje vypuštěny; toto vypuštění nepodléhá posuzování vlivů na udržitelný rozvoj území. Vyhodnocení vlivů na udržitelný rozvoj území, které se vztahuje k původní politice územního rozvoje, se neupravuje.

(3) Bylo-li zahájeno pořizování zprávy o uplatňování politiky územního rozvoje přede dnem nabytí účinnosti tohoto zákona a nedošlo-li k předložení návrhu zprávy o uplatňování ke schválení vládě podle § 35 odst. 4 zákona č. 183/2006 Sb., dokončí se pořizování i předložení vládě podle dosavadních právních předpisů. Zpráva o uplatňování schválená vládou podle § 35 odst. 4 zákona č. 183/2006 Sb. se považuje za zprávu o plnění podle tohoto zákona a dále se postupuje podle tohoto zákona.

(4) Bylo-li zahájeno pořizování aktualizace politiky územního rozvoje přede dnem nabytí účinnosti tohoto zákona, a nedošlo-li k předložení návrhu ke schválení vládě podle § 34 zákona č. 183/2006 Sb., zajistí ministerstvo uvedení návrhu této aktualizace do souladu s tímto zákonem. V rozsahu provedených úprav se dále postupuje podle § 71b a 71c a § 71d odst. 1.

(5) Politika architektury a stavební kultury schválená přede dnem nabytí účinnosti tohoto zákona se považuje za politiku architektury a stavební kultury podle tohoto zákona.

#### § 319 — Územní rozvojový plán

(1) Ministerstvo pořídí první územní rozvojový plán, který bude obsahovat pouze nadregionální územní systém ekologické stability vymezený v zásadách územního rozvoje, u kterého marně uplynula lhůta pro přezkum podle správního řádu a soudního řádu správního, a záměry dopravní a technické infrastruktury vymezené v zásadách územního rozvoje a obsažené v politice územního rozvoje, které dosud nebyly dokončeny a u kterých marně uplynula lhůta pro přezkum podle správního řádu a soudního řádu správního.

(2) Vymezení záměrů podle odstavce 1 převezme ministerstvo ze zásad územního rozvoje tak, že textová část vymezení záměru bude obsahovat pouze výčet obcí dotčených tímto záměrem bez stanovení podmínek pro rozhodování v území, pořadí změn v území a kompenzační opatření podle § 100 odst. 4 tohoto zákona.

(3) Záměry přebírané do prvního územního rozvojového plánu podle odstavce 1 nepodléhají projednání a posuzování vlivů na udržitelný rozvoj území podle § 40 tohoto zákona. Soulad s politikou územního rozvoje se neposuzuje.

(4) Dotčenými orgány při pořizování územního rozvojového plánu podle tohoto přechodného ustanovení jsou pouze Ministerstvo dopravy, Ministerstvo průmyslu a obchodu a Ministerstvo zemědělství, které mohou záměry podle odstavce 1 vyloučit.

(5) Pro první územní rozvojový plán se § 73 odst. 2 a 3 tohoto zákona nepoužije do doby vydání změny, která jej uvede do souladu s požadavky podle tohoto zákona.

#### § 320 — Zásady územního rozvoje

(1) Zásady územního rozvoje vydané podle dosavadních právních předpisů se považují za zásady územního rozvoje podle tohoto zákona. Při nejbližší změně, jejíž pořizování bude zahájeno po dni nabytí účinnosti tohoto zákona, se zásady územního rozvoje uvedou do souladu s ustanoveními tohoto zákona o obsahu zásad územního rozvoje.

(2) Do doby uvedení zásad územního rozvoje do souladu s ustanoveními tohoto zákona o obsahu zásad územního rozvoje nejsou záměry na změny v území obsažené v zásadách územního rozvoje, které jsou v rozporu s územním rozvojovým plánem, závazné pro pořizování územně plánovací dokumentace obcí a pro rozhodování v území.

#### § 321 — Územní plán a regulační plán

(1) Územní plány vydané podle dosavadních právních předpisů se považují za územní plány podle tohoto zákona.

(2) Regulační plány vydané od 1. ledna 2007 do dne nabytí účinnosti tohoto zákona se považují za regulační plány vydané podle tohoto zákona.

(3) Při nejbližší změně regulačních plánů, jejíž pořizování bude zahájeno po dni nabytí účinnosti tohoto zákona, se tyto regulační plány uvedou do souladu s ustanoveními tohoto zákona o obsahu regulačního plánu.

(4) Regulační plán pořízený na žádost přede dnem nabytí účinnosti tohoto zákona se po dobu jeho platnosti, nejdéle však do 31. prosince 2025, považuje za regulační plán vydaný podle tohoto zákona. Jeho změny lze pořizovat pouze na podnět toho, komu přísluší vykonávat práva z něj vyplývající.

#### § 322 — Územně plánovací dokumentace schválené přede dnem 1. ledna 2007  `[272 Čl.I/625]` {uc=A}

(1) Územně plánovací dokumentace sídelního útvaru nebo zóny, územní plán obce a regulační plán, schválené přede dnem 1. ledna 2007, pozbývají platnosti dnem nabytí účinnosti nové územně plánovací dokumentace, která je nahrazuje, nejpozději však 31. prosince 2028. Obecně závazné vyhlášky, jimiž byla vymezena závazná část této územně plánovací dokumentace, se považují za opatření obecné povahy, které je závazné pro navazující územně plánovací dokumentaci a pro rozhodování v území. Části územně plánovací dokumentace schválené přede dnem 1. ledna 2007, které nemohou být podle tohoto zákona její součástí, se nepoužijí.

(2) Zastupitelstvo obce může opatřením obecné povahy ukončit platnost územně plánovací dokumentace sídelního útvaru nebo zóny, územního plánu obce a regulačního plánu, schválených přede dnem 1. ledna 2007. Pro vydání opatření obecné povahy podle věty první se použije § 113 odst. 2 až 6 **ve znění účinném do 31. prosince 2026** obdobně. {uc=A}

(3) U územně plánovací dokumentace sídelního útvaru nebo zóny, územního plánu obce a regulačního plánu, byly-li schváleny přede dnem 1. ledna 2007, lze změnu vydat do 31. prosince 2028, jinak se pořizování zastaví.

(4) Rozhodne-li zastupitelstvo obce přede dnem nabytí účinnosti tohoto zákona o pořízení změny územně plánovací dokumentace sídelního útvaru nebo zóny, územního plánu obce a regulačního plánu, byly-li schváleny přede dnem 1. ledna 2007, a současně již bylo zastupitelstvem obce rozhodnuto o pořízení nového územního plánu nebo regulačního plánu, dokončí se pořizování této změny podle dosavadních právních předpisů. Požadavky na jednotný standard podle § 20a zákona č. 183/2006 Sb. se neuplatní.

(5) Územně plánovací dokumentaci sídelního útvaru nebo zóny, územní plán obce a regulační plán, byly-li schváleny přede dnem 1. ledna 2007, nelze upravit podle § 188 odst. 1 zákona č. 183/2006 Sb. a v rozsahu těchto úprav projednat a vydat, nebylo-li zahájeno společné jednání přede dnem nabytí účinnosti tohoto zákona; bylo-li přede dnem nabytí účinnosti tohoto zákona při pořizování úpravy podle § 188 odst. 1 zákona č. 183/2006 Sb. zahájeno společné jednání, dokončí se pořizování podle dosavadních právních předpisů. Takto upravenou dokumentaci lze vydat do 31. prosince 2025, jinak se pořizování zastaví.

#### § 323 — Pořizování územně plánovací dokumentace

(1) Činnosti při pořizování územně plánovací dokumentace ukončené přede dnem nabytí účinnosti tohoto zákona se posuzují podle dosavadních právních předpisů.

(2) Bylo-li ke dni nabytí účinnosti tohoto zákona zahájeno projednání zprávy o uplatňování zásad územního rozvoje nebo územního plánu, dokončí se její projednání a schválení podle dosavadních právních předpisů. Obsahuje-li zpráva pokyny pro zpracování nové územně plánovací dokumentace nebo její aktualizace nebo změny, považují se tyto pokyny za zadání změny podle tohoto zákona; požadavky obsažené v pokynech, které jsou v rozporu s tímto zákonem, se nepoužijí.

(3) Bylo-li ke dni nabytí účinnosti tohoto zákona zahájeno projednání zadání územního plánu, regulačního plánu nebo jejich změny, dokončí se projednání a schválení zadání podle dosavadních právních předpisů a toto zadání se považuje za zadání územního plánu, regulačního plánu, nebo za zadání změny podle tohoto zákona; požadavky, které jsou v rozporu s tímto zákonem, se nepoužijí.

(4) Zadání územně plánovací dokumentace nebo její změny, schválené přede dnem nabytí účinnosti tohoto zákona, se považuje za zadání územně plánovací dokumentace nebo její změny podle tohoto zákona; požadavky, které jsou v rozporu s tímto zákonem, se nepoužijí.

(5) Obsah změny územně plánovací dokumentace obce schválený zastupitelstvem obce současně s rozhodnutím o pořízení její změny zkráceným postupem se považuje za zadání změny podle tohoto zákona; požadavky, které jsou v rozporu s tímto zákonem, se nepoužijí.

(6) Pořizovatel zajistí úpravu návrhu územně plánovací dokumentace, u kterého nebylo zahájeno projednání ke dni nabytí účinnosti tohoto zákona, v souladu s tímto zákonem.

(7) Bylo-li přede dnem nabytí účinnosti tohoto zákona zahájeno projednávání návrhu územního rozvojového plánu, jeho aktualizace, nebo aktualizace zásad územního rozvoje, dokončí se podle dosavadních právních předpisů.

(8) Bylo-li přede dnem nabytí účinnosti tohoto zákona zahájeno společné jednání o návrhu územního plánu nebo jeho změny nebo regulačního plánu nebo jeho změny, dokončí se činnosti zakončené úpravou návrhu po společném jednání podle dosavadních právních předpisů. Při úpravě se zajistí soulad obsahu uvedené územně plánovací dokumentace s tímto zákonem. Veřejné projednání se bez nového projednávání vyhodnocení vlivů uskuteční v rozsahu vyžadovaném tímto zákonem. Dotčené orgány uplatní stanoviska k částem, které byly od společného jednání změněny.

(9) Bylo-li přede dnem nabytí účinnosti tohoto zákona zahájeno veřejné projednání nebo opakované veřejné projednání návrhu územního plánu nebo jeho změny nebo regulačního plánu nebo jeho změny, dokončí se podle dosavadních právních předpisů.

(10) Jde-li o návrh nového územního plánu a postupuje-li se podle odstavce 9, lze v tomto návrhu vymezit plochu nebo koridor, v němž je rozhodování v území podmíněno uzavřením plánovací smlouvy podle § 130. Ustanovení § 81 odst. 3 se použije obdobně. V takovém případě jde o podstatnou úpravu, pro kterou se § 53 odst. 2 zákona č. 183/2006 Sb. použije obdobně.

#### § 324 — Nepoužití některých částí územně plánovací dokumentace  `[272 Čl.I/627]` {uc=A}

Části územně plánovací dokumentace vydané podle zákona č. 183/2006 Sb., které nemohou být podle tohoto zákona její součástí, se nepoužijí a při nejbližší změně musí být z této dokumentace vypuštěny; toto vypuštění nepodléhá posuzování vlivů na udržitelný rozvoj území. Vyhodnocení vlivů, které se vztahuje k původní územně plánovací dokumentaci, se neupravuje.

**(1) Podmínka vydání regulačního plánu na žádost vymezená v územně plánovací dokumentaci podle dosavadních právních předpisů se považuje za podmínku vydání regulačního plánu podle tohoto zákona a pozbývá platnosti marným uplynutím lhůty 6 let od nabytí účinnosti územního plánu, který tuto podmínku vymezil.** {uc=A}

#### § 325 — Zastavěné území

(1) Úřad územního plánování pořídí a vydá vymezení zastavěného území postupem podle tohoto zákona pro obec, která nemá územní plán nebo vymezené zastavěné území, do 2 let ode dne nabytí účinnosti tohoto zákona. Věta první se nepoužije v případě obcí, ve kterých před nabytím účinnosti tohoto zákona rozhodlo zastupitelstvo obce o pořízení územního plánu.

(2) Do doby vymezení zastavěného území územním plánem nebo postupem podle tohoto zákona se u obce, která nemá územní plán nebo vymezené zastavěné území, považuje za zastavěné území intravilán.

(3) Zastavěné území vymezené územním plánem se při nejbližší změně územního plánu, jejíž pořizování bude zahájeno po dni nabytí účinnosti tohoto zákona, upraví v souladu s tímto zákonem; do nabytí účinnosti této změny se zastavěné území vymezené v územním plánu považuje za zastavěné území vymezené podle tohoto zákona.

(4) Zastavěné území vymezené na území obce, která nemá územní plán, úřad územního plánování vyhodnotí a v případě potřeby pořídí a vydá jeho změnu podle § 121 nejpozději do 2 let ode dne nabytí účinnosti tohoto zákona. Do té doby se zastavěné území vymezené podle dosavadních právních předpisů považuje za zastavěné území podle tohoto zákona.

(5) Dojde-li k pozbytí účinnosti územně plánovací dokumentace sídelního útvaru nebo zóny, územního plánu obce nebo regulačního plánu marným uplynutím lhůty podle § 322 odst. 1, považuje se současně zastavěné území obce nebo zastavěné území obce vymezené touto územně plánovací dokumentaci sídelního útvaru nebo zóny, územním plánu obce nebo regulačním plánu za zastavěné území obce vymezené podle tohoto zákona. Úřad územního plánování ve lhůtě 3 měsíců vyhodnotí aktuálnost vymezení zastavěného území a případně zajistí jeho aktualizaci postupem podle tohoto zákona.

#### § 326 — Územní opatření

(1) Stavební uzávěry vydané podle zákona č. 50/1976 Sb. z důvodu zamezení možnosti ztížení nebo znemožnění budoucího využití území podle připravované územně plánovací dokumentace pozbývají platnosti dnem nabytí účinnosti tohoto ustanovení.

(2) Stavební uzávěry vydané přede dnem nabytí účinnosti tohoto zákona, nejde-li o stavební uzávěry podle odstavce 1, prověří příslušný úřad územního plánování z hlediska jejich aktuálnosti a souladu s požadavky tohoto zákona nejpozději do 1 roku ode dne nabytí jeho účinnosti a informaci o prověření vloží do národního geoportálu územního plánování, jinak pozbývají platnosti; nejsou-li splněny požadavky na aktuálnost a soulad s tímto zákonem a neuplynula-li lhůta 1 roku, postupuje se podle § 123 odst. 4. Ustanovení § 123 odst. 3 se na stavební uzávěry vydané přede dnem nabytí účinnosti tohoto zákona použije obdobně.

(3) Obsahují-li územní opatření o stavební uzávěře omezení, která nejsou v souladu s požadavky tohoto zákona, ode dne nabytí účinnosti tohoto zákona se k těmto omezením při rozhodování nepřihlíží.

(4) Výjimku z omezení nebo zákazu stavební činnosti podle § 99 odst. 3 zákona č. 183/2006 Sb. povoluje po dni nabytí účinnosti tohoto zákona rada obce, a v obcích, kde se rada nevolí, zastupitelstvo obce, nebo rada kraje postupem podle § 129.

(5) Bylo-li přede dnem nabytí účinnosti tohoto zákona zahájeno pořizování územního opatření o stavební uzávěře nebo územního opatření o asanaci území, dokončí se podle dosavadních právních předpisů. Ustanovení § 123 odst. 3 se použije obdobně.

#### § 327 — Úprava vztahů k území

(1) Plánovací smlouvy uzavřené podle zákona č. 183/2006 Sb. se posuzují podle dosavadních právních předpisů.

(2) Předkupní právo vymezené v územně plánovací dokumentaci podle dosavadních právních předpisů zaniká účinností změny územního plánu, kterou bylo jeho vymezení vypuštěno nebo nahrazeno vymezením veřejně prospěšné stavby nebo veřejně prospěšného opatření, pro které lze práva k pozemkům vyvlastnit, nejpozději však uplynutím 4 let ode dne nabytí účinnosti tohoto zákona. Po zániku předkupního práva zajistí osoba oprávněná z předkupního práva jeho výmaz z katastru nemovitostí. Listinou, na jejímž základě má být právo z katastru nemovitostí vymazáno, je potvrzení o zániku práva podle katastrální vyhlášky.

(3) Dohody o parcelaci uzavřené podle dosavadních právních předpisů zůstávají v platnosti a lze je měnit nebo zrušit jen se souhlasem všech, kterým přísluší vykonávat práva a povinnosti z dohody vyplývající.

#### § 328 — Řízení o návrhu na zrušení opatření obecné povahy nebo jeho části

Řízení o návrhu na zrušení opatření obecné povahy nebo jeho části zahájená přede dnem nabytí účinnosti tohoto zákona se dokončí podle dosavadních právních předpisů.

##### Díl 3

*Přechodné ustanovení k dokumentacím a projektovým dokumentacím*

#### § 329

(1) Jako součást žádosti o povolení stavby nebo o rámcové povolení podané do 30. června 2027 lze namísto projektové dokumentace zpracované podle tohoto zákona předložit i dokumentaci zpracovanou podle dosavadních právních předpisů, jde-li o

a) projektovou dokumentaci nebo dokumentaci pro ohlášení stavby,

b) dokumentaci pro vydání rozhodnutí o umístění stavby, doplněnou o architektonicko-stavební řešení a stavebně konstrukční řešení zpracované podle prováděcího právního předpisu k tomuto zákonu,

c) dokumentaci pro vydání rozhodnutí o umístění souboru staveb v areálu jaderného zařízení,

d) projektovou dokumentaci pro vydání stavebního povolení nebo dokumentaci pro vydání společného povolení, nebo

e) dokumentaci pro vydání společného povolení, kterým se umisťuje a povoluje stavba dopravní infrastruktury podle liniového zákona, zpracovanou v omezeném rozsahu.

(2) Jako součást žádosti o povolení změny využití území podané do 30. června 2027 lze namísto projektové dokumentace zpracované podle tohoto zákona také předložit dokumentaci pro vydání rozhodnutí o změně využití území zpracovanou podle dosavadních právních předpisů.

(3) Bude-li provádění stavby zahájeno do 30. června 2027, lze jako dokumentaci pro provádění stavby podle tohoto zákona použít dokumentaci pro provádění stavby zpracovanou podle dosavadních právních předpisů.

(4) Jako součást žádosti o povolení odstranění stavby podané do 30. června 2027 lze namísto projektové dokumentace zpracované podle tohoto zákona předložit také dokumentaci bouracích prací zpracovanou podle dosavadních právních předpisů.

(5) Stavební úřad v řízení podle tohoto zákona přezkoumává dokumentaci podle odstavců 1 až 4 podle dosavadních právních předpisů.

##### Díl 4

*Přechodná ustanovení ke stavebnímu řádu*

#### § 330  `[272 Čl.I/628; 272 Čl.I/629]` {uc=A}

(1) Řízení a postupy zahájené přede dnem nabytí účinnosti tohoto zákona se dokončí podle dosavadních právních předpisů.

(2) Řízení a postupy zahájené přede dnem nabytí účinnosti tohoto zákona, které se týkají záměrů, u nichž není vyžadováno povolení záměru, jiné rozhodnutí nebo úkon podle tohoto zákona, stavební úřad usnesením zastaví; proti tomuto usnesení se nelze odvolat.

(3) Řízení a postupy zahájené přede dnem nabytí účinnosti tohoto zákona dokončí stavební úřad, který se stal příslušným k vedení řízení nebo provedení postupu v dané věci podle tohoto zákona. Územní řízení zahájené přede dnem nabytí účinnosti tohoto zákona týkající se vyhrazené stavby uvedené v příloze č. 3 k tomuto zákonu nebo stavby s ní související dokončí stavební úřad, který toto řízení vedl přede dnem nabytí účinnosti tohoto zákona. Stavební řízení zahájené přede dnem nabytí účinnosti tohoto zákona týkající se stavby související s vyhrazenou stavbou uvedenou v příloze č. 3 k tomuto zákonu dokončí stavební úřad, který toto řízení vedl přede dnem nabytí účinnosti tohoto zákona. Společné územní a stavební řízení zahájené přede dnem nabytí účinnosti tohoto zákona týkající se stavby související s vyhrazenou stavbou uvedenou v příloze č. 3 k tomuto zákonu dokončí stavební úřad, který se stal podle tohoto zákona příslušným k vedení řízení o povolení vyhrazené stavby uvedené v příloze č. 3 k tomuto zákonu, je-li vyhrazená stavba stavbou hlavní, v ostatních případech dokončí řízení stavební úřad, který toto řízení vedl přede dnem nabytí účinnosti tohoto zákona.

(4) Změnu záměru před dokončením povolí a kolaudační řízení provede u záměrů povolených přede dnem nabytí účinnosti tohoto zákona stavební úřad, na který přešla působnost k povolení záměru podle tohoto zákona. Jde-li o stavbu související s vyhrazenou stavbou uvedenou v příloze č. 3 k tomuto zákonu, změnu záměru před dokončením povolí a kolaudační řízení provede stavební úřad, který tuto stavbu povolil.

(5) U řízení zahájených podle tohoto zákona do konce kalendářního roku, ve kterém tento zákon nabyl účinnosti, se lhůty pro vydání rozhodnutí podle tohoto zákona prodlužují na dvojnásobek.

(6) Pravomocné územní rozhodnutí o umístění stavby vydané v územním řízení, v územním řízení s posouzením vlivů na životní prostředí anebo ve zjednodušeném územním řízení, účinný územní souhlas, účinná veřejnoprávní smlouva a vydaný regulační plán nahrazující územní rozhodnutí o umístění stavby se považují za rozhodnutí v části věci v řízení o povolení záměru podle tohoto zákona, pokud jimi byl umístěn záměr vyžadující povolení podle tohoto zákona. Pravomocné územní rozhodnutí o umístění stavby vydané v územním řízení anebo ve zjednodušeném územním řízení a účinný územní souhlas a účinná veřejnoprávní smlouva nahrazující územní rozhodnutí o umístění stavby se považují za povolení podle tohoto zákona, pokud tyto záměry nevyžadovaly podle dosavadních právních předpisů stavební povolení nebo ohlášení. **Pokud o to stavebník požádá, lze o změně takového pravomocného územního rozhodnutí o umístění stavby vydaného v územním řízení, v územním řízení s posouzením vlivů na životní prostředí anebo ve zjednodušeném územním řízení, účinného územního souhlasu, účinné veřejnoprávní smlouvy a vydaného regulačního plánu nahrazujícího územní rozhodnutí o umístění stavby rozhodnout v rámci řízení o povolení záměru, jeho části či etapy podle tohoto zákona. V takovém případě stavebník předloží společnou žádost o vydání rozhodnutí o změně územního rozhodnutí a povolení záměru a dokumentaci pro povolení záměru, která navíc obsahuje popis změn provedených proti pravomocnému územnímu rozhodnutí o umístění stavby, účinnému územnímu souhlasu, účinné veřejnoprávní smlouvě a vydanému regulačnímu plánu nahrazujícímu územní rozhodnutí o umístění stavby.** {uc=A}

(7) Účinný společný územní souhlas, souhlas s provedením ohlášeného stavebního záměru, pravomocné stavební povolení, společné povolení, společné povolení s posouzením vlivů na životní prostředí, oznámení s certifikátem stavebního inspektora stavebního záměru a účinná veřejnoprávní smlouva nahrazující stavební povolení a účinná veřejnoprávní smlouva nahrazující stavební územní rozhodnutí a stavební povolení se považují za povolení záměru podle tohoto zákona.

(8) Pravomocné územní rozhodnutí o změně využití území se považuje za rozhodnutí v části věci v řízení o povolení záměru podle tohoto zákona, pokud jím byl umístěn záměr vyžadující povolení podle tohoto zákona; v opačném případě se považuje za povolení podle tohoto zákona. Územní rozhodnutí o dělení nebo scelování pozemků nebo územní rozhodnutí o ochranném pásmu se považují za rozhodnutí o povolení nestavebního záměru podle tohoto zákona.

(9) Závazná stanoviska, stanoviska, souhlasy, popřípadě rozhodnutí dotčených orgánů, stanoviska vlastníků veřejné dopravní nebo technické infrastruktury a jiná vyjádření vydaná přede dnem nabytí účinnosti tohoto zákona se považují za podklady pro vydání rozhodnutí v řízeních podle tohoto zákona. Tyto podklady stavební úřad nepřezkoumává a jimi chráněné veřejné zájmy znovu neposuzuje. V řízeních o opravných prostředcích, jakož i při dalších postupech souvisejících s přezkumem správnosti a zákonnosti nebo změnou závazného stanoviska orgánu územního plánování podle § 96b zákona č. 183/2006 Sb. se postupuje podle dosavadních právních předpisů.

(10) Kolaudační souhlas se považuje za kolaudační rozhodnutí podle tohoto zákona.

(11) Osoba, která vykonávala činnost autorizovaného inspektora ke dni 31. prosince 2023, je oprávněna vykonávat činnost podle tohoto zákona do doby, která končí uplynutím 10 let ode dne jmenování ministrem pro místní rozvoj, nebo do doby prodloužené**, a pokud splní požadavky podle § 277 odst**. **1 písm. e).** {uc=A}

#### § 331 — Soudní řízení

Soudní řízení zahájená přede dnem nabytí účinnosti tohoto zákona se dokončí podle dosavadních právních předpisů.

##### Díl 5

*Přechodné ustanovení k obecným stavebním úřadům*

#### § 332

(1) Obecní úřady, které nebudou vykonávat působnost obecního stavebního úřadu podle tohoto zákona, jsou povinny předat nejpozději do 30 dnů od ukončení činnosti stavebního úřadu veškeré doklady týkající se neukončených správních řízení a jiných postupů vedených podle zákona č. 183/2006 Sb., o územním plánování a stavebním řádu, ve znění pozdějších předpisů, stavebním úřadům, na která přešla působnost podle tohoto zákona, a o předání sepsat protokol.

(2) Při provedení spisové rozluky v souvislosti s ukončením činnosti stavebního úřadu se postupuje obdobně podle § 68a zákona č. 499/2004 Sb., o archivnictví a spisové službě a o změně některých zákonů, ve znění pozdějších předpisů.

##### Díl 6

*Přechodné ustanovení k prováděcím právním předpisům*

#### § 332a

Do doby vydání prováděcích právních předpisů podle § 152 tohoto zákona, nejpozději však do 1. července 2027, se postupuje podle prováděcích právních předpisů k provedení § 194 zákona č. 183/2006 Sb., ve znění účinném ke dni předcházejícímu jejich zrušení tímto zákonem. Části prováděcích právních předpisů podle věty první, které jsou v rozporu s tímto zákonem, se nepoužijí.

#### HLAVA III

*ZMOCŇOVACÍ USTANOVENÍ*

#### § 333  `[272 Čl.I/630; 272 Čl.I/631]` {uc=A}

(1) ~~Ministerstvo~~ **Vláda** vydá ~~vyhlášky~~ **nařízení** k provedení § ~~18~~ **36** odst. ~~4~~ **5**, § ~~30 odst. 3 a 4, § 59 odst. 4, § 62 odst. 3, § 64~~ **152** odst. 1, § ~~66 odst. 3, § 87 odst. 4, § 109 odst. 4, § 152~~ **152a** odst. 1, § 154 odst. 2, § 158 odst. ~~5~~ **6**, § 161 odst. 4, § 166 odst. 4, § 167 **odst. 1** písm. e), f), j) a k)~~,~~ **a** § 169 odst. 2~~, § 172 odst~~. ~~2, § 227 odst~~ **Návrh nařízení vlády podle věty první připravuje a předkládá vládě Úřad ve spolupráci s dotčenými ministerstvy**. ~~5, § 267 odst. 5, § 268 odst. 3, § 269 odst. 7, § 270 odst. 3, § 271 odst. 4, § 273 odst. 3, § 278, § 285 odst. 4 a § 292 odst. 5.~~ {uc=A}

(2) ~~Ministerstvo dopravy~~ **Úřad** vydá ~~vyhlášku~~ **vyhlášky** k provedení § ~~17~~ **12 písm. p), § 59** odst. 3, § ~~152~~ **62 odst. 3, § 64** odst. 1 ~~a § 158 odst. 5~~, ~~kterou stanoví technické požadavky na stavby dálnic, silnic, místních komunikací a veřejně přístupných účelových komunikací, stavby drah a civilní letecké stavby a rozsah a obsah projektové dokumentace k těmto stavbám.~~ {uc=A}

**§ 87 odst. 4, 103 odst. 1, § 172 odst. 2, § 227 odst. 5, § 267 odst. 5, § 268 odst. 4, § 269 odst. 6,**

**§ 270 odst. 3, § 271 odst. 4, § 273 odst. 3, § 278, § 285 odst. 4 a § 292 odst. 5.**

(3) Hlavní město Praha **a obce**, ~~statutární město Brno a statutární město Ostrava~~ **ve kterých je sídlo kraje (krajská města),** mohou v přenesené působnosti vydat nařízení k provedení § 152 odst. 2 **a § 152a odst**. **1.** {uc=A}

#### HLAVA IV

*ZÁVĚREČNÉ USTANOVENÍ*

#### § 334

Zrušují se:

1. Zákon č. 183/2006 Sb., o územním plánování a stavebním řádu (stavební zákon).

2. Zákon č. 68/2007 Sb., kterým se mění zákon č. 183/2006 Sb., o územním plánování a stavebním řádu (stavební zákon).

3. Zákon č. 191/2008 Sb., kterým se mění zákon č. 183/2006 Sb., o územním plánování a stavebním řádu (stavební zákon), ve znění zákona č. 68/2007 Sb.

4. Část třicátá čtvrtá zákona č. 223/2009 Sb., kterým se mění některé zákony v souvislosti s přijetím zákona o volném pohybu služeb.

5. Zákon č. 345/2009 Sb., kterým se mění zákon č. 72/1994 Sb., kterým se upravují některé spoluvlastnické vztahy k budovám a některé vlastnické vztahy k bytům a nebytovým prostorům a doplňují některé zákony (zákon o vlastnictví bytů), ve znění pozdějších předpisů, a zákon č. 183/2006 Sb., o územním plánování a stavebním řádu (stavební zákon), ve znění pozdějších předpisů.

6. Zákon č. 379/2009 Sb., kterým se mění zákon č. 183/2006 Sb., o územním plánování a stavebním řádu (stavební zákon), ve znění pozdějších předpisů.

7. Část sto osmdesátá zákona č. 227/2009 Sb., kterým se mění některé zákony v souvislosti s přijetím zákona o základních registrech.

8. Část sedmnáctá zákona č. 424/2010 Sb., kterým se mění zákon č. 111/2009 Sb., o základních registrech, ve znění zákona č. 100/2010 Sb., a další související zákony.

9. Část sto sedmdesátá druhá zákona č. 281/2009 Sb., kterým se mění některé zákony v souvislosti s přijetím daňového řádu.

10. Část čtyřicátá první zákona č. 420/2011 Sb., o změně některých zákonů v souvislosti s přijetím zákona o trestní odpovědnosti právnických osob a řízení proti nim.

11. Část dvacátá sedmá zákona č. 142/2012 Sb., o změně některých zákonů v souvislosti se zavedením základních registrů.

12. Část třicátá druhá zákona č. 167/2012 Sb., kterým se mění zákon č. 499/2004 Sb., o archivnictví a spisové službě a o změně některých zákonů, ve znění pozdějších předpisů, zákon č. 227/2000 Sb., o elektronickém podpisu a o změně některých dalších zákonů (zákon o elektronickém podpisu), ve znění pozdějších předpisů, a další související zákony.

13. Část první zákona č. 350/2012 Sb., kterým se mění zákon č. 183/2006 Sb., o územním plánování a stavebním řádu (stavební zákon), ve znění pozdějších předpisů, a některé související zákony.

14. Část šestá zákona č. 257/2013 Sb., kterým se mění některé zákony v souvislosti s přijetím zákona o katastru nemovitostí.

15. Část čtvrtá zákona č. 39/2015 Sb., kterým se mění zákon č. 100/2001 Sb., o posuzování vlivů na životní prostředí a o změně některých souvisejících zákonů (zákon o posuzování vlivů na životní prostředí), ve znění pozdějších předpisů, a další související zákony.

16. Část čtvrtá zákona č. 91/2016 Sb., kterým se mění zákon č. 22/1997 Sb., o technických požadavcích na výrobky a o změně a doplnění některých zákonů, ve znění pozdějších předpisů, a některé další zákony.

17. Část čtyřicátá devátá zákona č. 298/2016 Sb., kterým se mění některé zákony v souvislosti s přijetím zákona o službách vytvářejících důvěru pro elektronické transakce, zákon č. 106/1999 Sb., o svobodném přístupu k informacím, ve znění pozdějších předpisů, a zákon č. 121/2000 Sb., o právu autorském, o právech souvisejících s právem autorským a o změně některých zákonů (autorský zákon), ve znění pozdějších předpisů.

18. Část desátá zákona č. 264/2016 Sb., kterým se mění některé zákony v souvislosti s přijetím atomového zákona.

19. Část sto sedmdesátá pátá zákona č. 183/2017 Sb., kterým se mění některé zákony v souvislosti s přijetím zákona o odpovědnosti za přestupky a řízení o nich a zákona o některých přestupcích.

20. Část čtvrtá zákona č. 194/2017 Sb., o opatřeních ke snížení nákladů na zavádění vysokorychlostních sítí elektronických komunikací a o změně některých souvisejících zákonů.

21. Část devátá zákona č. 205/2017 Sb., kterým se mění zákon č. 181/2014 Sb., o kybernetické bezpečnosti a o změně souvisejících zákonů (zákon o kybernetické bezpečnosti), ve znění zákona č. 104/2017 Sb., a některé další zákony.

22. Část devátá zákona č. 193/2017 Sb., kterým se mění zákon č. 256/2001 Sb., o pohřebnictví a o změně některých zákonů, ve znění pozdějších předpisů, a další související zákony.

23. Část první zákona č. 225/2017 Sb., kterým se mění zákon č. 183/2006 Sb., o územním plánování a stavebním řádu (stavební zákon), ve znění pozdějších předpisů, a další související zákony.

24. Část pátá zákona č. 169/2018 Sb., kterým se mění zákon č. 416/2009 Sb., o urychlení výstavby dopravní, vodní a energetické infrastruktury a infrastruktury elektronických komunikací, ve znění pozdějších předpisů, a další související zákony.

25. Část padesátá čtvrtá zákona č. 277/2019 Sb., kterým se mění některé zákony v souvislosti s přijetím zákona o Sbírce zákonů a mezinárodních smluv.

26. Část první zákona č. 312/2019 Sb., kterým se mění zákon č. 183/2006 Sb., o územním plánování a stavebním řádu (stavební zákon), ve znění pozdějších předpisů, a zákon č. 254/2001 Sb., o vodách a o změně některých zákonů (vodní zákon), ve znění pozdějších předpisů.

27. Část druhá zákona č. 47/2020 Sb., kterým se mění zákon č. 200/1994 Sb., o zeměměřictví a o změně a doplnění některých zákonů souvisejících s jeho zavedením, ve znění pozdějších předpisů, zákon č. 183/2006 Sb., o územním plánování a stavebním řádu (stavební zákon), ve znění pozdějších předpisů, a další související zákony.

28. Část dvacátá první zákona č. 403/2020 Sb., kterým se mění zákon č. 416/2009 Sb., o urychlení výstavby dopravní, vodní a energetické infrastruktury a infrastruktury elektronických komunikací, ve znění pozdějších předpisů, a další související zákony.

29. Část sto dvacátá šestá zákona č. 261/2021 Sb., kterým se mění některé zákony v souvislosti s další elektronizací postupů orgánů veřejné moci.

30. Část druhá zákona č. 19/2023 Sb., kterým se mění zákon č. 458/2000 Sb., o podmínkách podnikání a o výkonu státní správy v energetických odvětvích a o změně některých zákonů (energetický zákon), ve znění pozdějších předpisů, a další související zákony.

31. Vyhláška č. 590/2002 Sb., o technických požadavcích pro vodní díla.

32. Vyhláška č. 367/2005 Sb., kterou se mění vyhláška č. 590/2002 Sb., o technických požadavcích pro vodní díla.

33. Vyhláška č. 498/2006 Sb., o autorizovaných inspektorech.

34. Vyhláška č. 499/2006 Sb., o dokumentaci staveb.

35. Vyhláška č. 62/2013 Sb., kterou se mění vyhláška č. 499/2006 Sb., o dokumentaci staveb.

36. Část první vyhlášky č. 405/2017 Sb., kterou se mění vyhláška č. 499/2006 Sb., o dokumentaci staveb, ve znění vyhlášky č. 62/2013 Sb., a vyhláška č. 169/2016 Sb., o stanovení rozsahu dokumentace veřejné zakázky na stavební práce a soupisu stavebních prací, dodávek a služeb s výkazem výměr.

37. Vyhláška č. 500/2006 Sb., o územně analytických podkladech, územně plánovací dokumentaci a o způsobu evidence územně plánovací činnosti.

38. Vyhláška č. 458/2012 Sb., kterou se mění vyhláška č. 500/2006 Sb., o územně analytických podkladech, územně plánovací dokumentaci a způsobu evidence územně plánovací činnosti.

39. Vyhláška č. 13/2018 Sb., kterou se mění vyhláška č. 500/2006 Sb., o územně analytických podkladech, územně plánovací dokumentaci a způsobu evidence územně plánovací činnosti, ve znění vyhlášky č. 458/2012 Sb.

40. Vyhláška č. 501/2006 Sb., o obecných požadavcích na využívání území.

41. Vyhláška č. 269/2009 Sb., kterou se mění vyhláška č. 501/2006 Sb., o obecných požadavcích na využívání území.

42. Vyhláška č. 22/2010 Sb., kterou se mění vyhláška č. 501/2006 Sb., o obecných požadavcích na využívání území, ve znění vyhlášky č. 269/2009 Sb.

43. Vyhláška č. 20/2011 Sb., kterou se mění vyhláška č. 501/2006 Sb., o obecných požadavcích na využívání území, ve znění pozdějších předpisů.

44. Vyhláška č. 431/2012 Sb., kterou se mění vyhláška č. 501/2006 Sb., o obecných požadavcích na využívání území, ve znění pozdějších předpisů.

45. Vyhláška č. 360/2021 Sb., kterou se mění vyhláška č. 501/2006 Sb., o obecných požadavcích na využívání území, ve znění pozdějších předpisů.

46. Vyhláška č. 164/2022 Sb., kterou se mění vyhláška č. 360/2021 Sb., kterou se mění vyhláška č. 501/2006 Sb., o obecných požadavcích na využívání území, ve znění pozdějších předpisů.

47. Vyhláška č. 503/2006 Sb., o podrobnější úpravě územního rozhodování, územního opatření a stavebního řádu.

48. Vyhláška č. 63/2013 Sb., kterou se mění vyhláška č. 503/2006 Sb., o podrobnější úpravě územního řízení, veřejnoprávní smlouvy a územního opatření.

49. Vyhláška č. 66/2018 Sb., kterou se mění vyhláška č. 503/2006 Sb., o podrobnější úpravě územního rozhodování, územního opatření a stavebního řádu, ve znění vyhlášky č. 63/2013 Sb.

50. Vyhláška č. 146/2008 Sb., o rozsahu a obsahu projektové dokumentace dopravních staveb.

51. Vyhláška č. 251/2018 Sb., kterou se mění vyhláška č. 146/2008 Sb., o rozsahu a obsahu projektové dokumentace dopravních staveb.

52. Vyhláška č. 268/2009 Sb., o technických požadavcích na stavby.

53. Vyhláška č. 20/2012 Sb., kterou se mění vyhláška č. 268/2009 Sb., o technických požadavcích na stavby.

54. Vyhláška č. 323/2017 Sb., kterou se mění vyhláška č. 268/2009 Sb., o technických požadavcích na stavby, ve znění vyhlášky č. 20/2012 Sb.

55. Vyhláška č. 398/2009 Sb., o obecných technických požadavcích zabezpečujících bezbariérové užívání staveb.

56. Vyhláška č. 239/2017 Sb., o technických požadavcích pro stavby pro plnění funkcí lesa.

57. Vyhláška č. 418/2022 Sb., kterou se mění vyhláška č. 500/2006 Sb., o územně analytických podkladech, územně plánovací dokumentaci a způsobu evidence územně plánovací činnosti, ve znění pozdějších předpisů, vyhláška č. 501/2006 Sb., o obecných požadavcích na využívání území, ve znění pozdějších předpisů, a vyhláška č. 360/2021 Sb., kterou se mění vyhláška č. 501/2006 Sb., o obecných požadavcích na využívání území, ve znění pozdějších předpisů, ve znění vyhlášky č. 164/2022 Sb.

58. Nařízení hlavního města Prahy č. 10/2016 Sb. hl. m. Prahy, kterým se stanovují obecné požadavky na využívání území a technické požadavky na stavby v hlavním městě Praze (pražské stavební předpisy).

59. Nařízení hlavního města Prahy č. 14/2018 Sb. hl. m. Prahy, kterým se mění nařízení hlavního města Prahy č. 10/2016 Sb. hl. m. Prahy, kterým se stanovují obecné požadavky na využívání území a technické požadavky na stavby v hlavním městě Praze (pražské stavební předpisy).

#### HLAVA V

*ZVLÁŠTNÍ USTANOVENÍ O POUŽITELNOSTI ZÁKONA V PŘECHODNÉM OBDOBÍ*

#### § 334a

(1) Přechodným obdobím se rozumí pro účely odstavců 2 a 3 období od 1. ledna 2024 do 30. června 2024 a pro účely odstavce 4 období od 1. července 2022 do 30. června 2023.

(2) Ve věcech týkajících se územního plánování se v přechodném období postupuje podle dosavadních právních předpisů, s výjimkou územního řízení týkajícího se vyhrazené stavby uvedené v příloze č. 3 k tomuto zákonu nebo stavby s ní související, které v přechodném období nelze zahájit. Pro účely přechodných ustanovení v části dvanácté hlavě II dílu 2 se za den nabytí účinnosti tohoto zákona považuje 1. červenec 2024.

(3) Ve věcech týkajících se záměrů podle tohoto zákona se v přechodném období postupuje podle dosavadních právních předpisů s výjimkou věcí týkajících se vyhrazených staveb uvedených v příloze č. 3 k tomuto zákonu, staveb s nimi souvisejících a staveb tvořících s nimi soubor staveb. Pro účely přechodných ustanovení v části dvanácté hlavě II dílu 4 se za den nabytí účinnosti tohoto zákona považuje 1. červenec 2024. Ve věcech týkajících se vyhrazených staveb uvedených v příloze č. 3 k tomuto zákonu, staveb s nimi souvisejících a staveb tvořících s nimi soubor staveb se postupuje podle tohoto zákona s výjimkou § 172, 173, § 185 odst. 3 písm. c) a části sedmé.

(4) V přechodném období vykonává působnost Nejvyššího stavebního úřadu jako služebního úřadu Ministerstvo pro místní rozvoj a působnost stanovenou předsedovi Nejvyššího stavebního úřadu jako služebnímu orgánu státní tajemník v Ministerstvu pro místní rozvoj.

#### § 334b — ~~Použití informačních systémů stavební správy v přechodném období~~ **Použití informačních systémů v přechodném období**  `[272 Čl.I/562; 272 Čl.I/632; 272 Čl.I/633; 272 Čl.I/634; 272 Čl.I/635; 272 Čl.I/636; 272 Čl.I/637; 272 Čl.I/638; 272 Čl.I/639; 272 Čl.I/640]` {uc=A}

(1) Přechodným obdobím se ~~pro účely odstavce 2~~ rozumí období do 31. prosince ~~2027 a pro účely odstavců 3 a 5 až 9 období do 30~~ **2030**. ~~června 2027.~~ {uc=A}

(2) V přechodném období se ve věcech stavebního řádu § 173, § 180 odst. 2, § 181 odst. 2 a 3, § 267 odst. 5, § **268 odst. 3, §** 272 odst. **1,** 3 až 5 a § 273 odst. 2 nepoužijí. {uc=A}

~~(3) V přechodném období se ve věcech územního plánování § 22 písm. c), § 23 odst. 2 písm. f), § 25 písm. f), § 105 odst. 2, § 108 odst. 3, § 113 odst. 6, § 128 odst. 2 věta druhá, § 130 odst. 3, § 267 odst. 5, § 269 odst. 4 a 5 a § 303 odst. 4 nepoužijí.~~ {uc=A}

~~(4)~~ **(3)** K výkonu působnosti orgánů územního plánování, stavebních úřadů a dotčených orgánů lze v přechodném období použít vedle informačních systémů ~~stavební správy~~ i jiné informační systémy. Orgán územního plánování, stavební úřad a dotčený orgán zajistí, aby na žádost ministerstva mohla být data z jiného informačního systému, která vznikla při výkonu jejich působnosti v přechodném období, předána ministerstvu za účelem jejich přenosu do informačních systémů ~~stavební správy~~. {uc=A}

~~(5)~~ **(4)** ~~Seznamy podle § 42 odst. 4 a § 50 odst. 2 zveřejňuje ministerstvo~~ **Stanoví-li tento zákon povinnost vložit dokument do národního geoportálu územního plánování nebo odkázat na něj, lze** v přechodném období **splnit tuto povinnost i jiným** způsobem umožňujícím dálkový přístup ~~namísto jejich zveřejnění v národním geoportálu územního plánování~~. {uc=A}

~~(5) Stanoví-li tento zákon, že ministerstvo nebo pořizovatel vkládá dokument do národního geoportálu územního plánování nebo zveřejňuje dokument v národním geoportálu územního plánování, je tato povinnost v přechodném období splněna, pokud je ministerstvo nebo pořizovatel zveřejní způsobem umožňujícím dálkový přístup s uvedením data jeho uveřejnění. Adresu zveřejnění zašle pořizovatel nadřízenému orgánu. V přechodném období nelze povinnost podle § 64 odst. 1 splnit vložením údajů o území do národního geoportálu územního plánování. Lhůta podle § 69 odst. 1 počíná běžet ode dne zveřejnění územní studie způsobem umožňujícím dálkový přístup.~~ {uc=A}

~~(6) Stanoví-li tento zákon, že ministerstvo nebo pořizovatel odkazuje na dokument vložený do národního geoportálu územního plánování, lze v přechodném období odkázat na dokument zveřejněný postupem podle odstavce 6.~~ {uc=A}

~~(8)~~ **(5)** Územně analytické podklady, územní studie, územně plánovací dokumentace, její úplné znění, vymezení zastavěného území, změna vymezení zastavěného území, úplné znění vymezení zastavěného území po jeho změně, územní opatření a informace o prověření stavební uzávěry podle § 326 se v přechodném období namísto jejich vložení do národního geoportálu územního plánování zveřejňují způsobem umožňujícím dálkový přístup. Pořizovatel vloží dokumenty podle věty první do národního geoportálu územního plánování do 31. prosince ~~2026~~ **2030**. {uc=A}

~~(9)~~ **(6)** Ministerstvo zajišťuje v přechodném období evidenci územně plánovací činnosti. Předmětem evidence územně plánovací činnosti jsou metadata o územně plánovací dokumentaci, ~~zastavěném~~ **zastavitelném** území, územním opatření a územní studii včetně průběhu jejich pořizování. Data do evidence vkládá příslušný pořizovatel. Součástí metadat je i údaj o adrese zveřejnění dokumentů podle odstavce 8 způsobem umožňujícím dálkový přístup. {uc=A}

~~(10)~~ **(7)** Řízení a jiné postupy s výjimkou postupů podle části třetí zahájené od 1. července 2024 do konce přechodného období se dokončí podle odstavců 2 až ~~8~~ **5**. {uc=A}

### ČÁST TŘINÁCTÁ

*ÚČINNOST*

#### § 335

Tento zákon nabývá účinnosti dnem 1. ledna 2024, s výjimkou ustanovení

a) § 36, 319, § 322 odst. 1 a 3, § 324 a § 326 odst. 1, která nabývají účinnosti dnem následujícím po dni jeho vyhlášení,

b) § 15 až 18, § 312 odst. 1 a 7, § 313 odst. 1 a 2 a § 315 odst. 1, která nabývají účinnosti dnem 1. ledna 2022,

c) § 312 odst. 4, které nabývá účinnosti dnem 1. ledna 2023.

### PŘÍLOHY

#### Příloha č. 1 k zákonu č. 283/2021 Sb.

*Drobné stavby*

(1) Drobnými stavbami jsou

a) **doplnění, odstranění,** stavby nebo zařízení **a s nimi související terénní úpravy** a jejich údržba, a to {uc=B}

1. stavba do ~~40~~ **60** m2 zastavěné plochy a do 5 m výšky s nejvýše jedním nadzemním podlažím **a podkrovím**, podsklepená nejvýše do hloubky 3 m, na pozemku ~~rodinného domu nebo~~ **zázemí** stavby ~~pro rodinnou rekreaci~~, která souvisí s bydlením nebo rodinnou rekreací, a nejde o stavbu pro podnikatelskou činnost, která je umisťována v odstupové vzdálenosti od hranic pozemků nejméně 2 m a plocha části pozemku schopného vsakovat dešťové vody po jejím umístění bude nejméně 50 % z celkové plochy pozemku ~~rodinného domu nebo~~ **zázemí** stavby ~~pro rodinnou rekreaci~~, {uc=B}

2. skleník do 40 m2 zastavěné plochy a do 5 m výšky bez podsklepení nebo bazén do 40 m2 zastavěné plochy na pozemku ~~rodinného domu nebo~~ **zázemí** stavby ~~pro rodinnou rekreaci~~ v odstupové vzdálenosti nejméně 2 m od hranice pozemku, {uc=B}

3. stavba do 40 m2 zastavěné plochy a do 5 m výšky s nejvýše jedním nadzemním podlažím, podsklepená nejvýše do hloubky 3 m, na pozemku, který je určen rozhodnutím o povolení záměru, územním plánem ~~s prvky regulačního plánu~~ nebo regulačním plánem pro způsob využití jako zahrádkářská osada, a nejde o stavbu pro bydlení, pro rodinnou rekreaci a pro podnikatelskou činnost, která je umisťována v odstupové vzdálenosti od hranic pozemků nejméně 2 m a plocha části pozemku schopného vsakovat dešťové vody po jejím umístění bude nejméně 50 % z celkové plochy pozemku, {uc=B}

4. stavba~~, včetně základové konstrukce,~~ do ~~55~~ **60** m2 zastavěné plochy a do ~~4~~ **5** m výšky na pozemku, který je určen rozhodnutím o povolení záměru, územním plánem ~~s prvky regulačního plánu~~ nebo regulačním plánem pro způsob využití jako plochy rekreace, která je umisťována v odstupové vzdálenosti od hranic pozemků nejméně 2 m a plocha části pozemku schopného vsakovat dešťové vody po jejím umístění bude nejméně 50 % z celkové plochy pozemku, {uc=B}

**5. stavba pro zemědělství do 60 m2 zastavěné plochy a do 5 m výšky o jednom nadzemním podlaží, nepodsklepená, která je umisťována v odstupové vzdálenosti od hranic pozemků nejméně 2 m,**

~~5.~~ **6.** opěrné zdi do výšky 1**,5** m nebo oplocení do výšky 2 m mezi pozemky, které se nacházejí v ~~zastavěném~~ **zastavitelném** území ~~nebo v zastavitelné ploše~~, {uc=B}

~~6.~~ **7.** dočasné stavby bez podsklepení nebo zařízení, která slouží ke kulturním, společenským nebo sportovním účelům, přenosná prodejní zařízení anebo stánky, jejichž umístění nepřesáhne ~~30~~ **90** po sobě jdoucích dnů, {uc=B}

~~7.~~ **8.** reklamní zařízení o celkové ploše do 0,6 m2; plocha oboustranných panelů se započítává pouze jednou,

~~8.~~ **9.** **ohrady pro hospodářská zvířata do 1,5 m výšky,** oplocení lesních školek a obor59), oplocení zřízené k ochraně lesních porostů před zvěří na lesních pozemcích a oplocení dřevin vysazených za účelem založení územního systému ekologické stability, která jsou bez podezdívky, přičemž nesmí dojít k omezení provozu na pozemní komunikaci nebo k přerušení turisticky značené trasy **nebo k významnému zhoršení prostupnosti krajiny pro volně žijící drobné živočichy**, {uc=B}

~~9.~~ **10.** stavby pro hospodaření v lesích a stavby pro výkon práva myslivosti do 30 m2 zastavěné plochy a do 5 m výšky bez podsklepení,

~~10.~~ **11.** doplnění vlastní telekomunikační sítě60) k řízení, měření, zabezpečování a automatizaci provozu energetické soustavy a k přenosu informací pro činnost výpočetní techniky a informačních systémů a doplnění nezbytných systémů ochrany, řízení a zabezpečení sítě, to vše ke stávající energetické síti technické infrastruktury, pokud nedochází k překročení hranice stávajícího ochranného nebo bezpečnostního pásma,

~~11.~~ **12.** výměna nebo navýšení kapacity sítí technické infrastruktury, pokud nedochází k překročení hranice stávajícího ochranného nebo bezpečnostního pásma,

~~12.~~ **13.** výměna nebo navýšení kapacity sítí technické infrastruktury, pokud dochází k překročení hranice jejich stávajícího ochranného nebo bezpečnostního pásma, bez rozšíření jeho stávajícího rozsahu~~, výměna nebo navýšení kapacity sítě technické infrastruktury~~ a změna její stávající trasy nebo hranice jejího stávajícího ochranného a bezpečnostního pásma se dotýkají pouze pozemků již dotčených trasou sítě technické infrastruktury nebo jejím stávajícím ochranným nebo bezpečnostním pásmem, a ~~pro provedení~~ **s provedením doplnění, odstranění,** výměny nebo navýšení kapacity sítě technické infrastruktury mimo její stávající trasu ~~je s vlastníkem~~ **vlastník** dotčených pozemků ~~uzavřena smlouva o zřízení věcného břemene nebo smlouva o smlouvě budoucí o zřízení věcného břemene~~ **souhlasí**, {uc=B}

~~13.~~ **14.** povrchové rozvody nebo odvody vody na zemědělské půdě nebo na pozemcích určených k plnění funkcí lesa, nejde-li o vodní díla,

~~14.~~ **15.** přístřešky o jednom nadzemním podlaží, které slouží veřejné dopravě, a jiné veřejně přístupné přístřešky do 40 m2 zastavěné plochy a do 4 m výšky,

~~15.~~ **16.** ~~podpěrné~~ konstrukce dopravního značení a zařízení pro provozní informace na pozemních komunikacích **a dráhách**, ~~nejde-li o portálové konstrukce,~~ {uc=B}

~~16.~~ **17.** sjezdy a nájezdy na pozemní komunikace sloužící k připojení sousední nemovité věci61),

~~17.~~ **18.** nástupní ostrůvky hromadné veřejné dopravy a přejezdy přes chodníky,

~~18.~~ **19.** propustky na neveřejných účelových komunikacích,

~~19.~~ **20.** stavby mostních vah,

~~20.~~ **21.** signální věže, signály a pyramidy pro zeměměřické účely a body seismické monitorovací sítě,

~~21.~~ **22.** stožáry pro vlajky do výšky 8 m,

~~22.~~ **23.** antény, včetně jejich nosných konstrukcí a souvisejících elektronických komunikačních zařízení do celkové výšky 8 m, umisťované samostatně na pozemku nebo na budovách,

~~23.~~ **24.** ~~běžný~~ **běžné** dobíjecí ~~bod62~~ **body62**), {uc=B}

~~24.~~ **25.** zařízení sloužící k odběru povrchových nebo podzemních vod v případech ohrožujících život, zdraví nebo majetek těmito vodami,

~~25.~~ **26.** stavby pro výrobu energie z obnovitelných zdrojů a stavby pro ukládání energie s celkovým instalovaným výkonem do 100 kW, s výjimkou stavby vodního díla, stavby pro výrobu elektřiny využívající větrnou energii, stavby ve zvláště chráněném území, nebo v území vymezeném Ministerstvem obrany nebo Ministerstvem vnitra stanoveném v nařízení vlády,

~~26.~~ **27.** přípolože63) k existující stavbě dopravní či technické infrastruktury,

**28. zázemí zotavovací akce nebo jiné podobné akce pro děti86) tvořené přístřešky o celkové zastavěné ploše všech staveb do 60 m2, s výjimkou hygienického zařízení, bez podsklepení, s nejvýše jedním nadzemním podlažím, je-li ubytování účastníků takové akce zajištěno výhradně ve stanech; takové přístřešky se za stavbu ani za drobnou stavbu nepovažují, jsou-li pro uvedený účel využívány pouze mimo období školního vyučování. _____________**

~~27.~~ **29.** zázemí lesní mateřské školy a výdejny lesní mateřské školy o celkové zastavěné ploše všech staveb do ~~55~~ **60** m2, s výjimkou hygienického zařízení, bez podsklepení, s nejvýše jedním nadzemním podlažím, {uc=B}

~~28.~~ **30.** připojení k distribuční soustavě pomocí elektrické přípojky nebo smyčky, to vše v hladině nízkého napětí a v maximální délce do ~~25~~ **100** m od vedení a zařízení**, a to i** stávající distribuční soustavy, zřizované provozovatelem distribuční soustavy, jehož distribuční soustava je připojena k přenosové soustavě a k jehož soustavě je připojeno více než 90 000 odběrných míst, včetně připojení stavby a odběrných zařízení vedených mimo budovu nebo připojení staveb plnících doplňkovou funkci ke stavbě hlavní, {uc=B}

~~29.~~ **31.** plynovodní přípojky o tlakové úrovni do 4 bar v maximální délce do ~~25~~ **100** m od vedení stávající distribuční soustavy, s níž vyslovil provozovatel distribuční soustavy, k jehož soustavě je připojeno více než 90 000 odběrných míst, souhlas, včetně připojení stavby a odběrných zařízení**, a to i** vedených mimo budovu nebo připojení staveb plnících doplňkovou funkci ke stavbě hlavní, {uc=B}

~~30.~~ **32.** vodovodní nebo kanalizační přípojky v délce do ~~25~~ **100** m od stávajícího vodovodního řadu nebo stávající kanalizační stoky schválené vlastníkem dotčeného pozemku a vlastníkem vodovodu nebo kanalizace, popřípadě jeho provozovatelem, pokud je k tomu vlastníkem zmocněn, včetně připojení stavby a odběrných zařízení**, a to i** vedených mimo budovu nebo připojení staveb plnících doplňkovou funkci ke stavbě hlavní, {uc=B}

~~31.~~ **33.** stání pro obytné automobily a obytné přívěsy,

~~32.~~ **34.** ~~výrobky plnící funkci~~ stavby veřejné technické infrastruktury o jednom nadzemním podlaží do 40 m2 zastavěné plochy a do 5 m výšky, nepodsklepené, jsou-li umisťovány v ~~zastavěném~~ **zastavitelném** území mimo veřejná prostranství v odstupové vzdálenosti od hranic pozemků nejméně 2 m, {uc=B}

~~33.~~ **35.** přístřešky o jednom nadzemním podlaží do 40 m2 zastavěné plochy a do 5 m výšky, nepodsklepené~~, jestliže neobsahují obytné nebo pobytové místnosti nebo hygienická zařízení~~, a které neslouží k ustájení nebo chovu zvířat a neslouží k výrobě nebo skladování hořlavých kapalin nebo hořlavých plynů, a jsou-li umisťovány v ~~zastavěném~~ **zastavitelném** území mimo veřejná prostranství, {uc=B}

~~34.~~ **36.** stavby základnových stanic vlakového rádiového zařízení, včetně antén, jejich nosných konstrukcí a souvisejících elektronických komunikačních a energetických zařízení a sítí, do celkové výšky 15 m,

**37. sítě elektronických komunikací, pokud se umisťují na vlastních nemovitostech nebo pokud s jejich umístěním vlastník dotčené nemovitosti souhlasí, nebo přípojky elektronických komunikací do délky 100 metrů; přípojkou elektronických komunikací se rozumí část sítě elektronických komunikací, která umožňuje připojení bodu vstupu komunikačního vedení do budovy nebo na pozemek, kde je umístěn koncový bod sítě, k nejbližšímu rozhraní veřejné komunikační sítě,**

**38. uložení stávajícího nadzemního vedení na hladině nízkého napětí v zastavitelném území pod zem, pokud s tím vlastník dotčených pozemků souhlasí,**

**39. tepelná přípojka v maximální délce do 100 m od rozvodného tepelného zařízení zřizovaná držitelem licence na rozvod tepelné energie, včetně připojení stavby a odběrných zařízení nebo připojení staveb plnících doplňkovou funkci ke stavbě hlavní,**

**40. dočasné stavby náhradních tras dopravní a technické infrastruktury a souvisejících zařízení a staveb, jejichž trvání nepřesáhne 12 měsíců,**

**41. jiné dočasné stavby nebo zařízení, jejichž umístění nepřesáhne 90 po sobě jdoucích dnů,**

**42. venkovní dětská hřiště, sportoviště a zařízení pro sport do 300 m2,**

**43. stavba zpevněných ploch do 60 m2 na pozemku zázemí stavby, která souvisí s bydlením nebo rodinnou rekreací,**

**44. stavba veřejného osvětlení,**

**45. jiná nepatrná stavba, která nemůže ani potenciálně zasáhnout do žádných veřejných zájmů ani práv třetích osob,**

b) součásti a příslušenství drobných staveb, pokud nepřekročí parametry staveb uvedených v písmenu a), a stavby zařízení staveniště potřebné pro provedení nebo odstranění drobné stavby,

c) změny drobných staveb uvedených v písmenu a), při nichž nedojde k překročení uvedených parametrů,

d) udržovací práce, jejichž provedení nemůže negativně ovlivnit zdraví osob, požární bezpečnost, stabilitu, vzhled stavby, životní prostředí nebo bezpečnost při užívání ~~a nejde o udržovací práce na stavbě~~, ~~která je kulturní památkou,~~ {uc=B}

e) stavební úpravy **včetně zateplení budov**, pokud ~~se~~ jimi ~~nezasahuje do nosných konstrukcí~~ **není ovlivněna mechanická odolnost a stabilita** stavby, nemění se **významně** vzhled stavby ani ~~způsob~~ **účel** užívání stavby, jejich provedení nemůže negativně ovlivnit požární bezpečnost stavby ~~a nejde o stavební úpravy stavby~~, ~~která je kulturní památkou,~~ {uc=B}

f) stavební úpravy pro instalaci využívající obnovitelný zdroj energie s celkovým instalovaným výkonem do 100 kW, pokud ~~se~~ jimi ~~nezasahuje do nosných konstrukcí~~ **není ovlivněna mechanická odolnost a stabilita** stavby, nemění se ~~způsob~~ **účel** užívání stavby, nevyžaduje posouzení vlivů na životní prostředí, jsou splněny podmínky zejména požární bezpečnosti podle právního předpisu upravujícího požadavky na bezpečnou instalaci výroben elektřiny, {uc=B}

g) udržovací práce nebo stavební úpravy pozemních komunikací, a to

1. zařízení zabraňující vniknutí volně žijících živočichů na dálnici nebo silnici I. třídy,

2. výměna mostních závěrů nebo izolačních systémů na mostech,

3. technická zařízení a jejich součásti určené k vyměření, výběru a kontrole úhrady poplatku za užití pozemní komunikace mimo portálové konstrukce,

4. zřízení obrub k vozovce,

5. zvýšení nebo zesílení chodníku s výškovou úpravou obrub,

6. zřizování dalších přejezdů středního dělicího pásu,

7. stavební úpravy dálnice, silnice a místní komunikace, při nichž změna původní nivelety nepřesáhne 3 cm u komunikací s přímo přilehlou zástavbou nebo s přímo přilehlými chodníky, na železničních přejezdech, na mostech, v podjezdech a v místech, kde jsou umístěny inženýrské sítě a jiná vedení nebo 10 cm u ostatních komunikací anebo 6 cm v případě krátkých příčných prahů prováděných formou stavební úpravy,

8. stavební úpravy vozovek a krajnic v rozsahu běžné a souvislé údržby64),

h) udržovací práce nebo stavební úpravy staveb dráhy, a to

1. odvodnění nástupišť, přejezdů nebo tunelů,

2. stavební úpravy svršku železničních a tramvajových tratí,

3. výměna kolejí, kolejových polí, pražců a výhybek a jejich součástí,

4. výměna nenosných částí mostů,

5. zařízení pro ochranu osob před nebezpečným dotykovým napětím,

6. zařízení pro ochranu před účinky bludných proudů elektrické trakce,

7. zařízení dálkového ovládání elektroenergetických zařízení,

8. zařízení protikorozní ochrany, zařízení ochrany proti rušení telekomunikačních systémů a zařízení zamezující vlivu vysokého napětí,

9. zařízení dálkového ovládání, regulace a měření,

10. sdělovací a informační zařízení drah,

11. zařízení elektrické požární signalizace,

i) stavby, terénní úpravy, stavební úpravy a udržovací práce na území vojenských újezdů nebo ve vojenských objektech, a to

1. mostní provizoria a nájezdové rampy k nim,

2. terénní úpravy do 2,5 m hloubky a do ~~5~~ **3**,0 m výšky nebo o výměře do ~~1~~ **0,25** km2, {uc=B}

3. stavby odstavných, manipulačních a skladových ploch o výměře do ~~1~~ **0,4** km2, {uc=B}

4. účelové komunikace,

5. výrobky plnící funkci stavby včetně základových konstrukcí pro ně~~.~~**,**

**j) změny využití území, a to**

**1. terénní úprava do 1,5 m výšky nebo hloubky o výměře do 300 m2 na pozemku, který nemá společnou hranici s veřejnou pozemní komunikací nebo veřejným prostranstvím,**

**2. odstavná, manipulační, prodejní, skladová nebo výstavní plocha do 300 m2, která neslouží pro skladování hořlavých látek nebo manipulaci s hořlavými látkami nebo látkami, které mohou způsobit znečištění životního prostředí, nebo se zvláště nebezpečnými a nebezpečnými látkami podle vodního zákona,**

**3. změna druhu pozemku48) nebo způsobu využití pozemků49) o výměře do 300 m2,**

**4. terénní úprava v přirozeném korytu vodního toku a na pozemcích sousedících s ním, kterou se podstatně nemění přirozené koryto vodního toku, pokud se neprovádí ve stanoveném záplavovém území,**

**5. úprava pozemku, která má vliv na schopnost vsakování vody, provedená na pozemku stavby pro bydlení nebo rodinnou rekreaci, která souvisí nebo podmiňuje bydlení nebo rodinnou rekreaci, neslouží ke skladování hořlavých látek nebo výbušnin, není v rozporu s územně plánovací dokumentací a plocha části pozemku schopného vsakovat dešťové vody po jejím provedení bude nejméně 50 % z celkové plochy pozemku stavby pro bydlení nebo rodinnou rekreaci.**

(2) Za drobné stavby se nepovažují

a) stavby pro bydlení,

b) stavby pro rodinnou rekreaci s výjimkou stavby uvedené v odstavci 1 písm. a) bodu 4,

~~c) stavby garáží,~~

~~d)~~ **c)** trafostanice, pokud nejsou výrobkem plnícím funkci stavby,

~~e)~~ **d)** stavby skladů hořlavých látek, pyrotechnických výrobků, střeliva, munice a výbušnin,

~~f)~~ **e)** stavby pro civilní obranu a požární ochranu,

~~g)~~ **f)** stavby uranového průmyslu a stavby jaderného zařízení s výjimkou staveb podle odstavce 1 písm. d) až f),

~~h)~~ **g)** sklady a skládky nebezpečných odpadů,

~~i)~~ **h)** stavby vodních děl s výjimkou staveb podle odstavce 1 písm. a) bodů 11 a 12 a odstavce 1 písm. d) až f),

~~i) výměna nebo navýšení kapacity sítí technické infrastruktury, nejde-li o výměnu nebo navýšení kapacity sítí technické infrastruktury podle odstavce 1 písm. a) bodů 11 a 12,~~

~~k)~~ **i)** důlní díla a důlní stavby pod povrchem, pokud podléhají schvalování a dozoru státní báňské správy podle horních předpisů,

~~l)~~ **j)** záměry EIA~~.~~**,**

**k) změny využití území realizované v území, pro které je vydán plán území s archeologickými nálezy, nebo ve zvláště chráněném území, evropsky významné lokalitě nebo ptačí oblasti nebo v chráněném ložiskovém území,**

**l) stavby pódií ve venkovním prostoru pro akce, jejichž převažujícím účelem je elektronicky zesilovaná hudební produkce, pokud doba umístění takové stavby přesáhne 10 po sobě jdoucích dnů a pokud je stavba umisťována nad tuto dobu bez souhlasu obce, na jejímž území se má stavba umístit.**

#### Příloha č. 2 k zákonu č. 283/2021 Sb.

*Jednoduché stavby*

(1) Jednoduchými stavbami jsou stavby nebo zařízení a **nimi související** terénní úpravy **a jejich údržba, pokud nejde o drobnou stavbu**, a to {uc=B}

a) **rodinné domy a** stavby pro ~~bydlení a~~ rodinnou rekreaci, které mají nejvýše dvě nadzemní a jedno podzemní podlaží a podkroví nebo ustoupené podlaží, {uc=B}

**b) bytové domy do 500 m2 zastavěné plochy, které mají nejvýše 4 nadzemní podlaží, výšku podle jiného právního předpisu87) do 9 m, nejvýše jedno podzemní podlaží a jsou určeny výhradně k bydlení, _______________**

~~b)~~ **c)** podzemní stavby do 300 m2 zastavěné plochy a do 3 m hloubky, pokud nejde o stavby technické infrastruktury,

~~d) stavby garáží do 5 m výšky s jedním nadzemním podlažím, podsklepené nejvýše do hloubky 3 m,~~

d) reklamní zařízení a stavby pro reklamu,

e) opěrné zdi nebo oplocení, ~~pokud nejde o drobnou stavbu,~~ {uc=B}

~~f) stavby pro zemědělství do 60 m2 zastavěné plochy a do 5 m výšky o jednom nadzemním podlaží, nepodsklepené, pokud nejde o stavby pro hospodářská zvířata anebo stavby, které mají sloužit pro skladování a zpracování hořlavých látek jako sušičky, sklady hořlavých kapalin, sklady chemických hnojiv a jiné,~~

~~g)~~ **f)** stavby pro zemědělství ~~nad 60 m2 zastavěné plochy nebo nad 5 m výšky~~ do 300 m2 zastavěné plochy a do 7 m výšky, o jednom nadzemním podlaží, ~~nepodsklepené~~ **podsklepené nejvýše do hloubky 3 m**, ~~pokud nejde o stavby pro hospodářská zvířata anebo stavby, které mají sloužit pro skladování a zpracování hořlavých látek jako sušičky, sklady hořlavých kapalin, sklady chemických hnojiv a jiné,~~ {uc=B}

~~g) stavby pro hospodářská zvířata do 60 m2 zastavěné plochy a do 5 m výšky, podsklepené nejvýše do hloubky 3 m,~~

~~i)~~ **g)** přípojky sítí technické infrastruktury, ~~pokud nejde o drobnou stavbu,~~ {uc=B}

~~j)~~ **h)** výrobky plnící funkci stavby, včetně základových konstrukcí pro ně, ~~pokud nejde o drobnou stavbu,~~ {uc=B}

~~k)~~ **i)** zásobníky pro zkapalněné uhlovodíkové plyny do celkového objemu 5 m3 určené výhradně pro odběr plynné fáze,

~~l)~~ **j)** dobíjecí stanice, ~~pokud nejde o drobnou stavbu,~~ {uc=B}

~~m)~~ **k)** stavby pro výrobu energie z obnovitelných zdrojů a stavby pro ukládání energie s celkovým instalovaným výkonem do 250 kW,

~~n)~~ **l)** stavby odstavných, manipulačních, prodejních, skladových nebo výstavních ploch do 1000 m2, které neslouží pro skladování nebo manipulaci s hořlavými látkami nebo látkami, které mohou způsobit znečištění životního prostředí,

~~m) stavby, terénní úpravy, stavební úpravy a udržovací práce na území vojenských újezdů nebo ve vojenských objektech, pokud nejde o drobnou stavbu,~~

~~p)~~ **m)** stavby zařízení staveniště, ~~pokud nejde o drobnou stavbu,~~ {uc=B}

~~q)~~ **n)** stavba pro bydlení do 80 m2 zastavěné plochy a do 5 m výšky s nejvýše jedním nadzemním podlažím **a podkrovím**, bez podsklepení, na pozemku ~~rodinného domu~~ **zázemí stavby**, která je se stavbou ~~rodinného domu~~ **zázemí stavby** funkčně spojena a je umisťována v odstupové vzdálenosti od hranic pozemků nejméně 2 m, pokud nejde o stavbu pro podnikatelskou činnost a plocha části pozemku schopného vsakovat dešťové vody po jejím umístění bude nejméně 50 % z celkové plochy pozemku ~~rodinného domu~~ **zázemí stavby**; požadavky územního plánu na sklon střechy stavby se nepoužijí, {uc=B}

~~r)~~ **o)** studny k odběru vody, jenž nepřekračuje 6 000 m3 za kalendářní rok nebo 500 m3 v každém měsíci kalendářního roku,

~~s)~~ **p)** čistírny odpadních vod do kapacity 50 ekvivalentních obyvatel,

~~t)~~ **q)** zemní kabelové vedení na hladině nízkého a vysokého napětí, ~~pokud nejde o drobnou stavbu,~~ {uc=B}

~~u)~~ **r)** elektrické stanice nejvýše o jednom nadzemním podlaží, nepodsklepené, do rozlohy 40 m2 a 5 metrů výšky,

~~v)~~ **s)** podzemní vedení distribuční soustavy plynu o tlakové hladině do 4 bar, ~~pokud nejde o drobnou stavbu.~~ {uc=B}

**t) venkovní sportoviště do 3 000 m2 včetně staveb zázemí sportoviště (toalety, sprchy, šatny, občerstvení) do 300 m2 zastavěné plochy a do 7 m výšky.**

(2) Dále se pro účely tohoto zákona jednoduchými stavbami rozumí**, pokud nejde o drobnou stavbu,** {uc=B}

a) součásti a příslušenství jednoduchých staveb, pokud nepřekročí parametry staveb uvedených v odstavci 1,

b) změny jednoduchých staveb uvedených v odstavci 1, při nichž nedojde k překročení uvedených parametrů,

c) udržovací práce neuvedené v příloze č. 1,

~~d) stavební úpravy pro změny v užívání části stavby, kterými se nezasahuje do nosných konstrukcí stavby a nemění se její vzhled,~~

~~e)~~ **d)** větší změny dokončené budovy podle jiného právního předpisu s celkovou energeticky vztažnou plochou větší než 350 m2,

~~f)~~ **e)** terénní úpravy do 1,5 m výšky nebo hloubky o výměře nad 300 m2 nejvíce však do 1000 m2 na pozemcích, které nehraničí s veřejnými pozemními komunikacemi nebo veřejným prostranstvím, pokud nedochází k nakládání s odpady,

~~g)~~ **f)** terénní úpravy sloužící k zadržování vody v krajině do 1,5 m hloubky o výměře nad 300 m2 nejvíce však do 20 000 m2 v ~~nezastavěném~~ **nezastavitelném** území, které nemají společnou hranici s veřejnou pozemní komunikací, {uc=B}

~~h)~~ **g)** změny druhu pozemku a způsobu využití pozemků o výměře nad 300 m2 nejvíce však do 1000 m2,

~~i)~~ **h)** drobné stavby, které nesplní požadavek na odstupové vzdálenosti od hranic pozemku.

(3) Za jednoduché stavby se nepovažují

a) stavby skladů hořlavých látek, pyrotechnických výrobků, střeliva, munice a výbušnin,

b) stavby pro civilní obranu a požární ochranu,

c) stavby uranového průmyslu a jaderných zařízení,

d) stavby důležité pro obranu a bezpečnost státu, pokud nejde o drobnou stavbu podle přílohy č. 1 odst. 1 písm. i) ~~nebo jednoduchou stavbu podle odstavce 1 písm. o) této přílohy~~, {uc=B}

e) stavby vodních děl neuvedené v odstavci 1 a 2 nebo v příloze č. 1,

f) záměry EIA.

#### Příloha č. 3 k zákonu č. 283/2021 Sb.  `[272 Čl.I/689; 272 Čl.I/690]`

*Vyhrazené stavby*

Vyhrazenými stavbami jsou **(2) Dále se pro účely tohoto zákona vyhrazenými stavbami rozumí stavby a záměry s vyhrazenými stavbami související.** {uc=A}

a) stavby dálnic,

b) stavby drah,

c) civilní letecké stavby,

d) strategické investiční stavby podle zákona o urychlení výstavby strategicky významné infrastruktury,

e) stavby a zařízení přenosové soustavy a stavby a zařízení pro ukládání energie připojené do přenosové soustavy,

f) výrobny elektřiny o celkovém instalovaném výkonu 100 MW a více,

g) stavby a zařízení přepravní soustavy,

h) výrobny plynu nad 1 MW připojené k plynárenské soustavě včetně těžebních plynovodů a zásobníky plynu,

i) stavby a zařízení produktovodů65), včetně skladovacích zařízení, která jsou součástí technické infrastruktury produktovodů,

j) stavby k účelům těžby, zpracování, transportu a ukládání radioaktivních surovin na území vyhrazeném pro tyto účely,

k) stavby související s úložišti radioaktivních odpadů obsahujících výlučně přírodní radionuklidy,

l) stavby jaderného zařízení a stavby související, nacházející se uvnitř i vně areálu jaderného zařízení,

m) stavby určené k nakládání s výbušninami,

n) stavby, které mají sloužit otvírce, přípravě a dobývání ložisek, jakož i úpravě a zušlechťování nerostů prováděných v souvislosti s jejich dobýváním **nebo likvidaci a zajištění**, a úložná místa pro těžební odpad, {uc=A}

o) výrobna z obnovitelných zdrojů energie s výjimkou vodních děl, a to

1. výrobna elektřiny využívající energii slunečního záření s celkovým instalovaným elektrickým výkonem výrobny elektřiny nad 5 MW,

2. výrobna elektřiny s celkovým instalovaným elektrickým výkonem nad 1 MW, nejde-li o výrobnu elektřiny podle bodu 1,

3. výrobna tepla z obnovitelných zdrojů energie s celkovým instalovaným tepelným příkonem výrobny tepla nad 10 MW,

4. zařízení na energetické využívání odpadů,

p) stavby a zařízení rozvodného tepelného zařízení o dimenzi potrubí DN 300 a více,

q) stavby a zařízení, které mají sloužit k ukládání oxidu uhličitého do přírodních horninových struktur nebo k zachytávání oxidu uhličitého, a stavby přepravní sítě určené k přepravě oxidu uhličitého na úložiště oxidu uhličitého~~.~~**,** {uc=A}

**r) stavby pro hromadné bydlení,** {uc=A}

**s) stavby zařízení pro výrobu polovodičů, pokud byly Evropskou komisí uznány jako integrované výrobní zařízení nebo otevřená továrna na polovodiče podle čl. 13 až 15 nařízení (EU) 2023/1781 (Akt o čipech),** {uc=A}

**t) stavby infrastruktury pro vodní dopravu,** {uc=A}

**u) stavby nových zdravotnických zařízení za účelem zajištění poskytování lůžkové péče s předpokládanou kapacitou nad 1 500 lůžek,** {uc=A}

**v) stavby spaloven nebezpečného odpadu,** {uc=A}

**w) deponie produktů po spalování uhlí nebo jiné deponie certifikovaných výrobků určené pro redeponizaci a kaskádové využití jako zdroje stavebních surovin a kritických či strategických surovin podle nařízení Evropského parlamentu a Rady (EU) 2024/1252, včetně souvisejících technologických zařízení pro těžbu, separaci, extrakci a úpravu těchto materiálů.** {uc=A}

#### Příloha č. 4 k zákonu č. 283/2021 Sb.

I. Obsah a struktura vyhodnocení předpokládaných vlivů politiky územního rozvoje a územně plánovací dokumentace na udržitelný rozvoj území

1. Vyhodnocení vlivů politiky územního rozvoje, územního rozvojového plánu nebo zásad územního rozvoje na životní prostředí, zpracované podle části II. této přílohy, nebo pokud příslušný úřad uplatnil u změny politiky územního rozvoje nebo změny územního rozvojového plánu, změny zásad územního rozvoje nebo u územního plánu nebo jeho změny požadavek na toto vyhodnocení.

2. Vyhodnocení vlivů politiky územního rozvoje nebo posuzované územně plánovací dokumentace na evropsky významné lokality nebo ptačí oblasti, pokud orgán ochrany přírody nevyloučil významný vliv na předmět ochrany nebo celistvost evropsky významných lokalit nebo ptačích oblastí66).

3. Vyhodnocení vlivů politiky územního rozvoje nebo posuzované územně plánovací dokumentace na hospodářský rozvoj a soudržnost společenství obyvatel území.

4. Vyhodnocení vlivů politiky územního rozvoje nebo posuzované územně plánovací dokumentace na udržitelný rozvoj území, které spočívá v posouzení vztahu a zlepšování podmínek pro příznivé životní prostředí, hospodářský rozvoj a soudržnost společenství obyvatel území a posouzení naplnění priorit územního plánování.

5. Návrh požadavků na rozhodování ve vymezených plochách a koridorech z hlediska vyváženosti vlivů na životní prostředí, hospodářský rozvoj a soudržnost společenství obyvatel území (udržitelný rozvoj území).

Hodnotí se vlivy, které lze rozumně předpokládat, a to v rozsahu, podrobnosti a míře konkrétnosti, jakou má pořizovaná politika územního rozvoje nebo územně plánovací dokumentace. Vlivy se stanoví odborným odhadem.

II. Obsah a struktura vyhodnocení předpokládaných vlivů politiky územního rozvoje, územního rozvojového plánu, zásad územního rozvoje a územního plánu na životní prostředí

1. Stručné shrnutí obsahu a hlavních cílů posuzované politiky územního rozvoje nebo územně plánovací dokumentace, vztah k jiným koncepcím.

2. Zhodnocení vztahu posuzované politiky územního rozvoje nebo územně plánovací dokumentace k cílům ochrany životního prostředí přijatým na mezistátní, unijní a vnitrostátní úrovni.

3. Údaje o současném stavu životního prostředí v řešeném území a jeho předpokládaném vývoji, pokud by nebyla uplatněna posuzovaná politika územního rozvoje nebo územně plánovací dokumentace.

4. Charakteristiky životního prostředí, které by mohly být uplatněním posuzované politiky územního rozvoje nebo územně plánovací dokumentace významně ovlivněny.

5. Současné problémy a jevy životního prostředí, které by mohly být uplatněním posuzované politiky územního rozvoje nebo územně plánovací dokumentace významně ovlivněny, zejména s ohledem na zvláště chráněná území a jejich ochranná pásma, evropsky významné lokality a ptačí oblasti.

6. Zhodnocení stávajících a předpokládaných vlivů navrhovaných variant posuzované politiky územního rozvoje nebo územně plánovací dokumentace nebo jejího invariantního návrhu, včetně vlivů sekundárních, synergických, kumulativních, krátkodobých, střednědobých a dlouhodobých, trvalých a přechodných, kladných a záporných; hodnotí se vlivy na obyvatelstvo, lidské zdraví, biologickou rozmanitost, faunu, flóru, půdu, zemědělský půdní fond a pozemky určené k plnění funkcí lesa, horninové prostředí, vodu, ovzduší, klima, hmotné statky, kulturní dědictví, včetně dědictví architektonického a archeologického a vlivy na krajinu, včetně vztahů mezi uvedenými oblastmi vyhodnocení.

7. Porovnání zjištěných nebo předpokládaných kladných a záporných vlivů podle jednotlivých variant řešení nebo podle invariantního řešení ve srovnání se současným stavem a jejich zhodnocení. Srozumitelný popis použitých metod vyhodnocení, včetně jejich omezení.

8. Popis navrhovaných opatření pro předcházení, snížení nebo kompenzaci všech zjištěných nebo předpokládaných významných záporných vlivů na životní prostředí.

9. Zhodnocení způsobu zapracování cílů ochrany životního prostředí přijatých na mezinárodní, unijní nebo národní úrovni do posuzované politiky územního rozvoje nebo územně plánovací dokumentace a jejich zohlednění při výběru řešení, včetně případného výběru nejvhodnější varianty.

10. Vyhodnocení možných přeshraničních vlivů politiky územního rozvoje nebo územně plánovací dokumentace na životní prostředí.

11. Souhrnné vypořádání požadavků uplatněných ve stanovisku příslušného úřadu k návrhu zadání nebo k návrhu zadání změny územně plánovací dokumentace nebo stanovisku podle § 71a odst. 2, § 71d odst. 4 písm. c) nebo § 71e odst. 5 písm. e).

12. Návrh ukazatelů pro sledování vlivu posuzované politiky územního rozvoje nebo územně plánovací dokumentace na životní prostředí.

13. Návrh požadavků na rozhodování ve vymezených plochách a koridorech z hlediska minimalizace negativních vlivů na životní prostředí.

14. Netechnické shrnutí výše uvedených údajů.

#### Příloha č. 5 k zákonu č. 283/2021 Sb.

*Obsah a struktura politiky územního rozvoje*

(1) Politika územního rozvoje obsahuje

a) celostátní priority územního plánování pro zajištění udržitelného rozvoje území,

b) koncepci sídelní struktury České republiky **a jejího rozvoje**, {uc=A}

c) vymezení rozvojových oblastí a rozvojových os,

d) vymezení specifických oblastí,

e) vymezení záměrů dopravní infrastruktury,

f) vymezení záměrů technické infrastruktury,

g) další úkoly pro ministerstva a jiné ústřední správní úřady, a

h) úkoly pro územní plánování.

(2) Politika územního rozvoje je doplněna schématy, zejména schématem

a) sídelní struktury České republiky,

b) rozvojových oblastí a rozvojových os,

c) specifických oblastí,

d) záměrů dopravní infrastruktury,

e) záměrů technické infrastruktury a

f) vztahu sídelní struktury, rozvojových oblastí, rozvojových os a specifických oblastí.

(3) Je-li to účelné, lze schéma záměrů dopravní infrastruktury a schéma záměrů technické infrastruktury členit na samostatná schémata.

(4) Spolu s návrhem politiky územního rozvoje se zpracuje

a) zpráva o projednání návrhu politiky územního rozvoje obsahující vyhodnocení připomínek ministerstev, jiných ústředních správních úřadů, krajů, obcí a veřejnosti, případných vyjádření sousedních států a výsledků konzultací se zdůvodněním způsobu jejich zapracování,

b) výsledek vyhodnocení vlivů na udržitelný rozvoj území,

c) stanovisko Ministerstva životního prostředí k vyhodnocení vlivů na životní prostředí se sdělením, jak bylo zohledněno, s uvedením závažných důvodů, pokud některé požadavky nebo podmínky zohledněny nebyly, a další části prohlášení podle § 10g odst. 5 zákona o posuzování vlivů na životní prostředí, a

d) sdělení, jak bylo zohledněno vyhodnocení vlivů na udržitelný rozvoj území s uvedením důvodů výběru přijaté varianty řešení.

#### Příloha č. 6 k zákonu č. 283/2021 Sb.

*Obsah a struktura územního rozvojového plánu*

I. Územní rozvojový plán

(1) Textová část územního rozvojového plánu obsahuje

a) vymezení ~~zastavitelných ploch, transformačních~~ ploch a koridorů a stanovení účelu a požadavků na jejich využití, popřípadě podmínek pro rozhodování v nich, {uc=A}

b) vymezení akceleračních oblastí celostátního významu, včetně určení druhu primární energie zdrojů, pro něž se oblast vymezuje,

c) vymezení ploch a koridorů nadregionálního územního systému ekologické stability,

d) vymezení veřejně prospěšných staveb, veřejně prospěšných opatření, staveb a opatření k zajišťování obrany a bezpečnosti státu a ploch pro asanaci,

e) kompenzační opatření podle zákona o ochraně přírody a krajiny, byla-li stanovena.

(2) Je-li to účelné, textová část územního rozvojového plánu dále obsahuje

a) vymezení **ploch a koridorů** územních rezerv, {uc=A}

b) vymezení ploch a koridorů, ve kterých se ukládá prověření změn jejich využití územní studií,

c) stanovení pořadí provádění změn v území a

d) ~~vymezení definic~~ **definice** pojmů, které nejsou definovány v tomto zákoně nebo v jiných právních předpisech. {uc=A}

(3) Grafická část územního rozvojového plánu **má formu prostorových dat a** obsahuje {uc=A}

a) výkres ploch a koridorů, včetně akceleračních oblastí celostátního významu a územního systému ekologické stability nadregionálního významu,

b) výkres veřejně prospěšných staveb, opatření a asanací,

c) je-li to účelné, výkres vymezení ploch a koridorů, ve kterých se ukládá prověření změn jejich využití územní studií, a

d) je-li to účelné, výkres pořadí provádění změn v území.

(4) Výkresy**, které jsou součástí** grafické části**,** se ~~vydávají~~ **zpracovávají nad mapovým podkladem** v měřítku 1: 200 000 nebo 1: 100 000 a obsahují jevy zobrazitelné v daném měřítku. Grafická část může být doplněna schématy. Je-li to účelné, lze výkres ploch a koridorů dále členit na samostatné výkresy. {uc=A}

II. Odůvodnění územního rozvojového plánu

(1) Textová část odůvodnění územního rozvojového plánu obsahuje zejména

a) stručný popis postupu pořízení územního rozvojového plánu,

b) vyhodnocení souladu s cíli a úkoly územního plánování a s požadavky tohoto zákona,

c) vyhodnocení souladu s politikou územního rozvoje,

d) vyhodnocení souladu s požadavky jiných právních předpisů a se stanovisky dotčených orgánů, popřípadě s výsledkem řešení rozporů,

e) vyhodnocení souladu se zadáním, ~~zprávou o uplatňování nebo zadáním změny nebo požadavku podle § 71 odst. 1 písm. h),~~ {uc=A}

f) základní informace o výsledcích vyhodnocení vlivů na udržitelný rozvoj území, včetně výsledků vyhodnocení vlivů na životní prostředí a posouzení vlivu na předmět ochrany a celistvost evropsky významné lokality nebo ptačí oblasti,

g) sdělení, jak bylo zohledněno vyhodnocení vlivů na udržitelný rozvoj území,

h) stanovisko příslušného orgánu k vyhodnocení vlivů na životní prostředí se sdělením, jak bylo zohledněno s uvedením závažných důvodů, pokud některé požadavky nebo podmínky zohledněny nebyly, a další části prohlášení podle § 10g odst. 5 zákona o posuzování vlivů na životní prostředí,

i) komplexní zdůvodnění přijatého řešení, včetně zdůvodnění vybrané varianty,

j) kvalifikovaný odhad záborů půdního fondu pro navrhované zastavitelné plochy a koridory a

k) vyhodnocení připomínek, včetně jeho odůvodnění.

(2) Součástí textové části odůvodnění je i posouzení souladu územního rozvojového plánu s jednotným standardem.

(3) V případě změny územního rozvojového plánu je součástí odůvodnění text s vyznačením změn.

(4) ~~Grafická část odůvodnění~~ **Odůvodnění** územního rozvojového plánu ~~obsahuje zejména~~ **může být doplněno grafickou částí.** {uc=A}

~~a) koordinační výkres v měřítku 1 : 200 000 nebo 1 : 100 000 a~~

~~b) je-li to účelné, schéma širších vztahů dokumentující vazby na území sousedních států.~~

#### Příloha č. 7 k zákonu č. 283/2021 Sb.

*Obsah a struktura zásad územního rozvoje*

I. Zásady územního rozvoje

(1) Textová část zásad územního rozvoje obsahuje

a) koncepci rozvoje území kraje a rozvoje a ochrany jeho hodnot, včetně koncepce sídelní struktury,

b) zpřesnění vymezení rozvojových oblastí a rozvojových os vymezených v politice územního rozvoje a vymezení nadmístních rozvojových oblastí a nadmístních rozvojových os,

c) zpřesnění ~~vymezení~~ specifických oblastí vymezených v politice územního rozvoje a ~~vymezení~~ specifických oblastí nadmístního významu, {uc=A}

d) přebíraná věcná řešení územního rozvojového plánu, zejména ~~zastavitelné plochy, transformační~~ plochy a koridory a akcelerační oblasti a, je-li to účelné, jejich zpřesnění, {uc=A}

e) vymezení ~~zastavitelných ploch, transformačních~~ ploch a koridorů nadmístního významu, včetně stanovení jejich účelu a požadavků na jejich využití, {uc=A}

f) vymezení akceleračních oblastí nadmístního významu, včetně určení druhu primární energie zdrojů, pro něž se oblast vymezuje,

g) ~~vymezení~~ ploch a koridorů **zelené infrastruktury, zejména** regionálního územního systému ekologické stability a, je-li to účelné, zpřesnění ~~vymezení~~ ploch a koridorů nadregionálního územního systému ekologické stability, {uc=A}

h) vymezení ploch pro těžbu nerostů,

i) stanovení cílových kvalit krajin, včetně územních podmínek pro jejich zachování nebo dosažení,

j) přebírané vymezení ploch a koridorů pro veřejně prospěšné stavby, veřejně prospěšná opatření, stavby a opatření k zajišťování obrany a bezpečnosti státu a ploch pro asanace z územního rozvojového plánu a, je-li to účelné, jejich zpřesnění,

k) vymezení veřejně prospěšných staveb, veřejně prospěšných opatření, staveb a opatření k zajišťování obrany a bezpečnosti státu a ploch pro asanace,

l) stanovení požadavků na koordinaci územně plánovací činnosti obcí a na řešení v územně plánovací dokumentaci obcí s přihlédnutím ke stanovené sídelní struktuře, a

m) kompenzační opatření podle zákona o ochraně přírody a krajiny, byla-li stanovena.

(2) Je-li to účelné, textová část zásad územního rozvoje dále obsahuje

a) vymezení ploch a koridorů územních rezerv,

b) vymezení ploch a koridorů, ve kterých se ukládá prověření změn jejich využití územní studií,

c) ~~je-li to účelné,~~ stanovení pořadí provádění změn v území a {uc=A}

d) ~~vymezení definic~~ **definici** pojmů, které nejsou definovány v tomto zákoně nebo v jiných právních předpisech. {uc=A}

(3) Grafická část zásad územního rozvoje **má formu prostorových dat a** obsahuje {uc=A}

a) výkres uspořádání území kraje obsahující zejména rozvojové oblasti a rozvojové osy, specifické oblasti a sídelní strukturu,

b) výkres ploch a koridorů, včetně **zelené infrastruktury a** akceleračních oblastí celostátního a nadmístního významu ~~a územního systému ekologické stability nadregionálního a regionálního významu~~, {uc=A}

c) výkres krajin, pro které se stanovují cílové kvality,

d) výkres veřejně prospěšných staveb, opatření a asanací,

e) je-li to účelné, výkres oblastí, ploch a koridorů, ve kterých je uloženo prověření změn jejich využití územní studií a

f) je-li to účelné, výkres pořadí provádění změn v území.

(4) Výkresy**, které jsou součástí grafické části,** se ~~vydávají~~ **zpracovávají nad mapovým podkladem** v měřítku 1: 50 000 nebo v odůvodněných případech 1: 100 000. Výkresy obsahují jevy zobrazitelné v daném měřítku. Ve výkresech se vyznačí hranice řešeného území. V případě potřeby lze výkresy uvedené v odstavci 3 písm. a) a b) dále členit na samostatné výkresy nebo vybranou problematiku řešit samostatným výkresem v měřítku 1: 25 000. Grafická část může být doplněna schématy. {uc=A}

II. Odůvodnění zásad územního rozvoje

(1) Textová část odůvodnění zásad územního rozvoje obsahuje zejména

a) stručný popis postupu pořízení zásad územního rozvoje,

b) vyhodnocení souladu s cíli a úkoly územního plánování a s požadavky tohoto zákona,

c) vyhodnocení souladu s požadavky jiných právních předpisů a se stanovisky dotčených orgánů, popřípadě s výsledkem řešení rozporů,

d) vyhodnocení souladu s politikou územního rozvoje a územním rozvojovým plánem,

e) vyhodnocení souladu se zadáním, ~~zprávou o uplatňování nebo zadáním změny,~~ {uc=A}

f) základní informace o výsledcích vyhodnocení vlivů na udržitelný rozvoj území, včetně výsledků vyhodnocení vlivů na životní prostředí a posouzení vlivu na předmět ochrany a celistvost evropsky významné lokality nebo ptačí oblasti,

g) sdělení, jak bylo zohledněno vyhodnocení vlivů na udržitelný rozvoj území,

h) stanovisko příslušného orgánu k vyhodnocení vlivů na životní prostředí se sdělením, jak bylo zohledněno s uvedením závažných důvodů, pokud některé požadavky nebo podmínky zohledněny nebyly, a další části prohlášení podle § 10g odst. 5 zákona o posuzování vlivů na životní prostředí,

i) komplexní zdůvodnění přijatého řešení, včetně zdůvodnění vybrané varianty,

j) výčet záležitostí týkajících se rozvoje území státu, které nejsou obsaženy v politice územního rozvoje nebo územním rozvojovém plánu, s odůvodněním potřeby jejich vymezení,

k) kvalifikovaný odhad záborů půdního fondu pro navrhované plochy a koridory a

l) vyhodnocení připomínek, včetně jeho odůvodnění.

(2) Součástí textové části odůvodnění je i posouzení souladu zásad územního rozvoje s jednotným standardem.

(3) V případě změny zásad územního rozvoje je součástí odůvodnění text s vyznačením změn.

(4) ~~Grafická část odůvodnění~~ **Odůvodnění** zásad územního rozvoje ~~obsahuje zejména~~ **může být doplněno grafickou částí.** {uc=A}

~~a) koordinační výkres v měřítku 1 : 50 000 nebo 1 : 100 000 a~~

~~b) výkres širších vztahů v měřítku 1 : 500 000.~~

#### Příloha č. 8 k zákonu č. 283/2021 Sb.

*Obsah a struktura územního plánu*

I. Územní plán

(1) Textová část územního plánu obsahuje

a) vymezení ~~zastavěného~~ **zastavitelného** území, {uc=A}

b) základní koncepci rozvoje území obce,

c) urbanistickou koncepci,

d) koncepci veřejné infrastruktury,

e) koncepci uspořádání krajiny,

**f) požadavky na rozvoj, zachování nebo změnu charakteru území,**

~~f)~~ **g)** podmínky pro využití a prostorové uspořádání ~~vymezených ploch s rozdílným způsobem využití~~ **území**, {uc=A}

~~g)~~ **h)** vymezení veřejně prospěšných staveb, veřejně prospěšných opatření, staveb a opatření k zajišťování obrany a bezpečnosti státu**, ploch těžby** a ploch pro asanaci, {uc=A}

~~h)~~ **i)** kompenzační opatření podle zákona o ochraně přírody a krajiny, byla-li stanovena a

~~i)~~ **j)** v případě územního plánu pro část území ~~hlavního města Prahy~~ **obce** vymezení řešeného území. {uc=A}

(2) Je-li to účelné, textová část územního plánu dále obsahuje

a) členění území podle převažujícího charakteru na lokality,

~~b) vymezení zastavitelného území,~~

~~c)~~ **b)** vymezení ploch a koridorů územních rezerv,

~~d)~~ **c)** vymezení ploch a koridorů, ve kterých je rozhodování o změnách v území podmíněno plánovací smlouvou,

~~e)~~ **d)** vymezení ploch a koridorů, ve kterých je rozhodování o změnách v území podmíněno zpracováním územní studie,

~~f)~~ **e)** vymezení ploch a koridorů, ve kterých je rozhodování o změnách v území podmíněno vydáním regulačního plánu,

~~g)~~ **f)** vymezení ploch a koridorů, ve kterých je rozhodování v území podmíněno realizací architektonické nebo urbanistické soutěže,

~~h)~~ **g)** vymezení architektonicky významných staveb nebo urbanisticky významných celků,

~~i)~~ **h)** stanovení pořadí provádění změn v území,

~~j)~~ **i)** stanovení požadavků na výstavbu odchylně od prováděcího právního předpisu u části území obce, pro které územní plán obsahuje prvky regulačního plánu, a

~~k)~~ **j)** ~~vymezení definic~~ **definici** pojmů, které nejsou definovány v tomto zákoně nebo v jiných právních předpisech. {uc=A}

(3) Grafická část územního plánu **má formu prostorových dat a** obsahuje {uc=A}

a) výkres základního členění území, který obsahuje **zejména** vyznačení {uc=A}

1. hranice řešeného území,

2. hranice ~~zastavěného~~ **zastavitelného** území, {uc=A}

3. zastavitelných ploch, transformačních ploch a ploch změn ~~v krajině~~, {uc=A}

~~4. koridorů dopravní a technické infrastruktury,~~

~~5.~~ **4.** ploch a koridorů územních rezerv,

~~6.~~ **5.** ploch a koridorů, ve kterých je rozhodování o změnách v území podmíněno uzavřením plánovací smlouvy, zpracováním územní studie vydáním regulačního plánu nebo realizací architektonické nebo urbanistické soutěže,

~~7.~~ **6.** části území obce, pro které územní plán obsahuje prvky regulačního plánu,

b) hlavní výkres, který obsahuje **zejména** {uc=A}

1. vyznačení hranice zastavěného území,

2. základní koncepci rozvoje území obce,

3. urbanistickou koncepci, včetně vymezení zastavitelných ploch**, nestavebních ploch** a ~~transformačních~~ ploch **změn**, {uc=A}

4. koncepci uspořádání krajiny, včetně vymezení zelené infrastruktury a územního systému ekologické stability a vymezení ploch změn ~~v krajině~~, {uc=A}

5. koncepci veřejné infrastruktury, včetně ~~vymezení~~ ploch a koridorů pro dopravní a technickou infrastrukturu a akceleračních oblastí, {uc=A}

6. vymezení ploch ~~s rozdílným způsobem~~ využití **území a prostorového uspořádání**, {uc=A}

7. je-li to účelné, vymezení ploch a koridorů pro územní rezervy,

8. je-li to účelné, hranici lokalit a ~~hranici zastavitelného území a~~ {uc=A}

9. je-li to účelné, ~~vyznačení lokalit a zastavitelného území~~ **vymezení ploch těžby**, {uc=A}

c) výkres veřejně prospěšných staveb, opatření a asanací,

d) je-li to účelné, samostatný výkres územního plánu s prvky regulačního plánu a

e) je-li to účelné, výkres pořadí provádění změn v území.

(4) Je-li to účelné, lze ~~urbanistickou koncepci, koncepci uspořádání krajiny a koncepci veřejné infrastruktury zpracovat v~~ **hlavní výkres rozdělit do** samostatných ~~výkresech~~ **výkresů**. {uc=A}

(5) Výkresy~~, které jsou součástí~~ grafické části územního plánu, se zpracovávají nad mapovým podkladem v měřítku katastrální mapy nebo ~~v měřítku 1: 5 000 a vydávají se~~ v měřítku 1: 5 000 nebo 1:10 000. Pro zvlášť rozsáhlá území lze výkres základního členění území a samostatné výkresy koncepce uspořádání krajiny a koncepce veřejné infrastruktury vydat v měřítku 1: 25 000. Výkresy obsahují jevy zobrazitelné v daném měřítku. Grafická část může být doplněna schématy. {uc=A}

(6) Je-li územní plán s prvky regulačního plánu zpracován pro vymezenou část území obce, lze tuto část územního plánu vydat jako samostatný výkres v měřítku katastrální mapy nebo v měřítku 1 : 1 000 nebo 1 : 500.

(7) Výkresy územního plánu vojenského újezdu se zpracovávají nad Státní mapou v měřítku 1: 5 000 ~~a vydávají~~ **nebo** v měřítku, které stanoví Ministerstvo obrany v zadání územního plánu. {uc=A}

II. Odůvodnění územního plánu

(1) Textová část odůvodnění územního plánu obsahuje zejména

a) stručný popis postupu pořízení územního plánu,

b) vyhodnocení souladu s cíli a úkoly územního plánování a s požadavky tohoto zákona,

c) vyhodnocení souladu s požadavky jiných právních předpisů a se stanovisky dotčených orgánů, popřípadě s výsledkem řešení rozporů,

d) vyhodnocení souladu s politikou územního rozvoje a nadřazenou územně plánovací dokumentací,

e) vyhodnocení souladu se zadáním, ~~zprávou o uplatňování nebo zadáním změny,~~ {uc=A}

f) základní informace o výsledcích vyhodnocení vlivů na udržitelný rozvoj území, včetně výsledků vyhodnocení vlivů na životní prostředí a posouzení vlivu na předmět ochrany a celistvost evropsky významné lokality nebo ptačí oblasti,

g) sdělení, jak bylo zohledněno vyhodnocení vlivů na udržitelný rozvoj území,

h) stanovisko příslušného orgánu k vyhodnocení vlivů na životní prostředí se sdělením, jak bylo zohledněno s uvedením závažných důvodů, pokud některé požadavky nebo podmínky zohledněny nebyly, a další části prohlášení podle § 10g odst. 5 zákona o posuzování vlivů na životní prostředí,

i) komplexní zdůvodnění přijatého řešení, včetně zdůvodnění vybrané varianty a vyloučení záměrů podle § 122 odst. 3,

j) výčet záležitostí nadmístního významu, které nejsou obsaženy v zásadách územního rozvoje, s odůvodněním potřeby jejich vymezení,

~~k) vyhodnocení účelného využití zastavěného území a vyhodnocení potřeby vymezení zastavitelných ploch,~~

~~l)~~ **k)** výčet prvků regulačního plánu, případně s odchylně stanovenými požadavky na výstavbu s odůvodněním jejich vymezení,

~~m)~~ **l)** vyhodnocení předpokládaných důsledků navrhovaného řešení na zemědělský půdní fond a pozemky určené k plnění funkce lesa a

~~n)~~ **m)** vyhodnocení připomínek, včetně jeho odůvodnění.

(2) Součástí textové části odůvodnění je i posouzení souladu územního plánu s jednotným standardem.

(3) V případě změny územního plánu je součástí odůvodnění text s vyznačením změn.

(4) ~~Grafická část odůvodnění~~ **Odůvodnění** územního plánu **může být doplněno grafickou částí, která** obsahuje zejména {uc=A}

~~a) koordinační výkres v měřítku 1 : 5 000 nebo 1:10 000,~~

~~b)~~ **a)** výkres širších vztahů v měřítku 1 : 50 000 nebo 1 : 100 000 a

~~c)~~ **b)** výkres předpokládaných záborů půdního fondu v měřítku 1 : 5 000 nebo 1:10 000.

#### Příloha č. 9 k zákonu č. 283/2021 Sb.

*Obsah a struktura regulačního plánu*

I. Regulační plán

(1) Textová část regulačního plánu obsahuje

a) vymezení řešeného území,

b) podrobné podmínky pro vymezení a využití pozemků,

c) podrobné podmínky pro umístění a prostorové uspořádání staveb,

d) podrobné podmínky pro umístění a prostorové uspořádání staveb veřejné infrastruktury,

e) podrobné podmínky pro ochranu hodnot, charakteru území a krajinného rázu.

(2) Je-li to účelné, textová část regulačního plánu dále obsahuje

a) **a) podrobné podmínky pro umístění a prostorové uspořádání staveb, b) podrobné podmínky pro umístění a prostorové uspořádání staveb veřejné infrastruktury, c) podrobné podmínky pro ochranu hodnot, charakteru území a krajinného rázu,** podmínky pro příznivé životní prostředí a zelenou infrastrukturu, včetně vymezení a využití pozemků územního systému ekologické stability, {uc=A}

b) **a) podrobné podmínky pro umístění a prostorové uspořádání staveb, b) podrobné podmínky pro umístění a prostorové uspořádání staveb veřejné infrastruktury, c) podrobné podmínky pro ochranu hodnot, charakteru území a krajinného rázu,** vymezení veřejně prospěšných staveb, veřejně prospěšných opatření, staveb a opatření k zajišťování obrany a bezpečnosti státu a vymezení pozemků pro asanaci, pro které lze práva k pozemkům a stavbám vyvlastnit, {uc=A}

c) **a) podrobné podmínky pro umístění a prostorové uspořádání staveb, b) podrobné podmínky pro umístění a prostorové uspořádání staveb veřejné infrastruktury, c) podrobné podmínky pro ochranu hodnot, charakteru území a krajinného rázu,** stanovení pořadí změn v území (etapizaci), {uc=A}

d) podmínky pro požární ochranu,

e) podmínky pro ochranu veřejného zdraví,

f) stanovení požadavků na výstavbu odchylně od prováděcího právního předpisu,

g) vymezení architektonicky významných staveb nebo urbanisticky významných celků,

h) vymezení záměrů, pro které je uzavření plánovací smlouvy podmínkou pro rozhodování,

i) vymezení záměrů, pro které je realizace architektonické nebo urbanistické soutěže podmínka pro rozhodování,

j) vymezení staveb domů pro dostupné nájemní bydlení, a

k) vymezení definic pojmů, které nejsou definovány v tomto zákoně nebo v jiných právních předpisech.

(3) Grafická část regulačního plánu **má formu prostorových dat a** obsahuje {uc=A}

a) hlavní výkres obsahující hranici řešené plochy, vymezení a využití pozemků a graficky vyjádřitelné podmínky umístění a prostorového uspořádání staveb,

b) výkres veřejně prospěšných staveb, opatření a asanací a

c) je-li to účelné, výkres pořadí změn v území (etapizace).

(4) Je-li to účelné, lze ~~graficky vyjádřitelné podmínky umístění a prostorového uspořádání staveb, včetně jejich napojení na veřejnou dopravní a technickou infrastrukturu, zpracovat v~~ **hlavní výkres rozdělit do** samostatných ~~výkresech~~ **výkresů**. {uc=A}

(5) Výkresy, které jsou součástí grafické části regulačního plánu, se zpracovávají ~~a vydávají~~ zpravidla v měřítku 1: 1 000, popřípadě 1: 2 000 nebo 1: 500, s výjimkou výkresu veřejně prospěšných staveb, opatření a asanací, který se zpracovává a vydává v měřítku katastrální mapy. Výkres širších vztahů se zpracovává a vydává v měřítku hlavního výkresu územního plánu. Výkresy obsahují jevy zobrazitelné v daném měřítku. Grafická část může být doplněna schématy. {uc=A}

II. Odůvodnění regulačního plánu

(1) Textová část odůvodnění regulačního plánu obsahuje zejména

a) stručný popis postupu pořízení regulačního plánu,

b) vyhodnocení souladu s cíli a úkoly územního plánování a s požadavky tohoto zákona,

c) vyhodnocení souladu s požadavky jiných právních předpisů a se stanovisky dotčených orgánů, popřípadě s výsledkem řešení rozporů,

d) vyhodnocení souladu s politikou územního rozvoje a nadřazenou územně plánovací dokumentací,

e) vyhodnocení souladu se zadáním ~~nebo zadáním změny~~, {uc=A}

f) komplexní zdůvodnění přijatého řešení, včetně vybrané varianty,

g) odůvodnění stanovení požadavků na výstavbu odchylně od prováděcího právního předpisu,

h) kvalifikovaný odhad záborů půdního fondu pro navrhované plochy a koridory a

i) vyhodnocení připomínek, včetně jeho odůvodnění.

(2) Součástí textové části odůvodnění je i posouzení souladu regulačního plánu s jednotným standardem.

(3) V případě změny regulačního plánuje součástí odůvodnění text s vyznačením změn.

(4) ~~Grafická část odůvodnění~~ **Odůvodnění** regulačního plánu **může být doplněno grafickou částí, která** obsahuje zejména {uc=A}

~~a) koordinační výkres v měřítku 1 : 1 000 nebo 1 : 2 000,~~

~~b)~~ **a)** výkres širších vztahů v měřítku 1 : 5 000 nebo 1:10 000 a

~~c)~~ **b)** výkres předpokládaných záborů půdního fondu v měřítku 1 : 1 000 nebo 1 : 2 000.

**Poznámky pod čarou:**

1) § 34 zákona č. 128/2000 Sb., o obcích (obecní zřízení), ve znění pozdějších předpisů. § 14b zákona č. 131/2000 Sb., o hlavním městě Praze, ve znění pozdějších předpisů.
2) § 3 odst. 1 písm. a) zákona č. 114/1992 Sb., o ochraně přírody a krajiny, ve znění pozdějších předpisů.
3) Čl. 15 a 16 směrnice Evropského parlamentu a Rady (EU) 2018/2001 ze dne 11. prosince 2018 o podpoře využívání energie z obnovitelných zdrojů, v platném znění.
5) § 29 zákona č. 222/1999 Sb., o zajišťování obrany České republiky, ve znění pozdějších předpisů.
6) § 2 odst. 4 zákona č. 312/2002 Sb., o úřednících územních samosprávných celků a o změně některých zákonů, ve znění pozdějších předpisů.
7) Zákon č. 312/2002 Sb., o úřednících územních samosprávných celků a o změně některých zákonů, ve znění pozdějších předpisů.
8) § 34 odst. 1 zákona č. 312/2002 Sb.
9) Zákon č. 262/2006 Sb., zákoník práce, ve znění pozdějších předpisů.
~~10) § 3 odst. 7 zákona č. 106/1999 Sb., o svobodném přístupu k informacím, ve znění pozdějších předpisů.~~
~~11) § 2 písm. e) zákona č. 123/1998 Sb., o právu na informace o životním prostředí, ve znění pozdějších předpisů.~~
14) § 4b až 4d zákona č. 200/1994 Sb., o zeměměřictví a o změně a doplnění některých zákonů souvisejících s jeho zavedením, ve znění pozdějších předpisů.
15) Například zákon č. 61/1988 Sb., o hornické činnosti, výbušninách a o státní báňské správě, ve znění pozdějších předpisů.
16) § 4b odst. 7 a 8 zákona č. 200/1994 Sb.
17) Zákon č. 111/2009 Sb., o základních registrech, ve znění pozdějších předpisů.
18) Evropská úmluva o krajině, vyhlášená pod č. 12/2017 Sb. m. s.
19) § 17 písm. d) a § 18 písm. a) a b) zákona č. 360/1992 Sb., o výkonu povolání autorizovaných architektů a o výkonu povolání autorizovaných inženýrů a techniků činných ve výstavbě.
20) § 3 písm. f) zákona č. 100/2001 Sb., o posuzování vlivů na životní prostředí a o změně některých souvisejících zákonů (zákon o posuzování vlivů na životní prostředí), ve znění pozdějších předpisů.
21) § 10i zákona č. 100/2001 Sb.
22) Zákon č. 100/2001 Sb., ve znění pozdějších předpisů.
23) Zákon č. 13/1997 Sb., o pozemních komunikacích, ve znění pozdějších předpisů.
24) Zákon č. 541/2020 Sb., o odpadech, ve znění zákona č. 261/2021 Sb. Zákon č. 254/2001 Sb., o vodách a o změně některých zákonů (vodní zákon), ve znění pozdějších předpisů.
25) Zákon č. 12/1997 Sb., o bezpečnosti a plynulosti provozu na pozemních komunikacích, ve znění pozdějších předpisů.
26) Zákon č. 133/1985 Sb., o požární ochraně, ve znění pozdějších předpisů. Vyhláška č. 23/2008 Sb., o technických podmínkách požární ochrany staveb, ve znění vyhlášky č. 268/2011 Sb.
27) Zákon č. 258/2000 Sb., o ochraně veřejného zdraví a o změně některých souvisejících zákonů, ve znění pozdějších předpisů. Nařízení vlády č. 272/2011 Sb., o ochraně zdraví před nepříznivými účinky hluku a vibrací, ve znění pozdějších předpisů.
28) Například zákon č. 114/1992 Sb., zákon č. 334/1992 Sb., o ochraně zemědělského půdního fondu, ve znění pozdějších předpisů, zákon č. 201/2012 Sb., o ochraně ovzduší, ve znění pozdějších předpisů.
29) Zákon č. 406/2000 Sb., o hospodaření energií, ve znění pozdějších předpisů. Vyhláška č. 264/2020 Sb., o energetické náročnosti budov.
30) Zákon č. 541/2020 Sb. Vyhláška č. 273/2021 Sb., o podrobnostech nakládání s odpady.
31) § 3 odst. 2 písm. e) zákona č. 263/2016 Sb., atomový zákon, ve znění pozdějších předpisů.
32) Zákon č. 128/2000 Sb.
33) Příloha I nařízení Evropského parlamentu a Rady (EU) č. 305/2011 ze dne 9. března 2011, kterým se stanoví harmonizované podmínky pro uvádění stavebních výrobků na trh a kterým se zrušuje směrnice Rady 89/106/EHS, v platném znění.
34) Zákon č. 22/1997 Sb., o technických požadavcích na výrobky a o změně a doplnění některých zákonů, ve znění pozdějších předpisů, Nařízení vlády č. 163/2002 Sb., kterým se stanoví technické požadavky na vybrané stavební výrobky, ve znění pozdějších předpisů.
35) Zákon č. 360/1992 Sb., o výkonu povolání autorizovaných architektů a o výkonu povolání autorizovaných inženýrů a techniků činných ve výstavbě, ve znění pozdějších předpisů. Zákon č. 200/1994 Sb., o zeměměřictví a o změně a doplnění některých zákonů souvisejících s jeho zavedením, ve znění pozdějších předpisů.
36) Zákon č. 200/1994 Sb., o zeměměřictví a o změně a doplnění některých zákonů souvisejících s jeho zavedením, ve znění pozdějších předpisů.
37) Zákon č. 406/2000 Sb.
38) Například zákon č. 200/1994 Sb., zákon č. 44/1988 Sb., o ochraně a využití nerostného bohatství (horní zákon).
39) Například zákon č. 360/1992 Sb., zákon č. 200/1994 Sb.
40) Zákon č. 309/2006 Sb., kterým se upravují další požadavky bezpečnosti a ochrany zdraví při práci v pracovněprávních vztazích a o zajištění bezpečnosti a ochrany zdraví při činnosti nebo poskytování služeb mimo pracovněprávní vztahy (zákon o zajištění dalších podmínek bezpečnosti a ochrany zdraví při práci), ve znění pozdějších předpisů.
41) § 1194 zákona č. 89/2012 Sb., občanský zákoník, ve znění pozdějších předpisů.
42) § 7 zákona č. 100/2001 Sb. § 45h až 45i zákona č. 114/1992 Sb.
43) Směrnice Evropského parlamentu a Rady 2011/92/EU ze dne 13. prosince 2011 o posuzování vlivů některých veřejných a soukromých záměrů na životní prostředí. Směrnice Evropského parlamentu a Rady 2014/52/EU ze dne 16. dubna 2014, kterou se mění směrnice Rady 2011/92/EU o posuzování vlivů některých veřejných a soukromých záměrů na životní prostředí.
48) Zákon č. 256/2013 Sb., o katastru nemovitostí (katastrální zákon), ve znění pozdějších předpisů.
49) Vyhláška č. 357/2013 Sb., o katastru nemovitostí (katastrální vyhláška), ve znění pozdějších předpisů.
50) § 4b zákona č. 200/1994 Sb.
51) § 3 odst. 1 písm. a) bod 1 zákona č. 151/1997 Sb., o oceňování majetku a o změně některých zákonů (zákon o oceňování majetku), ve znění pozdějších předpisů.
52) § 2 zákona č. 458/2000 Sb., o podmínkách podnikání a o výkonu státní správy v energetických odvětvích a o změně některých zákonů (energetický zákon), ve znění pozdějších předpisů.
54) § 31 zákona č. 128/2000 Sb.
55) Zákon č. 365/2000 Sb., o informačních systémech veřejné správy a o změně některých dalších zákonů, ve znění pozdějších předpisů.
56) Zákon č. 12/2020 Sb., o právu na digitální služby a o změně některých zákonů.
57) § 4d zákona č. 200/1994 Sb.
58) § 21 až 26 zákona č. 312/2002 Sb.
59) § 2 zákona č. 449/2001 Sb., o myslivosti, ve znění pozdějších předpisů.
60) Zákon č. 458/2000 Sb., o podmínkách podnikání a o výkonu státní správy v energetických odvětvích a o změně některých zákonů, ve znění pozdějších předpisů.
61) § 10 zákona č. 13/1997 Sb.
62) § 2 zákona č. 311/2006 Sb., o pohonných hmotách a čerpacích stanicích pohonných hmot a o změně některých souvisejících zákonů (zákon o pohonných hmotách), ve znění pozdějších předpisů.
63) § 1 odst. 6 zákona č. 416/2009 Sb., o urychlení výstavby dopravní, vodní a energetické infrastruktury a infrastruktury elektronických komunikací (liniový zákon).
64) Vyhláška č. 104/1997 Sb., kterou se provádí zákon o pozemních komunikacích, ve znění pozdějších předpisů.
65) Zákon č. 189/1999 Sb., o nouzových zásobách ropy, o řešení stavů ropné nouze a o změně některých souvisejících zákonů (zákon o nouzových zásobách ropy), ve znění pozdějších předpisů.
66) Vyhláška č. 142/2018 Sb., o náležitostech posouzení vlivu záměru a koncepce na evropsky významné lokality a ptačí oblasti a o náležitostech hodnocení vlivu závažného zásahu na zájmy ochrany přírody a krajiny.
67) § 6a zákona č. 406/2000 Sb., o hospodaření energií, ve znění pozdějších předpisů.
67) Vyhláška č. 38/2022 Sb., o kontrole provozovaného systému vytápění a kombinovaného systému vytápění a větrání.
**68) Zejména zákon č. 258/2000 Sb., o ochraně veřejného zdraví a o změně některých souvisejících zákonů, ve znění pozdějších předpisů; zákon č. 164/2001 Sb., o přírodních léčivých zdrojích, zdrojích přírodních minerálních vod, přírodních léčebných lázních a lázeňských místech a o změně některých souvisejících zákonů (lázeňský zákon), ve znění pozdějších předpisů.**
**69) Zejména zákon č. 17/1992 Sb., o životním prostředí, ve znění pozdějších předpisů, zákon č. 114/1992 Sb., o ochraně přírody a krajiny, ve znění pozdějších předpisů, zákon č. 185/2001 Sb., o odpadech a o změně některých dalších zákonů, ve znění pozdějších předpisů, zákon č. 254/2001 Sb., o vodách a o změně některých zákonů (vodní zákon), ve znění pozdějších předpisů, zákon č. 201/2012 Sb., o ochraně ovzduší, ve znění pozdějších předpisů, Nařízení Evropského parlamentu a Rady (EU) 2024/1991 ze dne 24. června 2024 o obnově přírody a o změně nařízení (EU) 2022/869.**
**70) Zejména zákon č. 20/1987 Sb., o státní památkové péči, ve znění pozdějších předpisů.**
**71) Zejména zákon č. 266/1994 Sb., o dráhách, ve znění pozdějších předpisů, zákon č. 114/1995 Sb., o vnitrozemské plavbě, ve znění pozdějších předpisů, zákon č. 13/1997 Sb., o pozemních komunikacích, ve znění pozdějších předpisů, zákon č. 49/1997 Sb., o civilním letectví a o změně a doplnění zákona č. 455/1991 Sb., o živnostenském podnikání (živnostenský zákon), ve znění pozdějších předpisů, ve znění pozdějších předpisů, zákon č. 274/2001 Sb., o vodovodech a kanalizacích pro veřejnou potřebu a o změně některých zákonů (zákon o vodovodech a kanalizacích), ve znění pozdějších předpisů, zákon č. 127/2005 Sb., o elektronických komunikacích a o změně některých souvisejících zákonů (zákon o elektronických komunikacích), ve znění pozdějších předpisů, zákon č. 416/2009 Sb., o urychlení výstavby dopravní, vodní a energetické infrastruktury a infrastruktury elektronických komunikací, ve znění pozdějších předpisů.**
**72) Zejména zákon č. 252/1997 Sb., o zemědělství, ve znění pozdějších předpisů, zákon č. 334/1992 Sb., o ochraně zemědělského půdního fondu, ve znění pozdějších předpisů, zákon č. 289/1995 Sb., o lesích a o změně a doplnění některých zákonů (lesní zákon), ve znění pozdějších předpisů, zákon č. 166/1999 Sb. o veterinární péči a o změně některých souvisejících zákonů (veterinární zákon), ve znění pozdějších předpisů, zákon č. 246/1992 Sb., na ochranu zvířat proti týrání, ve znění pozdějších předpisů.**
**73) Zejména zákon č. 44/1988 Sb., o ochraně a využití nerostného bohatství (horní zákon), ve znění pozdějších předpisů, zákon č. 61/1988 Sb., o hornické činnosti, výbušninách a o státní báňské správě, ve znění pozdějších předpisů, zákon č. 157/2009 Sb., o nakládání s těžebním odpadem a o změně některých zákonů, ve znění pozdějších předpisů.**
**74) Zejména zákon č. 406/2000 Sb., o hospodaření energií, ve znění pozdějších předpisů, zákon č. 458/2000 Sb., o podmínkách podnikání a o výkonu státní správy v energetických odvětvích a o změně některých zákonů (energetický zákon), ve znění pozdějších předpisů, zákon č. 165/2012 Sb., o podporovaných zdrojích energie a o změně některých zákonů, ve znění pozdějších předpisů, zákon č. 263/2016 Sb., atomový zákon, ve znění pozdějších předpisů, zákon č. 249/2025 Sb., o urychlení využívání některých obnovitelných zdrojů energie a o změně souvisejících zákonů (zákon o urychlení využívání obnovitelných zdrojů energie).**
**75) Zejména zákon č. 133/1985 Sb., o požární ochraně, ve znění pozdějších předpisů, zákon č. 239/2000 Sb., o integrovaném záchranném systému a o změně některých zákonů, ve znění pozdějších předpisů.**
**76) Zejména zákon č. 76/2002 Sb., o integrované prevenci a omezování znečištění, o integrovaném registru znečišťování a o změně některých zákonů (zákon o integrované prevenci), ve znění pozdějších předpisů, zákon č. 224/2015 Sb., o prevenci závažných havárií způsobených vybranými nebezpečnými chemickými látkami nebo chemickými směsmi a o změně zákona č. 634/2004 Sb., o správních poplatcích, ve znění pozdějších předpisů, (zákon o prevenci závažných havárií), ve znění pozdějších předpisů, zákon č. 167/2008 Sb., o předcházení ekologické újmě a o její nápravě a o změně některých zákonů, ve znění pozdějších předpisů.**
**77) Zejména zákon č. 128/2000 Sb., o obcích (obecní zřízení), ve znění pozdějších předpisů, zákon č. 129/2000 Sb., o krajích (krajské zřízení), ve znění pozdějších předpisů, zákon č. 131/2000 Sb., o hlavním městě Praze, ve znění pozdějších předpisů.**
**78) Zejména zákon č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů, § 1 odst. 3 a § 16.**
**79) § 1 odst. 13 zákona č. 416/2009 Sb., o urychlení výstavby strategicky významné infrastruktury, ve znění pozdějších předpisů.**
**80) Zákon č. 20/1987 Sb., o státní památkové péči, ve znění pozdějších předpisů. Zákon č. 44/1988 Sb., o ochraně a využití nerostného bohatství (horní zákon), ve znění pozdějších předpisů. Zákon č. 61/1988 Sb., o hornické činnosti, výbušninách a o státní báňské správě, ve znění pozdějších předpisů. Zákon č. 62/1988 Sb., o geologických pracích a o Českém geologickém úřadu, ve znění pozdějších předpisů. Zákon č. 114/1992 Sb., o ochraně přírody a krajiny, ve znění pozdějších předpisů. Zákon č. 334/1992 Sb., o ochraně zemědělského půdního fondu, ve znění pozdějších předpisů. Zákon č. 266/1994 Sb., o dráhách, ve znění pozdějších předpisů. Zákon č. 114/1995 Sb., o vnitrozemské plavbě, ve znění pozdějších předpisů. Zákon č. 289/1995 Sb., o lesích a o změně a doplnění některých zákonů (lesní zákon), ve znění pozdějších předpisů. Zákon č. 13/1997 Sb., o pozemních komunikacích, ve znění pozdějších předpisů. Zákon č. 49/1997 Sb., o civilním letectví, ve znění pozdějších předpisů. Zákon č. 166/1999 Sb., o veterinární péči a o změně některých souvisejících zákonů (veterinární zákon), ve znění pozdějších předpisů. Zákon č. 222/1999 Sb., o zajišťování obrany České republiky, ve znění pozdějších předpisů. Zákon č. 239/2000 Sb., o integrovaném záchranném systému a o změně některých zákonů, ve znění pozdějších předpisů. Zákon č. 258/2000 Sb., o ochraně veřejného zdraví a o změně některých souvisejících zákonů, ve znění pozdějších předpisů. Zákon č. 406/2000 Sb., o hospodaření energií, ve znění pozdějších předpisů. Zákon č. 458/2000 Sb., o podmínkách podnikání a o výkonu státní správy v energetických odvětvích a o změně některých zákonů (energetický zákon), ve znění pozdějších předpisů. Zákon č. 100/2001 Sb., o posuzování vlivů na životní prostředí a o změně některých souvisejících zákonů (zákon o posuzování vlivů na životní prostředí), ve znění pozdějších předpisů. Zákon č. 164/2001 Sb., o přírodních léčivých zdrojích, zdrojích přírodních minerálních vod, přírodních léčebných lázních a lázeňských místech a o změně některých souvisejících zákonů (lázeňský zákon), ve znění pozdějších předpisů. Zákon č. 254/2001 Sb., o vodách a o změně některých zákonů (vodní zákon), ve znění pozdějších předpisů. Zákon č. 312/2001 Sb., o státních hranicích a o změně zákona č. 200/1990 Sb., o přestupcích, ve znění pozdějších předpisů, (zákon o státních hranicích), ve znění pozdějších předpisů. Zákon č. 139/2002 Sb., o pozemkových úpravách a pozemkových úřadech a o změně zákona č. 229/1991 Sb., o úpravě vlastnických vztahů k půdě a jinému zemědělskému majetku, ve znění pozdějších předpisů, ve znění pozdějších předpisů. Zákon č. 201/2012 Sb., o ochraně ovzduší, ve znění pozdějších předpisů. Zákon č. 224/2015 Sb., o prevenci závažných havárií způsobených vybranými nebezpečnými chemickými látkami nebo chemickými směsmi a o změně zákona č. 634/2004 Sb., o správních poplatcích, ve znění pozdějších předpisů, (zákon o prevenci závažných havárií), ve znění pozdějších předpisů. Zákon č. 263/2016 Sb., atomový zákon, ve znění pozdějších předpisů. Zákon č. 541/2020 Sb., o odpadech, ve znění pozdějších předpisů. Zákon č. 249/2025 Sb., o urychlení využívání některých obnovitelných zdrojů energie a o změně souvisejících zákonů (zákon o urychlení využívání obnovitelných zdrojů energie), ve znění pozdějších předpisů.**
**81) § 1 odst. 5 zákona č. 416/2009 Sb., o urychlení výstavby strategicky významné infrastruktury.**
**82) § 39, 39a a 39b zákona č. 361/2000 Sb., o provozu na pozemních komunikacích a o změnách některých zákonů (zákon o silničním provozu), ve znění pozdějších předpisů.**
**83) § 104a zákona č. 127/2005 Sb., o elektronických komunikacích a o změně některých souvisejících zákonů (zákon o elektronických komunikacích), ve znění pozdějších předpisů, a § 97b zákona č. 458/2000 Sb., o podmínkách podnikání a o výkonu státní správy v energetických odvětvích a o změně některých zákonů (energetický zákon), ve znění pozdějších předpisů.**
**84) § 41 zákona č. 258/2000 Sb., o ochraně veřejného zdraví, ve znění pozdějších předpisů.**
**85) Zákon č. 330/2025 Sb., o správě informací o stavbě a vystavěném prostředí a o změně některých dalších zákonů.**
**86) § 8 odst. 1, § 12 zákona č. 258/2000 Sb., o ochraně veřejného zdraví, ve znění pozdějších předpisů.**
**87) Vyhláška Ministerstva vnitra č. 460/2021 Sb., o kategorizaci staveb z hlediska požární bezpečnosti a ochrany obyvatelstva.**
