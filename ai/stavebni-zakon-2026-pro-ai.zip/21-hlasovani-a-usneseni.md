# Hlasování — PSP, 27. schůze, hlasování č. 117 — 3. čtení tisku 67 (usnesení č. 253)

- **Záznam:** 27. schůze, 117. hlasování, 10. července 2026, 13:04:00 Novela z. - stavební zákon
- **Výsledek:** NÁVRH BYL PŘIJAT
- **Souhrn:** Přítomno 170 · Je třeba 86 · Ano 88 · Ne 79 · Nepřihlášen 2 · Omluven 28 · Zdržel se 3
- **Originál:** https://www.psp.cz/sqw/hlasy.sqw?G=88252
- **Staženo:** 2026-10-21

## Jmenovitě

### ANO2011

- Věra Adámková — ano
- Andrej Babiš — ano
- Ondřej Babka — zdržel se
- Pavel Bartoň — ano
- Jana Berkovcová — ano
- Drahomír Blažej — ano
- Jiří Bouška — ano
- Milan Brázdil — omluven
- František Bureš — ano
- Jana Demjanová — ano
- Denis Doksanský — ano
- Lenka Dražilová — ano
- Jaroslav Faltýnek — omluven
- Kamal Farhan — ano
- Eva Fialová — ano
- Stanislav Fridrich — ano
- Karin Gajdová — ano
- Jana Hanzlíková — ano
- Karel Havlíček — ano
- Vlastimil Hebr — ano
- Tomáš Helebrant — ano
- Igor Hendrych — ano
- Monika Hubíková — omluven
- Miloslav Janulík — ano
- Aleš Juchelka — ano
- David Kasal — ano
- Jiřina Klčová — ano
- Tomáš Kohoutek — ano
- Vladimír Kolek — ano
- Martin Kolovratník — ano
- Jiří Kotlík — ano
- Petr Kowanda — ano
- Robert Králíček — omluven
- Roman Kubíček — ano
- Martin Kupec — ano
- Hubert Lang — ano
- Ivana Mádlová — ano
- Taťána Malá — ano
- Jiří Mašek — ano
- Lubomír Metnar — ano
- Zuzana Mrázová — ano
- Jana Murová — ano
- Patrik Nacher — ano
- Marek Novák — ano
- Monika Oborná — ano
- Ladislav Okleštěk — ano
- Renata Oulehlová — ano
- Pavel Outrata — ano
- Zuzana Ožanová — ano
- Patrik Pařil — ano
- Jana Pastuchová — omluven
- Jiří Penc — ano
- Berenika Peštová — ano
- František Petrtýl — ano
- Robert Plaga — ano
- David Pražák — ano
- Michal Ratiborský — ano
- Barbora Rázga — ano
- Jan Richter — omluven
- Pavel Růžička — ano
- Drahoslav Ryba — ano
- Petr Sadovský — ano
- Miroslav Samaš — ano
- Alena Schillerová — omluven
- Jiří Strýček — ano
- Robert Stržínek — ano
- Jiří Svoboda — ano
- David Štolpa — ano
- Václav Trojan — ano
- Karel Tureček — omluven
- Helena Válková — omluven
- Josef Váňa — omluven
- Adam Vojtěch — ano
- Jitka Volfová — ano
- Radek Vondráček — ano
- Otto Vopěnka — ano
- Petr Vrána — ano
- Lubomír Wenzl — ano
- Martin Záhoř — ano
- Miroslav Žbánek — ano

### ODS

- Ivan Adamec — ne
- Jana Bačíková — omluven
- Lucie Bartošová — ne
- Jan Bauer — ne
- Martin Baxa — ne
- Marek Benda — ne
- Petr Bendl — ne
- Jan Bureš — ne
- Jana Černochová — ne
- Eva Decroix — omluven
- Petr Fiala — ne
- Karel Haas — zdržel se
- Jiří Havránek — ne
- Libor Hoppe — ne
- Jakub Janda — ne
- Pavel Karpíšek — ne
- Martin Kupka — omluven
- Jan Lipavský — ne
- Vojtěch Munzar — zdržel se
- Zdenka Němečková Crkvenjaš — omluven
- Vítězslav Schrek — ne
- Jan Skopeček — ne
- Štěpán Slovák — ne
- Petr Sokol — ne
- Libor Turek — ne
- Renáta Zajíčková — ne
- Pavel Žáček — ne

### STAN

- Jan Berki — ne
- Karel Dvořák — ne
- Josef Flek — ne
- Matěj Hlavatý — ne
- Adriana Chochelová — ne
- Zdena Kašparová — ne
- Věra Kovářová — ne
- Jakub Krainer — ne
- Jana Krutáková — ne
- Anežka Nedomová — ne
- Eliška Olšáková — ne
- Jan Papajanovský — ne
- Pavla Pivoňka Vaňková — ne
- Vít Rakušan — ne
- Michaela Řehková — ne
- Lucie Sedmihradská — ne
- Julie Smejkalová — ne
- Jan Sviták — ne
- Michaela Šebelová — ne
- Barbora Urbanová — ne
- Lukáš Vlček — ne
- Ester Weimerová — omluven

### Piráti

- Hana Ančincová — ne
- Ivan Bartoš — ne
- Katerina Demetrashvili — ne
- Irena Ferčíková Konečná — omluven
- Andrea Hoffmannová — nepřihlášen
- Zdeněk Hřib — nepřihlášen
- Veronika Kovářová — ne
- Lenka Martínková Španihelová — ne
- Michaela Moricová — ne
- Jana Patková — ne
- Barbora Pipášová — ne
- Olga Richterová — ne
- Kateřina Stojanová — ne
- Gabriela Svárovská — ne
- Vendula Svobodová — ne
- Martin Šmída — ne
- Eva Šrámková — ne
- Samuel Volpe — ne

### KDU-ČSL

- Jan Bartošek — ne
- Monika Brzesková — ne
- Benjamin Činčila — ne
- Jana Filipovičová — ne
- Petr Hladík — ne
- Jiří Horák — ne
- Marian Jurečka — omluven
- Marie Kršková — ne
- Bohuslav Niemiec — ne
- Hayato Okamura — ne
- Tom Philipp — ne
- Václav Pláteník — ne
- František Talíř — omluven
- Róbert Teleky — ne
- Jiří Vojáček — ne
- Marek Výborný — ne

### SPD

- Tomáš Doležal — ano
- Radim Fiala — omluven
- Jaroslav Foldyna — ano
- Jan Hrnčíř — ano
- Radek Koten — omluven
- Zuzana Majerová — ano
- Irena Němcová — ano
- Josef Nerušil — ano
- Tomio Okamura — ano
- Marie Pošarová — ano
- Jindřich Rajchl — omluven
- Jan Síla — ano
- Lucie Šafránková — ano
- Miroslav Ševčík — omluven
- Libor Vondráček — ano

### MS

- Jiří Barták — omluven
- Igor Červený — ano
- Libor Forman — ano
- Matěj Gregor — ano
- Oto Klempíř — ano
- Miroslav Krejčí — omluven
- Vojtěch Krňanský — omluven
- Petr Macinka — omluven
- Vladimír Pikora — omluven
- Gabriela Sedláčková — ano
- Boris Šťastný — ano
- Filip Turek — ano
- Renata Vesecká — ano

### TOP09

- Zdeňka Blišťanová — ne
- Matěj Ondřej Havel — ne
- Jan Jakob — ne
- Michal Kučera — ne
- Helena Langšádlová — ne
- Jiří Pospíšil — ne
- Vlastimil Válek — omluven
- Michal Zuna — ne
- Marek Ženíšek — ne
- Ano — ano
- Ne — ne
- Nepřihlášen — nepřihlášen
- Zdržel se — zdržel se
- Omluven — omluven
- 1 — nepřihlášen
- 21 — nepřihlášen
- 2 — nepřihlášen
- 21 — nepřihlášen
- 1 — nepřihlášen
- 15 — nepřihlášen
- 1 — nepřihlášen
- 14 — nepřihlášen
- 2 — nepřihlášen
- 4 — nepřihlášen
- 5 — nepřihlášen
- 8 — nepřihlášen
- 1 — nepřihlášen


---

# Hlasování č. 117 a usnesení č. 253 — schválení ve 3. čtení (10. 7. 2026) – usnesení č. 253

- **Vydavatel:** Poslanecká sněmovna
- **Originál:** https://www.psp.cz/sqw/text/orig2.sqw?idd=290325
- **Kopie na tomto webu:** https://taiemnik.github.io/stavebnizakon/zdroje/psp/usneseni/usneseni-253-2026-07-10.pdf
- **Pozn.:** automatický převod do textu; při citaci ověřte v originálu.

---

<!-- strana 1 -->

2026
10. volební období
253.
USNESENÍ
Poslanecké sněmovny
z 27. schůze ze dne 10. července 2026
k návrhu poslanců Andreje Babiše, Karla Havlíčka, Tomia Okamury, Petra Macinky,
Aleny Schillerové, Zuzany Schwarz Bařtipánové, Radima Fialy, Borise Šťastného,
Vojtěcha Krňanského a Marie Pošarové na vydání zákona, kterým se mění zákon
č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů, a některé další související
zákony /sněmovní tisk 67/ – třetí čtení

Poslanecká sněmovna

vyslovuje souhlas s návrhem poslanců Andreje Babiše, Karla Havlíčka, Tomia Okamury,
Petra Macinky,
Aleny
Schillerové,
Zuzany
Schwarz
Bařtipánové,
Radima
Fialy,
Borise Šťastného, Vojtěcha Krňanského a Marie Pošarové na vydání zákona, kterým se mění
zákon č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů, a některé další související
zákony, podle sněmovního tisku 67, ve znění schváleném Poslaneckou sněmovnou.

Tomio OKAMURA v. r.
předseda Poslanecké sněmovny

Gabriela SEDLÁČKOVÁ v. r.
ověřovatelka Poslanecké sněmovny


---

# Hlasování — PSP, 30. schůze, hlasování č. 36 — setrvání na zákoně vráceném Senátem (usnesení č. 273)

- **Záznam:** 30. schůze, 36. hlasování, 9. září 2026, 18:47:00 Novela z. - stavební zákon
- **Výsledek:** NÁVRH BYL PŘIJAT
- **Souhrn:** Přítomno 168 · Je třeba 101 · Ano 105 · Ne 52 · Nepřihlášen 5 · Omluven 27 · Zdržel se 11
- **Originál:** https://www.psp.cz/sqw/hlasy.sqw?G=88454
- **Staženo:** 2026-10-21

## Jmenovitě

### ANO2011

- Věra Adámková — ano
- Andrej Babiš — omluven
- Ondřej Babka — ano
- Pavel Bartoň — ano
- Jana Berkovcová — ano
- Drahomír Blažej — ano
- Jiří Bouška — ano
- Milan Brázdil — ano
- František Bureš — ano
- Jana Demjanová — ano
- Denis Doksanský — ano
- Lenka Dražilová — ano
- Jaroslav Faltýnek — ano
- Kamal Farhan — ano
- Eva Fialová — ano
- Stanislav Fridrich — ano
- Karin Gajdová — ano
- Jana Hanzlíková — ano
- Karel Havlíček — ano
- Vlastimil Hebr — ano
- Tomáš Helebrant — ano
- Igor Hendrych — ano
- Monika Hubíková — ano
- Miloslav Janulík — ano
- Aleš Juchelka — ano
- David Kasal — ano
- Jiřina Klčová — ano
- Tomáš Kohoutek — ano
- Vladimír Kolek — ano
- Martin Kolovratník — ano
- Jiří Kotlík — ano
- Petr Kowanda — ano
- Robert Králíček — ano
- Roman Kubíček — ano
- Martin Kupec — ano
- Hubert Lang — ano
- Ivana Mádlová — ano
- Taťána Malá — ano
- Jiří Mašek — ano
- Lubomír Metnar — ano
- Zuzana Mrázová — ano
- Jana Murová — ano
- Patrik Nacher — ano
- Marek Novák — ano
- Monika Oborná — ano
- Ladislav Okleštěk — ano
- Renata Oulehlová — ano
- Pavel Outrata — ano
- Zuzana Ožanová — ano
- Patrik Pařil — ano
- Jana Pastuchová — ano
- Jiří Penc — ano
- Berenika Peštová — ano
- František Petrtýl — ano
- Robert Plaga — ano
- David Pražák — ano
- Michal Ratiborský — ano
- Barbora Rázga — ano
- Jan Richter — ano
- Pavel Růžička — ano
- Drahoslav Ryba — ano
- Petr Sadovský — ano
- Miroslav Samaš — ano
- Alena Schillerová — ano
- Jiří Strýček — ano
- Robert Stržínek — ano
- Jiří Svoboda — ano
- David Štolpa — ano
- Václav Trojan — ano
- Karel Tureček — ano
- Helena Válková — ano
- Josef Váňa — ano
- Adam Vojtěch — ano
- Jitka Volfová — ano
- Radek Vondráček — ano
- Otto Vopěnka — ano
- Petr Vrána — ano
- Lubomír Wenzl — ano
- Martin Záhoř — ano
- Miroslav Žbánek — ano

### ODS

- Ivan Adamec — zdržel se
- Jana Bačíková — omluven
- Lucie Bartošová — zdržel se
- Jan Bauer — zdržel se
- Martin Baxa — omluven
- Marek Benda — omluven
- Petr Bendl — zdržel se
- Jan Bureš — zdržel se
- Jana Černochová — omluven
- Eva Decroix — ne
- Petr Fiala — omluven
- Karel Haas — zdržel se
- Jiří Havránek — ne
- Libor Hoppe — ne
- Jakub Janda — zdržel se
- Pavel Karpíšek — nepřihlášen
- Martin Kupka — nepřihlášen
- Jan Lipavský — omluven
- Vojtěch Munzar — zdržel se
- Zdenka Němečková Crkvenjaš — ne
- Vítězslav Schrek — zdržel se
- Jan Skopeček — omluven
- Štěpán Slovák — ne
- Petr Sokol — ne
- Libor Turek — zdržel se
- Renáta Zajíčková — ne
- Pavel Žáček — omluven

### STAN

- Jan Berki — ne
- Karel Dvořák — omluven
- Josef Flek — ne
- Matěj Hlavatý — ne
- Adriana Chochelová — ne
- Zdena Kašparová — ne
- Věra Kovářová — ne
- Jakub Krainer — ne
- Jana Krutáková — ne
- Anežka Nedomová — omluven
- Eliška Olšáková — ne
- Jan Papajanovský — nepřihlášen
- Pavla Pivoňka Vaňková — ne
- Vít Rakušan — omluven
- Michaela Řehková — nepřihlášen
- Lucie Sedmihradská — omluven
- Julie Smejkalová — ne
- Jan Sviták — ne
- Michaela Šebelová — omluven
- Barbora Urbanová — ne
- Lukáš Vlček — omluven
- Ester Weimerová — ne

### Piráti

- Hana Ančincová — ne
- Ivan Bartoš — ne
- Katerina Demetrashvili — ne
- Irena Ferčíková Konečná — ne
- Andrea Hoffmannová — ne
- Zdeněk Hřib — omluven
- Veronika Kovářová — ne
- Lenka Martínková Španihelová — ne
- Michaela Moricová — ne
- Jana Patková — ne
- Barbora Pipášová — ne
- Olga Richterová — ne
- Kateřina Stojanová — ne
- Gabriela Svárovská — omluven
- Vendula Svobodová — ne
- Martin Šmída — ne
- Eva Šrámková — ne
- Samuel Volpe — ne

### KDU-ČSL

- Jan Bartošek — omluven
- Monika Brzesková — omluven
- Benjamin Činčila — zdržel se
- Jana Filipovičová — ne
- Petr Hladík — ne
- Jiří Horák — ne
- Marian Jurečka — omluven
- Marie Kršková — ne
- Bohuslav Niemiec — ne
- Hayato Okamura — ne
- Tom Philipp — ne
- Václav Pláteník — ne
- František Talíř — ne
- Róbert Teleky — omluven
- Jiří Vojáček — omluven
- Marek Výborný — ne

### SPD

- Tomáš Doležal — ano
- Radim Fiala — ano
- Jaroslav Foldyna — omluven
- Jan Hrnčíř — ano
- Radek Koten — ano
- Zuzana Majerová — ano
- Irena Němcová — ano
- Josef Nerušil — ano
- Tomio Okamura — ano
- Marie Pošarová — ano
- Jindřich Rajchl — ano
- Jan Síla — ano
- Lucie Šafránková — ano
- Miroslav Ševčík — ano
- Libor Vondráček — ano

### MS

- Jiří Barták — ano
- Igor Červený — ano
- Libor Forman — ano
- Matěj Gregor — ano
- Oto Klempíř — ano
- Miroslav Krejčí — ano
- Vojtěch Krňanský — omluven
- Petr Macinka — ano
- Vladimír Pikora — ano
- Gabriela Sedláčková — omluven
- Boris Šťastný — ano
- Filip Turek — ano
- Renata Vesecká — ano

### TOP09

- Zdeňka Blišťanová — ne
- Matěj Ondřej Havel — ne
- Jan Jakob — omluven
- Michal Kučera — ano
- Helena Langšádlová — ne
- Jiří Pospíšil — nepřihlášen
- Vlastimil Válek — ne
- Michal Zuna — omluven
- Marek Ženíšek — ne
- Ano — ano
- Ne — ne
- Nepřihlášen — nepřihlášen
- Zdržel se — zdržel se
- Omluven — omluven
- 1 — nepřihlášen
- 7 — nepřihlášen
- 14 — nepřihlášen
- 6 — nepřihlášen
- 16 — nepřihlášen
- 2 — nepřihlášen
- 10 — nepřihlášen
- 1 — nepřihlášen
- 1 — nepřihlášen
- 2 — nepřihlášen
- 2 — nepřihlášen


---

# Hlasování č. 36 a usnesení č. 273 — setrvání na zákoně (9. 9. 2026) – usnesení č. 273

- **Vydavatel:** Poslanecká sněmovna
- **Originál:** https://www.psp.cz/sqw/text/orig2.sqw?idd=291043
- **Kopie na tomto webu:** https://taiemnik.github.io/stavebnizakon/zdroje/psp/usneseni/usneseni-273-2026-09-09.pdf
- **Pozn.:** automatický převod do textu; při citaci ověřte v originálu.

---

<!-- strana 1 -->

2026
10. volební období
273.
USNESENÍ
Poslanecké sněmovny
z 30. schůze ze dne 9. září 2026
k návrhu zákona, kterým se mění zákon č. 283/2021 Sb., stavební zákon, ve znění pozdějších
předpisů, a další související zákony /sněmovní tisk 67/14/ – zamítnutému Senátem

Poslanecká sněmovna

schvaluje návrh zákona, kterým se mění zákon č. 283/2021 Sb., stavební zákon, ve znění
pozdějších předpisů, a další související zákony, podle sněmovního tisku 67/14.

Tomio OKAMURA v. r.
předseda Poslanecké sněmovny

Barbora RÁZGA v. r.
ověřovatelka Poslanecké sněmovny


---

# Hlasování — Senát, 29. schůze — návrh schválit tisk 272

- **Záznam:** 29. schůze, 22. hlasování, 20.08.2026. 272/15 - Návrh zákona, kterým se mění zákon č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů, a některé další související zákony
- **Výsledek:** NÁVRH BYL ZAMÍTNUT
- **Souhrn:** PŘÍTOMNO=66 · JE TŘEBA=34 · [A] ANO=10 · [N] NE=55 · [0] NEPŘÍTOMEN=15 · [X] ZDRŽEL SE=1
- **Originál:** https://www.senat.cz/xqw/xervlet/pssenat/hlasy?G=23950&O=15
- **Staženo:** 2026-10-21

## Jmenovitě

### Senátorský klub Občanské demokratické strany a TOP 09

- Lumír Aschenbrenner — nepřítomen
- Stanislav Balík — ne
- Tomáš Czernin — ne
- Martin Červíček — ne
- Jiří Dušek — nepřítomen
- Tomáš Fiala — ne
- Pavel Fischer — ne
- Tomáš Goláň — ne
- Jan Grulich — ne
- Zdeněk Hraba — ne
- Jaroslav Chalupský — ne
- Tomáš Jirsa — ne
- Hana Kordová Marvanová — ne
- Vladimíra Ludková — ne
- Miroslava Němcová — ne
- Zdeněk Nytra — nepřítomen
- Jiří Oberfalzer — nepřítomen
- Jan Paparega — nepřítomen
- Zdeněk Papoušek — ne
- Jan Pirk — ne
- Jiří Růžička — ne
- Břetislav Rychlík — ne
- Marek Slabý — ne
- Jarmila Smotlachová — ne
- Zbyněk Sýkora — ne
- Ondřej Šimetka — ne
- Jan Tecl — ne
- Tomáš Töpfer — ne
- Tomáš Třetina — ne
- Miloš Vystrčil — ne

### Senátorský klub Starostové a nezávislí

- Miroslav Bárta — nepřítomen
- Michael Canov — ne
- Jiří Drahoš — ne
- Pavel Kárník — ne
- Miroslav Kroc — ne
- Zbyněk Linhart — nepřítomen
- Ondřej Lochman — ne
- Lena Mlejnková — nepřítomen
- Marek Ošťádal — ne
- Helena Pešatová — ne
- Miroslav Plevný — ne
- David Smoljak — ne
- Jan Sobotka — ne
- Petr Štěpánek — ne
- Ivo Trešl — ne
- Jiří Vosecký — ne
- Karel Zitterbart — nepřítomen
- Hana Žáková — ne

### Senátorský klub ANO 2011

- Martin Bednář — ano
- Ondřej Feber — nepřítomen
- Oldřich Hájek — ano
- František Jura — ano
- Jan Látka — ano
- Zdeněk Matušek — ano
- Jana Mračková Vildumetzová — ano
- Tomáš Navrátil — ano
- Věra Procházková — ano
- Jan Schiller — ano
- Róbert Šlachta — ne
- Ondřej Štěrba — ano
- Ladislav Václavec — nepřítomen
- Petr Vícha — ne
- Jana Zwyrtek Hamplová — nepřítomen

### Senátorský klub KDU-ČSL a nezávislí

- Josef Bazala — ne
- Jiří Čunek — nepřítomen
- Petr Fiala — nepřítomen
- Miluše Horská — ne
- Lumír Kantor — ne
- Josef Klement — ne
- Bohuslav Procházka — ne
- Eva Rajchmanová — ne
- Jitka Seitlová — ne
- David Šimek — ne
- Ivana Váňová — ne
- Jaromíra Vítková — ne

### Senátorský klub SEN 21 a Piráti

- Jan Holásek — ne
- Martin Krsek — ne
- Václav Láska — ne
- Přemysl Rabas — nepřítomen
- Adéla Sucharda Šípová — ne

### Nezařazení

- Daniela Kovářová — zdržel se


---

# Hlasování — Senát, 29. schůze — návrh zamítnout tisk 272 (usnesení č. 515)

- **Záznam:** 29. schůze, 23. hlasování, 20.08.2026. 272/15 - Návrh zákona, kterým se mění zákon č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů, a některé další související zákony
- **Výsledek:** NÁVRH BYL PŘIJAT
- **Souhrn:** PŘÍTOMNO=66 · JE TŘEBA=34 · [A] ANO=55 · [N] NE=7 · [0] NEPŘÍTOMEN=15 · [X] ZDRŽEL SE=4
- **Originál:** https://www.senat.cz/xqw/xervlet/pssenat/hlasy?G=23951&O=15
- **Staženo:** 2026-10-21

## Jmenovitě

### Senátorský klub Občanské demokratické strany a TOP 09

- Lumír Aschenbrenner — nepřítomen
- Stanislav Balík — ano
- Tomáš Czernin — ano
- Martin Červíček — ano
- Jiří Dušek — nepřítomen
- Tomáš Fiala — ano
- Pavel Fischer — ano
- Tomáš Goláň — ano
- Jan Grulich — ano
- Zdeněk Hraba — ano
- Jaroslav Chalupský — ano
- Tomáš Jirsa — ano
- Hana Kordová Marvanová — ano
- Vladimíra Ludková — ano
- Miroslava Němcová — ano
- Zdeněk Nytra — nepřítomen
- Jiří Oberfalzer — nepřítomen
- Jan Paparega — nepřítomen
- Zdeněk Papoušek — ano
- Jan Pirk — ano
- Jiří Růžička — ano
- Břetislav Rychlík — ano
- Marek Slabý — ano
- Jarmila Smotlachová — ano
- Zbyněk Sýkora — ano
- Ondřej Šimetka — ano
- Jan Tecl — ano
- Tomáš Töpfer — ano
- Tomáš Třetina — ano
- Miloš Vystrčil — ano

### Senátorský klub Starostové a nezávislí

- Miroslav Bárta — nepřítomen
- Michael Canov — ano
- Jiří Drahoš — ano
- Pavel Kárník — ano
- Miroslav Kroc — ano
- Zbyněk Linhart — nepřítomen
- Ondřej Lochman — ano
- Lena Mlejnková — nepřítomen
- Marek Ošťádal — ano
- Helena Pešatová — ano
- Miroslav Plevný — ano
- David Smoljak — ano
- Jan Sobotka — ano
- Petr Štěpánek — ano
- Ivo Trešl — ano
- Jiří Vosecký — ano
- Karel Zitterbart — nepřítomen
- Hana Žáková — ano

### Senátorský klub ANO 2011

- Martin Bednář — ne
- Ondřej Feber — nepřítomen
- Oldřich Hájek — ne
- František Jura — ne
- Jan Látka — ne
- Zdeněk Matušek — zdržel se
- Jana Mračková Vildumetzová — zdržel se
- Tomáš Navrátil — zdržel se
- Věra Procházková — ne
- Jan Schiller — ne
- Róbert Šlachta — ano
- Ondřej Štěrba — ne
- Ladislav Václavec — nepřítomen
- Petr Vícha — ano
- Jana Zwyrtek Hamplová — nepřítomen

### Senátorský klub KDU-ČSL a nezávislí

- Josef Bazala — ano
- Jiří Čunek — nepřítomen
- Petr Fiala — nepřítomen
- Miluše Horská — ano
- Lumír Kantor — ano
- Josef Klement — ano
- Bohuslav Procházka — ano
- Eva Rajchmanová — ano
- Jitka Seitlová — ano
- David Šimek — ano
- Ivana Váňová — ano
- Jaromíra Vítková — ano

### Senátorský klub SEN 21 a Piráti

- Jan Holásek — ano
- Martin Krsek — ano
- Václav Láska — ano
- Přemysl Rabas — nepřítomen
- Adéla Sucharda Šípová — ano

### Nezařazení

- Daniela Kovářová — zdržel se


---

# Hlasování — Senát, 29. schůze — pověření senátorů odůvodněním ve Sněmovně

- **Záznam:** 29. schůze, 24. hlasování, 20.08.2026. 272/15 - Návrh zákona, kterým se mění zákon č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů, a některé další související zákony
- **Výsledek:** NÁVRH BYL PŘIJAT
- **Souhrn:** PŘÍTOMNO=66 · JE TŘEBA=34 · [A] ANO=60 · [N] NE=0 · [0] NEPŘÍTOMEN=15 · [X] ZDRŽEL SE=6
- **Originál:** https://www.senat.cz/xqw/xervlet/pssenat/hlasy?G=23952&O=15
- **Staženo:** 2026-10-21

## Jmenovitě

### Senátorský klub Občanské demokratické strany a TOP 09

- Lumír Aschenbrenner — nepřítomen
- Stanislav Balík — ano
- Tomáš Czernin — ano
- Martin Červíček — ano
- Jiří Dušek — nepřítomen
- Tomáš Fiala — ano
- Pavel Fischer — ano
- Tomáš Goláň — ano
- Jan Grulich — ano
- Zdeněk Hraba — ano
- Jaroslav Chalupský — ano
- Tomáš Jirsa — ano
- Hana Kordová Marvanová — ano
- Vladimíra Ludková — ano
- Miroslava Němcová — ano
- Zdeněk Nytra — nepřítomen
- Jiří Oberfalzer — nepřítomen
- Jan Paparega — nepřítomen
- Zdeněk Papoušek — ano
- Jan Pirk — ano
- Jiří Růžička — ano
- Břetislav Rychlík — ano
- Marek Slabý — ano
- Jarmila Smotlachová — ano
- Zbyněk Sýkora — ano
- Ondřej Šimetka — ano
- Jan Tecl — ano
- Tomáš Töpfer — ano
- Tomáš Třetina — ano
- Miloš Vystrčil — ano

### Senátorský klub Starostové a nezávislí

- Miroslav Bárta — nepřítomen
- Michael Canov — ano
- Jiří Drahoš — ano
- Pavel Kárník — ano
- Miroslav Kroc — ano
- Zbyněk Linhart — nepřítomen
- Ondřej Lochman — ano
- Lena Mlejnková — nepřítomen
- Marek Ošťádal — ano
- Helena Pešatová — ano
- Miroslav Plevný — ano
- David Smoljak — ano
- Jan Sobotka — ano
- Petr Štěpánek — ano
- Ivo Trešl — ano
- Jiří Vosecký — ano
- Karel Zitterbart — nepřítomen
- Hana Žáková — ano

### Senátorský klub ANO 2011

- Martin Bednář — zdržel se
- Ondřej Feber — nepřítomen
- Oldřich Hájek — ano
- František Jura — zdržel se
- Jan Látka — ano
- Zdeněk Matušek — zdržel se
- Jana Mračková Vildumetzová — zdržel se
- Tomáš Navrátil — zdržel se
- Věra Procházková — zdržel se
- Jan Schiller — ano
- Róbert Šlachta — ano
- Ondřej Štěrba — ano
- Ladislav Václavec — nepřítomen
- Petr Vícha — ano
- Jana Zwyrtek Hamplová — nepřítomen

### Senátorský klub KDU-ČSL a nezávislí

- Josef Bazala — ano
- Jiří Čunek — nepřítomen
- Petr Fiala — nepřítomen
- Miluše Horská — ano
- Lumír Kantor — ano
- Josef Klement — ano
- Bohuslav Procházka — ano
- Eva Rajchmanová — ano
- Jitka Seitlová — ano
- David Šimek — ano
- Ivana Váňová — ano
- Jaromíra Vítková — ano

### Senátorský klub SEN 21 a Piráti

- Jan Holásek — ano
- Martin Krsek — ano
- Václav Láska — ano
- Přemysl Rabas — nepřítomen
- Adéla Sucharda Šípová — ano

### Nezařazení

- Daniela Kovářová — ano

### Pozn.:

### M. Plevný, M. Kroc, T. Třetina


---

# Hlasování — Senát, 29. schůze — doprovodné usnesení (usnesení č. 516)

- **Záznam:** 29. schůze, 25. hlasování, 20.08.2026. 272/15 - Návrh zákona, kterým se mění zákon č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů, a některé další související zákony
- **Výsledek:** NÁVRH BYL PŘIJAT
- **Souhrn:** PŘÍTOMNO=66 · JE TŘEBA=34 · [A] ANO=55 · [N] NE=5 · [0] NEPŘÍTOMEN=15 · [X] ZDRŽEL SE=6
- **Originál:** https://www.senat.cz/xqw/xervlet/pssenat/hlasy?G=23953&O=15
- **Staženo:** 2026-10-21

## Jmenovitě

### Senátorský klub Občanské demokratické strany a TOP 09

- Lumír Aschenbrenner — nepřítomen
- Stanislav Balík — ano
- Tomáš Czernin — ano
- Martin Červíček — ano
- Jiří Dušek — nepřítomen
- Tomáš Fiala — ano
- Pavel Fischer — ano
- Tomáš Goláň — ano
- Jan Grulich — ano
- Zdeněk Hraba — ano
- Jaroslav Chalupský — ano
- Tomáš Jirsa — ano
- Hana Kordová Marvanová — ano
- Vladimíra Ludková — ano
- Miroslava Němcová — ano
- Zdeněk Nytra — nepřítomen
- Jiří Oberfalzer — nepřítomen
- Jan Paparega — nepřítomen
- Zdeněk Papoušek — ano
- Jan Pirk — ano
- Jiří Růžička — ano
- Břetislav Rychlík — ano
- Marek Slabý — ano
- Jarmila Smotlachová — ano
- Zbyněk Sýkora — ano
- Ondřej Šimetka — ano
- Jan Tecl — ano
- Tomáš Töpfer — ano
- Tomáš Třetina — ano
- Miloš Vystrčil — ano

### Senátorský klub Starostové a nezávislí

- Miroslav Bárta — nepřítomen
- Michael Canov — ano
- Jiří Drahoš — ano
- Pavel Kárník — ano
- Miroslav Kroc — ano
- Zbyněk Linhart — nepřítomen
- Ondřej Lochman — ano
- Lena Mlejnková — nepřítomen
- Marek Ošťádal — ano
- Helena Pešatová — ano
- Miroslav Plevný — ano
- David Smoljak — ano
- Jan Sobotka — ano
- Petr Štěpánek — ano
- Ivo Trešl — ano
- Jiří Vosecký — ano
- Karel Zitterbart — nepřítomen
- Hana Žáková — ano

### Senátorský klub ANO 2011

- Martin Bednář — ne
- Ondřej Feber — nepřítomen
- Oldřich Hájek — ne
- František Jura — ne
- Jan Látka — ne
- Zdeněk Matušek — zdržel se
- Jana Mračková Vildumetzová — zdržel se
- Tomáš Navrátil — zdržel se
- Věra Procházková — ne
- Jan Schiller — zdržel se
- Róbert Šlachta — ano
- Ondřej Štěrba — zdržel se
- Ladislav Václavec — nepřítomen
- Petr Vícha — ano
- Jana Zwyrtek Hamplová — nepřítomen

### Senátorský klub KDU-ČSL a nezávislí

- Josef Bazala — ano
- Jiří Čunek — nepřítomen
- Petr Fiala — nepřítomen
- Miluše Horská — ano
- Lumír Kantor — ano
- Josef Klement — ano
- Bohuslav Procházka — ano
- Eva Rajchmanová — ano
- Jitka Seitlová — ano
- David Šimek — ano
- Ivana Váňová — ano
- Jaromíra Vítková — ano

### Senátorský klub SEN 21 a Piráti

- Jan Holásek — ano
- Martin Krsek — ano
- Václav Láska — ano
- Přemysl Rabas — nepřítomen
- Adéla Sucharda Šípová — ano

### Nezařazení

- Daniela Kovářová — zdržel se


---

# Hlasování a usnesení Senátu č. 515 a 516 (20. 8. 2026) – usnesení č. 515

- **Vydavatel:** Senát
- **Originál:** https://www.senat.cz/xqw/webdav/pssenat/original/121151/101783
- **Kopie na tomto webu:** https://taiemnik.github.io/stavebnizakon/zdroje/senat/usneseni/usneseni-515-2026-08-20.pdf
- **Pozn.:** automatický převod do textu; při citaci ověřte v originálu.

---

<!-- strana 1 -->

SENÁT PARLAMENTU ČESKÉ REPUBLIKY

15. FUNKČNÍ OBDOBÍ

515.

USNESENÍ  SENÁTU

z 29. schůze konané dne 20. srpna 2026

k návrhu zákona, kterým se mění zákon č. 283/2021 Sb., stavební zákon, ve znění
pozdějších předpisů, a některé další související zákony /senátní tisk č. 272/

Senát

I.
zamítá návrh zákona;
II.
pověřuje senátory Miroslava Plevného, Miroslava Kroce a Tomáše Třetinu
odůvodněním usnesení Senátu na schůzi Poslanecké sněmovny.

Miloš Vystrčil v. r.
předseda Senátu

Adéla Sucharda Šípová v. r.
ověřovatelka Senátu


---

# Hlasování a usnesení Senátu č. 515 a 516 (20. 8. 2026) – usnesení č. 516

- **Vydavatel:** Senát
- **Originál:** https://www.senat.cz/xqw/webdav/pssenat/original/121152/101784
- **Kopie na tomto webu:** https://taiemnik.github.io/stavebnizakon/zdroje/senat/usneseni/usneseni-516-2026-08-20.pdf
- **Pozn.:** automatický převod do textu; při citaci ověřte v originálu.

---

<!-- strana 1 -->

SENÁT PARLAMENTU ČESKÉ REPUBLIKY

15. FUNKČNÍ OBDOBÍ

516.

USNESENÍ  SENÁTU

z 29. schůze konané dne 20. srpna 2026

přijaté v souvislosti s projednáváním návrhu zákona, kterým se mění zákon
č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů, a některé další
související zákony /senátní tisk č. 272/

Senát

I.
vyzývá Poslaneckou sněmovnu, aby nepřehlasovala zamítnutí návrhu zákona Senátem
a vyzvala vládu ČR k předložení komplexní novely dotčeného zákona řádnou
legislativní cestou;
II.
pověřuje předsedu Senátu, aby toto usnesení postoupil předsedovi Poslanecké
sněmovny.

Miloš Vystrčil v. r.
předseda Senátu

Adéla Sucharda Šípová v. r.
ověřovatelka Senátu
