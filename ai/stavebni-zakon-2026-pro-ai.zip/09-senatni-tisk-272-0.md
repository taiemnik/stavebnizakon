# Senátní tisk 272/0 — návrh zákona postoupený Senátu

- **Vydavatel:** Senát
- **Datum:** 23. 7. 2026
- **Originál:** https://www.senat.cz/xqw/webdav/pssenat/original/120818/101499
- **Kopie na tomto webu:** https://taiemnik.github.io/stavebnizakon/zdroje/senat/tisky/272-0-navrh-zakona.pdf
- **Pozn.:** automatický převod do textu; při citaci ověřte v originálu.

---

272

15. funkční období

272

Návrh zákona, kterým se mění zákon č. 283/2021
Sb., stavební zákon, ve znění pozdějších předpisů,
a některé další související zákony

Lhůta pro projednání Senátem
uplyne 22. srpna 2026

(Navazuje na sněmovní tisk č. 67
z 10. volebního období PS PČR)

2026

ZÁKON
ze dne 2026,
kterým se mění zákon č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů,
a další související zákony
Parlament se usnesl na tomto zákoně České republiky:
ČÁST PRVNÍ
Změna stavebního zákona
Čl. I
Zákon č. 283/2021 Sb., stavební zákon, ve znění zákona č. 195/2022 Sb., zákona
č. 152/2023 Sb., zákona č. 465/2023 Sb., zákona č. 126/2024 Sb., zákona č. 183/2024 Sb.,
zákona č. 437/2024 Sb., zákona č. 23/2025 Sb., zákona č. 39/2025 Sb., zákona č. 87/2025 Sb.,
zákona č. 223/2025 Sb., zákona č. 249/2025 Sb., zákona č. 330/2025 Sb. a zákona č. 91/2026
Sb., se mění takto:
1.
V nadpisu § 1 se slovo „úpravy“ nahrazuje slovy „a účel zákona“.
2.
V § 1 odst. 1 se slova „orgánů stavební správy, orgánů územního plánování a orgánů
územní samosprávy“ nahrazují slovy „úřadů rozvoje území, územních samosprávných
celků a dotčených orgánů“.
3.
V § 1 odst. 3 se za slovo „pro“ vkládají slova „bydlení, práci, podnikání a život lidí,“.
4.
Za § 1 se vkládají nové § 1a a 1b, které včetně nadpisů a poznámek pod čarou č. 68 až 78
znějí:
„§ 1a
Základní zásady
(1) Orgány územního plánování a stavební úřady zajišťují ochranu a rovnováhu dotčených
zájmů, které koordinují, a usilují o předcházení jejich rozporům a o naplnění účelu tohoto
zákona. Uplatňování požadavku ochrany veřejného zájmu nesmí vést k nepřiměřenému dotčení
jiných veřejných zájmů a k narušení nebo znehodnocení charakteru, potenciálu a hodnot území
jako celku.
(2) V případě rozporu zájmů orgán územního plánování nebo stavební úřad porovná jejich
význam a závažnost s cílem zajistit, aby zásah do žádného z nich svými nepříznivými následky
nepřesahoval přínosy, nepřekračoval limitní hodnoty stanovené právními předpisy a výsledné
řešení bylo v souladu s převažujícím veřejným zájmem, s právními předpisy včetně práva
Evropské unie a s mezinárodními závazky a oprávněnými zájmy přímo dotčených osob. Přitom
vychází ze stávajícího stavu poznání a ekonomicky a technicky přijatelných možností řešení.
V odůvodnění opatření obecné povahy nebo v rozhodnutí orgán územního plánování nebo
stavební úřad uvede, jak byly tyto požadavky zohledněny.
(3) Znemožnit rozvoj sídel, hospodářství, veřejné infrastruktury nebo výstavbu lze jen
tehdy, není-li možné zajistit dostatečnou ochranu jiných hodnot podmínkami, kompenzačními
anebo zmírňujícími opatřeními.
(4) Při řešení rozporů a námitek podle tohoto zákona orgány územního plánování
a stavební úřady usilují o dosažení smíru.
§ 1b
Ochrana veřejných zájmů
(1) Stavební úřady posuzují a chrání veřejné zájmy podle tohoto zákona a další veřejné
zájmy zejména v oblasti
a) života a zdraví lidí68),
b) životního prostředí69),
c) státní památkové péče70),
d) veřejné infrastruktury71),
e) zemědělství, lesnictví a ochrany zvířat72),
f)
nerostů, hornické činnosti, těžby a výbušnin a surovinové bezpečnosti a soběstačnosti73),
g) výroby a hospodaření s energií a energetické bezpečnosti74),
h) požární ochrany a integrovaného záchranného systému75),
i)
prevence závažných havárií, integrované prevence a omezování znečištění76),
j)
práva na územní samosprávu územních samosprávných celků77),
k) hospodářského a průmyslového rozvoje78).
(2) Při posuzování a ochraně veřejných zájmů podle odstavce 1 v řízení podle části šesté,
deváté a desáté tohoto zákona vykonávají stavební úřady pravomoc dotčených orgánů podle
jiných zákonů namísto těchto orgánů, nestanoví-li zvláštní zákon jinak. Rozhodnutí stavebního
úřadu podle části šesté, deváté a desáté tohoto zákona nahrazuje rozhodnutí, závazná stanoviska
a jiné úkony dotčených orgánů, nestanoví-li zvláštní zákon jinak; v rozhodnutí stanoví stavební
úřad i podmínky k ochraně veřejných zájmů chráněných jinými právními předpisy.
__________
68)
Zejména zákon č. 258/2000 Sb., o ochraně veřejného zdraví a o změně některých
souvisejících zákonů, ve znění pozdějších předpisů; zákon č. 164/2001 Sb., o přírodních
léčivých zdrojích, zdrojích přírodních minerálních vod, přírodních léčebných lázních
a lázeňských místech a o změně některých souvisejících zákonů (lázeňský zákon), ve
znění pozdějších předpisů.
69)
Zejména zákon č. 17/1992 Sb., o životním prostředí, ve znění pozdějších předpisů,
zákon č. 114/1992 Sb., o ochraně přírody a krajiny, ve znění pozdějších předpisů, zákon
č. 185/2001 Sb., o odpadech a o změně některých dalších zákonů, ve znění pozdějších
předpisů, zákon č. 254/2001 Sb., o vodách a o změně některých zákonů (vodní zákon),
ve znění pozdějších předpisů, zákon č. 201/2012 Sb., o ochraně ovzduší, ve znění
pozdějších předpisů, Nařízení Evropského parlamentu a Rady (EU) 2024/1991 ze dne
24. června 2024 o obnově přírody a o změně nařízení (EU) 2022/869.
70)
Zejména zákon č. 20/1987 Sb., o státní památkové péči, ve znění pozdějších předpisů.
71)
Zejména zákon č. 266/1994 Sb., o dráhách, ve znění pozdějších předpisů, zákon
č. 114/1995 Sb., o vnitrozemské plavbě, ve znění pozdějších předpisů, zákon č. 13/1997
Sb., o pozemních komunikacích, ve znění pozdějších předpisů, zákon č. 49/1997 Sb., o
civilním letectví a o změně a doplnění zákona č. 455/1991 Sb., o živnostenském
podnikání (živnostenský zákon), ve znění pozdějších předpisů, ve znění pozdějších
předpisů, zákon č. 274/2001 Sb., o vodovodech a kanalizacích pro veřejnou potřebu a o
změně některých zákonů (zákon o vodovodech a kanalizacích), ve znění pozdějších
předpisů, zákon č. 127/2005 Sb., o elektronických komunikacích a o změně některých
souvisejících zákonů (zákon o elektronických komunikacích), ve znění pozdějších
předpisů, zákon č. 416/2009 Sb., o urychlení výstavby dopravní, vodní a energetické
infrastruktury a infrastruktury elektronických komunikací, ve znění pozdějších
předpisů.
72)
Zejména zákon č. 252/1997 Sb., o zemědělství, ve znění pozdějších předpisů, zákon
č. 334/1992 Sb., o ochraně zemědělského půdního fondu, ve znění pozdějších předpisů,
zákon č. 289/1995 Sb., o lesích a o změně a doplnění některých zákonů (lesní zákon),
ve znění pozdějších předpisů, zákon č. 166/1999 Sb. o veterinární péči a o změně
některých souvisejících zákonů (veterinární zákon), ve znění pozdějších předpisů, zákon
č. 246/1992 Sb., na ochranu zvířat proti týrání, ve znění pozdějších předpisů.
73)
Zejména zákon č. 44/1988 Sb., o ochraně a využití nerostného bohatství (horní zákon),
ve znění pozdějších předpisů, zákon č. 61/1988 Sb., o hornické činnosti, výbušninách a
o státní báňské správě, ve znění pozdějších předpisů, zákon č. 157/2009 Sb., o nakládání
s těžebním odpadem a o změně některých zákonů, ve znění pozdějších předpisů.
74)
Zejména zákon č. 406/2000 Sb., o hospodaření energií, ve znění pozdějších předpisů,
zákon č. 458/2000 Sb., o podmínkách podnikání a o výkonu státní správy v
energetických odvětvích a o změně některých zákonů (energetický zákon), ve znění
pozdějších předpisů, zákon č. 165/2012 Sb., o podporovaných zdrojích energie a o
změně některých zákonů, ve znění pozdějších předpisů, zákon č. 263/2016 Sb., atomový
zákon, ve znění pozdějších předpisů, zákon č. 249/2025 Sb., o urychlení využívání
některých obnovitelných zdrojů energie a o změně souvisejících zákonů (zákon o
urychlení využívání obnovitelných zdrojů energie).
75)
Zejména zákon č. 133/1985 Sb., o požární ochraně, ve znění pozdějších předpisů, zákon
č. 239/2000 Sb., o integrovaném záchranném systému a o změně některých zákonů, ve
znění pozdějších předpisů.
76)
Zejména zákon č. 76/2002 Sb., o integrované prevenci a omezování znečištění,
o integrovaném registru znečišťování a o změně některých zákonů (zákon o integrované
prevenci), ve znění pozdějších předpisů, zákon č. 224/2015 Sb., o prevenci závažných
havárií způsobených vybranými nebezpečnými chemickými látkami nebo chemickými
směsmi a o změně zákona č. 634/2004 Sb., o správních poplatcích, ve znění pozdějších
předpisů, (zákon o prevenci závažných havárií), ve znění pozdějších předpisů, zákon č.
167/2008 Sb., o předcházení ekologické újmě a o její nápravě a o změně některých
zákonů, ve znění pozdějších předpisů.
77)
Zejména zákon č. 128/2000 Sb., o obcích (obecní zřízení), ve znění pozdějších předpisů,
zákon č. 129/2000 Sb., o krajích (krajské zřízení), ve znění pozdějších předpisů, zákon
č. 131/2000 Sb., o hlavním městě Praze, ve znění pozdějších předpisů.
78)
Zejména zákon č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů, § 1
odst. 3 a § 16.“.
5.
V § 2 se vkládá nový odstavec 1, který zní:
„(1) Dotčené orgány uplatňují stanoviska, vyjádření nebo závazná stanoviska
k záležitostem podle tohoto zákona pouze v mezích své působnosti a činí tak co nejdříve
a v první fázi, kdy je to možné; přitom dbají, aby se jejich stanoviska, vyjádření nebo závazná
stanoviska dotýkala oprávněných zájmů a práv osob jen v nezbytném rozsahu, který je potřebný
k ochraně jimi hájeného veřejného zájmu, a zvláště dbají zachování účelu tohoto zákona, jeho
základních zásad a jeho ustanovení, která se týkají jejich působnosti.“.
Dosavadní odstavce 1 až 3 se označují jako odstavce 2 až 4.
6.
V § 2 odst. 3 se slovo „ke“ nahrazuje slovy „k vyjádřením a“.
7.
V § 2 se na konci textu odstavce 4 doplňují slova „ , a ve věcech, které byly vyhodnoceny
v závazném stanovisku k posouzení vlivů provedení záměru na životní prostředí podle
jiného právního předpisu“.
8.
V § 3 se na konci odstavce 1 doplňuje věta „Změnit své původní vyjádření, stanovisko
nebo závazné stanovisko může dotčený orgán též za účelem řešení rozporu, je-li to pro
stavebníka příznivější.“.
9.
V § 4 odst. 1 se slova „ , dělení nebo scelování pozemků“ zrušují.
10.
V § 5 odst. 3 se za slovo „záměru“ vkládají slova „nebo více souvisejících záměrů anebo
v etapách“.
11.
V § 5 odst. 4 větě první se za slovo „výstavby“ vkládají slova „ , druh stavby podle
odstavce 2 a příslušnost stavebního úřadu k celému“.
12.
V § 5 se doplňují odstavce 7 a 8, které znějí:
„(7) Stavbou pro hromadné bydlení je stavba nebo soubor staveb s převažující funkcí
bydlení s celkovou podlahovou plochou od 10 000 m2.
(8) Plánování, příprava, výstavba a provozování veřejné infrastruktury a vyhrazených
staveb je ve veřejném zájmu.“.
13.
V § 6 odstavec 2 zní:
„(2) Změnou dokončené stavby se v tomto zákoně rozumí také změna, která spočívá ve
změně
a) účelu užívání stavby, ve změně v době trvání dočasné stavby nebo ve změně dočasné
stavby na stavbu trvalou, nebo
b) činnosti, jejíž účinky by mohly ohrozit život nebo veřejné zdraví, život a zdraví zvířat,
bezpečnost nebo životní prostředí.“.
14.
V § 10 odst. 1 písm. a) se za slova „zejména stavby“ vkládá slovo „cest,“.
15.
V § 11 odst. 1 se za slovo „dokumentaci“ vkládají slova „nebo v zákoně“ a na konci textu
odstavce se doplňují slova „a strategická investiční stavba79)“.
Poznámka pod čarou č. 79 zní:
 „79)
§ 1 odst. 13 zákona č. 416/2009 Sb., o urychlení výstavby strategicky významné
infrastruktury, ve znění pozdějších předpisů.“.
16.
V § 12 písm. a) se slova „funkčního využití nebo“ zrušují a za slovo „uspořádání“ se
vkládají slova „nebo využití“.
17.
V § 12 písm. c) se slova „zastavěným stavebním“ zrušují a za slovo „pozemkem“ se
vkládají slova „zázemí stavby“.
18.
V § 12 písm. d) se slova „územním rozvojovém plánu, zásadách územního rozvoje nebo
územním plánu, popřípadě v územně plánovacích podkladech, s ohledem na stávající
nebo požadovaný způsob využití nebo její význam“ nahrazují slovy „nástrojích územního
plánování pro určité prostorové uspořádání nebo využití“.
19.
V § 12 se na konci textu písmene e) doplňují slova „v nástrojích územního plánování“.
20.
V § 12 písm. g) se slova „svým významem, rozsahem nebo využitím ovlivní území více
městských částí“ nahrazují slovy „mají celoměstský význam, rozsah nebo využití“.
21.
V § 12 písmeno h) zní:
„h) zastavitelným územím území vymezené v územním plánu, které obsahuje zastavitelné
plochy a nestavební plochy; dále se zastavitelným územím rozumí zastavitelné území
vymezené samostatným postupem podle § 116 až 121 (dále jen „vymezení zastavitelného
území“),“.
22.
V § 12 písmeno j) zní:
„j) nestavební plochou plocha v zastavitelném území, která není určena k umístění zástavby,
s výjimkou veřejné infrastruktury,“.
23.
V § 12 se za písmeno j) vkládá nové písmeno k), které zní:
„k) nezastavitelným územím území nezahrnuté do zastavitelného území,“.
Dosavadní písmena k) až w) se označují jako písmena l) až x).
24.
V § 12 písm. l) se slova „transformační plochou“ nahrazují slovy „plochou změny
v zastavitelném území zastavitelná nebo nestavební“, slova „k vytvoření zcela nového“
se nahrazují slovy „ke změně“ a slova „vymezená územním rozvojovým plánem,
zásadami územního rozvoje nebo v zastavěném území územním plánem“ se zrušují.
25.
V § 12 písm. m) se slovo „krajině“ nahrazuje slovy „nezastavitelném území“, slovo
„nezastavěného“ se nahrazuje slovem „nezastavitelného“ a slovo „nezastavěném“ se
nahrazuje slovem „nezastavitelném“.
26.
V § 12 písm. n) se slova „pozemky a veřejným prostranstvím“ nahrazují slovy „uličním
prostranstvím a bloky“.
27.
V § 12 se za písmeno n) vkládá nové písmeno o), které zní:
„o) blokem ucelená část území tvořená souborem pozemků, jedním pozemkem nebo jeho částí,
zpravidla ohraničená uličním prostranstvím a vymezená uliční čarou; bloky se rozlišují na
stavební, které jsou určené převážně k zastavění budovami, a nestavební, které jsou určené
převážně k nestavebním účelům,“.
Dosavadní písmena o) až x) se označují jako písmena p) až y).
28.
V § 12 písm. p) úvodní části ustanovení se slova „stavební čára může být“ nahrazují slovy
„typy stavebních čar stanoví prováděcí právní předpis,“ a body 1 a 2 se zrušují.
29.
V § 12 písm. u) se slova „měřítku menším“ nahrazují slovy „podrobnosti menší“.
30.
V § 13 písmeno d) zní:
„d) přístupností vytváření podmínek pro samostatné a bezpečné využití pozemků a staveb
podle jejich potřeby a účelu osobami s pohybovým, zrakovým nebo sluchovým postižením
s cílem zajištění jejich bezpečnosti a nezbytného bezbariérového užívání,“.
31.
V § 13 písm. e) se čárka za slovy „bytový dům“ nahrazuje slovem „a“ a slova „ani stavba
pro rodinnou rekreaci“ se zrušují.
32.
V § 13 písm. f) se za slovo „s“ vkládá slovo „převažující“.
33.
V § 13 písm. h) se za slovo „výrobu“ vkládají slova „ , a to i bez nutnosti využití místní
půdy,“.
34.
V § 13 písmeno o) zní:
„o) zastavěnou plochou stavby plocha ohraničená svislými průměty vnějšího líce obvodových
konstrukcí, případně jejich spojnic, všech nadzemních i podzemních podlaží do vodorovné
roviny; plochy balkonů a arkýřů se nezapočítávají; u objektů poloodkrytých (bez některých
obvodových stěn) je zastavěná plocha vymezena obalovými čarami vedenými vnějšími líci
svislých konstrukcí do vodorovné roviny,“.
35.
V § 13 se na konci písmene p) čárka nahrazuje tečkou a písmeno q) se zrušuje.
36.
V části druhé nadpisu hlavy I se slovo „STAVEBNÍ“ nahrazuje slovem „VEŘEJNÁ“.
37.
V § 15 se slova „Ministerstvo pro místní rozvoj (dále jen „ministerstvo“), orgány
územního plánování, stavební úřady, obce, a“ zrušují a na konci textu ustanovení se
doplňují slova „ , obce, úřady rozvoje území, Ministerstvo obrany, Ministerstvo
spravedlnosti a Ministerstvo vnitra“.
38.
§ 16 a 17 včetně nadpisů znějí:
„§ 16
Obec a kraj
(1) Obec a kraj prosazují a hájí veřejný zájem na všestranném rozvoji svého území a na
vytváření podmínek pro bydlení, práci, podnikání a život lidí.
(2) K podpoře výkonu působnosti samosprávy podle tohoto zákona a k naplňování cílů
tohoto zákona může obec, společenství obcí nebo kraj zřídit útvar architekta nebo jmenovat
obecního, městského nebo krajského architekta.
§ 17
Úřady rozvoje území
(1) Zřizují se Úřad rozvoje území České republiky (dále jen „Úřad“), úřady rozvoje území
krajů a jejich územní pracoviště.
(2) Úřad je účetní jednotkou. Úřady rozvoje území krajů a jejich územní pracoviště nejsou
účetními jednotkami a pro účely hospodaření s majetkem České republiky, účetnictví
a pracovněprávních vztahů mají postavení vnitřních organizačních jednotek Úřadu.“.
39.
Za § 17 se vkládají nové § 17a a 17b, které včetně nadpisů znějí:
„§ 17a
Úřad
(1) Úřad je ústředním správním úřadem ve věcech územního plánování, stavebního řádu,
vyvlastnění a dalších věcí upravených tímto zákonem. Úřad metodicky sjednocuje činnost
orgánů územního plánování a řídí a metodicky sjednocuje činnost stavebních úřadů; dále
provádí výzkum, publikační činnost a řeší koncepční otázky teorie a praxe v oblasti rozvoje
území, územního plánování, stavebního řádu, stavební kultury a vystavěného prostředí,
urbanismu a architektury.
(2) Sídlem Úřadu je Praha. Úřad může zřídit svá detašovaná územní pracoviště.
(3) V čele Úřadu je předseda, kterého jmenuje a odvolává vláda na návrh ministra pro
místní rozvoj. Předsedu zastupují v jím vymezených oblastech místopředsedové, které na návrh
předsedy jmenuje a odvolává ministr pro místní rozvoj. V případech stanovených vnitřním
předpisem Úřadu nebo na základě písemného pověření předsedy může v úřadech rozvoje území
právně jednat jménem státu i jiný státní zaměstnanec. Orgán, který předsedu nebo
místopředsedu jmenoval, ho odvolá, pokud přestane splňovat podmínky pro jmenování.
(4) Předseda a místopředsedové Úřadu jsou jmenováni na dobu 6 let a mohou být
jmenováni opakovaně. Předsedou a místopředsedou Úřadu může být jmenována osoba, jejíž
znalosti, zkušenosti a morální vlastnosti jsou předpokladem, že bude svoji funkci řádně
zastávat, a která
a) je státním občanem České republiky,
b) je plně svéprávná,
c) je bezúhonná a
d) má ukončené vysokoškolské vzdělání získané studiem v magisterském studijním
programu.
(5) S funkcí předsedy a místopředsedy Úřadu je neslučitelný výkon funkce člena řídícího,
dozorčího nebo kontrolního orgánu podnikajících osob, výkon výdělečné činnosti s výjimkou
správy vlastního majetku a činnosti vědecké, pedagogické, literární, publicistické a umělecké.
§ 17b
Úřady rozvoje území krajů
(1) Úřady rozvoje území krajů jsou územními správními orgány ve věcech územního
plánování, stavebního řádu, vyvlastnění a dalších věcí upravených tímto zákonem.
(2) Úřady rozvoje území krajů jsou
a) Úřad rozvoje území pro hlavní město Prahu se sídlem v Praze,
b) Úřad rozvoje území pro Středočeský kraj se sídlem v Praze,
c) Úřad rozvoje území pro Jihočeský kraj se sídlem v Českých Budějovicích,
d) Úřad rozvoje území pro Plzeňský kraj se sídlem v Plzni,
e) Úřad rozvoje území pro Karlovarský kraj se sídlem v Karlových Varech,
f)
Úřad rozvoje území pro Ústecký kraj se sídlem v Ústí nad Labem,
g) Úřad rozvoje území pro Liberecký kraj se sídlem v Liberci,
h) Úřad rozvoje území pro Královéhradecký kraj se sídlem v Hradci Králové,
i)
Úřad rozvoje území pro Pardubický kraj se sídlem v Pardubicích,
j)
Úřad rozvoje území pro Kraj Vysočina se sídlem v Jihlavě,
k) Úřad rozvoje území pro Jihomoravský kraj se sídlem v Brně,
l)
Úřad rozvoje území pro Olomoucký kraj se sídlem v Olomouci,
m) Úřad rozvoje území pro Moravskoslezský kraj se sídlem v Ostravě,
n) Úřad rozvoje území pro Zlínský kraj se sídlem ve Zlíně.
(3) Územní pracoviště úřadů rozvoje území krajů (dále jen „územní pracoviště“) jsou
územními správními orgány ve věcech stavebního řádu a územního plánování. Územní
pracoviště jsou v obcích s rozšířenou působností. Úřad může zřídit detašovaná pracoviště
územních pracovišť i v jiných obcích, je-li to potřebné. Detašované pracoviště je součástí
územního pracoviště.
(4) Úřad rozvoje území kraje vykonává územní působnost v území příslušného kraje.
Územní pracoviště vykonává územní působnost ve správním obvodu obce s rozšířenou
působností, ve které má sídlo.
(5) V čele úřadu rozvoje území kraje stojí ředitel, v čele územního pracoviště stojí
vedoucí.“.
40.
V § 18 se na konci textu odstavce 1 doplňují slova „a v souladu se zásadami uvedenými
v části první hlavě I zajišťují koordinaci jejich vyjádření, stanovisek a závazných
stanovisek, řešení rozporů a odstraňování vad“.
41.
V § 18 odstavec 2 zní:
„(2) Orgány územního plánování a stavební úřady mohou nařídit společné jednání
s obcemi, kraji nebo dotčenými orgány, a to oznámením nejméně 5 pracovních dnů před jeho
konáním, nedohodnou-li se jinak. Společné jednání je neveřejné, o jeho závěrech se sepisuje
protokol. Je-li to účelné, lze ke společnému jednání přizvat jiné osoby. Nezúčastní-li se dotčený
orgán bez důvodné omluvy společného jednání, platí, že souhlasí s řešením orgánu územního
plánování nebo stavebního úřadu. K odstranění rozporů nebo zjevných vad vyjádření,
stanovisek nebo závazných stanovisek může orgán územního plánování nebo stavební úřad
stanovit dotčeným orgánům lhůtu, která nepřekročí 15 dní.“.
42.
V § 18 se na konci textu odstavce 3 doplňují slova „s tím, že je-li příslušným správním
orgánem tentýž úřad, rozhodne o rozporu jeho vedoucí“.
43.
§ 19 a 20 včetně nadpisů znějí:
„§ 19
Obecná ustanovení
(1) Působnost ve věcech územního plánování vykonávají vláda a orgány územního
plánování, kterými jsou
a) úřady rozvoje území,
b) Ministerstvo obrany,
c) kraje,
d) obce a
e) hlavní město Praha.
(2) Orgány územního plánování soustavně sledují uplatňování jimi vydané územně
plánovací dokumentace a vyhodnocují je. Dojde-li ke změně podmínek, za kterých byla územně
plánovací dokumentace vydána, pořídí změnu příslušné územně plánovací dokumentace.
§ 20
Vláda
Vláda schvaluje
a) politiku architektury a stavební kultury,
b) politiku územního rozvoje,
c) územní rozvojový plán,
d) územní opatření celostátního významu.“.
44.
Nadpis § 21 zní: „Úřady rozvoje území“.
45.
V § 21 odstavec 1 zní:
„(1) Úřad je nadřízeným správním orgánem úřadů rozvoje území krajů jako orgánů
územního plánování.“.
46.
V § 21 odst. 2 úvodní část ustanovení zní: „Úřad“.
47.
V § 21 odst. 2 se na začátek písmen b), c) a e) vkládají slova „zpracovává a“.
48.
V § 21 odst. 2 se na začátek písmen d) a f) vkládá slovo „zpracovává,“ a za slovo
„pořizuje“ se vkládají slova „a vydává“.
49.
V § 21 odst. 2 písm. e) se slova „územně plánovací podklady“ nahrazují slovy „územní
studie“.
50.
V § 21 odst. 2 písm. f) se slova „o stavební uzávěře, jedná-li se o změny v území“ zrušují.
51.
V § 21 odst. 2 písmeno g) zní:
„g) poskytuje údaje pro územně analytické podklady,“.
52.
V § 21 odst. 2 se písmena h) a i) zrušují.
Dosavadní písmeno j) se označuje jako písmeno h).
53.
V § 21 se doplňují odstavce 3 a 4, které znějí:
„(3) Úřad rozvoje území kraje je nadřízeným orgánem krajů a obcí jako orgánů územního
plánování.
(4) Úřad rozvoje území kraje, případně z jeho pověření jeho územní pracoviště
a) vykonává kontrolu ve věcech územního plánování,
b) pořizuje územní plán a územní opatření na žádost obce podle § 47 odst. 2,
c) pořizuje a vydává vymezení zastavitelného území obcí, které nemají územní plán, a
d) vykonává další činnosti podle tohoto zákona.“.
54.
V § 22 písm. a) se za slovo „pořizuje“ vkládá slovo „ , schvaluje“.
55.
V § 22 písm. b) se slova „územně plánovací podklady“ nahrazují slovy „územní studie“.
56.
V § 22 písmeno c) zní:
„c) poskytuje údaje pro územně analytické podklady.“.
57.
§ 23 včetně nadpisu zní:
„§ 23
Kraj
Kraj v samostatné působnosti pro své území zpracovává, pořizuje, schvaluje a vydává
zásady územního rozvoje, územní studie a územní opatření, poskytuje údaje pro územně
analytické podklady a vykonává další územně plánovací činnosti v zájmu rozvoje kraje v rámci
svého práva na samosprávu. Při tom jej lze omezit jen na základě zákona a jen v nezbytně
nutném rozsahu.“.
58.
V § 24 odst. 1 se písmeno c) zrušuje.
Dosavadní písmena d) a e) se označují jako písmena c) a d).
59.
V § 24 odst. 1 písm. c) se slovo „vydává“ nahrazuje slovem „schvaluje“.
60.
V § 24 odst. 1 se na konci písmene c) čárka nahrazuje tečkou a písmeno d) se zrušuje.
61.
V § 24 odst. 2 písm. b), § 42 odst. 2 větě druhé, § 42 odst. 4 větě první a druhé, § 50
odst. 2, § 71 odst. 2, § 71b odst. 3 větě druhé, § 71c odst. 3, § 71d odst. 3 úvodní části
ustanovení, § 71e odst. 3 větě druhé, § 76 odst. 2, § 95 odst. 2, § 154 odst. 3 větě druhé,
§ 269 odst. 1 písm. e), § 277 odst. 1 úvodní části ustanovení, § 277 odst. 1 písm. f), § 279
odst. 3 a § 300 se slovo „ministerstvo“ nahrazuje slovem „Úřad“.
62.
V § 24 odst. 2 písm. c) se slova „o stavební uzávěře a asanaci území, k jejichž“ nahrazují
slovy „ , k jehož“ a slova „krajský úřad“ se nahrazují slovem „kraj“.
63.
V § 24 odst. 2 písm. d) se slovo „vydává“ nahrazuje slovem „schvaluje“, slova „o stavební
uzávěře a asanaci území“ se zrušují a slova „krajský úřad“ se nahrazují slovem „kraj“.
64.
V § 24 se na konci odstavce 2 tečka nahrazuje slovem „a“ a doplňuje se písmeno f), které
zní:
„f) uděluje souhlas ke zpřesnění navazující územně plánovací dokumentace podle § 73 odst.
5 nebo k možnosti odchýlit se od územně plánovací dokumentace nebo územního opatření
podle § 193 odst. 2.“.
65.
§ 25 a 26 včetně nadpisů znějí:
„§ 25
Společenství obcí
Společenství obcí může na základě veřejnoprávní smlouvy s obcí v samostatné působnosti
vykonávat odborné činnosti pořizovatele, jimiž se rozumí zpracovávání, pořizování a vydávání
nástrojů územního plánování, pro obce, které jsou jeho členem.
§ 26
Obec
Obec v samostatné působnosti pro své území zpracovává, pořizuje, schvaluje a vydává
územní plán, regulační plán, územní studii a územní opatření, poskytuje údaje pro územně
analytické podklady a vykonává další územně plánovací činnosti v zájmu rozvoje obce v rámci
svého práva na samosprávu. Při tom ji lze omezit jen na základě zákona a jen v nezbytně nutném
rozsahu.“.
66.
V § 27 odst. 1 se písmeno c) zrušuje.
Dosavadní písmena d) a e) se označují jako písmena c) a d).
67.
V § 27 odst. 1 písm. c) se slovo „vydává“ nahrazuje slovem „schvaluje“.
68.
V § 27 odst. 1 se na konci písmene c) čárka nahrazuje tečkou a písmeno d) se zrušuje.
69.
V § 27 odst. 2 písm. b), § 57 odst. 1 větě první, § 57 odst. 2, § 61 písm. d), § 114 odst. 5
větě první, druhé a poslední, § 116 odst. 1 větě druhé, § 116 odst. 2 úvodní části
ustanovení větě první a druhé, § 116 odst. 3 úvodní části ustanovení a písmenu e) a f),
§ 118 odst. 1, § 118 odst. 3 úvodní části ustanovení a písmenu a), § 118 odst. 4 úvodní
části ustanovení a písmenu a), § 119 odst. 1 větě první a druhé, § 119 odst. 2 větě první
a poslední, § 120 odst. 1 větě druhé, § 120 odst. 4, § 121 odst. 1, § 121 odst. 2 větě první,
§ 121 odst. 3, § 121 odst. 4 větě první, § 121 odst. 5 větě první a druhé a § 193 odst. 1
písm. a) se slovo „zastavěného“ nahrazuje slovem „zastavitelného“.
70.
V § 27 odst. 2 písm. c) se slova „o asanaci území a územního opatření o stavební uzávěře“
zrušují, slova „krajský úřad jako úřad územního plánování,“ se nahrazují slovem „kraj“ a
slovo „ministerstvo“ se nahrazuje slovem „Úřad“.
71.
V § 27 odst. 2 písm. d) se slova „o stavební uzávěře a o asanaci území“ zrušují.
72.
V § 27 odst. 2 písm. e) se slovo „vydává“ nahrazuje slovem „schvaluje“ a slova
„o stavební uzávěře a o asanaci území“ se zrušují.
73.
V § 27 odst. 2 se písmeno f) zrušuje.
Dosavadní písmeno g) se označuje jako písmeno f).
74.
V § 27 odst. 2 písmeno f) zní:
„f) uděluje souhlas k možnosti odchýlit se od územně plánovací dokumentace nebo územního
opatření podle § 193 odst. 2.“.
75.
§ 28 včetně nadpisu zní:
„§ 28
Působnost na území hlavního města Prahy
Hlavní město Praha v samostatné působnosti pro své území zpracovává, pořizuje, schvaluje
a vydává zásady územního rozvoje, územní plán, regulační plán, územní studii a územní
opatření, poskytuje údaje pro územně analytické podklady a vykonává další územně plánovací
činnosti v zájmu rozvoje hlavního města Prahy v rámci svého práva na samosprávu. Při tom ji
lze omezit jen na základě zákona a jen v nezbytně nutném rozsahu.“.
76.
§ 29 se včetně nadpisu zrušuje.
77.
§ 30 včetně nadpisu zní:
„§ 30
Obecná ustanovení
(1) Působnost ve věcech stavebního řádu vykonávají stavební úřady, kterými jsou úřady
rozvoje území, jiné stavební úřady a autorizovaný inspektor.
(2) Jinými stavebními úřady jsou Ministerstvo obrany, Ministerstvo vnitra a Ministerstvo
spravedlnosti.
(3) Úřad je nadřízeným správním orgánem úřadů rozvoje území krajů. Úřady rozvoje
území krajů jsou nadřízeným správním orgánem svých územních pracovišť.
(4) Nadřízeným správním orgánem autorizovaného inspektora je stavební úřad, který
v dané věci vydal povolení záměru, a není-li tomu tak, je jím úřad rozvoje území kraje, v němž
má autorizovaný inspektor sídlo.
(5) Nadřízený úřad rozvoje území může usnesením pověřit prováděním postupů podle části
šesté, deváté a desáté tohoto zákona jiný věcně příslušný stavební úřad, jestliže je to účelné;
usnesení se pouze poznamená do spisu.“.
78.
§ 30a se včetně nadpisu zrušuje.
79.
§ 31 a 32 včetně nadpisů znějí:
„§ 31
Metodická činnost
Jiné ústřední orgány státní správy v rámci své působnosti metodicky podporují výkon
působnosti Úřadu v oblastech, ve kterých stavební úřady rozhodují o věcech v působnosti jiných
ústředních orgánů státní správy.
§ 32
Úřad
(1) Úřad
a) vykonává působnost stavebního úřadu ve věcech vyhrazených a s nimi souvisejících
staveb,
b) vydává rámcové povolení pro stavby jaderného zařízení a stavby související, nacházející
se uvnitř i vně areálu jaderného zařízení,
c) vykonává působnost vyvlastňovacího úřadu ve věcech vyhrazených staveb,
d) vydává rozhodnutí o změně využití území pro stanovení prostoru pro dobývání ložisek
nerostů, pro která se nestanoví dobývací prostor podle horního zákona,
e) rozhoduje v pochybnostech, zda se jedná o vyhrazenou stavbu nebo stavbu či záměr
související s vyhrazenou stavbou,
f)
vede systém stavebně technické prevence, v němž sleduje a analyzuje závažné nebo
opakující se závady nebo havárie staveb, kterým je třeba ve veřejném zájmu předcházet,
a navrhuje opatření k zabránění jejich opakování,
g) sleduje účinnost technických předpisů pro stavby a dbá o zlepšování jejich úrovně,
h) navrhuje úpravy požadavků na stavby, jejich části, funkce, prvky a stavební výrobky
a podává podněty k úpravě českých technických norem nebo certifikace stavebních
výrobků anebo k jiným stavebně technickým opatřením,
i)
připravuje seznam závazných českých technických norem nebo jejich částí obsahujících
podrobnější technické požadavky na stavby, které určí Úřad pro technickou normalizaci,
metrologii a státní zkušebnictví jako určené technické normy ve stavebnictví a oznámí je
ve Věstníku podle jiného právního předpisu s výjimkou norem stanovených prováděcím
právním předpisem územního samosprávného celku,
j)
zajišťuje bezplatný přístup k určeným technickým normám ve stavebnictví podle jiného
právního předpisu s výjimkou norem stanovených prováděcím právním předpisem
územního samosprávného celku,
k) vykonává kontrolu ve věcech stavebního řádu,
l)
vykonává kontrolu nad činností autorizovaných inspektorů a
m) je jednotným kontaktním místem ve smyslu čl. 9 nařízení Evropského parlamentu a Rady
(EU) 2024/1252 pro vyhrazené stavby.
(2) Proti rozhodnutí Úřadu vydanému v řízení podle části šesté tohoto zákona není
přípustný rozklad.“.
80.
§ 32a a 32b se zrušují.
81.
§ 33 a 34 včetně nadpisů znějí:
„§ 33
Úřad rozvoje území kraje
Úřad rozvoje území kraje
a) vykonává působnost stavebního úřadu v případech, ve kterých nevykonává působnost Úřad
nebo jiný stavební úřad, ve věcech
1. záměrů EIA,
2. silnic I. třídy,
3. výroben z obnovitelných zdrojů energie neuvedených v příloze č. 3 k tomuto zákonu,
4. vodních nádrží s celkovým objemem nad 1000000 m3 nebo s výškou vzdutí nad 10 m
ode dna základové výpusti,
5. staveb a zařízení distribuční soustavy o napětí 110 kV včetně transformovny 110 kV
a staveb a zařízení pro ukládání energie připojených do distribuční soustavy s napětím
110 kV,
6. staveb a zařízení distribuční soustavy plynu o tlakové hladině nad 4 do 40 barů včetně
a souvisejících technologických objektů, u nichž se uvedené tlakové rozmezí týká
výstupního tlaku,
b) vykonává působnost stavebního úřadu a vyvlastňovacího úřadu u staveb vyžadujících
vyvlastňovací řízení, které by jinak spadaly do působnosti územního pracoviště úřadu
rozvoje území kraje, a působnost vyvlastňovacího úřadu u drobných staveb a v dalších
případech, není-li k nim příslušný Úřad,
c) vydává rámcové povolení pro stavby v působnosti jiného stavebního úřadu, včetně staveb
souvisejících,
d) vykonává kontrolu ve věcech stavebního řádu a
e) uplatňuje stanovisko k návrhu územního opatření o podmínkách a zmírňujících opatřeních
a jeho změnám podle zákona o urychlení využívání obnovitelných zdrojů energie
a vykonává působnost stavebního úřadu ve věcech záměrů pro využití obnovitelného
zdroje energie v akcelerační oblasti, u kterých nevykovává působnost Úřad.
§ 34
Územní pracoviště
Územní pracoviště
a) vykonává působnost stavebního úřadu ve věcech záměrů, u kterých nevykonává působnost
Úřad, úřad rozvoje území kraje nebo jiný stavební úřad, a
b) vykonává kontrolu ve věcech stavebního řádu.“.
82.
§ 34a se včetně nadpisu zrušuje.
83.
V § 35 odst. 4 se slova „krajského úřadu nebo obecního stavebního úřadu“ nahrazují slovy
„úřadů rozvoje území“.
84.
V § 36 odst. 1 úvodní části ustanovení se slova „a bezpečnosti“ nahrazují slovy „nebo
bezpečnosti“.
85.
V § 36 odst. 1 písm. a) se za slovo „vydává“ vkládají slova „vyjádření pro stavby
kategorie I nebo“ a za slovo „stanovisko“ se vkládají slova „pro stavby kategorie II“.
86.
V § 36 se doplňují odstavce 4 a 5, které znějí:
„(4) Z hlediska dopadů na zajišťování obrany nebo bezpečnosti státu podle odstavce 1 se
stavby člení na
a) stavbu kategorie 0, nepředstavující zvláštní dopady,
b) stavbu kategorie I, představující mírné dopady,
c) stavbu kategorie II, představující vyšší dopady.
(5) Prováděcí právní předpis stanoví charakteristiku stavby pro její zařazení do kategorie
podle odstavce 4. Charakteristikou stavby je druh stavby, případně stavebně technický parametr
stavby a její umístění.“.
87.
§ 37 včetně nadpisu zní:
„§ 37
Kvalifikační požadavky
(1) Orgány územního plánování a stavební úřady vykonávají činnost prostřednictvím osob
splňujících kvalifikační požadavky podle tohoto zákona nebo podle jiných zákonů.
(2) Kvalifikační požadavky splňuje dále fyzická osoba, která má
a) osvědčení o zvláštní odborné způsobilosti pro úředníky územních samosprávných celků
pro správní činnosti v územním plánování, stavebním řádu nebo vyvlastnění nebo
osvědčení o úspěšném vykonání úřednické zkoušky pro obor specializace, jehož součástí
je legislativa, právní činnost, stavebnictví, bydlení, regionální rozvoj, územní plánování
nebo stavební řád, a
b) vzdělání
1. vysokoškolské ve studijním programu náležejícím do oblasti architektura
a urbanismus, biologie, ekologie a životní prostředí, doprava, ekonomické obory,
energetika, lesnictví a dřevařství, právo, stavebnictví, vědy o zemi, strojírenství,
technologie a materiály,
2. vyšší odborné nebo střední s maturitní zkouškou v oboru stavebnictví, geodézie
a katastr nemovitostí, obecně právní činnost, veřejnosprávní činnost nebo doprava.
(3) Pokud při postupech podle tohoto zákona vykonává stavební úřad působnost podle
jiných právních předpisů, podílejí se na této činnosti oprávněné úřední osoby, které splňují
kvalifikační požadavky podle jiných právních předpisů a mají osvědčení o zvláštní odborné
způsobilosti pro úředníky územních samosprávných celků pro příslušnou správní činnost nebo
osvědčení o úspěšném vykonání úřednické zkoušky pro příslušný obor.
(4) Osoba nesplňující kvalifikační požadavky může vykonávat činnost, pouze pokud je
zajištěno, že bude do doby splnění požadavků vykonávat tuto činnost pod odborným vedením
osoby splňující kvalifikační požadavky, nejvýše však po dobu 3 let.“.
88.
V § 38 odstavce 1 až 4 znějí:
„(1) Cílem územního plánování je ve veřejném zájmu vytvářet předpoklady pro využití
a udržitelný rozvoj území spočívající ve vyváženém vztahu podmínek pro život lidí a jejich
bydlení, práci, podnikání, rekreaci a soudržnost společenství obyvatel území, pro příznivé
životní prostředí a pro hospodářský rozvoj, který uspokojuje potřeby současné generace, aniž
by ohrožoval podmínky života generací budoucích. Cílem územního plánování ve veřejném
zájmu je také zvyšovat kvalitu a krásu vystavěného prostředí sídel, rozvíjet jejich identitu
a vytvářet funkční a harmonické prostředí pro každodenní život jejich obyvatel.
(2) Územní plánování soustavně a komplexně řeší využití území a stanovuje zásady jeho
prostorového a funkčního uspořádání.
(3) Územní plánování rozvíjí a chrání civilizační, kulturní a přírodní hodnoty území, včetně
urbanistického, architektonického a archeologického dědictví a krajiny jako podstatné složky
prostředí života obyvatel a základ jejich totožnosti, to vše při zajištění životních potřeb lidí,
hospodářského rozvoje a zdrojů energie a surovin.
(4) Územní plánování vytváří podmínky pro co nejlepší, efektivní a hospodárné využívání
zastavitelného území, vytváření kompaktních měst krátkých vzdáleností, ochranu
nezastavitelného území a rozvoj veřejné infrastruktury.“.
89.
V § 39 úvodní části ustanovení se za slovo „zájmu“ vkládají slova „rozvíjet a chránit
území, a za tím účelem“.
90.
V § 39 písmena a) a b) znějí:
„a) zjišťovat, posuzovat a vyhodnocovat stav území, potenciál jeho rozvoje, prognózy jeho
dalšího vývoje a jeho civilizační, kulturní a přírodní hodnoty,
b) stanovovat s ohledem na jeho potenciál, podmínky a hodnoty území koncepci využití
a rozvoje území, včetně dlouhodobé urbanistické koncepce sídel, rozvoje bydlení,
hospodářství a veřejné infrastruktury s preferencí co nejlepšího a nejpestřejšího využití
zastavitelného území, ochrany volné krajiny a zlepšování prostupnosti území,“.
91.
V § 39 písm. c) se za slovo „na“ vkládají slova „potenciál jeho rozvoje,“.
92.
V § 39 písm. e) se za slovo „pro“ vkládá slovo „efektivní“, slovo „zastavěného“ se
nahrazuje slovem „zastavitelného“ a slova „sídel prostřednictvím cílené revitalizace“ se
nahrazují slovy „a revitalizací nevyužitých,“.
93.
V § 39 písm. f) se slova „vyhodnocovat a, je-li to účelné,“ zrušují, za slova „vhodné
plochy pro výrobu“ se vkládají slova „ , skladování, distribuci a nakládání s odpady“ a za
slova „ ; plochy pro výrobu“ se vkládají slova „ , skladování a distribuci“.
94.
V § 39 písm. g) se za slovo „bydlení“ vkládají slova „ , příležitosti pro práci a podnikání“.
95.
V § 39 se písmeno h) zrušuje.
Dosavadní písmena i) až s) se označují jako písmena h) až r).
96.
V § 39 písm. o) se slovo „transformačních“ zrušuje a na konci textu písmene se doplňuje
slovo „změn“.
97.
V § 39 písm. q) se slovo „regulovat“ nahrazuje slovem „stanovovat“ a na konci textu
písmene se doplňují slova „s přihlédnutím k jedinečnosti a nepřemístitelnosti nerostných
zdrojů a jejich významu pro surovinovou bezpečnost a soběstačnost“.
98.
Za § 39 se vkládá nový § 39a, který včetně nadpisu zní:
„§ 39a
Politika architektury a stavební kultury
(1) Politika architektury a stavební kultury je strategickým dokumentem s celostátní
působností, který určuje vizi, cíle a opatření k dosažení kvality vystavěného prostředí.
(2) Politika architektury a stavební kultury rozvíjí cíle a úkoly územního plánování a je
podkladem pro zpracování politiky územního rozvoje. Politika architektury a stavební kultury
je kritériem pro posuzování hodnot chráněných stavebním zákonem.
(3) Úřad zajistí zveřejnění usnesení vlády, kterým byla schválena politika architektury
a stavební kultury, ve Věstníku vlády pro orgány krajů a orgány obcí a v téže lhůtě zveřejní
politiku architektury a stavební kultury způsobem umožňujícím dálkový přístup.
(4) Úřad nejpozději do 6 let od schválení politiky architektury a stavební kultury a poté
nejméně jednou za 6 let předloží vládě zprávu o plnění politiky architektury a stavební kultury.
Vláda může na jejím základě uložit Úřadu pořídit aktualizaci nebo novou politiku architektury
a stavební kultury.“.
99.
V § 41 se slova „funkčního využití,“ nahrazují slovy „stávající nebo plánované“ a za
slovo „jejich“ se vkládají slova „využití a“.
100. V § 41 se dosavadní text označuje jako odstavec 1 a doplňuje se odstavec 2, který zní:
„(2) Při posuzování souladu s charakterem území se zohledňuje veřejný zájem na
zvyšování kvality vystavěného prostředí, architektury a stavební kultury.“.
101. V § 42 se na konci textu odstavce 1 doplňují slova „a organizace podle horního zákona“.
102. V § 42 odst. 3 větě první, § 50 odst. 1 úvodní části ustanovení, § 53 odst. 3 úvodní části
ustanovení, § 70 odst. 3 větě první, § 71a odst. 1, § 71b odst. 1 úvodní části ustanovení,
§ 71b odst. 3 větě první, § 71b odst. 4, § 71c odst. 1, § 71d odst. 1 a 2, § 71d odst. 5 větě
první, § 71e odst. 3 větě první, § 114 odst. 3 větě druhé, § 128 odst. 4 větě druhé, § 129,
§ 267 odst. 1, § 268 odst. 2, § 281 odst. 1 úvodní části ustanovení, § 281 odst. 2, § 286
větě první a § 287 odst. 2 úvodní části ustanovení se slovo „Ministerstvo“ nahrazuje
slovem „Úřad“.
103. V § 42 odst. 4 větě druhé se slovo „na“ nahrazuje slovem „v“.
104. V 42 odst. 5 se věta první zrušuje a ve větě druhé se slova „ministerstvo, které“ nahrazují
slovy „Úřad, který“.
105. § 43 včetně nadpisu zní:
„§ 43
Zveřejňování a ukládání dokumentů
(1) Orgány územního plánování informují veřejnost a dotčené orgány o své činnosti,
zejména o pořizování nástrojů územního plánování podle tohoto zákona; ustanovení části šesté
správního řádu o zveřejňování a doručování se nepoužijí. Osobám, které nejsou schopny využít
národní geoportál územního plánování, orgány územního plánování umožní nahlížet do
zveřejňovaných informací a činit si z nich výpisy a kopie.
(2) Příslušný pořizovatel zveřejňuje zadání územně plánovací dokumentace, územně
plánovací dokumentaci a její úplné znění, zastavitelné území, územní studii a územní opatření
a jejich návrhy v národním geoportálu územního plánování.“.
106. V části třetí hlavě II se díl 2 včetně nadpisů zrušuje.
Dosavadní díly 3 až 5 se označují jako díly 2 až 4.
107. § 46 a 47 včetně nadpisů znějí:
„§ 46
Pořizovatel
(1) Pořizovatelem se v tomto zákoně rozumí orgán územního plánování.
(2) Pořizovatel vykonává odbornou územně plánovací činnost prostřednictvím
a) státního zaměstnance v oboru specializace, jehož součástí je územní plánování nebo
regionální rozvoj,
b) úředníka územního samosprávného celku nebo zaměstnance jím zřízené právnické osoby
nebo společenství obcí s osvědčením o zvláštní odborné způsobilosti pro správní činnost
územní plánování podle jiného právního předpisu, nebo
c) osoby splňující kvalifikační požadavky pro výkon územně plánovací činnosti, které bylo
uděleno oprávnění k výkonu územně plánovací činnosti Úřadem (dále jen „zástupce
pořizovatele“).
§ 47
Pořizování jiným pořizovatelem
(1) Obec může uzavřít veřejnoprávní smlouvu s jinou obcí, krajem nebo společenstvím
obcí, jehož je členem, o výkonu odborných činností pořizovatele nástrojů územního plánování.
(2) Úřad rozvoje území kraje nebo jeho územní pracoviště pořídí bezplatně na základě
veřejnoprávní smlouvy územní plán a územní opatření pro obec, pokud jej o to obec požádá.“.
108. § 48 se včetně nadpisu zrušuje.
109. V § 49 odst. 1 se slova „a zastupitelstvo kraje“ nahrazují slovy „ , pro kterou pořizuje
územní plán, regulační plán nebo územní studii jiný pořizovatel,“ a slova „územně
plánovací dokumentace obce nebo kraje“ se zrušují.
110. V § 49 odst. 2 se slovo „Pořizovatel“ nahrazuje slovy „Jiný pořizovatel“.
111. V § 49 odst. 3 se za slovo „mezi“ vkládá slovo „jiným“.
112. V § 49 se odstavec 4 zrušuje.
113. V § 50 odst. 1 písm. b) se za slova „má osvědčení“ vkládá slovo „o“ a slova „státní služby“
se nahrazují slovem „specializace“.
114. V § 50 odst. 1 písm. c) se slova „vzdělání a praxe“ zrušují a text „44 odst. 4“ se nahrazuje
číslem „37“.
115. V § 50 odst. 1 písm. e) se za slovo „činnost“ vkládají slova „ve veřejné správě po dobu
nejméně 3 let“ a slovo „ministerstvo“ se nahrazuje slovem „Úřad“.
116. V § 51 odst. 1 písm. b) se slova „Českou komorou architektů“ zrušují.
117. V § 51 se odstavce 2 až 4 zrušují a zároveň se zrušuje označení odstavce 1.
118. V § 52 odst. 1 písm. a) se slova „podle § 44 odst. 3, nebo doklad o udělení výjimky podle
§ 45 odst. 1“ zrušují.
119. V § 52 odst. 1 písm. c) se slovo „zvláštní“ nahrazuje slovy „o zvláštní“.
120. V § 52 se odstavec 2 zrušuje a zároveň se zrušuje označení odstavce 1.
121. V § 53 se odstavec 1 zrušuje.
Dosavadní odstavce 2 až 4 se označují jako odstavce 1 až 3.
122. V § 53 odst. 1 písm. a) se slova „ministrovi pro místní rozvoj“ nahrazují slovem „Úřadu“.
123. V § 53 odst. 1 se písmeno b) zrušuje.
Dosavadní písmena c) až e) se označují jako písmena b) až d).
124. V § 53 odst. 1 písm. d) se číslo „3“ nahrazuje číslem „2“.
125. V § 53 odst. 3 se slova „obecní úřad“ nahrazují slovem „pořizovatele“ a slovo „který“ se
nahrazuje slovem „kterého“.
126. V § 54 se vkládá nový odstavec 1, který včetně poznámky pod čarou č. 80 zní:
„(1) Dotčené orgány chrání veřejné zájmy podle jiných zákonů80), jsou-li tyto zájmy
dotčeny, způsobem podle § 2 a 3 a při respektování cílů a úkolů územního plánování
a s přihlédnutím k zájmu územních samosprávných celků a státu na rozvoji svého území.
__________
80)
Zákon č. 20/1987 Sb., o státní památkové péči, ve znění pozdějších předpisů.
Zákon č. 44/1988 Sb., o ochraně a využití nerostného bohatství (horní zákon), ve znění
pozdějších předpisů.
Zákon č. 61/1988 Sb., o hornické činnosti, výbušninách a o státní báňské správě, ve
znění pozdějších předpisů.
Zákon č. 62/1988 Sb., o geologických pracích a o Českém geologickém úřadu, ve znění
pozdějších předpisů.
Zákon č. 114/1992 Sb., o ochraně přírody a krajiny, ve znění pozdějších předpisů.
Zákon č. 334/1992 Sb., o ochraně zemědělského půdního fondu, ve znění pozdějších
předpisů.
Zákon č. 266/1994 Sb., o dráhách, ve znění pozdějších předpisů.
Zákon č. 114/1995 Sb., o vnitrozemské plavbě, ve znění pozdějších předpisů.
Zákon č. 289/1995 Sb., o lesích a o změně a doplnění některých zákonů (lesní zákon),
ve znění pozdějších předpisů.
Zákon č. 13/1997 Sb., o pozemních komunikacích, ve znění pozdějších předpisů.
Zákon č. 49/1997 Sb., o civilním letectví, ve znění pozdějších předpisů.
Zákon č. 166/1999 Sb., o veterinární péči a o změně některých souvisejících zákonů
(veterinární zákon), ve znění pozdějších předpisů.
Zákon č. 222/1999 Sb., o zajišťování obrany České republiky, ve znění pozdějších
předpisů.
Zákon č. 239/2000 Sb., o integrovaném záchranném systému a o změně některých
zákonů, ve znění pozdějších předpisů.
Zákon č. 258/2000 Sb., o ochraně veřejného zdraví a o změně některých souvisejících
zákonů, ve znění pozdějších předpisů.
Zákon č. 406/2000 Sb., o hospodaření energií, ve znění pozdějších předpisů.
Zákon č. 458/2000 Sb., o podmínkách podnikání a o výkonu státní správy
v energetických odvětvích a o změně některých zákonů (energetický zákon), ve znění
pozdějších předpisů.
Zákon č. 100/2001 Sb., o posuzování vlivů na životní prostředí a o změně některých
souvisejících zákonů (zákon o posuzování vlivů na životní prostředí), ve znění
pozdějších předpisů.
Zákon č. 164/2001 Sb., o přírodních léčivých zdrojích, zdrojích přírodních minerálních
vod, přírodních léčebných lázních a lázeňských místech a o změně některých
souvisejících zákonů (lázeňský zákon), ve znění pozdějších předpisů.
Zákon č. 254/2001 Sb., o vodách a o změně některých zákonů (vodní zákon), ve znění
pozdějších předpisů.
Zákon č. 312/2001 Sb., o státních hranicích a o změně zákona č. 200/1990 Sb., o
přestupcích, ve znění pozdějších předpisů, (zákon o státních hranicích), ve znění
pozdějších předpisů.
Zákon č. 139/2002 Sb., o pozemkových úpravách a pozemkových úřadech a o změně
zákona č. 229/1991 Sb., o úpravě vlastnických vztahů k půdě a jinému zemědělskému
majetku, ve znění pozdějších předpisů, ve znění pozdějších předpisů.
Zákon č. 201/2012 Sb., o ochraně ovzduší, ve znění pozdějších předpisů.
Zákon č. 224/2015 Sb., o prevenci závažných havárií způsobených vybranými
nebezpečnými chemickými látkami nebo chemickými směsmi a o změně zákona č.
634/2004 Sb., o správních poplatcích, ve znění pozdějších předpisů, (zákon o prevenci
závažných havárií), ve znění pozdějších předpisů.
Zákon č. 263/2016 Sb., atomový zákon, ve znění pozdějších předpisů.
Zákon č. 541/2020 Sb., o odpadech, ve znění pozdějších předpisů.
Zákon č. 249/2025 Sb., o urychlení využívání některých obnovitelných zdrojů energie
a o změně souvisejících zákonů (zákon o urychlení využívání obnovitelných zdrojů
energie), ve znění pozdějších předpisů.“.
Dosavadní odstavce 1 až 4 se označují jako odstavce 2 až 5.
127. V § 54 odst. 2 větě první se za slovo „je“ vkládají slova „z hlediska souladu s dotčenými
veřejnými zájmy chráněnými jinými zákony“, slovo „zastavěného“ se nahrazuje slovem
„zastavitelného“ a za slovo „rozporů“ se vkládají slova „dohodnuto nebo“.
128. V § 54 se na konci odstavce 2 doplňují věty „Pořizovatel nepřihlíží k vyjádřením
a stanoviskům dotčených orgánů ve věcech, o nichž bylo rozhodnuto při schválení
politiky územního rozvoje a vydání nadřazené územně plánovací dokumentace.
Pořizovatel se může od stanoviska dotčeného orgánu odchýlit v části, ve které není
stanovisko odůvodněno nebo překračuje působnost dotčeného orgánu nebo měřítko či
podrobnost pořizované územně plánovací dokumentace.“.
129. V § 54 odst. 3 se slova „ , návrhu zprávy o uplatňování územně plánovací dokumentace
a návrhu zadání změny územně plánovací dokumentace“ zrušují.
130. § 55 včetně nadpisu zní:
„§ 55
Řešení rozporů
(1) Pořizovatel projednává protichůdná stanoviska dotčených orgánů a zájmy obcí, krajů
a státu a oprávněných investorů, koordinuje je a řeší případné rozpory podle zásad uvedených
v § 1a a § 18 odst. 1 a 2.
(2) Dojde-li k rozporu mezi dotčenými orgány nebo mezi obcí nebo krajem a dotčeným
orgánem, projedná jej pořizovatel se stranami tohoto rozporu v dohodovacím řízení, jež je
zahájeno dnem, kdy oznámení pořizovatele o jeho zahájení spolu s návrhem řešení dojde
stranám rozporu. Nezúčastní-li se dotčený orgán bez důvodné omluvy dohodovacího řízení,
které pořizovatel svolal alespoň 5 pracovních dnů před jeho konáním, platí, že od rozporu
ustoupil.
(3) Nedojde-li k dohodě do 30 dnů od zahájení dohodovacího řízení, podá pořizovatel
návrh na rozhodnutí o rozporu Úřadu spolu s návrhem řešení rozporu. Je-li pořizovatelem
Ministerstvo obrany nebo Úřad, podá pořizovatel návrh na rozhodnutí o rozporu vládě spolu
s návrhem řešení rozporu.
(4) Před rozhodnutím o rozporu Úřad vyzve příslušný ústřední orgán státní správy
k vyjádření ve lhůtě 15 dnů. Před rozhodnutím o rozporu zašle Úřad vyjádření ústředního
orgánu státní správy podle věty první stranám rozporu a může též nařídit společné jednání podle
§ 18 odst. 2.
(5) Úřad rozhodne o rozporu bez zbytečného odkladu, nejpozději do 60 dnů od doručení
návrhu pořizovatele. Nerozhodne-li Úřad ve stanovené lhůtě, může pořizovatel předložit zprávu
o průběhu dohodovacího řízení spolu s návrhem řešení rozporu vládě, která o rozporu rozhodne
bezodkladně.
(6) O rozporu mezi obcí nebo krajem a státním orgánem rozhodne Úřad rozhodnutím podle
části druhé správního řádu; proti rozhodnutí Úřadu není přípustný rozklad.
(7) Rozhodnutí o rozporu zveřejní Úřad v národním geoportálu územního plánování.“.
131. V § 56 se odstavec 6 zrušuje.
132. Ve skupinovém nadpisu nad označením § 57 se slova „a koordinační výkres“ zrušují.
133. V § 57 se odstavce 3 a 4 zrušují.
134. § 59 včetně nadpisu zní:
„§ 59
Jednotný standard
(1) Územně plánovací dokumentace, její změna a úplné znění, územní studie, vymezení
zastavitelného území, jeho změna a úplné znění a územní opatření se vyhotovují a vydávají
v jednotném standardu jako digitální textová a prostorová data ve vektorové formě ve strojově
čitelném formátu.
(2) Jednotný standard stanoví standardizované části a požadavky na
a) geodetický referenční systém,
b) strukturu standardizovaných částí,
c) výměnný formát dat a
d) metadata.
(3) Obsah jednotného standardu a požadavky na strojově čitelný formát stanoví prováděcí
právní předpis.“.
Poznámky pod čarou č. 10 a 11 se zrušují.
135. V § 62 odst. 1 se slova „ , vymezení zastavěného území a pro rozhodování v území“
nahrazují slovy „a vymezení zastavitelného území“.
136. V § 62 odstavec 2 zní:
„(2) Územně analytické podklady jsou tvořeny údaji o území, které obsahují zjištění stavu
území, jeho hodnot a limitů využití území, včetně známých záměrů a které vkládají do
národního geoportálu územního plánování příslušní poskytovatelé. Územně analytické
podklady jsou vedeny v národním geoportálu územního plánování v jednotné databázi, jejímž
správcem je Úřad.“.
137. V § 62 odst. 3 se za slovo „podkladů“ vkládají slova „ , obsah, rozsah a podrobnost údajů
o území a způsob jejich poskytování Úřadu“.
138. V § 63 odst. 1 se za slovo „například“ vkládá slovo „koridoru“.
139. V § 63 odst. 2 úvodní části ustanovení se slovo „pořizovateli“ zrušuje.
140. V § 63 se doplňuje odstavec 3, který zní:
„(3) Kraj zpracovává a poskytuje údaje o území v podrobnosti a rozsahu nezbytném pro
územně plánovací činnost kraje a obcí v území kraje.“.
141. V § 64 se odstavec 3 zrušuje.
Dosavadní odstavec 4 se označuje jako odstavec 3.
142. V nadpisu § 65 se slova „Pořizování a aktualizace“ nahrazují slovem „Aktualizace“.
143. V § 65 odst. 1 větě první se slova „a jejich aktualizace pořizuje pořizovatel“ nahrazují
slovy „aktualizují jednotliví poskytovatelé“ a věta druhá se zrušuje.
144. V § 65 odst. 2 se slovo „pořízení“ nahrazuje slovem „aktualizaci“.
145. V § 65 se odstavec 3 zrušuje.
146. § 66 se včetně nadpisu zrušuje.
147. V § 68 odstavec 4 zní:
„(4) Pořizovatel může projednat návrh územní studie s vlastníky dotčených nemovitostí,
s dotčenými orgány nebo s veřejností.“.
148. V § 68 odst. 5 se slovo „vloží“ nahrazuje slovem „vydá“ a slova „ , kdy schválil možnost
jejího využití,“ se nahrazují slovy „jejího schválení vložením“.
149. V § 69 odst. 2 se slova „ministerstvo, nebo jím pověřená organizační složka státu,“
nahrazují slovem „Úřad“.
150. V § 70 odst. 1 větě první se za slovo „konkretizaci“ vkládají slova „cílů a“ a za slovo
„těchto“ se vkládají slova „cílů a“.
151. V § 71 odst. 1 se na konci textu písmene b) doplňují slova „a jejího rozvoje“.
152. V § 71 odst. 1 písmeno d) zní:
„d) vymezí oblasti se specifickým potenciálem, specifickými hodnotami nebo se specifickými
problémy, mají-li mezinárodní nebo celostátní význam anebo přesahují-li území jednoho
kraje (dále jen „specifické oblasti“),“.
153. V § 71a odst. 2 větě první se slovo „ministerstva“ nahrazuje slovem „Úřadu“ a ve větě
druhé se slovo „ministerstvu“ nahrazuje slovem „Úřadu“.
154. V § 71a odst. 3 úvodní části ustanovení se slovo „ministerstvo“ nahrazuje slovy „Úřad
zejména“.
155. V § 71a odst. 3 se vkládá nové písmeno a), které zní:
„a) politiky architektury a stavební kultury,“.
Dosavadní písmena a) až e) se označují jako písmena b) až f).
156. V § 71c odst. 2 větě druhé se slovo „ministerstvu“ nahrazuje slovem „Úřadu“.
157. V § 71c odst. 4 větě druhé se číslo „1“ nahrazuje číslem „2“.
158. V § 71d odst. 1 se za slovo „rozvoje“ vkládají slova „prostřednictvím Ministerstva
hospodářství“.
159. V § 71d odst. 3 písm. b) se slova „vyplývající z územně analytických podkladů“ zrušují.
160. V § 71d odst. 5 větě druhé se slovo „ministerstvu“ nahrazuje slovem „Úřadu“.
161. V § 71d odst. 6 úvodní části ustanovení se slovo „ministerstvo“ nahrazuje slovy „Úřad
prostřednictvím Ministerstva hospodářství“.
162. V § 72 se na začátek odstavce 1 vkládá věta „Územně plánovací dokumentace naplňuje
a rozvíjí cíle a úkoly územního plánování a vyjadřuje veřejný zájem na prostorovém
uspořádání a způsobu využití území.“.
163. V § 72 se na konci odstavce 3 doplňuje věta „Vztah původní a nové, případně změněné
územně plánovací dokumentace mohou upravit přechodná ustanovení.“.
164. V § 73 odst. 2 se na konci textu věty první doplňují slova „ , nestanoví-li zákon jinak“.
165. V § 73 se na konci odstavce 3 doplňuje věta „Za rozpor se nepovažuje, pokud navazující
územně plánovací dokumentace obsahuje záležitosti, které nejsou vymezeny v nadřazené
územně plánovací dokumentaci.“.
166. V § 73 odst. 5 se na konci textu věty první doplňují slova „nebo v území s ním
souvisejícím po zohlednění potřeb území, podrobností regulace a jejího měřítka“, za větu
první se vkládá věta „Navazující územně plánovací dokumentace se může se souhlasem
Úřadu a toho, kdo vydal nadřazenou územně plánovací dokumentaci, v rámci zpřesnění
vymezení ploch a koridorů v nezbytném rozsahu odchýlit od jejich vymezení v nadřazené
územně plánovací dokumentaci, pokud dodrží smysl a účel nadřazené územně plánovací
dokumentace.“ a na konci odstavce se doplňuje věta „Pro možnost odchýlení se od
územního opatření, vymezení zastavitelného území a ochranného pásma platí možnost
odchýlení se od jejich vymezení a podmínek při dodržení jejich smyslu a účelu obdobně.“.
167. V § 74 odst. 2 písm. a) se slova „zastavitelné plochy, transformační“, slova „dopravní
a technické infrastruktury“ a slova „ , vymezené politikou územního rozvoje“ zrušují a za
slova „podmínky pro“ se vkládají slova „jejich využití a pro“.
168. V § 74 odst. 2 písmeno b) zní:
„b) plochy a koridory pro strategické investiční stavby,“.
169. V § 76 se doplňuje odstavec 3, který zní:
„(3) Do územního rozvojového plánu může pořizovatel převzít plochy a koridory pro
záměry mezinárodního nebo celostátního významu anebo záměry přesahující svým významem
území jednoho kraje, vymezené v zásadách územního rozvoje, u kterých marně uplynula lhůta
pro jejich zrušení podle správního řádu a soudního řádu správního. Tento postup nepodléhá
řízení podle § 87 až 111a ani posuzování vlivů na udržitelný rozvoj území podle § 40 a nabývá
účinnosti dnem vyvěšení veřejné vyhlášky o zveřejnění úplného znění. Soulad s politikou
územního rozvoje se neposuzuje.“.
170. V § 77 odst. 2 písm. d) a e) se slova „zastavitelné plochy, transformační“ zrušují.
171. V § 79 se doplňuje odstavec 5, který zní:
„(5) Do zásad územního rozvoje může pořizovatel se souhlasem příslušného úřadu rozvoje
území kraje převzít plochy a koridory pro záměry nadmístního významu vymezené v územním
plánu, u kterých marně uplynula lhůta pro jejich zrušení podle správního řádu a soudního řádu
správního. Tento postup nepodléhá řízení podle § 87 až 111a ani posuzování vlivů na udržitelný
rozvoj území podle § 40 a nabývá účinnosti dnem vyvěšení veřejné vyhlášky o zveřejnění
úplného znění. Soulad s politikou územního rozvoje a s nadřazenou územně plánovací
dokumentací se neposuzuje.“.
172. V § 80 odst. 2 písm. a) se slovo „zastavěné“ nahrazuje slovem „zastavitelné“ a slova „a
stanoví datum, k němuž je vymezeno“ se zrušují.
173. V § 80 odst. 2 písm. c) se slova „ , jejíž součástí je i urbanistická kompozice, vymezení
ploch podle stávajícího nebo nově požadovaného způsobu využití (dále jen „plocha
s rozdílným způsobem využití“), vymezení zastavitelných ploch, transformačních ploch,
systému veřejných prostranství a systému sídelní zeleně“ zrušují.
174. V § 80 odst. 2 písm. d) se slova „a koridorů“ nahrazují slovy „ , koridorů a prvků“.
175. V § 80 odst. 2 písm. e) se slova „i vymezení ploch s rozdílným způsobem využití, ploch
změn v krajině a“ zrušují a slovo „jejich“ se nahrazuje slovem „její“.
176. V § 80 odst. 2 písmeno f) zní:
„f) stanoví podmínky prostorového uspořádání a využití území, včetně požadavků na rozvoj,
zachování nebo změnu charakteru území; plochy a koridory, podmínky pro jejich využití
a podmínky prostorového uspořádání mohou být vymezeny vzájemně nezávisle; podmínky
pro využití ploch se stanovují určením hlavního využití, nepřípustného využití, popřípadě
podmíněně přípustného využití těchto ploch a“.
177. V § 81 se odstavec 2 zrušuje.
Dosavadní odstavce 3 až 6 se označují jako odstavce 2 až 5.
178. V § 81 odst. 2 větě druhé se za slovo „základní“ vkládají slova „podmínky pro“ a slovo
„ , podmínky“ se zrušuje.
179. V § 82 odst. 2 větě první a druhé se slova „hlavního města Prahy“ nahrazují slovem
„obce“.
180. V § 82 odst. 3 se slova „ , stanoví-li tak zastupitelstvo obce v zadání územního plánu nebo
v zadání změny územního plánu“ zrušují.
181. V § 83 se odstavec 3 zrušuje.
182. V § 85 odstavec 1 zní:
„(1) Regulační plán v řešeném území stanoví podrobné podmínky pro vymezení a využití
pozemků.“.
183. V § 85 odst. 2 úvodní části ustanovení se slova „zpravidla stanoví“ nahrazují slovy „může
stanovit zejména“.
184. V § 85 odst. 2 se za písmeno a) vkládá nové písmeno b), které zní:
„b) umístění a prostorové uspořádání staveb, včetně jejich napojení na veřejnou dopravní
a technickou infrastrukturu, a urbanistických a architektonických podmínek,“.
Dosavadní písmena b) až g) se označují jako písmena c) až h).
185. V § 85 odst. 2 písm. d) se za slovo „objem“ vkládají slova „nebo požadavky na vnější
vzhled“.
186. V § 85 se na konci odstavce 2 tečka nahrazuje čárkou a doplňuje se písmeno i), které zní:
„i) podmínky pro ochranu hodnot, charakteru území nebo krajinného rázu.“.
187. V § 86 odst. 3 větě druhé se za slovo „základní“ vkládají slova „obsah plánovací
smlouvy,“.
188. V § 86 se odstavec 5 zrušuje.
Dosavadní odstavec 6 se označuje jako odstavec 5.
189. V § 87 odst. 1 úvodní části ustanovení se slovo „vydání“ nahrazuje slovem „schválení“.
190. V § 87 odst. 2 větě první, § 90 odst. 1, § 93 odst. 2, § 93 odst. 3 větě první, § 98 odst. 1,
§ 98 odst. 2 větě první, § 98 odst. 4 a 6 a § 104 odst. 1 úvodní části ustanovení větě první
se za slovo „zastupitelem“ vkládají slova „ , je-li určen,“.
191. V § 87 odst. 2 se věta druhá zrušuje.
192. V § 87 odst. 3 se slova „územního plánu pro vymezenou část území hlavního města
Prahy“ nahrazují slovy „územních plánů pro vymezenou část obce“.
193. V § 87 se doplňuje odstavec 5, který zní:
„(5) Rozhodnutí o pořízení regulačního plánu nebo územního plánu může zastupitelstvo
kraje nebo obce nahradit schválením plánovací smlouvy, ve které se stavebník zaváže ke
zpracování nebo převzetí nákladů na zpracování návrhu zadání regulačního plánu nebo
územního plánu nebo návrhu regulačního plánu nebo územního plánu.“.
194. V § 88 odst. 1 úvodní části ustanovení větě první se slovo „toto“ nahrazuje slovy „adresu
tohoto“.
195. V § 88 odst. 1 se vkládá nové písmeno a), které zní:
„a) krajům v případě územního rozvojového plánu,“.
Dosavadní písmena a) a b) se označují jako písmena b) a c).
196. V § 88 odst. 1 písm. b) se slovo „ministerstvu“ nahrazuje slovy „nadřízenému orgánu“.
197. V § 88 odst. 1 písm. c) se slova „územního plánování a územním samosprávným celkům
s řešeným územím přímo sousedícím“ nahrazují slovy „a kraji, ve kterém se obec nachází,
Ministerstvu obrany, je-li územní plán zpracováván pro obec sousedící s vojenským
újezdem a sousedním obcím“.
198. V § 88 se na konci odstavce 1 tečka nahrazuje čárkou a doplňuje se písmeno d), které zní:
„d) nadřízenému orgánu a sousedním krajům a sousedním obcím v případě územního plánu
hlavního města Prahy.“.
199. V § 88 se odstavec 2 zrušuje a zároveň se zrušuje označení odstavce 1.
200. V § 89 odst. 5 úvodní části ustanovení se text „odst. 1“ zrušuje.
201. V § 89 odst. 5 písm. a) se slovo „a“ nahrazuje čárkou a za slova „nadřízený orgán“ se
vkládají slova „a oprávněný investor“.
202. V § 90 se odstavec 2 zrušuje.
Dosavadní odstavec 3 se označuje jako odstavec 2.
203. § 91 se včetně skupinového nadpisu zrušuje.
204. Pod označení § 92 se vkládá nadpis, který zní: „Úhrada nákladů“.
205. V § 92 odst. 1 se slova „uvedené v § 91 odst. 1 na žádost ministerstvo, jedná-li se
o politiku územního rozvoje nebo územní rozvojový plán, nebo územní samosprávný
celek, který vydal nadřazenou územně plánovací dokumentaci“ nahrazují slovy „na
pořízení změny na žádost pořizovatele ten, kdo potřebu změny vyvolal“.
206. V § 92 odst. 3 se slova „schvalující orgán“ nahrazují slovem „pořizovatel“ a slova
„uvedených v odstavci 1 a v § 91 odst. 1“ se zrušují.
207. V § 93 odst. 5 úvodní části ustanovení se slova „do 7 dnů po kladném vyhodnocení podle
odstavce 2“ nahrazují slovem „bezodkladně“
208. V § 93 odst. 5 písm. a) se slova „vystaví je k nahlédnutí“ zrušují.
209. V § 93 odst. 5 se písmeno b) zrušuje.
Dosavadní písmeno c) se označuje jako písmeno b).
210. V § 93 odst. 5 písm. b) se slova „místa, kde je možné do návrhu územně plánovací
dokumentace a vyhodnocení vlivů, zpracovává-li se, nahlédnout“ nahrazují slovy „adresu
zveřejnění v národním geoportálu územního plánování“.
211. § 94 se včetně nadpisu zrušuje.
212. V § 96 odst. 1 se za slovo „ , veřejnosti“ vkládají slova „ , dotčeným orgánům a územním
samosprávným celkům“ a slova „dotazů veřejnosti“ se nahrazují slovem „dotazů“.
213. V § 96 odst. 2 větě první se slova „postupem podle § 93 odst. 5 písm. c)“ nahrazují slovy
„ , je-li určen“.
214. V § 96 odst. 3 se za slovo „koná“ vkládají slova „nejdříve 15 dnů a“.
215. V § 96 se za odstavec 3 vkládá nový odstavec 4, který zní:
„(4) Pořizovatel oznámí místo a dobu konání veřejného projednání a adresu uložení návrhu
územně plánovací dokumentace v národním geoportálu územního plánování jednotlivě
dotčeným orgánům a adresátům uvedeným v § 88.“.
Dosavadní odstavec 4 se označuje jako odstavec 5.
216. V § 96 odst. 5 se slovo „písemný“ zrušuje.
217. Na konci nadpisu § 97 se doplňují slova „a stanoviska“.
218. V § 97 se doplňuje odstavec 5, který zní:
„(5) Dotčené orgány uplatní do 15 dnů ode dne konání veřejného projednání svá stanoviska
k návrhu územně plánovací dokumentace a vyjádření k vyhodnocení vlivů. Neuplatní-li
dotčený orgán v této lhůtě stanovisko nebo vyjádření, platí, že s návrhem územně plánovací
dokumentace souhlasí. Ke stanoviskům uplatněným po uvedené lhůtě nebo uplatněným ve
věcech, o nichž bylo rozhodnuto v nadřazené územně plánovací dokumentaci, se nepřihlíží.“.
219. V § 98 odst. 5 větě druhé se za slovo „stanovisko“ vkládají slova „a oprávněný investor
vyjádření“, slova „má se za to“ se nahrazují slovem „platí“ a na konci textu odstavce se
doplňují slova „ ; k později uplatněnému stanovisku nebo vyjádření se nepřihlíží“.
220. § 99 se včetně nadpisu zrušuje.
221. V § 100 odst. 2 větě druhé se číslo „1“ nahrazuje číslem „2“ a věty třetí a poslední se
zrušují.
222. V § 101 odst. 2 se věty druhá a poslední zrušují.
223. V § 101 odst. 3 se slova „věty první, nebo ve lhůtě prodloužené, je možné zásady
územního rozvoje nebo územní plán vydat i bez jeho stanoviska“ nahrazují slovy „ , platí,
že s návrhem zásad územního rozvoje nebo územního plánu souhlasí“ a na konci odstavce
se doplňuje věta „Ke stanovisku nadřízeného orgánu uplatněnému po uvedené lhůtě se
nepřihlíží.“.
224. V § 102 odst. 1 větě první se slova „vypracuje pokyny pro úpravu návrhu“ nahrazují slovy
„ , je-li určen, zajistí úpravu“.
225. V § 102 odst. 2 se věta první nahrazuje větou „Úprava návrhu územně plánovací
dokumentace může obsahovat další drobné změny, které se podstatně nedotýkají práv
dotčených osob ani veřejných zájmů chráněných dotčenými orgány, a změny
odůvodnění.“.
226. Pod označení § 103 se vkládá nadpis, který zní: „Podstatná úprava“.
227. V § 103 odstavec 1 zní:
„(1) Dojde-li na základě projednání k upravení návrhu územně plánovací dokumentace, při
němž jsou nově podstatně negativně dotčeny veřejné zájmy nebo v případě územního plánu
nebo regulačního plánu podstatně negativně dotčeno vlastnictví pozemků a staveb a dotčený
orgán, nadřízený orgán, oprávněný investor nebo vlastník neměli možnost k upravené
dokumentaci uplatnit stanovisko nebo připomínku (dále jen „podstatná úprava“), nařídí
pořizovatel bez zbytečného odkladu nové projednání v rozsahu podstatné úpravy, ledaže
dotčený orgán, nadřízený orgán, oprávněný investor nebo vlastník, kteří neměli možnost
k upravené dokumentaci uplatnit stanovisko nebo připomínku, s takovou změnou souhlasí.
Podstatnou úpravou není uvedení návrhu do souladu s nadřazenou územně plánovací
dokumentací, zpřesnění návrhu podle § 73 odst. 4 a 5, omezení rozsahu nebo podmínek územní
rezervy, přechodné ustanovení podle § 72 odst. 3, zúžení návrhu na nejvhodnější variantu, jiný
způsob grafického vyjádření nebo vnitřního uspořádání prostorových dat, a dále se souhlasem
vlastníka pozemku a oprávněného investora úprava nebo zpřesnění hranic ploch nebo koridorů,
etapizace, doplnění podmínky pro rozhodování v území, doplnění prvků regulačního plánu do
územního plánu nebo změna objemu, výšky, koeficientu nebo kapacity nepřesahující 10 %.“.
228. V § 103 odst. 3 větě první se slova „§ 93 odst. 5, § 94 až 99“ nahrazují slovy „93 odst. 5,
§ 95 až 98“ a slova „ ; společné jednání a veřejné projednání lze při splnění požadavků
kladených na obě jednání spojit“ se zrušují.
229. V § 103 odstavec 5 zní:
„(5) Stanovisko nadřízeného orgánu k podstatné úpravě návrhu zásad územního rozvoje
a územního plánu uplatní nadřízený orgán do 30 dnů ode dne konání opakovaného projednání;
pro obsah stanoviska, postup při jeho nevydání ve stanovené lhůtě a pro případ upozornění na
nedostatky se postupuje obdobně podle § 101 odst. 2 až 4.“.
230. V § 104 odst. 1 úvodní části ustanovení se věta poslední včetně písmen a) až c) zrušuje.
231. V § 104 odst. 2 větě první se slovo „vydá“ nahrazuje slovem „schválí“ a slova „po
ověření, že není v rozporu s požadavky uvedenými v odstavci 1 písm. a) a b)
a nadřazenou územně plánovací dokumentací“ se zrušují a ve větě druhé se za slovo
„návrhem,“ vkládají slova „může jej sám změnit, nedojde-li tím k podstatné úpravě,
nebo“ a slova „pořizovateli, nebo“ se nahrazují slovy „pořizovateli, anebo“.
232. V § 104 odst. 3 větě první se slova „k vydání“ zrušují.
233. V § 105 odst. 1 se slovo „vydání“ nahrazuje slovem „schválení“ a slovo „vložení“ se
nahrazuje slovy „vydání vložením“ a na konci odstavce se doplňuje věta „Okamžikem
vložení do národního geoportálu územního plánování je územně plánovací dokumentace
platná.“.
234. V § 105 odst. 2 se slova „Územně plánovací dokumentaci“ nahrazují slovy „Vydání
územně plánovací dokumentace“ a na konci textu odstavce se doplňují slova „ , není-li
v ní stanovena účinnost pozdější“.
235. V § 105 odstavec 3 zní:
„(3) Územně plánovací dokumentaci opatří pořizovatel záznamem o účinnosti.“.
236. V části třetí hlavě III dílu 4 se oddíl 3 včetně nadpisů zrušuje.
Dosavadní oddíly 4 a 5 se označují jako oddíly 3 a 4.
237. V § 108 odst. 1 se za slovo „projednává“ vkládá slovo „ , schvaluje“.
238. V § 108 odst. 2 se slovo „vydání“ nahrazuje slovem „schválení“ a slovo „vloží“ se
nahrazuje slovy „vydá vložením“.
239. V § 108 odst. 3 se slovo „Změnu“ nahrazuje slovy „Informaci o změně“ a slova „ , úplné
znění územně plánovací dokumentace po této změně a adresy jejich“ se nahrazují slovy
„a adresu jejího“.
240. V § 108 se odstavec 4 zrušuje.
241. V § 109 odst. 1 úvodní části ustanovení se slova „nebo nejde-li o změnu pořizovanou na
základě zprávy o uplatňování“ zrušují.
242. V § 109 odst. 1 písm. b) se slovo „ministerstva“ nahrazuje slovem „Úřadu“.
243. V § 109 odst. 1 se písmeno d) zrušuje.
Dosavadní písmeno e) se označuje jako písmeno d).
244. V § 109 odst. 2 úvodní části ustanovení se slova „v případě územního rozvojového plánu
u ministerstva, v ostatních případech u příslušného schvalujícího orgánu“ nahrazují slovy
„u příslušného pořizovatele“.
245. V § 109 odst. 2 písm. d) se slova „uvedených v § 91 odst. 1 a § 92“ zrušují.
246. V § 109 odst. 3 úvodní část ustanovení zní: „Nejde-li o změnu regulačního plánu, může
podnět dále obsahovat také“.
247. V § 109 odst. 3 se na konci textu písmene b) doplňují slova „ ; ustanovení § 89 odst. 4
platí obdobně“.
248. V § 109 odstavec 4 zní:
„(4) Stanovisko podle odstavce 3 písm. a) doručí orgán ochrany přírody navrhovateli
podnětu a příslušnému úřadu do 20 dnů od obdržení žádosti o jeho vydání. Stanovisko podle
odstavce 3 písm. b) doručí příslušný úřad navrhovateli podnětu do 30 dnů od obdržení žádosti
o jeho vydání.“.
249. V § 109 odstavec 5 zní:
„(5) Rozhodnutí o pořízení regulačního plánu nebo územního plánu může zastupitelstvo
kraje nebo obce nahradit schválením plánovací smlouvy, ve které se stavebník zaváže ke
zpracování nebo převzetí nákladů na zpracování návrhu zadání regulačního plánu nebo
územního plánu nebo návrhu regulačního plánu nebo územního plánu.“.
250. V § 110 odst. 1 úvodní části ustanovení se slova „návrhu zadání změny“ zrušují.
251. V § 110 odst. 2 se slova „ , a schvalující orgán“ zrušují.
252. V § 110 se doplňuje odstavec 3, který zní:
„(3) Nejde-li o změnu regulačního plánu a podnět neobsahuje stanoviska podle § 109
odst. 3, zajistí tato stanoviska pořizovatel. Ustanovení § 109 odst. 4 platí obdobně.“.
253. V § 111 se odstavec 1 zrušuje.
Dosavadní odstavce 2 až 5 se označují jako odstavce 1 až 4.
254. V § 111 odst. 1 se slova „návrh zadání“ nahrazují slovy „podnět na pořízení“.
255. V § 111 odst. 2 větě první se slova „návrhem zadání“ nahrazují slovy „podnětem na
pořízení“ a slova „schválí její zadání“ se nahrazují slovy „o jejím obsahu“ a ve větě druhé
se slova „návrhem, vrátí jej pořizovateli se svými pokyny k úpravě, nebo jej zamítne“
nahrazují slovy „podnětem, zamítne jej“.
256. V § 111 odst. 3 větě první se slova „Schvalující orgán“ nahrazují slovem „Pořizovatel“
a slova „podle § 91 odst. 1 a § 92“ se zrušují a věty druhá a poslední se zrušují.
257. V § 111 se za odstavec 3 vkládá nový odstavec 4, který zní:
„(4) Vyplyne-li ze stanovisek podle § 109 odst. 3, že návrh změny územně plánovací
dokumentace má být posuzován z hlediska vlivů na životní prostředí, doplní pořizovatel
rozhodnutí o pořízení změny o požadavek na vyhodnocení vlivů.“.
Dosavadní odstavec 4 se označuje jako odstavec 5.
258. V § 111 odst. 5 se slova „§ 90 odst. 3, § 93 až 104, § 105 odst. 3 a § 108“ nahrazují slovy
„§ 93 až 105“ a na konci odstavce se doplňuje věta „Pokud se v těchto ustanoveních
odkazuje na zadání, rozumí se tím pro účely pořizování změny rozhodnutí schvalujícího
orgánu o pořízení změny a o jejím obsahu.“.
259. V § 111 se doplňuje odstavec 6, který zní:
„(6) Opravu chyb a zřejmých nesprávností územně plánovací dokumentace provede
pořizovatel kdykoli bez řízení; pro vymezení zastavitelného území a pro územní opatření to
platí obdobně.“.
260. Za § 111 se vkládá nový § 111a, který včetně nadpisu zní:
„§ 111a
Nepodstatná změna v zastavitelném území
Při změně územně plánovací dokumentace v zastavitelném území, která nevyžaduje
posouzení vlivů a kterou dochází pouze k uvedení do souladu s nadřazenou územně plánovací
dokumentací, zpřesnění podle § 73 odst. 4 a 5, omezení rozsahu nebo podmínek územní
rezervy, úpravě hranic ploch nebo koridorů, doplnění, změně nebo vypuštění podmínky pro
rozhodování v území, doplnění, změně nebo vypuštění prvků regulačního plánu v územním
plánu, doplnění, zrušení nebo změně etapizace výstavby, změně podrobného využití plochy při
zachování základního způsobu jejího využití, změně objemu, výšky, koeficientu nebo kapacity
nepřesahující 25 % nebo ke změně v souvislosti s obnovou podle § 264 se postupuje podle
ustanovení tohoto oddílu s tím, že obdobně se použijí pouze § 96 až 98, § 101, § 102, § 104
a § 105; lhůty uvedené v § 98 odst. 5, § 101 odst. 2 a § 110 odst. 1 se zkracují na polovinu.“.
261. V § 112 odst. 1 se na konci textu věty druhé doplňují slova „ , ledaže jde o zpřesnění
podle § 73 odst. 4 a 5“.
262. V § 113 odst. 2 se slova „v případě, že se změnily podstatně podmínky, za kterých byl
pořízen a vydán a“ nahrazují čárkou a na konci odstavce se doplňují věty „Tento postup
nepodléhá řízení podle § 87 až 111a. Zrušení regulačního plánu pořizovatel oznámí
veřejnou vyhláškou; dnem jejího doručení nabývá zrušení regulačního plánu účinnosti
a pořizovatel zveřejní informaci o zrušení regulačního plánu v národním geoportálu
územního plánování.“.
263. V § 113 se odstavce 3 až 6 zrušují.
264. V § 114 odst. 3 větě první se slovo „ministerstvu“ nahrazuje slovem „Úřadu“.
265. V § 114 odst. 4 se slova „Ministerstvo a krajský úřad“ nahrazují slovem „Úřad“.
266. V § 114 odst. 5 větě první se za slova „zrušení územního plánu“ vkládají slova „nebo
jeho části“, slovo „zastavěné“ se nahrazuje slovem „zastavitelné“ a za slovo „plánem“ se
vkládají slova „nebo jeho částí“.
267. V § 114 odst. 5 větě druhé se na konci textu věty doplňují slova „nebo jeho části“.
268. V § 114 odst. 5 větě poslední se slova „územního plánování“ nahrazují slovy „rozvoje
území kraje“.
269. Za § 115 se vkládá nový § 115a, který včetně nadpisu zní:
„§ 115a
Společné pořizování územně plánovací dokumentace
(1) Schvalující orgány mohou rozhodnout o společném pořízení více územně plánovacích
dokumentací stejného druhu a o jejich společném pořizovateli nebo o koordinaci pořizovatelů,
pokud spolu souvisí.
(2) Podklady, návrhy a úkony ve společném pořizování lze sdružit a provádět společně.
Změna společně pořizované územně plánovací dokumentace musí být schválena všemi
schvalujícími orgány.“.
270. V části třetí hlavě III nadpisu dílu 5 se slovo „zastavěného“ nahrazuje slovem
„zastavitelného“.
271. V části třetí hlavě III dílu 5 se označení oddílů 1 a 2 včetně nadpisů zrušují.
272. V § 116 odst. 1 větě první se za slovo „obce“ vkládají slova „bez účinného územního
plánu“ a slovo „zastavěných“ se nahrazuje slovem „zastavitelných“.
273. V § 116 odst. 2 úvodní části ustanovení větě druhé se slova „vymezené k 1. září 1966
vyznačené v mapách evidence nemovitostí (dále jen „intravilán“)“ nahrazují slovy „podle
územních analytických podkladů“.
274. V § 116 odst. 2 písm. d) se slovo „intravilánu“ nahrazuje slovy „zastavěné části obce“.
275. V § 116 odst. 3 úvodní části ustanovení se slovo „vždy“ zrušuje.
276. V § 116 odst. 3 písmeno a) zní:
„a) pozemky zázemí stavby,“.
277. V § 116 odst. 3 písm. c) se slova „zastavěnými stavebními pozemky“ nahrazují slovy
„pozemky zázemí stavby“.
278. V § 116 odst. 3 písm. e) se slovo „intravilánem“ nahrazuje slovy „zastavěnou částí obce“.
279. V § 116 se odstavec 4 zrušuje.
280. § 117 včetně nadpisu zní:
„§ 117
Vymezení zastavitelného území
(1) Není-li vydán územní plán, úřad rozvoje území kraje zajistí bezodkladně v souladu s §
116 odst. 1 až 3 zpracování návrhu vymezení zastavitelného území.
(2) Při vymezení zastavitelného území se v něm vyznačí nestavební plochy, a to
a) pozemek veřejné zeleně a parku tvořící veřejné prostranství1),
b) lesní pozemek nebo soubor sousedících lesních pozemků o výměře větší než 0,5 ha.
(3) Vymezení zastavitelného území vydává formou opatření obecné povahy úřad rozvoje
území kraje.
(4) Vymezení zastavitelného území podle tohoto dílu pozbývá platnosti vydáním
územního plánu.“.
281. V § 118 odst. 2 se slovo „zastavěné“ nahrazuje slovem „zastavitelné“.
282. V § 118 odst. 3 písmeno b) zní:
„b) nestavebních ploch.“.
283. V § 118 odst. 4 se na konci písmene c) slovo „a“ nahrazuje tečkou a písmeno d) se zrušuje.
284. V § 119 odst. 2 větě druhé se slovo „zastavěného“ nahrazuje slovy „vymezení
zastavitelného“ a slovo „zastavěné“ se nahrazuje slovem „zastavitelné“.
285. V § 119 se odstavce 3 až 6 zrušují.
286. V § 120 odst. 1 se věta první zrušuje.
287. V § 120 odst. 2 se slova „Vymezení zastavěného“ nahrazují slovy „Informaci o vymezení
zastavitelného“ a slovo „zastavěného“ se nahrazuje slovem „zastavitelného“.
288. V § 120 odstavec 3 zní:
„(3) Vymezení zastavitelného území opatří pořizovatel záznamem o účinnosti.“.
289. V § 121 odst. 2 větě druhé se slovo „zastavěných“ nahrazuje slovem „zastavitelných“.
290. V části třetí hlavě III dílu 5 se označení oddílu 3 včetně nadpisu nahrazuje označením
dílu 6, které včetně nadpisu zní:
„Díl 6
Nezastavitelné území“.
Dosavadní díly 6 a 7 se označují jako díly 7 a 8.
291. V § 122 odst. 1 úvodní části ustanovení a § 122 odst. 3 se slovo „nezastavěném“ nahrazuje
slovem „nezastavitelném“.
292. V § 122 odst. 1 úvodní části ustanovení se slova „v souladu s jeho charakterem“ zrušují
a za slovo „povolovat“ se vkládá slovo „pouze“.
293. V § 122 odst. 1 písm. g) se za slovo „pro“ vkládá slovo „sport,“.
294. V § 122 se doplňuje odstavec 4, který včetně poznámky pod čarou č. 81 zní:
„(4) V nezastavitelném území lze povolovat stavby pro energetickou bezpečnost81) podle
zákona o urychlení výstavby strategicky významné infrastruktury. Stavba pro energetickou
bezpečnost se považuje za souladnou s charakterem území.
_______________
81)
§ 1 odst. 5 zákona č. 416/2009 Sb., o urychlení výstavby strategicky významné
infrastruktury.“.
295. V § 123 odst. 3 se slova „6 let“ nahrazují slovy „4 roky“.
296. V § 123 odst. 5 větě druhé se slova „veřejně prospěšné“ zrušují a za slovo „rozvoje“ se
vkládají slova „nebo realizaci stavby pro energetickou bezpečnost“.
297. V § 125 se na začátek odstavce 3 vkládá věta „Územní opatření o asanaci území může
nabýt účinnosti dnem následujícím po vyvěšení veřejné vyhlášky, určí-li tak vláda, rada
kraje nebo rada obce.“.
298. Na konci nadpisu § 128 se doplňují slova „a zrušení“.
299. V § 128 odst. 2 větě první se slovo „vložení“ nahrazuje slovem „vydání“, za slovo
„opatření“ se vkládají slova „jeho vložením“ a slovo „vydání“ se nahrazuje slovem
„schválení“ a ve větě druhé se slovo „Územní“ nahrazuje slovy „Informaci o vydání
územního“.
300. V § 128 odstavec 3 zní:
„(3) Územní opatření opatří pořizovatel záznamem o účinnosti.“.
301. V § 128 odst. 4 větě první se slovo „ministerstvu“ nahrazuje slovem „Úřadu“.
302. V § 128 odst. 5 se slova „Ministerstvo a krajský úřad“ nahrazují slovem „Úřad“.
303. V § 128 se doplňuje odstavec 6, který zní:
„(6) Orgán, který územní opatření schválil, je může bez řízení zrušit, pominuly-li jeho
důvody; to neplatí v případě územního opatření o podmínkách a zmírňujících opatření podle
zákona o urychlení využívání obnovitelných zdrojů energie. Zrušení nabývá účinnosti dnem
zveřejnění informace o jeho zrušení v národním geoportálu územního plánování.“.
304. V § 130 odst. 1 se za slovo „infrastruktury,“ vkládají slova „organizací podle horního
zákona, případně i dalšími osobami,“.
305. V § 130 odstavec 3 zní:
„(3) Obec, městská část hlavního města Prahy nebo kraj zveřejní uzavřenou plánovací
smlouvu a její změnu či zánik v národním geoportálu územního plánování nebo v něm oznámí
její zveřejnění s uvedením adresy jejího uveřejnění v registru smluv.“.
306. V § 130 se doplňuje odstavec 4, který zní:
„(4) Plánovací smlouva není důvodem pro vyloučení z projednávání a rozhodování věci
podle správního řádu.“.
307. V § 131 odst. 2 se za písmeno b) vkládá nové písmeno c), které zní:
„c) zajistí společné řešení požadavků na výstavbu potřebných k uskutečnění záměru podle
§ 137 odst. 7,“.
Dosavadní písmena c) a d) se označují jako písmena d) a e).
308. V § 131 se na konci odstavce 3 tečka nahrazuje čárkou a doplňují se písmena f) až h),
která znějí:
„f) poskytnutí příspěvku na společné řešení požadavků na výstavbu potřebných k uskutečnění
záměru podle § 137 odst. 7,
g) poskytnutí peněžního nebo věcného plnění jako podílu na ekonomické aktivitě daného
dokončeného záměru,
h) zpracování nebo převzetí nákladů na zpracování návrhu územně plánovací dokumentace
nebo její části nebo její změny.“.
309. V § 132 se na konci odstavce 1 doplňují věty „Zastupitelstvo může přenést pravomoc
schvalovat plánovací smlouvu na radu, není-li obsahem plánovací smlouvy takové
ujednání, které je ze zákona vyhrazeno zastupitelstvu. O plánovací smlouvě a záměru,
který je jejím předmětem, lze konat místní referendum pouze před uzavřením plánovací
smlouvy.“.
310. V § 132 odst. 2 větě první se za slovo „obcí“ vkládají slova „nebo městskou částí hlavního
města Prahy“ a slova „krajský úřad“ se nahrazují slovy „úřad rozvoje území kraje“ a věta
druhá se zrušuje.
311. V § 132 odst. 3 se slova „příslušné ministerstvo“ nahrazují slovy „příslušný Úřad“.
312. V § 132 se doplňuje odstavec 4, který zní:
„(4) Pokud obec, městská část hlavního města Prahy nebo kraj neuzavřou se stavebníkem
v přiměřené době plánovací smlouvu, která je podmínkou pro povolení jeho záměru, i přesto,
že stavebník jim předložil návrh na uzavření plánovací smlouvy splňující podmínky územního
nebo regulačního plánu a plnění uvedená v návrhu plánovací smlouvy jsou přiměřená
okolnostem a podmínkám konkrétního záměru, je stavebník oprávněn domáhat se nahrazení
chybějícího souhlasu s uzavřením smlouvy rozhodnutím soudu.“.
313. V § 133 odst. 1 se slova „ , který slouží k zajištění dluhu“ zrušují.
314. V § 133 odst. 3 větě první se číslo „5“ nahrazuje číslem „6“.
315. V § 135 odst. 2 větě první se slova „v plné výši“ nahrazují slovy „ve výši odpovídající
snížení škody“.
316. V části třetí se hlava IV včetně nadpisu zrušuje.
317. V § 137 se na konci odstavce 2 doplňují věty „Požadavky na výstavbu se používají
s ohledem na jejich technickou, funkční a ekonomickou proveditelnost tak, aby jejich
výklad a povinnost jejich použití nebyly zjevně nepřiměřené přínosům, které tyto
požadavky sledují. Pokud je použití požadavků na výstavbu vyloučeno nebo omezeno
v důsledku jiných právních předpisů, jiných požadavků na výstavbu nebo územního plánu
nebo regulačního plánu, použijí se požadavky na výstavbu přiměřeně okolnostem
a zásadám podle § 1a.“.
318. V § 137 se na konci odstavce 3 doplňuje věta „Lze-li požadavky na výstavbu nebo
požadavky na stavby podle § 167 splnit více způsoby, náleží jejich volba stavebníkovi
nebo vlastníkovi stavby.“.
319. V § 137 odstavec 4 zní:
„(4) Požadavky na výstavbu, zejména požadavky na parkování, odstupy, denní osvětlení,
zastínění, izolační vlastnosti, úsporu energie, přístupnost, schodiště, výtahy, plochy, výšky,
šířky a další požadavky podle § 145 odst. 1 písm. c) až g), se v rozsahu, v jakém to závažné
územně technické nebo stavebně technické důvody nebo jiný veřejný zájem vylučují, nebo
pokud by jejich uplatnění bylo zjevně ekonomicky nepřiměřené vůči přínosům, neuplatní u
a) změny dokončené stavby,
b) údržby dokončené stavby,
c) změny v užívání stavby,
d) dočasné stavby,
e) zařízení staveniště,
f)
pozemku nebo stavby, které jsou kulturní památkou nebo se nacházejí v památkové
rezervaci nebo památkové zóně,
g) stavby v proluce.“.
320. V § 137 se doplňují odstavce 5 až 8, které znějí:
„(5) Nelze-li u staveb uvedených v odstavci 4 ze závažného stavebně technického důvodu,
nepřiměřených ekonomických nákladů nebo ochrany jiného převažujícího veřejného zájmu
splnit požadavky na výstavbu podle § 145 odst. 1 písm. a) a b), tyto požadavky se nepoužijí,
je-li v projektové dokumentaci zpracované autorizovanou osobou doloženo, že navržené řešení
zajišťuje dosažení alespoň rovnocenného výsledku a úrovně bezpečnosti z hlediska mechanické
odolnosti a stability a požární bezpečnosti stavby.
(6) U pozemků nebo staveb, které jsou kulturními památkami nebo se nacházejí
v památkových rezervacích nebo památkových zónách, se požadavky na výstavbu uplatní
přiměřeně s ohledem na zájmy státní památkové péče. U drobných staveb se požadavky na
výstavbu uplatní přiměřeně s ohledem na charakter stavby.
(7) Požadavky na výstavbu, jejichž povaha to nevylučuje, zejména požadavky na
parkování, napojení na sítě dopravní a technické infrastruktury, zelenou infrastrukturu,
občanské vybavení, hygienická zařízení či nakládání s odpady a s vodou, lze splnit též
poskytnutím příspěvku na jejich společné řešení na základě plánovací smlouvy uzavřené s obcí.
(8) Stanoví-li mírnější minimální úroveň určitého požadavku na výstavbu nebo požadavku
na stavbu právní předpis Evropské unie, považuje se takový požadavek za splněný, je-li splněn
v této úrovni. Umožňuje-li právní předpis Evropské unie výjimku z určitého požadavku na
výstavbu nebo z požadavku na stavbu, považuje se takový požadavek stanovený ve
vnitrostátním prováděcím právním předpisu za směrný.“.
321. V § 138 odst. 1 větě první se slova „z těch ustanovení prováděcího právního předpisu, ze
kterých tento předpis povolení výjimky výslovně umožňuje, a jen“ zrušují.
322. V § 138 odst. 2 se slova „ , který obsahuje prvky regulačního plánu,“ zrušují.
323. V § 139 odst. 2 větě první se slovo „zastavěném“ nahrazuje slovem „zastavitelném“.
324. V § 140 odst. 2 se slovo „vždy“ zrušuje a na konci textu odstavce se doplňují slova „nebo
k němu byl zajištěn přístup prostřednictvím věcného práva“.
325. V § 140 odst. 3 úvodní části ustanovení se slovo „vždy“ zrušuje.
326. V § 140 se na konci odstavce 3 tečka nahrazuje čárkou a doplňuje se písmeno d), které
zní:
„d) uplatnění základních ekosystémových funkcí prostřednictvím ploch nebo prvků zelené
infrastruktury.“.
327. V § 140 odst. 4 se slova „zastavěného stavebního“ zrušují.
328. V § 141 odst. 2 se za slovo „též“ vkládají slova „cyklisty a jinou“ a na konci odstavce se
doplňuje věta „Stavby a zařízení ve veřejném prostranství se přednostně sdružují, pokud
tomu nebrání technické, funkční či ekonomické důvody.“.
329. V § 141 se na konci textu odstavce 3 doplňují slova „ , pokud to místní podmínky
nevylučují“.
330. V § 141 se doplňují odstavce 4 až 6, které znějí:
„(4) Podél vodních toků a významných vodních ploch v zastavitelném území, kde je to
technicky, funkčně a ekonomicky proveditelné, se preferují veřejně přístupná nábřeží, parkově
upravené plochy nebo jiná veřejná prostranství. Stávající prostupnost pro pohyb chodců
a cyklistů podél vodních toků a okolo významných vodních ploch musí být zachována.
(5) Při vymezování veřejných prostranství se dbá na jejich prostorové a funkční propojení
do navazujících veřejných prostranství a do volné krajiny.
(6) Oplocení pozemku na hranici s veřejným prostranstvím musí vhodně navazovat na
oplocení v místě obvyklé a nesmí zhoršovat spojitost a prostupnost veřejného prostranství
a jeho kvalitu.“.
331. V § 142 se doplňuje odstavec 4, který včetně poznámky pod čarou č. 82 zní:
„(4) Ulice v územích se zvýšenými nároky na pobytovou kvalitu veřejných prostranství se
přednostně vymezují tak, aby umožňovaly využití sdílené, cyklistické, obytné nebo pěší
zóny82).
___________
82)
§ 39, 39a a 39b zákona č. 361/2000 Sb., o provozu na pozemních komunikacích a o
změnách některých zákonů (zákon o silničním provozu), ve znění pozdějších předpisů.“.
332. V § 143 se na konci textu odstavce 2 doplňují slova „vozidel a jízdních kol“.
333. V § 143 odst. 4 se za slovo „stavby“ vkládají slova „pro parkování,“.
334. V § 144 se doplňuje odstavec 3, který zní:
„(3) Požadavky na odstupy staveb se neuplatní u spojité zástavby nebo v rámci jedné
stavby, souboru staveb či společně řešeného celku.“.
335. Nadpis § 144a zní: „Fotovoltaické výrobny elektřiny a stavební úpravy pro instalaci
využívající obnovitelný zdroj energie“.
336. V § 144a odst. 1 písmena a) a b) znějí:
„a) v zastavitelných plochách hlavním využitím určeným pro výrobu nebo skladování a
b) pod stavbou je zachována vegetační plocha a jsou zajištěny podmínky pro její základní
ekosystémové funkce.“.
337. V § 144a odst. 2 se za slovo „to“ vkládají slova „z důvodu jiného převažujícího veřejného
zájmu“.
338. V § 144a se doplňuje odstavec 3, který zní:
„(3) Má se za to, že stavební úprava pro instalaci využívající obnovitelný zdroj energie
není v rozporu s charakterem území ani se zájmy státní památkové péče; možnost stanovení
podmínek pro její vhodné umístění nebo vzhled tím není dotčena. Domněnka podle věty první
se nepoužije pro nemovité kulturní památky a nemovité národní kulturní památky.“.
339. Za § 144a se vkládají nové § 144b až 144d, které včetně nadpisů znějí:
„§ 144b
Stavby pro reklamu a reklamní zařízení
(1) Stavbou pro reklamu a reklamním zařízením nesmí být narušen urbanistický,
architektonický nebo pietní charakter území.
(2) Při umisťování staveb pro reklamu a reklamních zařízení v území musí být zajištěn
jejich vzájemný soulad z hlediska jejich stavebně technického řešení.
(3) Stavby pro reklamu a reklamní zařízení umístěné na budovách musí odpovídat jejich
architektonickému charakteru a nesmí narušovat užívání přilehlého veřejného prostranství,
základní členění průčelí budov a jeho významné detaily a narušit stabilitu těchto budov.
(4) Reklamu a informace související se stavbou lze umístit též na oplocení staveniště.
§ 144c
Pohoda bydlení
(1) Každý má právo na ochranu před nepřiměřenými zásahy do pohody svého bydlení.
Pohodou bydlení se rozumí souhrn podmínek v území a v užívání staveb, který odpovídá
obvyklým požadavkům na bydlení s přihlédnutím k místním poměrům.
(2) Za narušení pohody bydlení se nepovažuje architektonické ztvárnění záměru ani imise
a účinky, které nejsou v rozporu s plánovaným charakterem území nebo které odpovídají běžné
okolní zástavbě nebo běžnému využívání okolního území.
(3) K dodržení požadavků na ochranu pohody bydlení stavební úřad upřednostňuje uložení
podmínek, kompenzačních nebo zmírňujících opatření před nepovolením, omezením či
zákazem záměru.
§ 144d
Účinky stávajících staveb a zařízení
Má-li být stavba povolena nebo užívána v území, které může být dotčeno obvyklými
účinky již dříve povolené dokončené stavby nebo zařízení nebo jejich provozu, musí nová
stavba přijmout stav území, jaký je. Povolení nové stavby nebo změny v užívání pozdější stavby
není samo o sobě důvodem pro omezení, změnu nebo dodatečné zpřísnění podmínek provozu
stávající stavby nebo zařízení.“.
340. V § 148 odst. 2 úvodní části ustanovení se slovo „nezpůsobila“ zrušuje.
341. V § 148 odst. 2 se na začátek písmene a) vkládá slovo „nezpůsobila“.
342. V § 148 odst. 2 se za písmeno a) vkládá nové písmeno b), které zní:
„b) předcházela, zmírňovala nebo kompenzovala poškozování nebo úhynu zvláště chráněných
rostlin a rušení, ničení, zraňování nebo usmrcení či úhynu zvláště chráněných živočichů
nebo poškozování a ničení jejich biotopu nebo jejich místní populace a jejího genofondu
a“.
Dosavadní písmeno b) se označuje jako písmeno c).
343. V § 148 odst. 2 písm. c) se slovo „zhoršení“ nahrazuje slovy „nevedla ke znemožnění“.
344. V § 148 se doplňuje odstavec 3, který zní:
„(3) Nelze-li zajistit splnění hygienických limitů hluku a vibrací, nebo je-li jejich splnění
technicky, funkčně či ekonomicky zjevně nepřiměřené, považují se tyto limity za splněné,
pokud se omezí na rozumně dosažitelnou míru nebo pokud imise záměru odpovídají běžnému
stávajícímu využití okolního území. Rozumně dosažitelnou mírou se rozumí poměr mezi
náklady na protihluková nebo antivibrační opatření a jejich přínosem ke snížení škodlivých
účinků hluku nebo vibrací, který je stanovený i s ohledem na význam záměru z hlediska celkové
hlukové zátěže a počet fyzických osob vystavených nadlimitnímu hluku nebo vibracím.
K navýšení hluku o méně než o 2 dB se nepřihlíží.“.
345. V § 149 písm. b) se slova „s omezenou schopností pohybu nebo orientace“ nahrazují
slovy „se zdravotním postižením“.
346. V § 150 větě první se slova „a na“ nahrazují čárkou a na konci textu věty první se doplňují
slova „a technickou, funkční a ekonomickou proveditelnost“.
347. V § 152 se na konci textu odstavce 1 doplňují slova „a technická zařízení staveb“ a na
konci odstavce se doplňuje věta „Prováděcí právní předpis může odkázat pouze na
technické normy, které byly určeny postupem podle § 152a.“.
348. V § 152 se na konci odstavce 4 doplňuje věta „Má-li prováděcí právní předpis územního
samosprávného celku obsahovat požadavky na vymezování pozemků a umisťování
staveb technické infrastruktury, projedná územní samosprávný celek jeho návrh
s dotčenými
vlastníky
technické
infrastruktury,
kteří
jsou
subjekty
kritické
infrastruktury.“.
349. Za § 152 se vkládá nový § 152a, který včetně nadpisu zní:
„§ 152a
Určené technické normy ve stavebnictví
(1) Prováděcí právní předpis může odkázat na podrobnější vymezení požadavků na stavby,
zejména mezní hodnoty, návrhové metody, národně stanovené parametry, technické vlastnosti
stavebních konstrukcí a technických zařízení, obsažené v českých technických normách nebo
jejich částech, které byly určeny postupem podle tohoto ustanovení.
(2) Pro podrobnější vymezení požadavků na stavby Česká agentura pro standardizaci na
návrh Úřadu a po odsouhlasení Úřadem určí konkrétní části české technické normy obsahující
podrobnější požadavky na stavby (dále jen „určená technická norma ve stavebnictví“), které
jsou v návaznosti na odkaz v právním předpisu závazné.
(3) Úřad pro technickou normalizaci, metrologii a státní zkušebnictví oznamuje ve
Věstníku podle jiného právního předpisu34) určené technické normy ve stavebnictví.
V oznámení uvede též požadavek prováděcího právního předpisu, k němuž jsou tyto normy
určeny.
(4) Pro změnu nebo zrušení určené technické normy ve stavebnictví platí odstavce 2 a 3
obdobně.
(5) Jiné části norem nebo jiné normy než určené technické normy ve stavebnictví nejsou
pro účely tohoto zákona závazné.
(6) Požadavky na stavby, které jsou podrobně vymezeny prostřednictvím určené technické
normy ve stavebnictví, mohou být splněny i jiným technickým řešením, pokud takové řešení
splňuje požadavek prováděcího právního předpisu, jako v případě řešení podle určených
technických norem ve stavebnictví.“.
350. V § 154 odst. 3 větě druhé se slovo „ministerstvo“ nahrazuje slovem „Úřad“.
351. V § 156 odst. 2 se za slova „stavebního směru“ vkládají slova „pro pozemní stavby“
a slova „3 roky“ se nahrazují slovy „5 let“.
352. V § 156 odst. 3 se za slovo „Projektantovi“ vkládají slova „a osobě podle odstavce 2“
a slova „neveřejné části“ se zrušují.
353. V § 157 odst. 1 písm. a) se slova „ , zařízení nebo udržovacích prací (dále jen
„dokumentace pro povolení stavby“)“ nahrazují slovy „nebo zařízení“.
354. V § 157 odst. 1 písm. d) se za slova „provádění stavby,“ vkládají slova „jednoduchých
staveb bytových domů uvedených v odstavci 1 písm. b) přílohy č. 2 k tomuto zákonu,“.
355. V § 157 odst. 1 písm. d) a e) se slova „jednoduchých staveb pro bydlení a rodinnou
rekreaci,“ zrušují.
356. V § 157 odst. 1 písm. e) se za slova „odstranění stavby,“ vkládají slova „jednoduchých
staveb bytových domů uvedených v odstavci 1 písm. b) přílohy č. 2 k tomuto zákonu,“.
357. V § 157 odst. 2 se na konci textu písmene a) doplňují slova „nebo zařízení podle § 156
odst. 2 a § 157 odst. 1 písm. a) (dále jen „dokumentace pro povolení stavby“)“.
358. V § 158 odst. 1 větě první se slovo „a“ nahrazuje čárkou a na konci textu věty se doplňují
slova „a odůvodnění řešení, které využívá možnost odchylného použití požadavků na
výstavbu podle § 137 odst. 4 až 8 nebo které navrhuje udělit výjimku podle § 138 odst. 1“
a ve větě poslední se slova „záměru stanovená“ nahrazují slovy „stavby stanovená“.
359. V § 158 odst. 5 se slova „projektové dokumentace, dokumentace, která nemusí být
zpracována projektantem,“ nahrazují slovy „dokumentace pro povolení záměru,
dokumentace pro provádění stavby, dokumentace pro odstranění stavby a“ a slova
„a obsahové náležitosti průzkumů“ se zrušují.
360. V § 159 odst. 2 písm. a) se slova „uvedených v odstavci 1 písm. a) bodu 11, 12 a 25
a v odstavci 1 písm. f) této přílohy“ nahrazují slovy „využívajících obnovitelné zdroje
energie“.
361. V § 159 odst. 2 písm. b) se slova „uvedených v odstavci 1 písm. m), r) a s) této přílohy“
nahrazují slovy „využívajících obnovitelné zdroje energie a staveb vodních děl“.
362. V § 159 odst. 2 písm. b) a § 159 odst. 3 se za slova „s výjimkou“ vkládají slova „staveb
uvedených v odstavci 1 písm. b) přílohy č. 2 k tomuto zákonu,“.
363. V § 159 odst. 2 závěrečné části ustanovení větě poslední se slova „nebo změnu stavby,
která je kulturní památkou“ zrušují.
364. V § 159 odst. 3 větě první se za slovo „drobné“ vkládají slova „a jednoduché“, slovo
„drobných“ se zrušuje a slova „uvedených v odstavci 1 písm. a) bodu 11, 12 a 25
a v odstavci 1 písm. f) přílohy č. 1 k tomuto zákonu, a jednoduché stavby uvedené v
příloze č. 2 k tomuto zákonu, s výjimkou jednoduchých staveb uvedených v odstavci 1
písm. m), r) a s) této přílohy“ se nahrazují slovy „využívajících obnovitelné zdroje
energie“.
365. V § 160 odst. 2 písm. a) se za slova „pro provádění“ vkládají slova „jednoduché stavby
bytového domu uvedeného v odstavci 1 písm. b) přílohy č. 2 k tomuto zákonu,“.
366. V § 160 odst. 2 písm. a) se slova „jednoduché stavby pro bydlení a rodinnou rekreaci,“
zrušují a na konci textu písmene se doplňují slova „v rozsahu nezbytném pro průběh
výstavby“.
367. V § 160 odst. 2 se na konci textu písmene b) doplňují slova „nebo ke každé změně
dokumentace pro provádění stavby vypracované podle písmene a), která má vliv na
požární bezpečnost stavby“.
368. V § 161 odst. 1 se za číslo „167“ vkládá text „odst. 1“.
369. V § 161 odst. 3 se slovo „vždy“ zrušuje.
370. V § 162 se na začátek odstavce 4 vkládá věta „Projektant odpovídá za soulad jím
zpracované projektové dokumentace, územně plánovací dokumentace a územní studie
s právními předpisy.“.
371. V § 163 odst. 1 písm. b), § 163 odst. 2 písm. a), § 164 odst. 1 písm. b) a § 165 odst. 2
písm. a) se slovo „záměru“ nahrazuje slovem „stavby“.
372. V § 165 odst. 1 se slova „3 roky“ nahrazují slovy „5 let“.
373. V § 166 odst. 5 se za slovo „předmětem“ vkládá slovo „nadlimitní“ a slova
„v nadlimitním režimu“ se nahrazují slovy „na stavební práce“.
374. V § 167 písm. d) se slova „projektovou dokumentaci“ nahrazují slovy „dokumentaci pro
povolení stavby“ a slova „stavby, došlo-li k odchylce od dokumentace pro povolení
stavby, popřípadě dokumentaci skutečného provedení stavby, včetně její geodetické
části“ se nahrazují slovy „pro povolení stavby s vyznačením odchylek“.
375. V § 167 písm. g) úvodní části ustanovení a § 167 písm. h) úvodní části ustanovení se za
slovo „technicky“ vkládají slova „a ekonomicky“.
376. V § 167 se dosavadní text označuje jako odstavec 1 a doplňuje se odstavec 2, který zní:
„(2) Pro účely zajištění dobíjecí infrastruktury pro elektrická vozidla a výpočtu povinného
množství dobíjecích bodů se jeden stejnosměrný dobíjecí bod s výkonem 50 až 150 kW
považuje za deset běžných dobíjecích bodů a jeden ultrarychlý stejnosměrný dobíjecí bod
s výkonem nad 150 kW za dvacet běžných dobíjecích bodů.“.
377. V § 170 odst. 1 úvodní části ustanovení se za slovo „omezit“ vkládají slova „pouze
tehdy“.
378. V § 170 odst. 1 se na konci textu písmene a) doplňují slova „podle § 11 odst. 1“.
379. V § 170 odst. 1 se na konci textu písmene b) doplňují slova „podle § 11 odst. 2“.
380. V § 170 odst. 2 se za slova „přístup k pozemku nebo stavbě“ vkládají slova „nebo
připojení na dopravní a technickou infrastrukturu“.
381. V § 171 se dosavadní text označuje jako odstavec 1 a doplňuje se odstavec 2, který zní:
„(2) Při postupech podle této části se znovu neposuzují veřejné zájmy v rozsahu, ve kterém
již byly nebo podle § 2 odst. 1 měly být posouzeny při vydání územně plánovací
dokumentace.“.
382. V § 172 se na konci odstavce 1 doplňuje věta „Je-li součástí podání dokumentace pro
povolení záměru nebo jde-li o podání osoby, která má zpřístupněnu datovou schránku bez
žádosti, lze podání včetně jeho příloh učinit jen jako digitální úkon; to neplatí pro stavby
v areálu jaderného zařízení a v případě podání směřujícímu vůči jinému stavebnímu
úřadu.“.
383. V § 172 odst. 2 větě první se slova „elektronicky prostřednictvím portálu stavebníka nebo
v listinné podobě“ zrušují.
384. V § 172 se odstavec 4 zrušuje.
385. V § 173 se odstavec 3 zrušuje.
386. V části šesté hlavě II nadpis dílu 1 zní: „Konzultace a předběžné informace“.
387. V § 174 se vkládá nový odstavec 1, který zní:
„(1) Stavební úřady, dotčené orgány, pořizovatelé, obce a kraje poskytují stavebníkům
a dalším žadatelům neformální konzultace v oblasti jejich působnosti, zejména o procesních
postupech a uplatňování jejich požadavků podle tohoto zákona a dalších právních předpisů
souvisejících s výstavbou.“.
Dosavadní odstavce 1 až 3 se označují jako odstavce 2 až 4.
388. V § 174 odst. 2 se na konci textu písmene a) doplňují slova „a o souladu záměru s územně
plánovací dokumentací“.
389. V § 174 odst. 2 se na konci textu písmene b) doplňují slova „nebo rekolaudace“.
390. V § 174 odst. 2. písm. c) se slova „o vydání rozhodnutí o povolení záměru“ zrušují.
391. V § 174 odst. 2 písm. d) se za slovo „o“ vkládají slova „účastnících a“.
392. V § 174 se na konci odstavce 2 tečka nahrazuje slovy „ , nejde-li o řízení s velkým počtem
účastníků,“ a doplňují se písmena e) a f), která znějí:
„e) o výkladu a použití nebo nepoužití požadavků na výstavbu podle § 137 nebo o možnosti
udělení výjimek podle § 138 odst. 1,
f)
o posuzování podstatných a nepodstatných změn stavby před jejím dokončením podle
§ 224.“.
393. V § 174 se na konci odstavce 3 tečka nahrazuje čárkou a doplňuje se písmeno c), které
zní:
„c) o rozsahu nezbytné dokumentace a podkladů pro vydání vyjádření nebo závazného
stanoviska dotčeného orgánu.“.
394. V § 174 se za odstavec 3 vkládají nové odstavce 4 a 5, které znějí:
„(4) Obec a kraj poskytnou tomu, kdo požádá, v rámci své působnosti do 30 dnů od
požádání předběžnou informaci o svém stanovisku k záměru, případně o požadavcích, po
jejichž splnění vydá obec či kraj se záměrem souhlas, případně o možnostech společného řešení
požadavků na výstavbu podle § 137 odst. 7.
(5) Pořizovatel poskytne tomu, kdo požádá, v rámci své působnosti do 30 dnů od požádání
předběžnou informaci o požadavcích vyplývajících z nástrojů územního plánování, které
pořídil.“.
Dosavadní odstavec 4 se označuje jako odstavec 6.
395. V § 174 se doplňuje odstavec 7, který zní:
„(7) Od předběžné informace nebo její části se lze odchýlit pouze v rozsahu nově zjištěných
skutečností nebo na základě změny okolností nebo právních předpisů, anebo pokud je
předběžná informace v rozporu s právními předpisy nebo je nesprávná. Ustanovení § 3 platí
obdobně.“.
396. V § 175 se vkládá nový odstavec 1, který zní:
„(1) Vyjádření k záměru vydává dotčený orgán, pouze pokud tak stanoví zákon. Dbá
přitom § 1a, 2 a 3.“.
Dosavadní odstavce 1 a 2 se označují jako odstavce 2 a 3.
397. § 176 včetně nadpisu zní:
„§ 176
Závazné stanovisko
(1) Závazné stanovisko k záměru vydává dotčený orgán, pouze pokud tak stanoví zákon.
Dbá přitom § 1a, 2 a 3.
(2) Je-li to nezbytné pro ochranu jím chráněných veřejných zájmů, dotčený orgán uvede
v závazném stanovisku též podmínky přípustnosti záměru. Dotčený orgán je povinen dbát, aby
podmínky byly ve vzájemném souladu.“.
398. V § 177 odst. 1 se za slovo „dokumentaci“ vkládají slova „pro povolení záměru v rozsahu
nezbytném pro vydání vyjádření nebo závazného stanoviska“.
399. V § 178 se na konci odstavce 1 doplňují věty „V případě zrušení vyjádření nebo
závazného stanoviska dotčený orgán vydá nové vyjádření nebo závazné stanovisko do 30
dnů ode dne, kdy mu bylo doručeno rozhodnutí o jeho zrušení. Nevydá-li dotčený orgán
vyjádření nebo závazné stanovisko ve lhůtě pro jeho vydání, považuje se za souhlasné a
bez podmínek.“.
400. V § 178 odstavce 2 a 3 znějí:
„(2) Při přezkumu závazného stanoviska podle § 149 odst. 7 správního řádu nadřízený
dotčený orgán závazné stanovisko potvrdí nebo změní do 30 dnů ode dne vyžádání jeho
potvrzení nebo změny; zrušit jej může pouze v případě, že nemělo být vůbec vydáno. Nevydá-
li nadřízený dotčený orgán závazné stanovisko ve lhůtě pro jeho vydání a přezkoumává-li
souhlasné závazné stanovisko, platí, že jej dnem uplynutí lhůty k přezkumu potvrdil.
(3) Lhůty podle odstavců 1 a 2 nelze prodloužit.“.
401. V § 178 odst. 4 úvodní části ustanovení se číslo „3“ nahrazuje slovy „1 věty třetí“.
402. V § 178 odst. 4 písm. b) se slova „jednotné environmentální stanovisko vydané podle
zákona o jednotném environmentálním stanovisku namísto závazného stanoviska
k posouzení vlivů provedení záměru na životní prostředí podle zákona o posuzování vlivů
na životní prostředí nebo správního úkonu orgánu ochrany přírody“ nahrazují slovy
„závazné stanovisko“.
403. V § 179 odst. 1 se číslo „3“ nahrazuje číslem „1“, slovo „se“ se zrušuje a slovo „ruší“ se
nahrazuje slovem „změní“.
404. V § 179 odst. 2 se slova „6 měsíců ode dne“ zrušují.
405. § 179a včetně nadpisu zní:
„§ 179a
Přezkum vyjádření a závazného stanoviska v přezkumném řízení
Vyjádření a závazné stanovisko nelze v přezkumném řízení zrušit nebo změnit po právní
moci rozhodnutí, jehož bylo vyjádření nebo závazné stanovisko podkladem.“.
406. V § 180 odst. 3 se slovo „vždy“ zrušuje a na konci odstavce se doplňují slova „v rozsahu
nezbytném pro vydání vyjádření“.
407. V § 181 odstavec 1 zní:
„(1) Vlastník veřejné dopravní nebo technické infrastruktury vydá vyjádření k záměru do
30 dnů ode dne doručení úplné žádosti. Pro stanovení podmínek záměru v případě energetické
technické infrastruktury může její vlastník prodloužit lhůtu před jejím uplynutím o 15 dnů, je-
li to nezbytné.“.
408. V § 181 odst. 2 se slova „Má se za to, že žádost“ nahrazují slovem „Žádost“.
409. V § 181 se doplňuje odstavec 5, který zní:
„(5) Nevydá-li vlastník veřejné dopravní nebo technické infrastruktury vyjádření k záměru
ve lhůtě pro jeho vydání, považuje se za souhlasné a bez podmínek.“.
410. V § 182 se dosavadní text označuje jako odstavec 1 a doplňuje se odstavec 2, který zní:
„(2) Zemřela-li osoba, která byla nebo by měla být účastníkem řízení, jemuž má být
doručena písemnost jednotlivě, a stavebnímu úřadu se do 30 dnů ode dne, kdy zjistil, že
zemřela, nepodaří zjistit osoby, které by se v důsledku její smrti staly účastníky řízení, ustanoví
jim opatrovníka.“.
411. V § 183 se věta první nahrazuje větou „Jsou-li účastníkem řízení vlastníci jednotek, je
společenství vlastníků jednotek41) jejich zástupcem.“.
412. V § 184 odst. 2 písm. e) se za slovo „orgánu,“ vkládají slova „týká-li se záměr jím
chráněných veřejných zájmů a“.
413. V § 184 odst. 2 se na konci textu písmene f) doplňují slova „ , týká-li se záměr této
infrastruktury“.
414. V § 184 odst. 2 se na začátek písmene h) vkládají slova „odůvodnění odchylného použití
požadavků na výstavbu podle § 137 odst. 4 až 8 nebo“.
415. V § 184 odst. 3 se slova „ověření změn záměru“ nahrazují slovy „posouzení vlivů
provedení záměru na životní prostředí“, text „§ 9a odst. 6“ se zrušuje a na konci textu
odstavce se doplňují slova „a pro vyhrazené stavby“.
416. V § 184 odst. 4 se text „odst. 3“ nahrazuje textem „odst. 1“.
417. V § 184 se doplňuje odstavec 5, který zní:
„(5) K žádosti lze připojit nebo doplnit návrh rozhodnutí o žádosti.“.
418. V § 185 odst. 2 se slova „a řízení usnesením přeruší“ zrušují.
419. V § 185 odstavec 3 zní:
„(3) Stavební úřad žádost neprojedná a usnesením ji odloží, není-li součástí žádosti
dokumentace pro povolení záměru.“.
420. V § 185 odst. 4 se za slovo „žádosti“ vkládají slova „a usnesení o zastavení řízení
z důvodu neodstranění vad žádosti nebo nezaplacení správního poplatku“.
421. V § 186 odst. 2 větě druhé se slova „a postupuje podle ustanovení jiného právního
předpisu“ zrušují.
422. V § 187 se na konci odstavce 1 doplňuje věta „V případě zákonné služebnosti, která není
předmětem evidence v katastru nemovitostí, doloží stavebník naplnění podmínek pro její
vznik čestným prohlášením; obdobně se postupuje v případech, kdy má zákonné věcné
břemeno podle jiného právního předpisu vzniknout na základě pravomocného rozhodnutí
o povolení záměru83).“.

Poznámka pod čarou č. 83 zní:
„83)
§ 104a zákona č. 127/2005 Sb., o elektronických komunikacích a o změně některých
souvisejících zákonů (zákon o elektronických komunikacích), ve znění pozdějších
předpisů, a § 97b zákona č. 458/2000 Sb., o podmínkách podnikání a o výkonu státní
správy v energetických odvětvích a o změně některých zákonů (energetický zákon), ve
znění pozdějších předpisů.“.
423. V § 187 odst. 2 větě poslední se za slovo „záměru,“ vkládají slova „která se týká
vlastníka,“.
424. V § 187 odst. 3 úvodní části ustanovení větě první se za slovo „dokumentace“ vkládají
slova „nebo k němu být připojen“.
425. V § 187 odst. 3 úvodní části ustanovení se věta druhá včetně písmen a) a b) zrušuje.
426. V § 187 se na konci odstavce 5 doplňuje věta „Souhlas není potřeba i v případech, kdy
vzniká zákonné věcné břemeno podle jiného právního předpisu80) na základě
pravomocného rozhodnutí o povolení záměru.“.
427. Na konci nadpisu § 188 se doplňují slova „a doručování“.
428. V § 188 odst. 1 větě první se číslo „7“ nahrazuje číslem „10“, slovo „řízení,“ se nahrazuje
slovy „řízení a“ a slova „a hlavního projektanta“ se nahrazují slovy „ , pokud jsou
záměrem dotčeny jimi chráněné veřejné zájmy a pokud se již k záměru nevyjádřily,“ a ve
větě druhé se za slovo „vyrozumění“ vkládají slova „vyzve k podání námitek ve lhůtě
10 dnů od doručení výzvy a“.
429. V § 188 odst. 3 a v § 188 odst. 4 větě první se za číslo „182“ vkládá text „odst. 1“.
430. V § 188 odst. 4 se věta poslední zrušuje.
431. V § 188 odstavec 5 zní:
„(5) Při doručování do ciziny se písemnost doručuje na adresu uvedenou v katastru
nemovitostí a za den doručení se považuje patnáctý den od předání písemnosti k poštovní
přepravě, neprokáže-li se doručení dříve.“.
432. V § 189 odst. 1 větě první se číslo „15“ nahrazuje číslem „10“ a věta druhá se zrušuje.
433. V § 189 odst. 2 větě poslední se číslo „30“ nahrazuje číslem „15“.
434. V § 190 odst. 1 se na konci textu věty první doplňují slova „ , jinak se k nim nepřihlíží“.
435. V § 190 odst. 2 větě poslední se za slovo „k“ vkládají slova „námitkám účastníka řízení,
které směřují proti tomu, s čím účastník řízení souhlasil, k námitkám účastníka řízení,
které přesahují působnost stavebního úřadu podle § 193, a k“.
436. V § 190 odst. 3 větě první se slovo „své“ nahrazuje slovy „územně plánovací
dokumentace, kterou schválila, a ochrany dalších hodnot v její“, ve větě druhé a třetí se
za číslo „182“ vkládá text „odst. 1“, ve větě druhé se slova „svých práv“ nahrazují slovy
„svého vlastnického nebo jiného věcného práva“ a věta poslední se zrušuje.
437. V § 190 se za odstavec 3 vkládá nový odstavec 4, který zní:
„(4) Účastník řízení je povinen v námitce uvést důvody podání námitky a rozsah, v jakém
jsou dotčeny jeho práva nebo zájmy, které jsou chráněny podle odstavce 3, jinak k ní stavební
úřad nepřihlíží.“.
Dosavadní odstavec 4 se označuje jako odstavec 5.
438. V § 190 se doplňuje odstavec 6, který zní:
„(6) Souhlas účastníka řízení se záměrem nelze vzít po podání žádosti o povolení záměru
zpět ani jej změnit, nedojde-li k podstatné změně záměru.“.
439. Za § 190 se vkládá nový § 190a, který včetně nadpisu zní:
„§ 190a
Námitka podjatosti úřední osoby
(1) Námitku podjatosti musí účastník řízení uplatnit do jednoho týdne ode dne, kdy se
o podjatosti dozvěděl; zjistí-li důvod podjatosti při ústním jednání, musí ji uplatnit při tomto
jednání. K později uplatněným námitkám se nepřihlíží. Námitka podjatosti musí být
zdůvodněna a musí v ní být uvedeny konkrétní skutečnosti a navrženy důkazy, z nichž je
dovozována, jinak se k ní nepřihlíží.
(2) Proti rozhodnutí o námitce podjatosti není odvolání ani přezkumné řízení přípustné.“.
440. Za § 191 se vkládá nový § 191a, který včetně nadpisu zní:
„§ 191a
Smír
(1) Na žádost stavebníka stavební úřad nařídí ústní jednání k projednání námitek
a dosažení smíru. Obsahem smíru může být zejména změna žádosti, zpětvzetí námitek,
poskytnutí finanční náhrady nebo provedení kompenzačních nebo zmírňujících opatření.
Ustanovení § 141 odst. 8 správního řádu se použije obdobně. Je-li součástí schváleného smíru
provedení kompenzačních nebo zmírňujících opatření, stavební úřad je zahrne do podmínek
v rozhodnutí o povolení záměru podle § 195.
(2) Nezúčastní-li se účastník řízení bez důvodné omluvy nařízeného jednání o smíru,
k jeho námitkám se nepřihlíží.“.
441. V § 193 odst. 1 písm. b) se slovo „vydán“ nahrazuje slovy „pro dané území“ a na konci
textu písmene se doplňují slova „nebo regulační plán“.
442. V § 193 odst. 1 se na konci textu písmene c) doplňují slova „ , s výjimkou technických
požadavků na stavby, za jejichž splnění v dokumentaci pro povolení záměru odpovídá
projektant nebo osoba uvedená v § 156 odst. 2“.
443. V § 193 odst. 1 se na konci textu závěrečné části ustanovení doplňují slova „podle zásad
uvedených v § 1a. Soulad záměru s požadavky jiných právních předpisů chránících
dotčené veřejné zájmy posoudí oprávněná úřední osoba splňující příslušné kvalifikační
požadavky podle § 37 odst. 3“.
444. V§ 193 se za odstavec 1 vkládá nový odstavec 2, který zní:
„(2) Se souhlasem toho, kdo územně plánovací dokumentaci, územní opatření nebo
vymezení zastavitelného území vydal, a se souhlasem vlastníka pozemku, pokud by se jinak
vyžadoval podle § 187, se záměr může odchýlit od územně plánovací dokumentace, územního
opatření nebo vymezení zastavitelného území, pokud nenaruší veřejné zájmy a nedotkne se
jiných osob, ochranných pásem nebo koridorů. Pro ochranná pásma platí možnost odchýlení se
od jejich vymezení se souhlasem toho, v jehož zájmu jsou vymezena, přiměřeně. Záměr
vyhrazené stavby v zastavitelném území, o kterém je uzavřena plánovací smlouva mezi
stavebníkem a tím, kdo územně plánovací dokumentaci, územní opatření nebo vymezení
zastavitelného území vydal, ve které se stavebník zaváže podat podnět k pořízení změny
územně plánovací dokumentace tak, aby s ní byl záměr v souladu, a uhradit náklady uvedené v
§ 91 odst. 1, nenarušuje veřejné zájmy.“.
Dosavadní odstavec 2 se označuje jako odstavec 3.
445. V § 193 odst. 3 větě první se za slovo „předpisů“ vkládají slova „ , které není oprávněn
posoudit sám,“ a za větu první se vkládá věta „Stavební úřad nepřihlíží k vyjádřením
a závazným stanoviskům dotčených orgánů v částech, v nichž překračují jejich
působnost, a ve věcech, o nichž bylo rozhodnuto již při vydání územně plánovací
dokumentace.“.
446. V § 193 se doplňují odstavce 4 až 6, které znějí:
„(4) Při posuzování souladu záměru s požadavky vlastníků veřejné dopravní a technické
infrastruktury, s výjimkou technické infrastruktury, s níž je příslušné hospodařit Ministerstvo
obrany, Ministerstvo vnitra nebo Vězeňská služba České republiky, stavební úřad vychází
z jimi vydaných vyjádření a z údajů uvedených v digitální technické mapě týkajících se
existence sítí a vlastníků této infrastruktury. Má se za to, že sítě, které nejsou uvedeny
v digitální technické mapě, neexistují, a případné následky jdou k tíži vlastníka veřejné
dopravní a technické infrastruktury.
(5) Při posuzování ochrany práv a právem chráněných zájmů účastníků řízení stavební úřad
vychází z jejich vlastních včasných a přípustných námitek podle § 190 až 191. Nepřípustné jsou
námitky účastníka, k nimž se podle zákona nepřihlíží. Nepřípustné námitky stavební úřad
nevypořádává. Námitky, které nespočívají v porušení právních předpisů, nejsou důvodné.
(6) Splnění podmínek podle odstavce 1 se posuzuje ke dni podání žádosti; to platí
i v odvolacím, přezkumném, soudním a opakovaném řízení. Pokud o to stavebník požádá,
posuzuje se splnění podmínek podle odstavce 1 ke dni rozhodnutí.“.
447. Za § 193 se vkládají nové § 194 a 194a, které včetně nadpisů znějí:
„§ 194
Posuzování záměru v zastavitelném území
(1) Má se za to, že stavební záměr umisťovaný v zastavitelném území nebo v koridoru pro
stavební záměr v souladu s územně plánovací dokumentací a v souladu s požadavky na
výstavbu je přípustný, a to i z hlediska jiných zákonů, jejichž požadavky byly zohledněny
v územně plánovací dokumentaci. Je-li to potřebné, stavební úřad stanoví podmínky k zajištění
ochrany veřejných zájmů a práv účastníků řízení.
(2) Má se za to, že povolení záměru v zastavitelném území nebo v koridoru pro stavební
záměr je v souladu s ochranou práv a právem chráněných zájmů účastníků řízení, pokud záměr
splňuje požadavky na výstavbu a odpovídá plánovanému charakteru území, běžné okolní
zástavbě nebo běžnému využívání okolního území.
(3) Při rozhodování v území, které již bylo v souladu se stanoviskem orgánu ochrany
přírody vymezeno v územně plánovací dokumentaci jako zastavitelné území, koridor pro
stavební záměr nebo plocha těžby, se při povolení záměru neposuzuje krajinný ráz.
(4) Při rozhodování v území, které bylo v souladu se stanoviskem orgánu ochrany
zemědělského půdního fondu vymezeno v územně plánovací dokumentaci jako zastavitelné
území, koridor pro stavební záměr nebo plocha těžby, se při povolení záměru neposuzují zásady
plošné ochrany podle § 4 odst. 1 až 5 zákona o ochraně zemědělského půdního fondu.
§ 194a
Vyjádření stavebníka
(1) Dojde-li stavební úřad po projednání a posouzení žádosti k předběžnému závěru, že
žádosti o povolení záměru nelze vyhovět, vyrozumí o tomto předběžném závěru a jeho
důvodech stavebníka, podle okolností jej poučí o možnostech řešení a vyzve jej, aby se k němu
ve stanovené lhůtě vyjádřil; za tímto účelem může řízení přerušit. Obdobně postupuje stavební
úřad i v případě, že z projednání žádosti vyplývá nezbytnost uložení podmínek, které nejsou
v souladu s podklady předloženými stavebníkem.
(2) Nelze-li žádosti vyhovět i přes vyjádření nebo jiný úkon stavebníka, nebo se stavebník
ve stanovené lhůtě nevyjádřil nebo neprovedl jiný úkon, neprovádí stavební úřad další úkony
a žádost zamítne. Pokud stavební úřad dosud nevyrozuměl další účastníky o zahájení řízení,
doručí rozhodnutí o zamítnutí žádosti pouze stavebníkovi.
(3) Vyrozumění podle odstavce 1 může stavební úřad spojit s jiným úkonem v řízení.“.
448. V § 195 se dosavadní text označuje jako odstavec 1 a doplňuje se nový odstavec 2, který
zní:
„(2) V rozhodnutí o záměru stavební úřad rozhodne též o ochraně veřejných zájmů podle
§ 1b. Vyžaduje-li ochrana veřejných zájmů podle § 1b stanovení podmínek rozhodnutí, je jejich
stanovení součástí výroku rozhodnutí. V ostatních případech se ochrana veřejných zájmů podle
§ 1b projeví přímo v povolení, nebo v zamítnutí žádosti a v odůvodnění rozhodnutí, v souladu
s požadavky § 1a.“.
449. Za § 195 se vkládají nové § 195a a 195b, které včetně nadpisů znějí:
„§ 195a
Přezkum rozhodnutí v přezkumném řízení
(1) Usnesení o zahájení přezkumného řízení lze vydat do 1 měsíce ode dne, kdy se
příslušný správní orgán o důvodu zahájení přezkumného řízení dozvěděl, nejpozději však do 3
měsíců od právní moci rozhodnutí ve věci.
(2) Rozhodnutí v přezkumném řízení v prvním stupni nelze vydat po uplynutí 6 měsíců od
právní moci rozhodnutí ve věci.
§ 195b
Obnova řízení
(1) Účastník řízení může podat žádost o obnovu řízení do 1 měsíce ode dne, kdy se
o důvodu obnovy řízení dozvěděl, nejpozději však do 3 měsíců od právní moci rozhodnutí ve
věci.
(2) Rozhodnutí o obnově řízení v prvním stupni nelze vydat po uplynutí 6 měsíců od právní
moci rozhodnutí ve věci. Bylo-li rozhodnutí dosaženo trestným činem, začíná tato lhůta běžet
dnem nabytí právní moci rozsudku.“.
450. V § 196 odst. 1 se na konci textu písmene a) doplňují slova „a v případech, kdy je
rozhodnutí prvním úkonem stavebního úřadu v řízení“.
451. V § 196 odst. 3 se slova „nebo 2“ zrušují.
452. V § 197 odst. 1 písm. b) se slova „ , popřípadě stanoví podmínky pro dělení nebo
scelování pozemků,“ zrušují.
453. V § 197 odst. 1 písm. c) se slovo „obecných“ zrušuje.
454. V § 197 odst. 2 se slova „nebo záměru na nemovité věci, která není kulturní památkou,
ale nachází se v památkové rezervaci nebo památkové zóně,“ zrušují.
455. V § 197 odst. 3 větě první a druhé se slova „projektové dokumentace“ nahrazují slovy
„dokumentace pro povolení stavby“ a věta poslední se nahrazuje větami „Toto oznámení
potvrzuje soulad dokumentace pro povolení stavby s povolením a s podmínkami podle
§ 193 odst. 1, které posuzuje stavební úřad. V případě rozporu mezi povolením záměru
a ověřenou dokumentací pro povolení stavby má přednost ověřená dokumentace pro
povolení stavby.“.
456. V § 198 odst. 1 větě první se za slovo „roky“ vkládají slova „a pro stavby dopravní
a technické infrastruktury 4 roky“ a číslo „5“ se nahrazuje číslem „7“.
457. V § 198 odst. 2 se věta druhá nahrazuje větou „Upustit lze i od oddělitelné části záměru;
v takovém případě pozbývá platnosti jen příslušná část povolení.“.
458. V § 198 se za odstavec 2 vkládá nový odstavec 3, který zní:
„(3) Jde-li o veřejně prospěšné stavby a vyhrazené stavby, včetně staveb souvisejících,
povolení nepozbývá platnosti, bylo-li provádění stavby zahájeno v době jeho platnosti.“.
Dosavadní odstavce 3 až 5 se označují jako odstavce 4 až 6.
459. V § 198 odst. 4 se na konci textu věty první doplňují slova „ ; u vyhrazených staveb
nejdéle však vždy o dalších 5 let“.
460. V § 200 odst. 1 se věta druhá zrušuje.
461. V § 200 odst. 2 se věta druhá zrušuje.
462. V § 200 se za odstavec 2 vkládá nový odstavec 3, který zní:
„(3) Na žádost stavebníka nebo vlastníka stavby lze změnit povolení části nebo etapy
záměru společně s povolením jiné části či etapy tohoto záměru. V takovém případě stavebník
nebo vlastník stavby předloží dokumentaci pro povolení části nebo etapy záměru a popis změn
jiné části či etapy záměru.“.
Dosavadní odstavec 3 se označuje jako odstavec 4.
463. Za § 200 se vkládá nový § 200a, který zní:
„§ 200a
Ustanovení tohoto dílu a dílu 6 a hlavy IV se použijí i pro řízení podle hlav IV až IX,
nevylučuje-li to jejich povaha nebo není-li v hlavách IV až IX uvedeno jinak.“.
464. V části šesté hlavě III se díl 2 včetně nadpisů zrušuje.
Dosavadní díly 3 až 8 se označují jako díly 2 až 7.
465. V § 211 odst. 1 úvodní části ustanovení se slova „a 2“ zrušují.
466. V § 211 odst. 1 písm. e) se za slovo „provedení“ vkládají slova „ , a případně pro užívání“.
467. V § 211 se na konci odstavce 1 čárka nahrazuje tečkou a písmeno f) se zrušuje.
468. V § 211 odst. 3 se slova „1 roku“ nahrazují slovy „3 let“.
469. V § 211 se doplňuje odstavec 4, který zní:
„(4) Při povolení stavby nebo zařízení se pro stejný záměr nevydává povolení změny
využití území.“.
470. V § 212 odst. 1 se písmeno c) zrušuje.
Dosavadní písmena d) a e) se označují jako písmena c) a d).
471. V § 212 odst. 1 písm. d) se slova „ , vyznačené na situačním výkresu dokumentace“
zrušují.
472. V § 212 se odstavec 2 zrušuje.
Dosavadní odstavec 3 se označuje jako odstavec 2.
473. Za § 212 se vkládá nový § 212a, který včetně nadpisu zní:
„§ 212a
Povolení záměru uplynutím lhůty
(1) Nevydá-li stavební úřad ve lhůtě podle § 196 rozhodnutí o povolení záměru jednoduché
stavby nebo stavby sítě technické infrastruktury, o jehož vydání požádal stavebník ve
zrychleném řízení podle § 212, považuje se záměr za povolený dnem uplynutí této lhůty.
(2) Považuje-li se záměr za povolený, stavební úřad o tom vydá osvědčení, a to ve lhůtě 15
dnů ode dne, kdy se záměr považuje za povolený. V osvědčení uvede popis záměru, označí
pozemky dotčené záměrem, pozemky, na kterých vzniklo věcné břemeno podle jiného právního
předpisu80), a den, od kdy se záměr považuje za povolený; vztahuje-li se na záměr zákon o
urychlení výstavby strategicky významné infrastruktury, uvede rovněž tuto skutečnost.
Osvědčení stavební úřad zveřejní na své úřední desce po dobu 15 dnů a současně ho zašle
nadřízenému stavebnímu úřadu, dotčeným orgánům a stavebníkovi.
(3) Nadřízený stavební úřad na základě podnětu účastníka řízení nebo z moci úřední,
pokud nebyly splněny podmínky pro povolení záměru, rozhodne v přezkumném řízení podle
správního řádu, že se záměr nepovažuje za povolený a věc vrátí stavebnímu úřadu
k pokračování v řízení o povolení záměru podle § 212.
(4) Účastník řízení může podat podnět podle odstavce 3 do 15 dnů ode dne zveřejnění
osvědčení podle odstavce 2.
(5) Rozhodnutí v přezkumném řízení o tom, zda se záměr nepovažuje za povolený, nelze
vydat po uplynutí 3 měsíců ode dne zveřejnění osvědčení podle odstavce 2.
(6) Proti rozhodnutí vydaném v přezkumném řízení o tom, zda se záměr nepovažuje za
povolený, se nelze odvolat a nelze jej přezkoumat v přezkumném řízení.
(7) Osvědčení podle odstavce 2 pozbývá právních účinků dnem nabytí právní moci
rozhodnutí podle odstavce 3.“.
474. § 214 se včetně nadpisu zrušuje.
475. V § 215 odst. 2 úvodní části ustanovení se slova „a 2“ zrušují.
476. V části šesté hlavě III dílu 3 se oddíl 2 včetně nadpisu zrušuje.
Dosavadní oddíl 3 se označuje jako oddíl 2.
477. V § 219 odst. 1 větě první se za slovo „dotýká,“ vkládají slova „a dotčený oprávněný
investor podle evidence v digitální technické mapě,“.
478. V § 219 odst. 2 se slova „a námitky“ zrušují.
479. V § 219 odstavec 3 zní:
„(3) Proti návrhu opatření obecné povahy o stanovení ochranného pásma nelze podat
námitky podle části šesté správního řádu.“.
480. V § 220 se na konci textu odstavce 3 doplňují slova „nebo zařízení“.
481. V § 220 odst. 6 větě druhé se za slovo „povolit“ vkládá slovo „rozhodnutím“.
482. V § 221 odst. 2 se slova „3, 6 a 8“ nahrazují slovy „2, 5 a 7“.
483. V § 221 odst. 3 větě čtvrté se slova „vydaného krajským úřadem“ zrušují a ve větě páté
se slova „může Dopravní a energetický stavební úřad“ nahrazují slovem „lze“.
484. V § 223 odst. 1 písm. e) se slovo „zastavěných“ nahrazuje slovem „zastavitelných“.
485. V § 224 odst. 2 větě první se za slovo „základě“ vkládá slovo „změny“ a na konci odstavce
se doplňuje věta „Změnu záměru před dokončením stavební úřad posuzuje pouze
v rozsahu požadované změny.“.
486. V § 224 odstavec 3 zní:
„(3) Nepodstatné odchylky od ověřené dokumentace pro povolení stavby, při kterých se
nemění půdorysný ani výškový rozsah stavby, nemění se mechanická odolnost a stabilita
stavby, nemění se účel užívání stavby a nedochází k ovlivnění požární bezpečnosti, nebo jiné
nepodstatné změny se nepovažují za změnu stavby a projednají se v kolaudačním řízení.“.
487. V § 224 odst. 4 se se za slova „popis změn a“ vkládají slova „je-li to nezbytné,“ a slova
„povolení záměru“ se nahrazují slovy „povolení stavby“.
488. V § 224 odst. 5 se slova „může stavební úřad vydat“ nahrazují slovy „stavební úřad vydá“.
489. V § 224 se doplňuje odstavec 6, který zní:
„(6) Pro změnu záměru před dokončením se uplatní požadavky na výstavbu a stav územně
plánovací dokumentace účinné ke dni podání žádosti o povolení původního záměru. Pokud o to
stavebník požádá, uplatní se pro změnu záměru před dokončením požadavky na výstavbu a stav
územně plánovací dokumentace účinné ke dni podání žádosti o změnu záměru před
dokončením nebo ke dni rozhodnutí.“.
490. V § 225 odst. 1 se za slovo „nesprávné“ vkládají slova „anebo že trpí jinou vadou“ a na
konci odstavce se doplňuje věta „Zrušení napadeného rozhodnutí a vrácení věci
stavebnímu úřadu prvního stupně k novému projednání podle věty první je nepřípustné.“.
491. V § 225 odst. 3 se slova „s výjimkou ustanovení o zrychleném řízení“ zrušují.
492. § 226 včetně nadpisu zní:
„§ 226
Postup odvolacího orgánu
(1) Neobsahuje-li odvolání proti rozhodnutí stavebního úřadu odůvodnění, v čem je
spatřován rozpor s právními předpisy nebo nesprávnost rozhodnutí nebo řízení, jež mu
předcházelo, k odstranění tohoto nedostatku se odvolatel nevyzývá. Neodstranil-li odvolatel
tento nedostatek před uplynutím lhůty pro podání odvolání, přezkoumává odvolací správní
orgán pouze soulad napadeného rozhodnutí a řízení, které vydání rozhodnutí předcházelo,
s právními předpisy. K doplnění důvodů odvolání po lhůtě stanovené pro jeho podání se
nepřihlíží.
(2) Odvolací správní orgán nepřihlíží k odvolacím námitkám, k nimž se nepřihlíží podle
§ 190 až 191.“.
493. V § 229 odst. 4 se slova „a 3“ nahrazují slovy „až 4“.
494. V části šesté hlavě VI nadpis dílu 1 zní: „Kolaudace“.
495. Nadpis § 230 zní: „Základní ustanovení“.
496. V § 230 se na konci odstavce 1 doplňuje věta „Kolaudační rozhodnutí vydává na základě
žádosti stavebníka nebo vlastníka stavby stavební úřad, nebo autorizovaný inspektor.“.
497. V § 230 odst. 2 se na konci textu věty první doplňují slova „a bytových domů uvedených
v odstavci 1 písm. b) přílohy č. 2 k tomuto zákonu“, na konci textu odstavce 2 se doplňují
slova „uvedených v odstavci 1 písm. a) přílohy č. 2 k tomuto zákonu“ a na konci odstavce
se doplňuje věta „Kolaudační rozhodnutí dále nevyžadují stavby zařízení staveniště, a to
bez ohledu na to, zda se jedná o jednoduché stavby či nikoliv.“.
498. V § 230 odst. 4 se za slovo „užívat“ vkládají slova „ihned po jejím dokončení a“.
499. V § 230 se doplňují odstavce 6 až 8, které znějí:
„(6) Pokud byly splněny podmínky pro vznik věcného břemene podle jiného právního
předpisu80), vydá o tom po dokončení stavby stavební úřad nebo autorizovaný inspektor
vlastníku sítě technické infrastruktury na jeho žádost osvědčení. Je-li to potřebné, přiloží
k žádosti vlastník sítě dokumentaci podle § 167 písm. d). Osvědčení podle věty první obsahuje
alespoň
a) údaj o tom, jaké věcné břemeno vzniklo a že byly splněny podmínky pro jeho vznik,
b) ustanovení jiného právního předpisu, podle kterého věcné břemeno vzniklo,
c) označení osoby, pro kterou věcné břemeno vzniklo,
d) identifikaci stavby, které věcné břemeno svědčí,
e) označení zatíženého pozemku údaji podle katastrálního zákona a
f)
datum vzniku věcného břemene.
(7) Pokud je zatížena pouze část pozemku nebo je toho potřeba z jiného důvodu, obsahuje
osvědčení i odkaz na geometrický plán předložený žadatelem, kterým je zatížená část pozemku
vymezena.
(8) Katastrální úřad zapíše věcné břemeno na základě osvědčení podle odstavce 6 na návrh
oprávněného do katastru nemovitostí; souhlas vlastníka pozemku se nevyžaduje.“.
500. V § 232 odst. 2 úvodní část ustanovení zní: „Součástmi žádosti, které je třeba předložit
stavebnímu úřadu nebo autorizovanému inspektorovi nejpozději k závěrečné kontrolní
prohlídce dokončené stavby, případně ke kolaudaci, pokud se od závěrečné kontrolní
prohlídky upouští, jsou“.
501. V § 233 odst. 1 se slova „V kolaudačním řízení stavební úřad“ nahrazují slovy „Stavební
úřad nebo autorizovaný inspektor“ a za slovo „zda“ se vkládají slova „je žádost úplná
a zda“.
502. V § 233 odst. 2 větě první se za slovo „úřad“ vkládají slova „nebo autorizovaný
inspektor“, slovo „ověřené“ se zrušuje a na konci textu věty se doplňují slova „a uvede je
v kolaudačním rozhodnutí“ a věta druhá se zrušuje.
503. V § 233 odstavec 3 zní:
„(3) Dojde-li během provádění stavby ke změně požadavků na výstavbu nebo norem,
posuzuje se stavba podle požadavků na výstavbu a norem, které platily v době podání žádosti
o povolení záměru stavebnímu úřadu.“.
504. V § 234 odst. 1 větě první se slova „V kolaudačním řízení stavební úřad“ nahrazují slovy
„Stavební úřad nebo autorizovaný inspektor“, ve větě třetí se číslo „30“ nahrazuje číslem
„15“, ve větě čtvrté se číslo „10“ nahrazuje číslem „5“ a na konci textu věty se doplňují
slova „ , nedohodnou-li se jinak“ a věta poslední se zrušuje.
505. V § 234 odst. 2 se slova „a její způsobilosti k užívání“ zrušují.
506. V § 234 se odstavec 3 zrušuje.
507. V § 235 odst. 1 se za slovo „úřad“ vkládají slova „nebo autorizovaný inspektor“.
508. V § 235 odst. 2 úvodní části ustanovení se slova „a náležitostí podle § 197 odst. 1 a 2“
zrušují.
509. V § 235 odst. 4 se věta druhá zrušuje.
510. V § 235 se doplňuje odstavec 6, který zní:
„(6) Odvolání proti kolaudačnímu rozhodnutí nemá odkladný účinek.“.
511. V § 236 odst. 1 se slovo „povolit“ nahrazuje slovy „nebo autorizovaný inspektor povolit
prvním úkonem stavebního úřadu v řízení“ a slova „nejdéle na dobu 1 roku“ se zrušují.
512. V § 236 odst. 2 se za slovo „stavby“ vkládá slovo „se“ a slova „stavební úřad“ se zrušují.
513. V § 236 odst. 3 se věta poslední nahrazuje větou „Povoluje-li předčasné užívání stavební
úřad, u stavby prováděné dodavatelsky stavebník k žádosti připojí vyjádření zhotovitele
stavby nebo autorizovaného inspektora ke splnění podmínek podle odstavce 1.“.
514. V § 236 se doplňují odstavce 6 a 7, které znějí:
„(6) Stavby přenosové, přepravní a distribuční soustavy lze užívat ihned po jejich
zprovoznění na základě platné revizní zprávy.
(7) Je-li žádost o vydání kolaudačního rozhodnutí podána před uplynutím doby trvání
předčasného užívání, prodlužuje se předčasné užívání do vykonatelnosti kolaudačního
rozhodnutí.“.
515. V § 237 odst. 2 se slova „stavební úřad“ zrušují, za slovo „povolí“ se vkládají slova
„stavební úřad nebo autorizovaný inspektor“, za slovo „nařídí“ se vkládají slova „stavební
úřad“ a na konci textu odstavce se doplňují slova „jako první úkon stavebního úřadu
v řízení“.
516. V § 237 odstavec 6 zní:
„(6) Je-li žádost o kolaudační rozhodnutí podána před ukončením zkušebního provozu,
prodlužuje se zkušební provoz do vykonatelnosti kolaudačního rozhodnutí.“.
517. V § 238 odst. 1 úvodní části ustanovení se slova „a náležitostí podle § 197 odst. 1 a 2“
zrušují.
518. V § 238 odstavec 2 zní:
„(2) Rozhodnutí o povolení předčasného užívání nebo zkušebním provozu určí dobu trvání
předčasného užívání nebo zkušebního provozu, nejdéle na dobu 3 let.“.
519. V § 238 odst. 3 větě první se za slovo „úřad“ vkládají slova „nebo autorizovaný
inspektor“, za slovo „stavebníka,“ se vkládá slovo „a“ a za slova „případě zkušebního
provozu“ se vkládají slova „stavební úřad“.
520. V § 238 odst. 3 větě druhé se za slovo „staveb“ vkládají slova „a veřejně prospěšných
staveb“ a na konci textu věty se doplňují slova „nebo 5 let od dokončení výstavby všech
staveb v rámci souboru staveb, pokud by jinak 10 let uplynulo dříve“.
521. V § 238 se doplňuje odstavec 4, který zní:
„(4) Odvolání proti rozhodnutí o předčasném užívání nebo zkušebním provozu nemá
odkladný účinek.“.
522. V § 239 odst. 1 se za slova „vlastníka stavby“ vkládají slova „nebo stavebníka se
souhlasem vlastníka stavby“.
523. V § 239 se doplňuje odstavec 5, který zní:
„(5) V řízení o změně v užívání stavby spočívající jen ve změně trvání dočasné stavby se
soulad s podmínkami podle § 193 posoudí pouze v případě, že od povolení stavby nebo od
posledního povolení prodloužení doby trvání této stavby došlo ke změně těchto podmínek.
Povolení změny v užívání stavby se nevyžaduje, pokud se změnily jen požadavky právních
předpisů.“.
524. V § 240 písm. a) a b) se za slovo „užívání“ vkládají slova „nebo dobu trvání“.
525. V § 241 odst. 1 úvodní části ustanovení se slova „může vydat“ nahrazují slovy „nebo
autorizovaný inspektor vydá“.
526. V § 242 odstavec 2 zní:
„(2) Je-li změna v užívání stavby podmíněna stavební úpravou vyžadující povolení,
projedná stavební úřad stavební úpravu v řízení o povolení záměru. Je-li užívání dokončené
stavební úpravy podmíněno kolaudací, postupuje se dále podle § 230 až 235. Nevyžaduje-li
se k užívání stavby a provedené stavební úpravy kolaudace, stanoví nový účel užívání stavby
stavební úřad v povolení záměru stavební úpravy.“.
527. § 243 a 244 se včetně nadpisů zrušují.
528. V § 245 se na konci odstavce 1 doplňuje věta „V případě podzemní stavby sítí technické
infrastruktury může být pasport stavby nahrazen dokumentací zaměření prostorové
polohy, rozměru a tvaru dokončené stavby nebo její části anebo technologického
zařízení.“.
529. V § 245 odst. 3 se věta poslední zrušuje.
530. V § 245 se doplňuje odstavec 4, který zní:
„(4) Není-li třeba pasport stavby doplnit, změnit nebo jinak přepracovat, stavební úřad nebo
autorizovaný inspektor jej ověří.“.
531. § 246 zní:
„§ 246
Vznikla-li realizací stavba, která musí být podle jiného zákona54) označena číslem, stavební
úřad nebo autorizovaný inspektor vyzve příslušnou obec k přidělení čísla.“.
532. V § 247 se na konci odstavce 1 doplňuje věta „Rozhodnutí o povolení odstranění stavby
vydává stavební úřad nebo v případě jednoduchých staveb, u nichž lze povolení
odstranění vydat jako první úkon stavebního úřadu v řízení, autorizovaný inspektor.“.
533. V § 247 odst. 2 se za slova „vlastník stavby“ vkládají slova „ , nebo ten, kdo má jiné
věcné právo k pozemku nebo stavbě,“.
534. V § 247 odst. 3 se za slovo „azbest,“ vkládají slova „nebo o vyhrazenou stavbu,“ a za
slovo „úřad“ se vkládají slova „nebo autorizovaný inspektor“.
535. V § 248 se vkládá nový odstavec 1, který zní:
„(1) Žádost o povolení odstranění stavby může podat vlastník stavby nebo se souhlasem
vlastníka stavby stavebník. Je-li pro realizaci záměru, pro který je stanoven účel vyvlastnění
v zákoně, třeba odstranění cizí stavby, může žádost o povolení odstranění takové stavby podat
i stavebník stavby, pro kterou je stanoven účel vyvlastnění v zákoně; souhlas vlastníka
odstraňované stavby se nevyžaduje.“.
Dosavadní odstavce 1 a 2 se označují jako odstavce 2 a 3.
536. V § 248 se doplňují odstavce 4 a 5, které znějí:
„(4) Žádost o povolení odstranění stavby lze podat jako součást žádosti o povolení záměru.
(5) V případě stavby obsahující azbest je součástí žádosti také návrh opatření k předcházení
a omezení rizik souvisejících s expozicí azbestu a doklad o splnění dalších požadavků pro práci
s azbestem podle jiného právního předpisu84).“.
Poznámka pod čarou č. 84 zní:
„84)
§ 41 zákona č. 258/2000 Sb., o ochraně veřejného zdraví, ve znění pozdějších
předpisů.“.
537. V § 249 se na konci odstavce 1 tečka nahrazuje čárkou a doplňuje se písmeno h), které
zní:
„h) v případě stavby obsahující azbest podmínky zajišťující splnění požadavků pro práci
s azbestem podle jiného právního předpisu84).“.
538. V § 249 se doplňuje odstavec 3, který zní:
„(3) Po nabytí právní moci povolení odstranění stavby stavební úřad zašle stavebníkovi
oznámení o ověření dokumentace pro odstranění stavby spolu se štítkem obsahujícím
identifikační údaje o odstraňované stavbě.“.
539. V § 250 odst. 1 úvodní části ustanovení se za slovo „stavby“ vkládají slova „ , případně
vlastníkovi pozemku“.
540. V § 250 odst. 1 písm. b) se slova „podle tohoto zákona“ nahrazují slovy „ , které měla
mít,“.
541. V § 250 odst. 1 písm. c) se slova „podle tohoto zákona“ zrušují.
542. V § 250 odst. 1 písm. e) se slova „do skončení této doby“ zrušují.
543. V § 250 odst. 2 se slova „a stavebník (dále jen „povinný“)“ zrušují a za slova „vlastník
pozemku, na němž se nachází stavba, která má být odstraněna,“ se vkládají slova
„a stavebník (dále jen „povinný“), a dále“.
544. V § 252 odst. 1 úvodní části ustanovení se slova „a náležitostí podle § 197 odst. 1 a 2“
zrušují.
545. V § 252 se na konci odstavce 1 tečka nahrazuje čárkou a doplňuje se písmeno i), které
zní:
„i) v případě stavby obsahující azbest podmínky zajišťující splnění požadavků pro práci
s azbestem podle jiného právního předpisu84).“.
546. V § 254 odst. 1 se za slovo „Stavbu“ vkládají slova „prováděnou nebo“.
547. V § 254 odst. 4 se slova „do skončení doby trvání stavby nebo“ zrušují a slova
„prodloužení doby trvání stavby“ se nahrazují slovy „změnu povolení“.
548. V § 254 se odstavec 5 zrušuje.
549. V § 255 odst. 1 se věta druhá zrušuje.
550. V § 255 se na konci odstavce 2 doplňuje věta „Ustanovení § 185 odst. 3 se nepoužije.“.
551. V § 255 se odstavec 3 zrušuje.
Dosavadní odstavec 4 se označuje jako odstavec 3.
552. V § 256 se za odstavec 2 vkládá nový odstavec 3, který zní:
„(3) Stavební úřad nenařídí odstranění stavby a stavbu, která vyžaduje povolení, dodatečně
povolí i bez splnění podmínek podle odstavce 1, pokud by nařízení odstranění stavby
představovalo pro povinného nebo pro jiné osoby nebo pro veřejný zájem zcela zjevně zásah
nepřiměřený přínosům a zároveň ponecháním stavby nejsou dotčeny veřejné zájmy ani práva
třetích osob. Odpovědnost povinného za přestupek tím není dotčena.“.
Dosavadní odstavce 3 a 4 se označují jako odstavce 4 a 5.
553. V § 258 se odstavec 2 zrušuje.
Dosavadní odstavce 3 a 4 se označují jako odstavce 2 a 3.
554. V § 259 odst. 1 větě první se slova „ , pokud povinný prokáže“ nahrazují slovem „při“
a ve větě druhé se za slovo „vznikla“ vkládá slovo „povinnému,“.
555. § 260 se včetně nadpisu zrušuje.
556. V části šesté hlavě VII se v nadpisu dílu 3 slovo „Společná“ nahrazuje slovem
„Společné“.
557. V § 261 se odstavce 2 až 4 zrušují a zároveň se zrušuje označení odstavce 1.
558. § 262 se zrušuje.
559. V § 264 odst. 5 větě poslední se číslo „3“ nahrazuje číslem „4“.
560. V § 264 se doplňují odstavce 6 až 8, které znějí:
„(6) Ustanovení odstavců 1 až 5 platí přiměřeně pro provedení stavby rodinného domu
nebo bytového domu anebo veřejné infrastruktury, pokud je tato stavba prováděna místo stavby
zničené nebo poškozené mimořádnou událostí, její podstatné parametry odpovídají zničené
nebo poškozené stavbě a vzhledem k okolnostem, zejména riziku opakování mimořádné
události, nelze požadovat, aby došlo k obnově zničené nebo poškozené stavby na původním
místě.
(7) Stavbu podle odstavce 6 lze umístit na pozemku vhodném pro provedení takové stavby,
v souladu s územně plánovací dokumentací, případně s územními opařeními a vymezením
zastavitelného území. Ustanovení § 187 platí obdobně.
(8) Pokud stavbu podle odstavce 6 není možné provést na pozemku uvedeném v odstavci
7, neboť takový pozemek není pro stavebníka dostupný, lze se souhlasem vlastníka pozemku
pořídit a vydat změnu územního nebo regulačního plánu podle § 111a.“.
561. V § 266 odst. 2 větě první se za slovo „úkon“ vkládají slova „stavebního úřadu“.
562. V § 267 odst. 2 úvodní části ustanovení, § 267 odst. 3 větě první až poslední, § 267 odst. 5
větě první, § 273 odst. 1, § 275 odst. 3 větě první a druhé a § 334b odst. 4 větě první
a druhé se slova „stavební správy“ zrušují.
563. V § 267 odst. 3 se na konci textu věty první doplňují slova „ ; § 172 odst. 1 se pro jiné
stavební úřady nepoužije“.
564. V § 268 se za odstavec 2 vkládá nový odstavec 3, který zní:
„(3) Portál stavebníka poskytuje účastníkům řízení službu sledování stavu řízení.“.
Dosavadní odstavec 3 se označuje jako odstavec 4.
565. V § 269 odstavec 3 zní:
„(3) V národním geoportálu územního plánování se zveřejňují územně plánovací podklady,
územně plánovací dokumentace, vymezení zastavitelného území a územní opatření.“.
566. V § 269 se odstavec 4 zrušuje.
Dosavadní odstavce 5 až 7 se označují jako odstavce 4 až 6.
567. V § 269 odst. 4 se věta první nahrazuje větou „Orgán územního plánování vkládá do
národního geoportálu územního plánování písemnosti, údaje a prostorová data, které mají
být zveřejněny v národním geoportálu územního plánování.“ a na konci odstavce se
doplňuje věta „Orgán územního plánování může vložit do národního geoportálu
územního plánování i další písemnosti vzniklé při územně plánovací činnosti.“.
568. V § 270 odst. 3 se na konci písmene c) slovo „a“ nahrazuje tečkou a písmeno d) se zrušuje.
569. V § 271 se na konci odstavce 1 doplňuje věta „Dále se do evidence elektronických
dokumentací vkládá informační kontejner pro povolení stavby a informační kontejner pro
kolaudaci stavby ve strojově čitelném formátu, stanoví-li tak jiný právní předpis85).“.
Poznámka pod čarou č. 85 zní:
„85)
Zákon č. 330/2025 Sb., o správě informací o stavbě a vystavěném prostředí a o změně
některých dalších zákonů.“.
570. V § 271 odst. 2 se věta druhá zrušuje.
571. V § 272 odst. 2 se za slovo „dokumentaci“ vkládají slova „a dokumentaci pro povolení
záměru“ a na konci textu odstavce se doplňují slova „ ; jiné osoby jen se souhlasem
stavebníka nebo vlastníka stavby, které se tato dokumentace týká“.
572. V § 272 odst. 3 se za slovo „dokumentaci“ vkládají slova „a dokumentaci pro povolení
záměru“.
573. V § 274 písm. c) se slova „orgánů stavební správy“ nahrazují slovy „stavebních úřadů“.
574. V § 275 odst. 1 větě první se slova „a stavební správy“ zrušují a ve větě druhé se slova
„ , evidenci stavebních postupů a evidenci elektronických dokumentací“ zrušují.
575. V § 276 odst. 1 se za slovo „inspektor“ vkládají slova „vede správní řízení podle tohoto
zákona obdobně jako stavební úřad, za podmínek podle tohoto zákona vydává kolaudační
rozhodnutí, rozhodnutí o povolení zkušebního provozu, rozhodnutí o předčasném užívání
stavby, rozhodnutí ve zrychleném řízení o změně v užívání stavby nebo rozhodnutí
o povolení odstranění stavby, vydává vyjádření pro předčasné užívání stavby a ověřuje
pasport stavby místo stavebního úřadu, pokud jej o to stavebník nebo vlastník stavby
požádá, a“.
576. V § 277 odst. 1 písm. d) se číslo „15“ nahrazuje číslem „7“ a slova „má-li osvědčení o
zvláštní odborné způsobilosti podle jiného právního předpisu58),“ se zrušují.
577. V § 277 odst. 1 se za písmeno d) vkládá nové písmeno e), které zní:
„e) má osvědčení o zvláštní odborné způsobilosti podle jiného právního předpisu58) nebo
osvědčení o úspěšném vykonání úřednické zkoušky pro obor specializace, jehož součástí
je stavební řád,“.
Dosavadní písmena e) a f) se označují jako písmena f) a g).
578. V § 279 se odstavec 2 zrušuje.
Dosavadní odstavec 3 se označuje jako odstavec 2.
579. V § 280 odst. 2 písm. a) se slovo „ministerstvu“ nahrazuje slovem „Úřadu“.
580. V § 281 odst. 1 písm. a) se slova „opakovaně nebo“ a slovo „nebo“ zrušují.
581. V § 281 odst. 1 se za písmeno a) vkládá nové písmeno b), které zní:
„b) při své činnosti závažně porušil své povinnosti stanovené tímto zákonem a jinými právními
předpisy, nebo“.
Dosavadní písmeno b) se označuje jako písmeno c).
582. V § 282 odst. 1 větě první a druhé se slovo „ministerstva“ nahrazuje slovem „Úřadu“
a část věty první za středníkem se včetně středníku zrušuje.
583. V § 283 se na konci odstavce 3 doplňuje věta „Vydal-li autorizovaný inspektor rozhodnutí
místo stavebního úřadu, doručí jej vždy také stavebnímu úřadu, a to společně se žádostí
žadatele včetně jejích příloh.“.
584. V § 284 odst. 1 úvodní části ustanovení větě první se slovo „vydávat“ nahrazuje slovy
„na celém území České republiky ověřovat pasport stavby, vést správní řízení a vydávat
kolaudační rozhodnutí, rozhodnutí o povolení zkušebního provozu, rozhodnutí
o předčasném užívání stavby, rozhodnutí ve zrychleném řízení o změně v užívání stavby,
rozhodnutí o povolení odstranění stavby a vyjádření pro předčasné užívání stavby a“.
585. V § 285 odst. 1 větě druhé se slovo „ministerstvem“ nahrazuje slovem „Úřadem“.
586. V nadpisu § 286 se slovo „ministerstva“ nahrazuje slovem „Úřadu“.
587. V § 287 odst. 1 se slova „ministerstvo a krajský úřad“ nahrazují slovy „Úřad a úřady
rozvoje území krajů“.
588. V § 287 odst. 3 úvodní části ustanovení se slova „Krajský úřad“ nahrazují slovy „Úřad
rozvoje území kraje“.
589. V § 288 odst. 1 se slova „ministerstvo a krajský úřad“ nahrazují slovy „příslušné úřady
rozvoje území“ a slova „ , jakož i dodržování usnesení vlády, směrnic ústředních
správních úřadů, jakož i opatření příslušných orgánů veřejné správy přijatých při kontrole
výkonu přenesené působnosti“ se zrušují.
590. V § 288 odst. 2 se slova „i přenesené“ zrušují.
591. V § 289 odst. 1 se slova „ministerstvo nebo krajský úřad“ nahrazují slovy „příslušný úřad
rozvoje území“.
592. V § 295 odst. 1 písm. e) se za slovo „že“ vkládají slova „je užívána bez povolení nebo“.
593. V § 297 odst. 1 se za slovo „pro“ vkládají slova „vytvoření podmínek pro provedení
stavby nebo její změny, nutných zabezpečovacích prací, nezbytných úprav, udržovacích
prací nebo k odstranění stavby nebo zařízení,“.
594. V § 298 včetně nadpisu zní:
„§ 298
Působnost
(1) Úřad kontroluje výkon působnosti úřadů rozvoje území krajů a autorizovaných
inspektorů. Úřady rozvoje území krajů kontrolují výkon působnosti svých územních pracovišť.
(2) Úřad a věcně příslušné ústřední orgány státní správy kontrolují dodržování jiných
právních předpisů při postupech podle tohoto zákona, jakož i dodržování usnesení vlády
a směrnic ústředních správních úřadů.“.
595. V § 299 se slova „Ministerstvo, Ministerstvo dopravy, Ministerstvo průmyslu a obchodu,
Dopravní a energetický stavební úřad a krajský stavební úřad“ nahrazují slovy „Úřad
a věcně příslušné ústřední orgány státní správy“ a slova „do doby zjednání nápravy
mohou pozastavit nebo omezit výkon činnosti, při níž dochází k porušování právní
povinnosti“ se nahrazují slovy „nesouhlasí-li Úřad s opatřením uloženým jiným
ústředním orgánem státní správy, předloží věc k rozhodnutí vládě“.
596. V § 301 odstavce 1 a 2 znějí:
„(1) Přestupku se dopustí ten, kdo
a) provede záměr bez povolení, které je podle tohoto zákona vyžadováno, nebo v rozporu
s ním,
b) provede jednoduchou stavbu bez povolení, které je podle tohoto zákona vyžadováno, nebo
v rozporu s ním,
c) užívá záměr vyžadující povolení bez tohoto povolení, nebo v rozporu s ním,
d) odstraní stavbu, která podléhá povolení, bez povolení odstranění stavby, nebo v rozporu
s ním, nebo
e) odstraní stavbu, která obsahuje azbest, bez povolení odstranění stavby nebo v rozporu
s ním.
(2) Přestupku se dopustí ten, kdo
a) poruší zakazující opatření podle § 294 nebo neplní uložená opatření k nápravě podle § 295
nebo
b) užívá záměr vyžadující povolení bez tohoto povolení za účelem zisku nebo kdo umožní
takové užívání jiným osobám.“.
597. V § 301 odst. 3 písm. a) se slova „nebo d)“ zrušují.
598. V § 301 odst. 3 písm. b) se slova „f), g), h), i), j), k), l) nebo n)“ nahrazují slovy „b) nebo
d)“.
599. V § 301 odst. 3 písm. c) se text „b),“ nahrazuje slovem „nebo“ a slova „nebo m),“ se
zrušují.
600. V § 301 odst. 3 písm. d) se slova „nebo b)“ zrušují a slova „nezastavitelném pozemku,
v nezastavěném“ se nahrazují slovy „nestavební ploše, v nezastavitelném“.
601. Nad označení § 302 se vkládá skupinový nadpis, který zní: „Přestupky vybraných
osob“.
602. Nadpis § 302 se zrušuje.
603. V § 302 odst. 7 písm. b) se za slovo „odstavce“ vkládají slova „1 písm. b) nebo odstavce“.
604. V § 302 odst. 7 písm. c) se slova „1 písm. b) nebo odstavce“ zrušují.
605. V § 302 odst. 7 písm. d) se slova „nezastavitelném pozemku, v nezastavěném“ nahrazují
slovy „nestavební ploše, v nezastavitelném“.
606. Nadpis § 303 se zrušuje.
607. V § 304 odst. 1 se slova „ ; přestupky podle § 302 odst. 4 a § 303 odst. 4 projednává
krajský úřad“ nahrazují slovy „a přestupky na úseku územního plánování Úřad“.
608. V § 304 se odstavec 2 zrušuje.
Dosavadní odstavec 3 se označuje jako odstavec 2.
609. V § 306 se odstavec 2 zrušuje a zároveň se zrušuje označení odstavce 1.
610. V § 307 odst. 1 se slova „je nepřípustná, obsahuje-li pouze“ nahrazují slovy „nebo
jednotlivé žalobní body jsou nepřípustné, směřují-li k řešení nepřípustných námitek nebo
obsahují-li“.
611. V § 307 odst. 2 se slova „je také nepřípustný, obsahuje-li“ nahrazují slovy „i jednotlivé
body tohoto návrhu jsou nepřípustné, obsahují-li“.
612. V § 307 se doplňuje odstavec 3, který zní:
„(3) Nepřípustné žalobní body soud nevypořádává.“.
613. § 308 včetně nadpisu zní:
„§ 308
Odkladný účinek
(1) Návrh na přiznání odkladného účinku žaloby proti rozhodnutí stavebního úřadu
o povolení záměru lze podat pouze společně s žalobou. Návrh na přiznání odkladného účinku
v řízení o kasační stížnosti lze podat pouze společně s touto kasační stížností.
(2) Přizná-li soud žalobě nebo kasační stížnosti odkladný účinek nebo nařídí-li předběžné
opatření, rozhodne ve věci přednostně s nejvyšším urychlením, nejpozději do 90 dnů od
přiznání odkladného účinku nebo od nařízení předběžného opatření.“.
614. Za § 308 se vkládá nový § 308a, který včetně nadpisu zní:
„§ 308a
Soudní smír
Připouští-li to povaha věci, mohou účastníci řízení a osoby zúčastněné na řízení skončit
řízení soudním smírem; ustanovení § 99 občanského soudního řádu se použije obdobně.
Obsahem smíru může být zejména netrvání na návrhu a poskytnutí finanční náhrady nebo
provedení kompenzačních nebo zmírňujících opatření.“.
615. § 309 včetně nadpisu zní:
„§ 309
Rozhodnutí o návrhu
(1) Soud přezkoumá pouze všechny přípustné žalobní nebo návrhové body. Nerozhodne-
li soud bez jednání, sdělí před rozhodnutím účastníkům řízení svůj právní názor na věc a umožní
jim na něj reagovat.
(2) Soud nezruší rozhodnutí ani opatření obecné povahy pouze pro nepřezkoumatelnost a
přezkoumá je z hlediska zákonnosti jejich výroku, je-li to na základě správního spisu nebo
doplnění podkladů nebo důvodů rozhodnutí v řízení před soudem možné; přitom vychází i z
vyjádření žalovaného, odpůrce nebo dotčeného orgánu v řízení před soudem, kteří mohou
chybějící podklady a důvody doplnit, k čemuž je soud vyzve. To platí i v případech, je-li
žalobou napadeno rozhodnutí, které neobsahuje odůvodnění podle § 311 odst. 4 nebo které je
založeno na závazném stanovisku bez odůvodnění podle § 178 odst. 1 nebo 2.
(3) O žalobách ve věcech vyhrazených staveb rozhodne soud ve lhůtě 90 dnů.
(4) Je-li žaloba důvodná a bez dalšího dokazování je zcela zřejmé, jak by v případě jeho
zrušení a vrácení stavebnímu úřadu k dalšímu řízení musel stavební úřad rozhodnout nebo
souhlasí-li s tím všichni účastníci řízení a taková změna by nemohla vést k zásahu do práv
třetích osob ani k zásahu do veřejných zájmů, může soud rozsudkem napadené rozhodnutí
změnit. Proti částem rozhodnutí stavebního úřadu, která byla změněna rozsudkem, není
přípustné vést přezkumné řízení podle správního řádu.
(5) Soud nezruší napadené rozhodnutí nebo opatření obecné povahy a návrh zamítne,
pokud by jeho zrušení představovalo pro jiné osoby nebo pro veřejný zájem nepoměrně větší
újmu v porovnání s újmou vzniklou navrhovateli zamítnutím návrhu.
(6) Odstavce 1 až 5 platí obdobně i pro řízení o kasační stížnosti.“.
616. Nadpis § 310 zní: „Příslušnost“.
617. V § 310 se za slovo „části“ vkládají slova „a k řízení o zrušení územního opatření
vydaného vládou“.
618. Nadpis pod označením § 311 se zrušuje.
619. V § 311 odst. 1 větě první se slova „orgány obce“ nahrazují slovem „obcí“ a slova
„krajský úřad“ se nahrazují slovy „úřad rozvoje území kraje“ a ve větě druhé se slova
„orgány kraje je příslušné ministerstvo“ nahrazují slovy „krajem je příslušný Úřad“.
620. V § 311 odst. 2 se za slovo „dokumentaci“ vkládají slova „ani územní opatření“.
621. V § 311 se doplňují odstavce 4 až 9, které znějí:
„(4) Povolení vydané podle tohoto zákona jako první úkon stavebního úřadu v řízení
obsahuje pouze výrok a poučení o opravném prostředku. Proti tomuto rozhodnutí není odvolání
přípustné. Rozhodnutí lze přezkoumat v přezkumném řízení, které lze zahájit do 1 měsíce ode
dne, kdy se stavební úřad o důvodu zahájení přezkumného řízení dozvěděl, nejpozději však do
2 měsíců od právní moci rozhodnutí. Rozhodnutí v přezkumném řízení v prvním stupni nelze
vydat po uplynutí 3 měsíců od právní moci přezkoumávaného rozhodnutí.
(5) Rozhodnutí nebo usnesení podle tohoto zákona, proti kterému se nelze odvolat, nabývá
právní moci dnem doručení stavebníkovi nebo povinnému.
(6) Na návrh účastníka nebo je-li to účelné, lze provést ústní jednání podle tohoto zákona
s využitím technického zařízení pro přenos obrazu a zvuku (videokonferenční zařízení).
(7) Nevyžaduje-li úkon správního orgánu podle tohoto zákona správní uvážení, lze jej
provést automatizovaně bez účasti úřední osoby, pokud tím nebude ohrožena ochrana práv
dotčených osob nebo ochrana veřejného zájmu. Místo údaje o úřední osobě se na úkonu podle
věty první uvede, že byl proveden automatizovaně bez účasti úřední osoby, a její podpis se
nahradí kvalifikovanou elektronickou pečetí.
(8) Vede-li se spis nebo jeho část v elektronické podobě, předává se spis nebo jeho část
všem orgánům výhradně v elektronické podobě.
(9) Postoupení spisu není důvodem pro přerušení řízení o žádosti.“.
622. V § 313 odst. 2 se za slova „196 zákona o státní službě“ vkládá čárka.
623. V § 314 se za slova „podle dosavadních“ vkládá slovo „právních“.
624. V § 316 odst. 4 se za slovo „osvědčení“ vkládá slovo „o“.
625. V § 322 odst. 2 větě druhé se za číslo „6“ vkládají slova „ve znění účinném do 31. prosince
2026“.
626. V § 323 odst. 10 větě druhé se číslo „3“ nahrazuje číslem „2“.
627. V § 324 se dosavadní text označuje jako odstavec 1 a doplňuje se odstavec 2, který zní:
„(2) Podmínka vydání regulačního plánu na žádost vymezená v územně plánovací
dokumentaci podle dosavadních právních předpisů se považuje za podmínku vydání
regulačního plánu podle tohoto zákona a pozbývá platnosti marným uplynutím lhůty 6 let od
nabytí účinnosti územního plánu, který tuto podmínku vymezil.“.
628. V § 330 se na konci odstavce 6 doplňují věty „Pokud o to stavebník požádá, lze o změně
takového pravomocného územního rozhodnutí o umístění stavby vydaného v územním
řízení, v územním řízení s posouzením vlivů na životní prostředí anebo ve
zjednodušeném územním řízení, účinného územního souhlasu, účinné veřejnoprávní
smlouvy a vydaného regulačního plánu nahrazujícího územní rozhodnutí o umístění
stavby rozhodnout v rámci řízení o povolení záměru, jeho části či etapy podle tohoto
zákona. V takovém případě stavebník předloží společnou žádost o vydání rozhodnutí
o změně územního rozhodnutí a povolení záměru a dokumentaci pro povolení záměru,
která navíc obsahuje popis změn provedených proti pravomocnému územnímu
rozhodnutí o umístění stavby, účinnému územnímu souhlasu, účinné veřejnoprávní
smlouvě a vydanému regulačnímu plánu nahrazujícímu územní rozhodnutí o umístění
stavby.“.
629. V § 330 se na konci textu odstavce 11 doplňují slova „ , a pokud splní požadavky podle
§ 277 odst. 1 písm. e)“.
630. V § 333 odstavce 1 a 2 znějí:
„(1) Vláda vydá nařízení k provedení § 36 odst. 5, § 152 odst. 1, § 152a odst. 1, § 154 odst.
2, § 158 odst. 6, § 161 odst. 4, § 166 odst. 4, § 167 odst. 1 písm. e), f), j) a k) a § 169 odst. 2.
Návrh nařízení vlády podle věty první připravuje a předkládá vládě Úřad ve spolupráci
s dotčenými ministerstvy.
(2) Úřad vydá vyhlášky k provedení § 12 písm. p), § 59 odst. 3, § 62 odst. 3, § 64 odst. 1,
§ 87 odst. 4, 103 odst. 1, § 172 odst. 2, § 227 odst. 5, § 267 odst. 5, § 268 odst. 4, § 269 odst. 6,
§ 270 odst. 3, § 271 odst. 4, § 273 odst. 3, § 278, § 285 odst. 4 a § 292 odst. 5.“.
631. V § 333 odst. 3 se slova „ , statutární město Brno a statutární město Ostrava“ nahrazují
slovy „a obce, ve kterých je sídlo kraje (krajská města),“ a na konci textu odstavce se
doplňují slova „a § 152a odst. 1“.
632. V nadpisu § 334b se slova „stavební správy“ zrušují.
633. V § 334b odstavec 1 zní:
„(1) Přechodným obdobím se rozumí období do 31. prosince 2030.“.
634. V § 334b odst. 2 se za text „odst. 5,“ vkládá text „§ 268 odst. 3,“ a za text „§ 272 odst.“
se vkládá číslo „1,“.
635. V § 334b se odstavec 3 zrušuje.
Dosavadní odstavce 4 až 10 se označují jako odstavce 3 až 9.
636. V § 334b odstavec 4 zní:
„(4) Stanoví-li tento zákon povinnost vložit dokument do národního geoportálu územního
plánování nebo odkázat na něj, lze v přechodném období splnit tuto povinnost i jiným
způsobem umožňujícím dálkový přístup.“.
637. V § 334b se odstavce 5 a 6 zrušují.
Dosavadní odstavce 7 až 9 se označují jako odstavce 5 až 7.
638. V § 334b odst. 5 větě druhé se číslo „2026“ nahrazuje číslem „2030“.
639. V § 334b odst. 6 větě druhé se slovo „zastavěném“ nahrazuje slovem „zastavitelném“ a
číslo „8“ se nahrazuje číslem „4“.
640. V § 334b odst. 7 se číslo „8“ nahrazuje číslem „5“.
641. V příloze č. 1 odst. 1 písm. a) úvodní části ustanovení se za slova „zařízení a“ vkládají
slova „s nimi související terénní úpravy a“.
642. V příloze č. 1 odst. 1 písm. a) bodě 1 se číslo „40“ nahrazuje číslem „60“, za slovo
„podlažím“ se vkládají slova „a podkrovím“ a slova „rodinného domu nebo stavby pro
rodinnou rekreaci“ se nahrazují slovy „zázemí stavby“.
643. V příloze č. 1 odst. 1 písm. a) bodě 2 se slova „rodinného domu nebo stavby pro rodinnou
rekreaci“ nahrazují slovy „zázemí stavby“.
644. V příloze č. 1 odst. 1 písm. a) bodech 3 a 4 se slova „s prvky regulačního plánu“ zrušují.
645. V příloze č. 1 odst. 1 písm. a) bodě 4 se slova „ , včetně základové konstrukce, do 55“
nahrazují slovy „do 60“ a číslo „4“ se nahrazuje číslem „5“.
646. V příloze č. 1 odst. 1 písm. a) se za bod 4 vkládá nový bod 5, který zní:
„5. stavba pro zemědělství do 60 m2 zastavěné plochy a do 5 m výšky o jednom nadzemním
podlaží, nepodsklepená, která je umisťována v odstupové vzdálenosti od hranic pozemků
nejméně 2 m,“.
Dosavadní body 5 až 34 se označují jako body 6 až 35.
647. V příloze č. 1 odst. 1 písm. a) bodě 6 se číslo „1“ nahrazuje číslem „1,5“ a slova
„zastavěném území nebo v zastavitelné ploše“ se nahrazují slovy „zastavitelném území“.
648. V příloze č. 1 odst. 1 písm. a) bodě 7 se číslo „30“ nahrazuje číslem „90“.
649. V příloze č. 1 odst. 1 písm. a) bodě 9 se na začátek vkládají slova „ohrady pro hospodářská
zvířata do 1,5 m výšky,“, slovo „nebo“ se nahrazuje čárkou a na konci textu bodu se
doplňují slova „nebo k významnému zhoršení prostupnosti krajiny pro volně žijící drobné
živočichy“.
650. V příloze č. 1 odst. 1 písm. a) se na začátek bodů 12 a 13 vkládají slova „doplnění,
odstranění,“.
651. V příloze č. 1 odst. 1 písm. a) bodě 13 se slova „ , výměna nebo navýšení kapacity sítě
technické infrastruktury“ zrušují, slova „pro provedení“ se nahrazují slovy „s provedením
doplnění, odstranění,“ a slova „je s vlastníkem dotčených pozemků uzavřena smlouva
o zřízení věcného břemene nebo smlouva o smlouvě budoucí o zřízení věcného břemene“
se nahrazují slovy „vlastník dotčených pozemků souhlasí“.
652. V příloze č. 1 odst. 1 písm. a) bodě 16 se slovo „podpěrné“ zrušuje a slova „ , nejde-li
o portálové konstrukce“ se nahrazují slovy „a dráhách“.
653. V příloze č. 1 odst. 1 písm. a) bod 24 zní:
„24. běžné dobíjecí body62),“.
654. V příloze č. 1 odst. 1 písm. a) se za bod 27 vkládá nový bod 28, který včetně poznámky
pod čarou č. 86 zní:
„28. zázemí zotavovací akce nebo jiné podobné akce pro děti86) tvořené přístřešky o
celkové zastavěné ploše všech staveb do 60 m2, s výjimkou hygienického zařízení, bez
podsklepení, s nejvýše jedním nadzemním podlažím, je-li ubytování účastníků takové akce
zajištěno výhradně ve stanech; takové přístřešky se za stavbu ani za drobnou stavbu
nepovažují, jsou-li pro uvedený účel využívány pouze mimo období školního vyučování.
_____________
86)
§ 8 odst. 1, § 12 zákona č. 258/2000 Sb., o ochraně veřejného zdraví, ve znění pozdějších
předpisů.“.
Dosavadní body 28 až 35 se označují jako body 29 až 36.
655. V příloze č. 1 odst. 1 písm. a) bodě 29 se číslo „55“ nahrazuje číslem „60“.
656. V příloze č. 1 odst. 1 písm. a) bodě 30 se číslo „25“ nahrazuje číslem „100“ a slova
„ , jehož distribuční soustava je připojena k přenosové soustavě a k jehož soustavě je
připojeno více než 90 000 odběrných míst“ a za slovo „zařízení“ se vkládají slova „ , a to
i“.
657. V příloze č. 1 odst. 1 písm. a) bodě 31 se číslo „25“ nahrazuje číslem „100“ a slova
„ , k jehož soustavě je připojeno více než 90 000 odběrných míst,“ a za slovo „zařízení“
se vkládají slova „ , a to i“.
658. V příloze č. 1 odst. 1 písm. a) bodě 32 se číslo „25“ nahrazuje číslem „100“ a za slovo
„zařízení“ se vkládají slova „ , a to i“.
659. V příloze č. 1 odst. 1 písm. a) bodě 34 se slova „výrobky plnící funkci“ zrušují a slovo
„zastavěném“ se nahrazuje slovem „zastavitelném“.
660. V příloze č. 1 odst. 1 písm. a) bodě 35 se slova „jestliže neobsahují obytné nebo pobytové
místnosti nebo hygienická zařízení,“ zrušují a slovo „zastavěném“ se nahrazuje slovem
„zastavitelném“.
661. V příloze č. 1 odst. 1 se na konci písmene a) doplňují body 37 až 45, které znějí:
„37. sítě elektronických komunikací, pokud se umisťují na vlastních nemovitostech nebo
pokud s jejich umístěním vlastník dotčené nemovitosti souhlasí, nebo přípojky
elektronických komunikací do délky 100 metrů; přípojkou elektronických komunikací se
rozumí část sítě elektronických komunikací, která umožňuje připojení bodu vstupu
komunikačního vedení do budovy nebo na pozemek, kde je umístěn koncový bod sítě,
k nejbližšímu rozhraní veřejné komunikační sítě,
38. uložení stávajícího nadzemního vedení na hladině nízkého napětí v zastavitelném
území pod zem, pokud s tím vlastník dotčených pozemků souhlasí,
39. tepelná přípojka v maximální délce do 100 m od rozvodného tepelného zařízení
zřizovaná držitelem licence na rozvod tepelné energie, včetně připojení stavby a
odběrných zařízení nebo připojení staveb plnících doplňkovou funkci ke stavbě hlavní,
40. dočasné stavby náhradních tras dopravní a technické infrastruktury a souvisejících
zařízení a staveb, jejichž trvání nepřesáhne 12 měsíců,
41. jiné dočasné stavby nebo zařízení, jejichž umístění nepřesáhne 90 po sobě jdoucích
dnů,
42. venkovní dětská hřiště, sportoviště a zařízení pro sport do 300 m2,
43. stavba zpevněných ploch do 60 m2 na pozemku zázemí stavby, která souvisí s
bydlením nebo rodinnou rekreací,
44. stavba veřejného osvětlení,
45. jiná nepatrná stavba, která nemůže ani potenciálně zasáhnout do žádných veřejných
zájmů ani práv třetích osob,“.
662. V příloze č. 1 odst. 1 písm. d) se slova „a nejde o udržovací práce na stavbě, která je
kulturní památkou“ zrušují.
663. V příloze č. 1 odst. 1 písm. e) se slova „stavební úpravy, pokud“ nahrazují slovy „stavební
úpravy včetně zateplení budov, pokud“, slova „se jimi nezasahuje do nosných konstrukcí
stavby“ se nahrazují slovy „jimi není ovlivněna mechanická odolnost a stabilita stavby“,
za slova „nemění se“ se vkládá slovo „významně“, slovo „způsob“ se nahrazuje slovem
„účel“ a slova „a nejde o stavební úpravy stavby, která je kulturní památkou“ se zrušují.
664. V příloze č. 1 odst. 1 písm. f) se slova „se jimi nezasahuje do nosných konstrukcí stavby,
nemění se způsob“ nahrazují slovy „jimi není ovlivněna mechanická odolnost a stabilita
stavby, nemění se účel“.
665. V příloze č. 1 odst. 1 písm. i) bodě 2 se číslo „5,0“ nahrazuje číslem „3,0“ a číslo „1“ se
nahrazuje číslem „0,25“.
666. V příloze č. 1 odst. 1 písm. i) bodě 3 se číslo „1“ nahrazuje číslem „0,4“.
667. V příloze č. 1 se na konci odstavce 1 tečka nahrazuje čárkou a doplňuje se písmeno j),
které zní:
„j) změny využití území, a to
1. terénní úprava do 1,5 m výšky nebo hloubky o výměře do 300 m2 na pozemku, který
nemá společnou hranici s veřejnou pozemní komunikací nebo veřejným prostranstvím,
2. odstavná, manipulační, prodejní, skladová nebo výstavní plocha do 300 m2, která
neslouží pro skladování hořlavých látek nebo manipulaci s hořlavými látkami nebo
látkami, které mohou způsobit znečištění životního prostředí, nebo se zvláště
nebezpečnými a nebezpečnými látkami podle vodního zákona,
3. změna druhu pozemku48) nebo způsobu využití pozemků49) o výměře do 300 m2,
4. terénní úprava v přirozeném korytu vodního toku a na pozemcích sousedících s ním,
kterou se podstatně nemění přirozené koryto vodního toku, pokud se neprovádí ve
stanoveném záplavovém území,
5. úprava pozemku, která má vliv na schopnost vsakování vody, provedená na pozemku
stavby pro bydlení nebo rodinnou rekreaci, která souvisí nebo podmiňuje bydlení nebo
rodinnou rekreaci, neslouží ke skladování hořlavých látek nebo výbušnin, není
v rozporu s územně plánovací dokumentací a plocha části pozemku schopného
vsakovat dešťové vody po jejím provedení bude nejméně 50 % z celkové plochy
pozemku stavby pro bydlení nebo rodinnou rekreaci.“.
668. V příloze č. 1 odst. 2 se písmeno c) zrušuje.
Dosavadní písmena d) až l) se označují jako písmena c) až k).
669. V příloze č. 1 odst. 2 se písmeno i) zrušuje.
Dosavadní písmena j) a k) se označují jako písmena i) a j).
670. V příloze č. 1 se na konci odstavce 2 tečka nahrazuje čárkou a doplňují se písmena k) a
l), která znějí:
„k) změny využití území realizované v území, pro které je vydán plán území s archeologickými
nálezy, nebo ve zvláště chráněném území, evropsky významné lokalitě nebo ptačí oblasti
nebo v chráněném ložiskovém území,
l)
stavby pódií ve venkovním prostoru pro akce, jejichž převažujícím účelem je elektronicky
zesilovaná hudební produkce, pokud doba umístění takové stavby přesáhne 10 po sobě
jdoucích dnů a pokud je stavba umisťována nad tuto dobu bez souhlasu obce, na jejímž
území se má stavba umístit.“.
671. V příloze č. 2 odst. 1 úvodní části ustanovení se za slova „zařízení a“ vkládají slova „nimi
související“ a za slovo „úpravy“ se vkládají slova „a jejich údržba, pokud nejde o drobnou
stavbu“.
672. V příloze č. 2 odst. 1 písm. a) se slova „stavby pro bydlení a“ nahrazují slovy „rodinné
domy a stavby pro“.
673. V příloze č. 2 odst. 1 se za písmeno a) vkládá nové písmeno b), které včetně poznámky
pod čarou č. 87 zní:
„b) bytové domy do 500 m2 zastavěné plochy, které mají nejvýše 4 nadzemní podlaží, výšku
podle jiného právního předpisu87) do 9 m, nejvýše jedno podzemní podlaží a jsou určeny
výhradně k bydlení,
_______________
87) Vyhláška Ministerstva vnitra č. 460/2021 Sb., o kategorizaci staveb z hlediska požární
bezpečnosti a ochrany obyvatelstva.“.
Dosavadní písmena b) až v) se označují jako písmena c) až w).
674. V příloze č. 2 odst. 1 se písmeno d) zrušuje.
Dosavadní písmena e) až w) se označují jako písmena d) až v).
675. V příloze č. 2 odst. 1 písm. e) se slova „ , pokud nejde o drobnou stavbu“ zrušují.
676. V příloze č. 2 odst. 1 se písmeno f) zrušuje.
Dosavadní písmena g) až v) se označují jako písmena f) až u).
677. V příloze č. 2 odst. 1 písm. f) se slova „nad 60 m2 zastavěné plochy nebo nad 5 m výšky“
zrušují a slova „nepodsklepené, pokud nejde o stavby pro hospodářská zvířata anebo
stavby, které mají sloužit pro skladování a zpracování hořlavých látek jako sušičky,
sklady hořlavých kapalin, sklady chemických hnojiv a jiné“ se nahrazují slovy
„podsklepené nejvýše do hloubky 3 m“.
678. V příloze č. 2 odst. 1 se písmeno g) zrušuje.
Dosavadní písmena h) až u) se označují jako písmena g) až t).
679. V příloze č. 2 odst. 1 písm. g), h), j), n) a r) se slova „ , pokud nejde o drobnou stavbu“
zrušují.
680. V příloze č. 2 odst. 1 se písmeno m) zrušuje.
Dosavadní písmena n) až t) se označují jako písmena m) až s).
681. V příloze č. 2 odst. 1 písm. n) se za slovo „podlažím“ vkládají slova „a podkrovím“
a slova „rodinného domu“ se nahrazují slovy „zázemí stavby“.
682. V příloze č. 2 odst. 1 písm. s) se slova „pokud nejde o drobnou stavbu.“ zrušují.
683. V příloze č. 2 se na konci odstavce 1 doplňuje písmeno t), které zní:
„t) venkovní sportoviště do 3 000 m2 včetně staveb zázemí sportoviště (toalety, sprchy, šatny,
občerstvení) do 300 m2 zastavěné plochy a do 7 m výšky.“.
684. V příloze č. 2 odst. 2 se na konci úvodní části ustanovení doplňují slova „ , pokud nejde
o drobnou stavbu,“.
685. V příloze č. 2 odst. 2 se písmeno d) zrušuje.
Dosavadní písmena e) až i) se označují jako písmena d) až h).
686. V příloze č. 2 odst. 2 písm. f) se slovo „nezastavěném“ nahrazují slovy „nezastavitelném“.
687. V příloze č. 2 odst. 3 písm. d) se slova „nebo jednoduchou stavbu podle odstavce 1 písm.
o) této přílohy“ zrušují.
688. V příloze č. 3 písm. n) se za slovo „dobýváním“ vkládají slova „nebo likvidaci
a zajištění“.
689. V příloze č. 3 se na konci písmene q) tečka nahrazuje čárkou a doplňují se písmena r) až
w), která znějí:
„r) stavby pro hromadné bydlení,
s) stavby zařízení pro výrobu polovodičů, pokud byly Evropskou komisí uznány jako
integrované výrobní zařízení nebo otevřená továrna na polovodiče podle čl. 13 až 15
nařízení (EU) 2023/1781 (Akt o čipech),
t)
stavby infrastruktury pro vodní dopravu,
u) stavby nových zdravotnických zařízení za účelem zajištění poskytování lůžkové péče
s předpokládanou kapacitou nad 1 500 lůžek,
v) stavby spaloven nebezpečného odpadu,
w) deponie produktů po spalování uhlí nebo jiné deponie certifikovaných výrobků určené pro
redeponizaci a kaskádové využití jako zdroje stavebních surovin a kritických či
strategických surovin podle nařízení Evropského parlamentu a Rady (EU) 2024/1252,
včetně souvisejících technologických zařízení pro těžbu, separaci, extrakci a úpravu těchto
materiálů.“.
690. V příloze č. 3 se dosavadní text označuje jako odstavec 1 a doplňuje se odstavec 2, který
zní:
„(2) Dále se pro účely tohoto zákona vyhrazenými stavbami rozumí stavby a záměry
s vyhrazenými stavbami související.“.
691. V příloze č. 5 odst. 1 se na konci textu písmene b) doplňují slova „a jejího rozvoje“.
692. V příloze č. 6 části I. odst. 1 písm. a) se slova „zastavitelných ploch, transformačních“
zrušují.
693. V příloze č. 6 části I. odst. 2 písm. a) se za slovo „vymezení“ vkládají slova „ploch
a koridorů“.
694. V příloze č. 6 části I. odst. 2 písm. d) se slova „vymezení definic“ nahrazují slovem
„definice“.
695. V příloze č. 6 části I. odst. 3 úvodní části ustanovení se za slovo „plánu“ vkládají slova
„má formu prostorových dat a“.
696. V příloze č. 6 části I. odst. 4 větě první se za slovo „Výkresy“ vkládají slova „ , které jsou
součástí“ a slova „se vydávají“ se nahrazují slovy „ , se zpracovávají nad mapovým
podkladem“.
697. V příloze č. 6 části II. odst. 1 písm. e) se slova „zprávou o uplatňování nebo zadáním
změny nebo požadavku podle § 71 odst. 1 písm. h)“ zrušují.
698. V příloze č. 6 části II. odstavec 4 zní:
„(4) Odůvodnění územního rozvojového plánu může být doplněno grafickou částí.“.
699. V příloze č. 7 části I. odst. 1 písm. c) a g) se slovo „vymezení“ zrušuje.
700. V příloze č. 7 části I. odst. 1 písm. d) se slova „zastavitelné plochy, transformační“
zrušují.
701. V příloze č. 7 části I. odst. 1 písm. e) se slova „zastavitelných ploch, transformačních“
zrušují.
702. V příloze č. 7 části I. odst. 1 písm. g) se za slovo „koridorů“ vkládají slova „zelené
infrastruktury, zejména“.
703. V příloze č. 7 části I. odst. 2 písm. c) se slova „je-li to účelné,“ zrušují.
704. V příloze č. 7 části I. odst. 2 písm. d) se slova „vymezení definic“ nahrazují slovem
„definici“.
705. V příloze č. 7 části I. odst. 3 úvodní části ustanovení se za slovo „rozvoje“ vkládají slova
„má formu prostorových dat a“.
706. V příloze č. 7 části I. odst. 3 písm. b) se za slovo „včetně“ vkládají slova „zelené
infrastruktury a“ a slova „a územního systému ekologické stability nadregionálního
a regionálního významu“ se zrušují.
707. V příloze č. 7 části I. odst. 4 větě první se slova „se vydávají“ nahrazují slovy „ , které
jsou součástí grafické části, se zpracovávají nad mapovým podkladem“.
708. V příloze č. 7 části II. odst. 1 písm. e) se slova „ , zprávou o uplatňování nebo zadáním
změny“ zrušují.
709. V příloze č. 7 části II. odstavec 4 zní:
„(4) Odůvodnění zásad územního rozvoje může být doplněno grafickou částí.“.
710. V příloze č. 8 části I. odst. 1 písm. a), příloze č. 8 části I. odst. 3 písm. a) bodě 2 a příloze
č. 8 části I. odst. 3 písm. b) bodě 1 se slovo „zastavěného“ nahrazuje slovem
„zastavitelného“.
711. V příloze č. 8 části I. odst. 1 se za písmeno e) vkládá nové písmeno f), které zní:
„f) požadavky na rozvoj, zachování nebo změnu charakteru území,“.
Dosavadní písmena f) až i) se označují jako písmena g) až j).
712. V příloze č. 8 části I. odst. 1 písm. g) se slova „vymezených ploch s rozdílným způsobem
využití“ nahrazují slovem „území“.
713. V příloze č. 8 části I. odst. 1 písm. h) se za slovo „státu“ vkládají slova „ , ploch těžby“.
714. V příloze č. 8 části I. odst. 1 písm. j) se slova „hlavního města Prahy“ nahrazují slovem
„obce“.
715. V příloze č. 8 části I. odst. 2 se písmeno b) zrušuje.
Dosavadní písmena c) až k) se označují jako písmena b) až j).
716. V příloze č. 8 části I. odst. 2 písm. j) se slova „vymezení definic“ nahrazují slovem
„definici“.
717. V příloze č. 8 části I. odst. 3 úvodní části ustanovení se za slovo „plánu“ vkládají slova
„má formu prostorových dat a“.
718. V příloze č. 8 části I. odst. 3 písm. a) úvodní části ustanovení se za slovo „obsahuje“
vkládá slovo „zejména“.
719. V příloze č. 8 části I. odst. 3 písm. a) bodě 3 se slova „ , transformačních ploch“ a slova
„v krajině“ zrušují.
720. V příloze č. 8 části I. odst. 3 písm. a) se bod 4 zrušuje.
Dosavadní body 5 až 7 se označují jako body 4 až 6.
721. V příloze č. 8 části I. odst. 3 písm. b) se na konci úvodní části ustanovení doplňuje slovo
„zejména“.
722. V příloze č. 8 části I. odst. 3 písm. b) bodě 3 se za slovo „ploch“ vkládají slova
„ , nestavebních ploch“, slovo „transformačních“ se zrušuje a na konci textu bodu se
doplňuje slovo „změn“.
723. V příloze č. 8 části I. odst. 3 písm. b) bodě 4 se slovo „vymezení“, slova „územního
systému ekologické stability a vymezení“ a slova „v krajině“ zrušují.
724. V příloze č. 8 části I. odst. 3 písm. b) bodě 5 se slovo „vymezení“ zrušuje.
725. V příloze č. 8 části I. odst. 3 písm. b) bodě 6 se slova „s rozdílným způsobem využití“
nahrazují slovy „využití území a prostorového uspořádání“.
726. V příloze č. 8 části I. odst. 3 písm. b) bodě 8 se slova „a hranici zastavitelného území“
zrušují.
727. V příloze č. 8 části I. odst. 3 písm. b) bodě 9 se slova „vyznačení lokalit a zastavitelného
území“ nahrazují slovy „vymezení ploch těžby“.
728. V příloze č. 8 části I. odst. 4 se slova „urbanistickou koncepci, koncepci uspořádání
krajiny a koncepci veřejné infrastruktury zpracovat v samostatných výkresech“ nahrazují
slovy „hlavní výkres rozdělit do samostatných výkresů“.
729. V příloze č. 8 části I. odst. 5 větě první se slova „ , které jsou součástí“ zrušují a slova
„a vydávají se v měřítku 1 : 5 000“ se zrušují.
730. V příloze č. 8 části I. odst. 7 se slova „a vydávají“ nahrazují slovem „nebo“.
731. V příloze č. 8 části II. odst. 1 písm. e) se slova „zprávou o uplatňování nebo zadáním
změny,“ zrušují.
732. V příloze č. 8 části II. odst. 1 se písmeno k) zrušuje.
Dosavadní písmena l) až n) se označují jako písmena k) až m).
733. V příloze č. 8 části II. odst. 4 úvodní části ustanovení se slova „Grafická část odůvodnění
územního plánu“ nahrazují slovy „Odůvodnění územního plánu může být doplněno
grafickou částí, která“.
734. V příloze č. 8 části II. odst. 4 se písmeno a) zrušuje.
Dosavadní písmena b) a c) se označují jako písmena a) a b).
735. V příloze č. 9 části I. odst. 1 se na konci písmene b) čárka nahrazuje tečkou a písmena c)
až e) se zrušují.
736. V příloze č. 9 části I. se na začátek odstavce 2 vkládají nová písmena a) až c), která znějí:
„a) podrobné podmínky pro umístění a prostorové uspořádání staveb,
b) podrobné podmínky pro umístění a prostorové uspořádání staveb veřejné infrastruktury,
c) podrobné podmínky pro ochranu hodnot, charakteru území a krajinného rázu,“.
Dosavadní písmena a) až k) se označují jako písmena d) až n).
737. V příloze č. 9 části I. odst. 3 úvodní části ustanovení se za slovo „plánu“ vkládají slova
„má formu prostorových dat a“.
738. V příloze č. 9 části I. odst. 4 se slova „graficky vyjádřitelné podmínky umístění
a prostorového uspořádání staveb, včetně jejich napojení na veřejnou dopravní
a technickou infrastrukturu, zpracovat v samostatných výkresech“ nahrazují slovy
„hlavní výkres rozdělit do samostatných výkresů“.
739. V příloze č. 9 části I. odst. 5 větě první se slova „ , které jsou součástí“ a slova
„a vydávají“ zrušují.
740. V příloze č. 9 části II. odst. 1 písm. e) se slova „nebo zadáním změny“ zrušují.
741. V příloze č. 9 části II. odst. 4 úvodní části ustanovení se slova „Grafická část odůvodnění
regulačního plánu“ nahrazují slovy „Odůvodnění regulačního plánu může být doplněno
grafickou částí, která“.
742. V příloze č. 9 části II. odst. 4 se písmeno a) zrušuje.
Dosavadní písmena b) a c) se označují jako písmena a) a b).
Čl. II
Přechodná ustanovení
Přechodná ustanovení k ústředním orgánům
1. Úřad rozvoje území České republiky (dále jen „Úřad“) vzniká a svou působnost podle
zákona č. 283/2021 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona začíná
vykonávat dnem 1. ledna 2027. Návrh první systemizace a ji provádějící organizační struktury
Úřadu předloží státní tajemník v Ministerstvu pro místní rozvoj do 30 dnů ode dne vyhlášení
tohoto zákona.
2. Dopravní a energetický stavební úřad a Ústav územního rozvoje zanikají dnem
31. prosince 2026 a jejich působnost, majetek České republiky, ke kterému měly ke dni
31. prosince 2026 příslušnost hospodaření, aktiva, závazky a další pasiva, která jim příslušela
ke dni 31. prosince 2026, a práva a povinnosti z jejich právních vztahů, přechází dnem vzniku
Úřadu na Úřad. Peněžní prostředky na účtech podle § 45 odst. 6 rozpočtových pravidel, se
kterými hospodaří Dopravní a energetický stavební úřad a Ústav územního rozvoje ke dni
31. prosince 2026, se převádějí na účet cizích prostředků vedený Ministerstvem pro místní
rozvoj, které je bezodkladně po vzniku Úřadu převede na účet Úřadu. Nároky
z nespotřebovaných výdajů těchto organizačních složek státu za předcházející roky se
přesouvají ke dni vzniku Úřadu na Úřad. Dosavadní územní pracoviště Dopravního
a energetického stavebního úřadu se dnem vzniku Úřadu stávají detašovanými územními
pracovišti Úřadu.
3. Výkon práv a povinností z pracovněprávních vztahů zaměstnanců Dopravního
a energetického stavebního úřadu a Ústavu územního rozvoje přechází podle § 338 až 345a
zákoníku práce dnem vzniku Úřadu na Úřad; body 16 až 18 těchto přechodných ustanovení
platí pro přecházející zaměstnance obdobně.
4. Působnosti Ministerstva pro místní rozvoj, Ministerstva dopravy a Ministerstva
hospodářství jako stavebních úřadů a působnost Ministerstva pro místní rozvoj jako orgánu
územního plánování přechází dnem vzniku Úřadu na Úřad.
5. Výkon práv a povinností vyplývajících z pracovněprávních vztahů zaměstnanců České
republiky zařazených v Ministerstvu pro místní rozvoj, Ministerstvu dopravy, Ministerstvu
hospodářství nebo v dotčených orgánech, kteří ke dni předcházejícímu dni vzniku Úřadu
převážně zajišťují výkon působnosti, která podle tohoto zákona přechází na Úřad, přechází
podle § 338 až 345a zákoníku práce k 1. lednu 2027 na Úřad; body 16 až 18 těchto přechodných
ustanovení platí pro přecházející zaměstnance obdobně.
6. Ministerstvo pro místní rozvoj, Ministerstvo dopravy a Ministerstvo hospodářství
předají Úřadu ke dni vzniku Úřadu dokumenty, spisy a jimi provozované informační systémy,
které se vztahují k působnosti, která přechází na Úřad.
7. Příslušnost k hospodaření s majetkem státu užívaným Ministerstvem pro místní rozvoj,
Ministerstvem dopravy a Ministerstvem hospodářství, který převážně slouží k výkonu
působnosti, která podle tohoto zákona přechází na Úřad, přechází dnem vzniku Úřadu na Úřad.
8. Rozpočtové prostředky kapitol Ministerstvo pro místní rozvoj, Ministerstvo dopravy,
Ministerstvo hospodářství a kapitol zahrnujících činnost dotčených orgánů, včetně nároků
z nespotřebovaných výdajů za předcházející léta, které souvisejí s výkonem působnosti
přecházející na Úřad, přecházejí ke dni vzniku Úřadu na Úřad.
Přechodná ustanovení k územním orgánům
9. Úřady rozvoje území krajů a jejich územní pracoviště vznikají a svou působnost podle
zákona č. 283/2021 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona začínají
vykonávat dnem 1. ledna 2028. Návrhy systemizací a je provádějících organizačních struktur
úřadů rozvoje území krajů předloží předseda Úřadu v termínu stanoveném pro předložení
návrhů systemizace pro rok 2028.
10. Krajské stavební úřady a obecní stavební úřady zanikají dnem 31. prosince 2027
a jejich působnost přechází dnem vzniku úřadů rozvoje území krajů na příslušné úřady rozvoje
území krajů a jejich územní pracoviště.
11. Působnost krajských úřadů jako nadřízených orgánů územního plánování a jejich
působnost ve věcech územního plánování, které mají podle zákona č. 283/2021 Sb., ve znění
účinném ode dne nabytí účinnosti tohoto zákona vykonávat úřady rozvoje území krajů, přechází
dnem vzniku působnosti úřadů rozvoje území krajů na příslušný úřad rozvoje území kraje; do
té doby vykonávají tuto působnost krajské úřady v přenesené působnosti. V ostatních případech
přechází působnost krajských úřadů v oblasti územního plánování dnem nabytí účinnosti tohoto
zákona na příslušný kraj.
12. Působnost obecních úřadů obcí s rozšířenou působností při pořizování územního plánu,
regulačního plánu a územního opatření na žádost jiné obce a při vymezování zastavěného
území, přechází dnem vzniku působnosti úřadů rozvoje území krajů na příslušný úřad rozvoje
území kraje, není-li dohodnuto podle § 47 odst. 1 jinak; do té doby vykonávají tuto působnost
obecní úřady obcí s rozšířenou působností v přenesené působnosti. V ostatních případech
přechází působnost obecních úřadů v oblasti územního plánování dnem nabytí účinnosti tohoto
zákona na příslušnou obec.
13. Předseda Úřadu vyhlásí výběrová řízení a vybere ředitele úřadů rozvoje území krajů,
případně i vedoucí územních pracovišť přede dnem vzniku úřadů rozvoje území krajů. Takto
vybraní zaměstnanci jsou do dne vzniku úřadů rozvoje území krajů organizačně zařazeni
v Úřadu a podílí se na přípravě zahájení činnosti úřadů rozvoje území krajů a jejich územních
pracovišť. Po tuto dobu může být jejich pracovněprávní vztah sjednán v souběhu s jejich
dosavadním pracovněprávním vztahem.
14. Práva a povinnosti vyplývající z pracovněprávních vztahů zaměstnanců krajů a obcí,
kteří ke dni předcházejícímu dni vzniku úřadů rozvoje území krajů převážně zajišťují výkon
působnosti, která podle tohoto zákona přechází na úřady rozvoje území krajů, přechází podle
§ 338 až 345a zákoníku práce k 1. lednu 2028 z těchto krajů a obcí na stát. Dosavadní
zaměstnanci krajů se stávají zaměstnanci s místem výkonu práce v úřadu rozvoje území kraje
v sídle kraje, z něhož práva a povinnosti z pracovněprávního vztahu přecházejí. Dosavadní
zaměstnanci obcí a městských obvodů a městských částí územně členěných statutárních měst
se stávají zaměstnanci s místem výkonu práce v územním pracovišti úřadu rozvoje území kraje
v sídle obce s rozšířenou působností, v jejímž správním obvodu se tato obec nachází. Obdobně
se postupuje v případě zaměstnanců úřadů městských obvodů a městských částí územně
členěných statutárních měst a hlavního města Prahy a městských částí hlavního města Prahy.
15. Kvalifikační požadavky podle tohoto zákona splňuje ten, kdo ke dni nabytí účinnosti
tohoto zákona splňoval kvalifikační požadavky podle dosavadní právní úpravy.
16. Platový tarif zaměstnancům stavebního úřadu nebo orgánu územního plánování, jejichž
pracovněprávní vztah přešel z krajů a obcí na stát, přísluší nejméně ve stejné výši, v jaké
příslušel ke dni bezprostředně předcházejícímu před tímto přechodem. Zařazení zaměstnanců
stavebního úřadu nebo orgánu územního plánování, jejichž pracovněprávní vztah přešel z krajů
a obcí na stát, do platové třídy a platového stupně se nemění, nejde-li o případy, kdy ke dni
vzniku pracovněprávního vztahu ke státu dosavadní zaměstnanec splnil podmínky pro zařazení
do jiné platové třídy nebo pro postup do vyššího platového stupně. Doba výkonu práce
zaměstnanců pro kraje a obce na úseku stavebního řízení nebo územního plánování se těmto
zaměstnancům započte pro účely stanovení platového stupně v plném rozsahu. Obdobně se
postupuje v případě dosavadních zaměstnanců úřadů městských obvodů a městských částí
územně členěných statutárních měst a hlavního města Prahy a městských částí hlavního města
Prahy.
17. Osobní příplatek zaměstnancům stavebního úřadu nebo orgánu územního plánování,
jejichž pracovněprávní vztah přešel z krajů a obcí na stát, přísluší nejméně ve stejné výši, v jaké
příslušel ke dni bezprostředně předcházejícímu před tímto přechodem. Pokud by však platový
tarif zaměstnanců po přechodu pracovněprávního vztahu byl vyšší, než platový tarif příslušející
ke dni bezprostředně předcházejícímu před tímto přechodem, přísluší osobní příplatek v takové
výši, aby úhrn platového tarifu a osobního příplatku nebyl vyšší, než úhrn platového tarifu
a osobního příplatku, který zaměstnancům příslušel ke dni bezprostředně předcházejícímu
tomuto přechodu; osobní příplatek se však nesníží o částku, o kterou se zvýšil platový tarif
zaměstnance v důsledku zařazení do jiné platové třídy, postupu do vyššího platového stupně
nebo změny výše platových tarifů nařízením vlády. Obdobně se postupuje v případě
dosavadních zaměstnanců úřadů městských obvodů a městských částí územně členěných
statutárních měst a hlavního města Prahy a městských částí hlavního města Prahy.
18. Přísluší-li zaměstnanci stavebního úřadu nebo orgánu územního plánování, jehož
pracovněprávní vztah přešel z kraje nebo obce na stát, zvláštní příplatek, poskytuje se mu
nejméně ve stejné výši, v jaké mu příslušel ke dni bezprostředně předcházejícímu tomuto
přechodu, a to po dobu 1 roku. Příplatek za vedení poskytovaný vedoucímu zaměstnanci
stavebního úřadu nebo orgánu územního plánování, jehož pracovněprávní vztah přešel z kraje
nebo obce na stát, a který se mu poskytuje ke dni přechodu, přísluší nejméně ve stejné výši, v
jaké mu příslušel ke dni bezprostředně předcházejícímu, a to po dobu 1 roku. Podle věty první
a druhé se obdobně postupuje v případě dosavadních zaměstnanců úřadů městských obvodů a
městských částí územně členěných statutárních měst a hlavního města Prahy a městských částí
hlavního města Prahy.
19. Kraje, obce a hlavní město Praha předají ke dni vzniku působnosti úřadů rozvoje území
krajů dokumenty a spisy, které se týkají výkonu působnosti stavebního úřadu, příslušnému
úřadu rozvoje území kraje. Při provedení spisové rozluky v souvislosti s činnostmi, které
přecházejí na úřady rozvoje území, se postupuje podle § 68a zákona o archivnictví a spisové
službě.
20. Prostory spisoven, úřadoven a sídel stavebních úřadů se ponechají podle potřeby
příslušného úřadu rozvoje území kraje na stávajících místech a budou využívány k výkonu
působnosti podle tohoto zákona až po dobu 5 let ode dne nabytí účinnosti tohoto zákona za
náhradu placenou kraji nebo obci ve výši obvyklého nájmu a nákladů za služby souvisejících
s nájmem. Povinnost zveřejnění záměru pronájmu podle zákona o obcích se nepoužije.
Přechodná ustanovení k územnímu plánování
21. Řízení a postupy zahájené a neskončené přede dnem nabytí účinnosti tohoto zákona se
dokončí podle zákona č. 283/2021 Sb., ve znění účinném ode dne nabytí účinnosti tohoto
zákona, není-li stanoveno jinak.
22. Činnosti při pořizování nástrojů územního plánování provedené přede dnem nabytí
účinnosti tohoto zákona se posuzují podle dosavadních právních předpisů. Ustanovení § 72
odst. 3 věty druhé, ve znění účinném ode dne nabytí účinnosti tohoto zákona, se použije i pro
územně plánovací dokumentace a jejich změny vydané přede dnem nabytí účinnosti tohoto
zákona. Bylo-li přede dnem nabytí účinnosti tohoto zákona oznámeno společné jednání,
dokončí se podle dosavadních právních předpisů. Bylo-li přede dnem nabytí účinnosti tohoto
zákona zahájeno veřejné projednání návrhu územně plánovací dokumentace nebo její změny,
projednávání návrhu se dokončí a územně plánovací dokumentace se schválí a vydá podle
dosavadních právních předpisů. V ostatních případech zajistí pořizovatel úpravu návrhu
územně plánovací dokumentace v souladu s tímto zákonem.
23. Pořizovatel, na kterého přešla působnost podle tohoto zákona, naváže na aktuální stav
pořizování nástrojů územního plánování a pokračuje v něm podle tohoto zákona. O rozporech,
které nebyly vyřešeny do 31. prosince 2026, rozhodne Úřad.
24. Tam, kde dosavadní právní předpisy a nástroje územního plánování používají pojmy
zastavěné území nebo nezastavěné území, rozumí se tím zastavitelné území a nezastavitelné
území podle tohoto zákona. Tam, kde dosavadní právní předpisy a nástroje územního plánování
používají pojmy zastavěný stavební pozemek nebo pozemek rodinného domu, rozumí se tím
pozemek zázemí stavby. Příslušní pořizovatelé provedou tyto změny v nástrojích územního
plánování bez řízení o jejich návrhu do 1 roku ode dne nabytí účinnosti tohoto zákona.
25. Nástroje územního plánování, které ke dni nabytí účinnosti tohoto zákona nebyly
převedeny do jednotného standardu, převedou příslušní pořizovatelé do jednotného standardu
bez řízení o jejich návrhu do 31. prosince 2027. Pokud již bylo zahájeno pořizování těchto
změn, které nebylo ke dni nabytí účinnosti tohoto zákona dokončeno, proces pořizování změn
se ukončí; to neplatí v případech, kdy jsou s převodem do jednotného standardu spojeny i jiné
změny. Povinnost převedení nástrojů územního plánování podle tohoto bodu neplatí na nástroje
pořízené podle právních předpisů účinných přede dnem nabytí účinnosti zákona č. 183/2006
Sb., o územním plánování a stavebním řádu (stavební zákon).
26. Při nejbližší změně územně plánovací dokumentace, jejíž pořizování bude zahájeno po
dni nabytí účinnosti tohoto zákona, se do územně plánovací dokumentace vyznačí jako plochy
těžby stanovené dobývací prostory podle horního zákona. V případě rozporu rozhodnutí
o stanovení dobývacího prostoru s územně plánovací dokumentací se k části územně plánovací
dokumentace, která je v rozporu s rozhodnutím o stanovení dobývacího prostoru, nepřihlíží.
27. Funkce určeného zastupitele zaniká dnem nabytí účinnosti tohoto zákona, pokud
nástroj územního plánování pořizuje pro sebe obec sama.
28. Projednávání zprávy o uplatňování územně plánovací dokumentace nebo návrhu zadání
změny územně plánovací dokumentace, zahájené přede dnem nabytí účinnosti tohoto zákona,
pořizovatel ukončí.
29. Náhrada za snížení hodnoty v území podle tohoto zákona náleží oprávněné osobě až za
snížení hodnoty v území způsobené vydáním nebo změnou územně plánovací dokumentace
nebo stavební uzávěry po dní nabytí účinnosti tohoto zákona.
30. Pořizovatelé územně analytických podkladů podle dosavadních právních předpisů
zašlou jimi pořízené územně analytické podklady včetně jejich zdrojových databází do
30. června 2027 Úřadu. Úřad převede územně analytické podklady podle věty první do jednotné
struktury a formátu a vloží je do 31. prosince 2027 do národního geoportálu územního
plánování.
Přechodné ustanovení k hmotnému právu
31. Požadavky na výstavbu a další ustanovení části čtvrté, ve znění účinném ode dne nabytí
účinnosti tohoto zákona, se použijí ode dne nabytí účinnosti tohoto zákona. Pro povolení
záměru v již zahájených řízeních však postačí splnění požadavků na výstavbu podle zákona
č. 283/2021 Sb. a jeho prováděcích právních předpisů, ve znění účinném přede dnem nabytí
účinnosti tohoto zákona, je-li to pro stavebníka příznivější.
Přechodná ustanovení ke stavebnímu řádu, kontrole a přestupkům
32. Řízení a postupy zahájené a neskončené přede dnem nabytí účinnosti tohoto zákona se
dokončí podle zákona č. 283/2021 Sb., ve znění účinném ode dne nabytí účinnosti tohoto
zákona, není-li stanoveno jinak.
33. Řízení a postupy zahájené a neskončené do dne nabytí účinnosti tohoto zákona, k nimž
je podle zákona č. 283/2021 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona,
příslušný Úřad, převezme a dokončí od svého vzniku Úřad; to platí i pro odvolací a přezkumné
řízení a pro posuzování veřejných zájmů podle jiných zákonů, k němuž přejde působnost z
dotčených orgánů na Úřad, není-li dále stanoveno jinak.
34. Závazná stanoviska, stanoviska, souhlasy, vyjádření, popřípadě pravomocná
rozhodnutí dotčených orgánů podle jiných zákonů vydaná přede dnem vzniku Úřadu ve věcech,
v nichž přechází působnost na stavební úřad podle § 1b odst. 2, mají v řízení vedeném Úřadem
právní význam a účinky podle dosavadních právních předpisů a považují se za podklady pro
vydání rozhodnutí podle zákona č. 283/2021 Sb., ve znění účinném ode dne nabytí účinnosti
tohoto zákona. Předloží-li stavebník závazné stanovisko nebo rozhodnutí, Úřad jimi chráněné
veřejné zájmy znovu neposuzuje. Pro jiné stavební úřady podle § 35 platí věta první obdobně.
35. Řízení a postupy zahájené a neskončené do dne vzniku úřadů rozvoje území krajů,
k nimž je příslušný úřad rozvoje území kraje nebo jeho územní pracoviště, ode dne vzniku
úřadů rozvoje území krajů převezme a dokončí příslušný úřad rozvoje území kraje nebo jeho
územní pracoviště; to platí i pro odvolací a přezkumné řízení a pro posuzování veřejných zájmů
podle jiných zákonů, k němuž přejde působnost z dotčených orgánů na stavební úřady, není-li
dále stanoveno jinak. Do dne vzniku úřadů rozvoje území krajů pokračují v těchto řízeních
a postupech krajské stavební úřady, obecní stavební úřady a dotčené orgány příslušné podle
dosavadních právních předpisů, a to podle zákona č. 283/2021 Sb., ve znění účinném ode dne
nabytí účinnosti tohoto zákona, s výjimkou § 1b, části druhé, § 176 a § 178 odst. 4 písm. b), a
dále podle části druhé, § 176, § 178 odst. 4 písm. b) a § 304 odst. 2 zákona č. 283/2021 Sb., ve
znění účinném přede dnem nabytí účinnosti tohoto zákona.
36. Závazná stanoviska, stanoviska, souhlasy, vyjádření, popřípadě pravomocná
rozhodnutí dotčených orgánů podle jiných zákonů vydaná přede dnem vzniku úřadů rozvoje
území krajů ve věcech, v nichž přechází působnost na stavební úřad podle § 1b odst. 2, mají
v řízení vedeném úřadem rozvoje území kraje nebo jeho územním pracovištěm právní význam
a účinky podle dosavadních právních předpisů a považují za podklady pro vydání rozhodnutí
podle zákona č. 283/2021 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona.
Předloží-li stavebník závazné stanovisko nebo rozhodnutí, úřad rozvoje území kraje nebo jeho
územní pracoviště jimi chráněné veřejné zájmy znovu neposuzuje.
37. Přezkum závazného stanoviska prováděný správním orgánem nadřízeným správnímu
orgánu příslušnému k vydání závazného stanoviska podle § 149 odst. 7 a 8 správního řádu ve
věcech, v nichž přechází působnost na stavební úřad podle § 1b odst. 2, zahájený a neskončený
do dne přechodu působnosti na příslušný stavební úřad podle § 1b odst. 2, se dnem tohoto
přechodu působnosti zastavuje; probíhá-li odvolací řízení, posouzení daného veřejného zájmu
dokončí stavební úřad, který rozhoduje o odvolání.
38. Žádost o vydání jednotného environmentálního stanoviska pro záměr, který podléhá
povolení podle stavebního zákona, včetně žádosti stavebního úřadu podle § 184 odst. 3, podaná
přede dnem vzniku příslušného úřadu rozvoje území, se posoudí podle dosavadních právních
předpisů; to neplatí pro žádosti, na základě nichž nebylo vydáno jednotné environmentální
stanovisko do 31. prosince 2027.
39. Zákon č. 148/2023 Sb., o jednotném environmentálním stanovisku, se ode dne 1. ledna
2027 nepoužije na žádost o vydání jednotného environmentálního stanoviska pro záměr, který
podléhá povolení podle stavebního zákona a u něhož je příslušným stavebním úřadem Úřad
rozvoje území České republiky, podanou po dni nabytí účinnosti tohoto zákona.
40. Lhůty nebo doby uvedené v § 178 odst. 1 větě druhé, § 178 odst. 2, § 181 odst. 5, § 188
odst. 1, § 188 odst. 5 a § 190a odst. 1 začínají běžet nejdříve ode dne nabytí účinnosti tohoto
zákona. Ustanovení § 179 odst. 2, § 179a, § 195a a § 195b se uplatní až od uplynutí třicátého
dne ode dne nabytí účinnosti tohoto zákona, ale možnost vydání nového vyjádření nebo
závazného stanoviska nebo možnost zahájení přezkumného řízení nebo obnovy řízení nebo
rozhodnutí v něm neskončí později, než by skončila podle dosavadních právních předpisů.
Došlo-li přede dnem nabytí účinnosti tohoto zákona k prodloužení lhůty pro vydání vyjádření
nebo závazného stanoviska podle § 178 odst. 2 nebo § 181 odst. 1 zákona č. 283/2021 Sb., ve
znění účinném přede dnem nabytí účinnosti tohoto zákona, platí takto prodloužené lhůty i po
dni nabytí účinnosti tohoto zákona.
41. Odvolací řízení proti rozhodnutím stavebních úřadů zahájená a neskončená do dne
nabytí účinnosti tohoto zákona ve věcech, v nichž podle zákona č. 283/2021 Sb., ve znění
účinném ode dne nabytí účinnosti tohoto zákona není odvolání přípustné, se dokončí.
42. Dokumentace a projektové dokumentace zpracované podle dosavadních právních
předpisů lze předložit jako součást žádosti o povolení záměru nebo odstranění stavby podle
zákona č. 283/2021 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona do 3 let ode
dne nabytí účinnosti tohoto zákona. Stavební úřad přezkoumává dokumentaci podle věty první
podle dosavadních právních předpisů; pro povolení záměru však postačí splnění požadavků na
výstavbu podle zákona č. 283/2021 Sb., ve znění účinném ode dne nabytí účinnosti tohoto
zákona.
43. Ustanovení § 194 odst. 3 se použije pouze ve vztahu k zastavitelnému území, koridoru
pro stavební záměr nebo ploše těžby, které již byly v souladu se stanoviskem orgánu ochrany
přírody vymezeny v územně plánovací dokumentaci vydané po 1. lednu 2007 jako zastavitelné
území, koridor pro stavební záměr nebo plocha těžby. Ustanovení § 194 odst. 4 se použije pouze
ve vztahu k zastavitelnému území, koridoru pro stavební záměr nebo ploše těžby vymezeným
v územně plánovací dokumentaci, k jejímuž návrhu bylo vydáno stanovisko orgánu ochrany
zemědělského půdního fondu podle § 5 zákona č. 334/1992 Sb. ode dne nabytí účinnosti zákona
č. 41/2015 Sb., kterým se mění zákon č. 334/1992 Sb., o ochraně zemědělského půdního fondu,
a zákon č. 388/1991 Sb., o Státním fondu životního prostředí České republiky; to platí obdobně
i pro zastavitelné území, koridory pro stavební záměry a plochy těžby vymezené změnou
územně plánovací dokumentace, k jejímuž návrhu bylo takové stanovisko vydáno od tohoto
dne.
44. O změně rozhodnutí vydaného přede dnem nabytí účinnosti tohoto zákona jiným
orgánem než stavebním úřadem ve věcech, k nimž je po nabytí účinnosti tohoto zákona
příslušný stavební úřad, lze na žádost stavebníka rozhodnout v rámci řízení o povolení záměru
podle tohoto zákona, pokud ke změně rozhodnutí dochází v souvislosti s činností vyžadující
povolení záměru podle stavebního zákona. Žádost a dokumentace musí v takovém případě
obsahovat náležitosti pro změnu dříve vydaného rozhodnutí.
45. Osvobození od správních poplatků podle zákona o správních poplatcích, pokud
stavební úřad o žádosti nerozhodne ve lhůtě podle stavebního zákona, se použije až v řízeních
zahájených po dni nabytí účinnosti tohoto zákona.
46. Řízení a postupy zahájené přede dnem nabytí účinnosti tohoto zákona, které se týkají
záměrů, u nichž není vyžadováno povolení záměru, stavební úřad usnesením zastaví; proti
tomuto usnesení se nelze odvolat.
47. Ustanovení § 193 odst. 6 a § 224 odst. 6 se použije i na posuzování žádosti podané
přede dnem nabytí účinnosti tohoto zákona. Ustanovení § 193 odst. 4 věty druhé se použije až
pro řízení zahájená po uplynutí 3 let ode dne nabytí účinnosti tohoto zákona.
48. Neskončené územní řízení, opakované územní řízení a další řízení nebo postupy podle
zákona č. 183/2006 Sb. nebo podle zákona č. 50/1976 Sb. se dokončí jako řízení o povolení
záměru nebo jiné odpovídající řízení nebo postup podle zákona č. 283/2021 Sb., ve znění
účinném ode dne nabytí účinnosti tohoto zákona. Stavební úřad poučí stavebníka o případné
potřebě doplnění podkladů pro rozhodnutí a umožní mu je doplnit. Ustanovení § 329 a § 330
odst. 6 až 8 se uplatní obdobně.
Přechodné ustanovení k informačním systémům
49. Do uplynutí přechodného období podle § 334b lze pro výkon působnosti podle tohoto
zákona použít vedle informačních systémů podle tohoto zákona i jiné informační systémy
veřejné správy a činit podání, vést evidenci, doručovat a předávat podklady i prostřednictvím
dosavadních informačních systémů, datových schránek a jiných způsobů komunikace podle
správního řádu.
Přechodná ustanovení k soudnímu přezkumu
50. Řízení a postupy zahájené a neskončené přede dnem nabytí účinnosti tohoto zákona se
dokončí podle tohoto zákona, není-li stanoveno jinak.
51. Žalobu podanou přede dnem nabytí účinnosti tohoto zákona lze rozšířit podle § 306
odst. 2, ve znění účinném přede dnem nabytím účinnosti tohoto zákona.
52. Ustanovení § 308 odst. 1 se použije až pro žaloby a kasační stížnosti podané po dni
nabytí účinnosti tohoto zákona. Lhůta uvedená v § 308 odst. 2 začíná běžet ode dne nabytí
účinnosti tohoto zákona.
Přechodná ustanovení k právním předpisům
53. Do dne nabytí účinnosti nařízení vlády podle § 333 odst. 1, nejpozději však do
31. prosince 2027, se postupuje podle prováděcích právních předpisů zrušených tímto
zákonem.
54. Dosavadní vyhlášky Ministerstva pro místní rozvoj vydané podle § 333 odst. 1 zákona
č. 283/2021 Sb., ve znění účinném přede dnem nabytí účinnosti tohoto zákona, se do vydání
vyhlášek Úřadu podle § 333 odst. 2, nejpozději však do 31. prosince 2027, považují za vyhlášky
Úřadu podle § 333 odst. 2.
55. Podle vyhlášky č. 130/2024 Sb., o stanovení obecních stavebních úřadů, se postupuje
až do vzniku úřadů rozvoje území krajů podle tohoto zákona.
56. Změny pojmů podle § 12 písm. c) a h), ve znění účinném ode dne nabytí účinnosti
tohoto zákona, se pro účely § 194 a přílohy č. 1 a 2 stavebního zákona, § 12, 26, 37 a 44 zákona
o ochraně přírody a krajiny a § 4 a 9 zákona o ochraně zemědělského půdního fondu použijí již
od prvního dne měsíce následujícího po dni vyhlášení tohoto zákona.
ČÁST DRUHÁ
Změna zákona o zřízení ministerstev a jiných ústředních orgánů státní správy
 České republiky
Čl. III
Zákon č. 2/1969 Sb., o zřízení ministerstev a jiných ústředních orgánů státní správy České
republiky, ve znění zákona č. 34/1970 Sb., zákona č. 147/1970 Sb., zákona č. 125/1973 Sb.,
zákona č. 25/1976 Sb., zákona č. 118/1983 Sb., zákona č. 60/1988 Sb., zákona č. 37/1989 Sb.,
zákona č. 173/1989 Sb., zákonného opatření č. 9/1990 Sb., zákona č. 93/1990 Sb., zákona
č. 126/1990 Sb., zákona č. 203/1990 Sb., zákona č. 288/1990 Sb., zákonného opatření
č. 305/1990 Sb., zákona č. 575/1990 Sb., zákona č. 173/1991 Sb., zákona č. 283/1991 Sb.,
zákona č. 19/1992 Sb., zákona č. 23/1992 Sb., zákona č. 103/1992 Sb., zákona č. 167/1992 Sb.,
zákona č. 239/1992 Sb., zákonného opatření č. 350/1992 Sb., zákona č. 358/1992 Sb., zákona
č. 359/1992 Sb., zákona č. 474/1992 Sb., zákona č. 548/1992 Sb., zákona č. 21/1993 Sb.,
zákona č. 166/1993 Sb., zákona č. 285/1993 Sb., zákona č. 47/1994 Sb., zákona č. 89/1995 Sb.,
zákona č. 289/1995 Sb., zákona č. 135/1996 Sb., zákona č. 272/1996 Sb., zákona č. 152/1997
Sb., zákona č. 15/1998 Sb., zákona č. 148/1998 Sb., zákona č. 63/2000 Sb., zákona č. 130/2000
Sb., zákona č. 154/2000 Sb., zákona č. 204/2000 Sb., zákona č. 239/2000 Sb., zákona
č. 257/2000 Sb., zákona č. 258/2000 Sb., zákona č. 365/2000 Sb., zákona č. 458/2000 Sb.,
zákona č. 256/2001 Sb., zákona č. 13/2002 Sb., zákona č. 47/2002 Sb., zákona č. 219/2002 Sb.,
zákona č. 517/2002 Sb., zákona č. 62/2003 Sb., zákona č. 162/2003 Sb., zákona č. 18/2004 Sb.,
zákona č. 362/2004 Sb., zákona č. 421/2004 Sb., zákona č. 499/2004 Sb., zákona č. 501/2004
Sb., zákona č. 587/2004 Sb., zákona č. 95/2005 Sb., zákona č. 127/2005 Sb., zákona č. 290/2005
Sb., zákona č. 57/2006 Sb., zákona č. 70/2006 Sb., zákona č. 71/2006 Sb., zákona č. 179/2006
Sb., zákona č. 186/2006 Sb., zákona č. 189/2006 Sb., zákona č. 225/2006 Sb., zákona
č. 267/2006 Sb., zákona č. 110/2007 Sb., zákona č. 274/2008 Sb., zákona č. 297/2008 Sb.,
zákona č. 304/2008 Sb., zákona č. 295/2009 Sb., zákona č. 375/2011 Sb., zákona č. 275/2012
Sb., zákona č. 399/2012 Sb., zákona č. 64/2014 Sb., zákona č. 250/2014 Sb., zákona č. 205/2015
Sb., zákona č. 377/2015 Sb., zákona č. 188/2016 Sb., zákona č. 298/2016 Sb., zákona
č. 302/2016 Sb., zákona č. 319/2016 Sb., zákona č. 14/2017 Sb., zákona č. 24/2017 Sb., zákona
č. 59/2017 Sb., zákona č. 205/2017 Sb., zákona č. 246/2017 Sb., zákona č. 178/2019 Sb., zákona
č. 34/2021 Sb., zákona č. 88/2021 Sb., zákona č. 284/2021 Sb., zákona č. 326/2021 Sb., zákona
č. 362/2022 Sb., zákona č. 471/2022 Sb., zákona č. 152/2023 Sb., zákona č. 172/2023 Sb.,
zákona č. 178/2023 Sb., zákona č. 349/2023 Sb., zákona č. 464/2023 Sb., zákona č. 448/2024
Sb., zákona č. 453/2024 Sb., zákona č. 169/2025 Sb., zákona č. 220/2025 Sb., zákona
č. 232/2025 Sb. a zákona č. 329/2025 Sb., se mění takto:
1.
V § 1 bodu 9 se slova „průmyslu a obchodu“ nahrazují slovem „hospodářství“.
2.
V § 2 se na konci bodu 19 tečka nahrazuje čárkou a doplňuje se bod 20, který zní:
„20. Úřad rozvoje území České republiky.“.
3.
V § 13 odst. 1 až 5 se slova „průmyslu a obchodu“ nahrazují slovem „hospodářství“.
4.
V § 14 odst. 1 se slova „územního plánování a stavebního řádu, vyvlastnění,“ zrušují.
Čl. IV
Přechodná ustanovení
1. Dnem 1. ledna 2027 se Ministerstvo průmyslu a obchodu přejmenuje na Ministerstvo
hospodářství.
2. Odkazuje-li jiný právní předpis na Ministerstvo průmyslu a obchodu, rozumí se tím ode
dne 1. ledna 2027 Ministerstvo hospodářství.
ČÁST TŘETÍ
Změna zákona o požární ochraně
Čl. V
Zákon č. 133/1985 Sb., o požární ochraně, ve znění zákona č. 425/1990 Sb., zákona
č. 40/1994 Sb., zákona č. 203/1994 Sb., zákona č. 163/1998 Sb., zákona č. 71/2000 Sb., zákona
č. 237/2000 Sb., zákona č. 320/2002 Sb., zákona č. 413/2005 Sb., zákona č. 186/2006 Sb.,
zákona č. 267/2006 Sb., zákona č. 281/2009 Sb., zákona č. 341/2011 Sb., zákona č. 350/2011
Sb., zákona č. 350/2012 Sb., zákona č. 303/2013 Sb., zákonného opatření Senátu č. 344/2013
Sb., zákona č. 64/2014 Sb., zákona č. 320/2015 Sb., zákona č. 229/2016 Sb., zákona č. 225/2017
Sb., zákona č. 284/2021 Sb., zákona č. 374/2021 Sb., zákona č. 415/2021 Sb., zákona
č. 152/2023 Sb., zákona č. 54/2024 Sb. a zákona č. 292/2025 Sb., se mění takto:
1.
V § 24 odst. 1 písm. t) se za slovo „stanovisko“ vkládají slova „nebo vyjádření“.
2.
V § 24 se odstavec 3 zrušuje.
3.
Za § 26 se vkládá nový § 26a, který zní:
„§ 26a
Vláda stanoví nařízením technické podmínky požární ochrany pro navrhování, výstavbu
nebo užívání staveb, a to za účelem omezení rozvoje a šíření ohně a kouře ve stavbě, omezení
šíření požáru na sousední stavby, evakuace a umožnění účinného a bezpečného zásahu jednotek
požární ochrany. Pro podrobnější vymezení těchto podmínek lze využít hodnot a postupů
stanovených českou technickou normou.“.
4.
V § 31 odst. 1 písmeno b) zní:
„b) posuzováním
1. dokumentace pro povolení stavby, zařízení nebo udržovacích prací podle stavebního
zákona, včetně změn této dokumentace,
2. dokumentace pro provádění stavby,
3. dokumentace nebo jiného podkladu ke změně v účelu užívání stavby,“.
5.
V § 31 odst. 1 písm. c) se slovo „stanovisek“ nahrazuje slovy „závazných stanovisek nebo
vyjádření“.
6.
V § 31 odstavec 3 zní:
„(3) Výsledkem posuzování podkladů, dokumentace a ověřování splnění stanovených
požadavků podle odstavce 1 písm. b) a c) je
a) závazné stanovisko dotčeného orgánu na úseku požární ochrany u stavby podle § 39 odst.
1 písm. d),
b) vyjádření dotčeného orgánu na úseku požární ochrany u stavby podle § 39 odst. 1 písm. c),
které slouží jako podklad pro řízení nebo jiný postup vedený podle stavebního zákona.“.
7.
V § 31 odst. 6 úvodní části ustanovení se za slovo „změně“ vkládají slova „vyjádření
nebo“.
8.
V § 31 se doplňuje odstavec 7, který zní:
„(7) Při kontrolách podle odstavce 1 písm. a) a g) postupují orgány vykonávající státní
požární dozor podle kontrolního řádu.“.
9.
V § 40 se na konci odstavce 3 doplňuje věta „K zpracování požárně bezpečnostního řešení
pro stavbu kategorie I je dále oprávněna i osoba, která je autorizovaným inženýrem pro
obor pozemní stavby podle zvláštního právního předpisu12) a které k tomuto současně
byla udělena specializace v rámci tohoto oboru podle zvláštního právního předpisu12).“.
10.
V § 95 se věty druhá a třetí zrušují.
11.
V § 99 větě první a druhé se text „§ 24 odst. 3“ nahrazuje textem „§ 26a“.
12.
§ 102 zní:
„§ 102
Vláda na návrh Ministerstva a Úřadu rozvoje území České republiky vydá prováděcí právní
předpis k provedení § 26a.“.
Čl. VI
Přechodná ustanovení
1. Řízení a postupy zahájené přede dnem nabytí účinnosti tohoto zákona se dokončí podle
dosavadních právních předpisů.
2. Do nabytí účinnosti nařízení vlády podle § 26a, nejpozději však do 31. prosince 2028,
se postupuje v případě posouzení podmínek požární ochrany pro navrhování, výstavbu nebo
užívání staveb podle vyhlášky č. 23/2008 Sb., o technických podmínkách požární ochrany
staveb, ve znění pozdějších předpisů.
ČÁST ČTVRTÁ
Změna zákona o státní památkové péči
Čl. VII
Zákon č. 20/1987 Sb., o státní památkové péči, ve znění zákona č. 242/1992 Sb., zákona
č. 361/1999 Sb., zákona č. 122/2000 Sb., zákona č. 132/2000 Sb., zákona č. 146/2001 Sb.,
zákona č. 320/2002 Sb., zákona č. 18/2004 Sb., zákona č. 186/2004 Sb., zákona č. 1/2005 Sb.,
zákona č. 3/2005 Sb., zákona č. 240/2005 Sb., zákona č. 186/2006 Sb., zákona č. 203/2006 Sb.,
zákona č. 158/2007 Sb., zákona č. 124/2008 Sb., zákona č. 189/2008 Sb., zákona č. 307/2008
Sb., zákona č. 223/2009 Sb., zákona č. 227/2009 Sb., zákona č. 124/2011 Sb., zákona
č. 142/2012 Sb., zákona č. 303/2013 Sb., zákona č. 127/2016 Sb., zákona č. 183/2017 Sb.,
zákona č. 225/2017 Sb., zákona č. 403/2020 Sb., zákona č. 261/2021 Sb., zákona č. 284/2021
Sb., zákona č. 152/2023 Sb., zákona č. 81/2024 Sb., zákona č. 169/2024 Sb. a zákona
č. 218/2025 Sb., se mění takto:
1.
§ 1 a 2 včetně nadpisů znějí:
„§ 1
Předmět a účel zákona
(1) Tento zákon upravuje ochranu památkového fondu (kulturních památek, národních
kulturních památek, památkových rezervací, památkových zón) jako součásti národního
kulturního pokladu České republiky při respektování nároků na současný život a na udržitelný
rozvoj památkového fondu a stanovuje podmínky pro jeho uchování, využití, poznávání,
dokumentaci, zpřístupňování a konverzi.
(2) Péče státu o památkový fond (dále jen „státní památková péče“) zahrnuje činnosti,
opatření a rozhodnutí orgánů státní památkové péče (§ 25 až 31) a činnost odborné organizace
státní památkové péče (§ 32) k zabezpečení ochrany, zpřístupňování, využívání a rozvoje
památkového fondu se zohledněním práv, možností a zájmů jejich vlastníků a zájmů obcí.
(3) Státní památková péče usiluje o vyvážené a udržitelné skloubení ochrany památkových
hodnot a využití nemovitého památkového fondu k plnění jeho funkcí, zejména pro potřeby
bydlení, občanského vybavení, cestovního ruchu a současného života lidí (konverze památek).
(4) Státní památková péče rozlišuje význam a hodnotu památkového fondu a chrání tomu
odpovídajícím způsobem pouze ty hodnoty, které vyžadují ochranu podle tohoto zákona.
§ 2
Kulturní památky
(1) Kulturní památkou je hmotný doklad lidské činnosti vzniklý v dějinném procesu
kultivace světa, který je pramenem poznání, a je významný svou historickou, uměleckou,
duchovní, architektonickou, uměleckořemeslnou, řemeslnou, technickou anebo urbanistickou
hodnotou nebo je významným pozůstatkem lidského osídlení v minulosti nebo se váže
k významným osobnostem, událostem či společenskému životu a který je prohlášen za kulturní
památku.
(2) Za podmínek podle odstavce 1 lze za kulturní památku prohlásit
a) věc, hromadnou věc, popřípadě jiný soubor věcí,
b) stavbu, která není samostatnou věcí, nebo pozemek bez stavby, která se na něm nachází,
c) soubor věcí nebo staveb, které nejsou samostatnou věcí, ačkoliv některé z takových věcí
nebo staveb nevykazují znaky podle odstavce 1, ale mají podstatný význam pro prohlášení
souboru za kulturní památku.“.
2.
V § 3 se na konci odstavce 2 doplňuje věta „Nesouhlasí-li vlastník s prohlášením jeho
věci nebo stavby za kulturní památku, lze ji prohlásit za kulturní památku jen prokáže-li
na tom Ministerstvo kultury převažující veřejný zájem nad zájmy jejího vlastníka.“.
3.
V § 3 odst. 4 větě druhé se za text „(§ 32)“ vkládají slova „ , u stavby též stavební úřad“.
4.
V nadpisu § 6a se za slovo „ochrany“ vkládají slova „ , péče a rozvoje“.
5.
V § 6a odst. 1 se slova „ , úřadem územního plánování1)“ zrušují, za slovo „ochraně“ se
vkládají slova „ , péči a rozvoji“, slova „(dále jen „plán ochrany“)“ se nahrazují slovy
„(dále jen „plán ochrany, péče a rozvoje“)“, za slovo „způsob“ se vkládají slova „péče
a rozvoje památkové rezervace nebo památkové zóny a“, za slovo „zabezpečení“ se
vkládá slovo „ochrany“, slova „ , včetně výsadby a kácení dřevin na veřejných
prostranstvích (dále jen „úprava dřevin“),“ se zrušují a na konci textu odstavce se doplňují
slova „ , pokud by se jinak vyžadovalo“.
6.
V § 6a se za odstavec 1 vkládá nový odstavec 2, který zní:
„(2) Plán ochrany, péče a rozvoje zajišťuje vyváženou a trvale udržitelnou kombinaci
ochrany památkových a přírodních hodnot, zájmů vlastníků nemovitostí, návštěvníků a potřeb
života lidí v památkové rezervaci nebo památkové zóně, zejména bydlení, práce, podnikání,
cestovního ruchu a trávení volného času, rozvoje daného území, veřejné infrastruktury a nových
funkcí, s důrazem na kvalitní architekturu a posilování jedinečných prvků identity, charakteru
a kontextu tohoto území.“.
Dosavadní odstavce 2 až 6 se označují jako odstavce 3 až 7.
7.
V § 6a odst. 3 až 7 se za slovo „ochrany“ vkládají slova „ , péče a rozvoje“.
8.
V § 9 odstavec 1 zní:
„(1) Vlastník kulturní památky je povinen ji na svůj náklad chránit před poškozením,
znehodnocením, zničením nebo odcizením, udržovat ji v takovém stavu, aby se zachovala
hodnota, pro kterou je chráněna, a užívat ji způsobem, který odpovídá její památkové hodnotě
a technickému stavu, s přihlédnutím k současným potřebám a využití v souladu se zásadami
uvedenými v § 1.“.
9.
V § 9 odst. 2 se slovo „ohrožením,“ zrušuje.
10.
V § 9 odstavec 3 zní:
„(3) Každý je povinen počínat si tak, aby vlastní činností nezpůsobil nepříznivé změny
stavu kulturních památek nebo jejich prostředí.“.
11.
V § 11 se na konci textu odstavce 2 doplňují slova „ , nestanoví-li tento nebo jiný právní
předpis jinak“.
12.
V § 12 odst. 1 větě první se slova „ohrožení nebo“ zrušují.
13.
V § 14 odst. 1 se za slovo „rekonstrukci“ vkládají slova „ , restaurování, modernizaci,
přístavbu, nástavbu“.
14.
V § 14 odstavce 2 a 3 znějí:
„(2) Vlastník (správce, uživatel) nemovitosti, která není kulturní památkou, ale je
v památkové rezervaci nebo v památkové zóně, je povinen si k zamýšlené stavbě, změně
stavby, kterou se mění vnější vzhled stavby, nebo k odstranění stavby, terénní úpravě nebo
umístění zařízení anebo reklamního poutače předem vyžádat rozhodnutí nebo vyjádření
obecního úřadu obce s rozšířenou působností, není-li tato jeho povinnost na základě tohoto
zákona vyloučena (§ 6a) a nejde-li o dočasnou stavbu nebo zařízení, jejichž umístění
nepřesáhne 30 po sobě jdoucích dnů.
(3) V rozhodnutí, závazném stanovisku nebo vyjádření podle odstavců 1 a 2 se vyjádří, zda
práce tam uvedené jsou z hlediska zájmů státní památkové péče přípustné a za jakých podmínek
je lze provést. Podmínky musí vycházet ze současného stavu poznání kulturně historických
hodnot, které je nezbytné zachovat při umožnění realizace zamýšleného záměru a respektování
práv vlastníků. Při posuzování zájmů státní památkové péče se dbá na využití památkového
fondu pro současné potřeby lidí a na využití potenciálu jejich rozvoje v souladu se zásadami
uvedenými v § 1. Má se za to, že v rozporu se zájmy státní památkové péče není samotná
skutečnost, že obnova památkového fondu vytváří nebo zdůrazňuje vědomý, autorsky
promyšlený a architektonicky kvalitní kontrast doby s respektem k ochraně památkově
chráněných hodnot.“.
15.
V § 14 odst. 4 větě první se slova „odstavců 1 a 2“ nahrazují slovy „odstavce 1“, ve větě
druhé a třetí se číslo „20“ nahrazuje číslem „10“, ve větě druhé se číslo „30“ nahrazuje
číslem „20“ a na konci odstavce se doplňuje věta „Podkladem pro rozhodnutí nebo
závazné stanovisko orgánu státní památkové péče mohou být i další odborné podklady.“.
16.
V § 14 odstavec 5 zní:
„(5) Orgán státní památkové péče nebo stavební úřad si mohou vyžádat odborné vyjádření
odborné organizace státní památkové péče i pro účely rozhodnutí nebo vyjádření podle odstavce
2.“.
17.
V § 14 se za odstavec 8 vkládají nové odstavce 9 a 10, které znějí:
„(9) Jde-li o záměr vyžadující povolení podle stavebního zákona, který je v památkové
rezervaci, památkové zóně nebo v ochranném pásmu, ověří splnění podmínek podle tohoto
zákona stavební úřad v řízení o záměru podle stavebního zákona. Při posuzování záměrů
v ochranném pásmu dbá pouze na to, aby nedošlo k narušení chráněných hodnot památkového
fondu. Při posuzování splnění podmínek podle tohoto zákona postupuje stavební úřad
přiměřeně podle odstavce 3 věty druhé, třetí a čtvrté.
(10) Podklady pro vydání rozhodnutí, závazného stanoviska, vyjádření nebo jiného
správního úkonu podle tohoto zákona vyžadují orgán státní památkové péče a odborná
organizace státní památkové péče pouze v nezbytném rozsahu. Obsah jednotlivých částí
dokumentace musí odpovídat druhu, účelu a významu záměru.“.
Dosavadní odstavec 9 se označuje jako odstavec 11.
18.
V § 15 odst. 3 větě první se slova „nebo užívá-li kulturní památku v rozporu s jejím
kulturně politickým významem, památkovou hodnotou nebo technickým stavem“ zrušují
a slovo „společenském“ se nahrazuje slovem „veřejném“.
19.
V § 17 odstavec 1 zní:
„(1) Vyžaduje-li to ochrana nemovité kulturní památky, nemovité národní kulturní
památky, památkové rezervace nebo památkové zóny, vydá obecní úřad obce s rozšířenou
působností, a v případě nemovité národní kulturní památky krajský úřad opatření obecné
povahy o ochranném pásmu. Ochranné pásmo a jeho rozsah musí být přiměřené předmětu
a významu ochrany a musí přihlížet i k zájmu rozvoje obce, zájmům vlastníků dotčených
nemovitostí a k zásadám podle § 1.“.
20.
V § 22 se na konci odstavce 1 doplňuje věta „Bez souhlasu vlastníka mohou být
archeologické průzkumy na nemovitosti prováděny nejvýše po dobu 8 měsíců.“.
21.
V § 22 odst. 2 větě první se za slova „dotčeném území“ vkládají slova „po dobu nezbytně
nutnou“, ve větě druhé se za slova „náklady záchranného archeologického výzkumu“
vkládají slova „nejvýše po dobu 4 měsíců od jeho zahájení“ a za slova „tento stavebník“
se vkládají slova „ , pokud se stavebník a Archeologický ústav nebo oprávněná organizace
nedohodnou jinak“.
22.
V § 25 se na konci textu odstavce 1 doplňují slova „a stavební úřady“.
23.
V § 25 se na konci textu odstavce 3 doplňují slova „a zásadami uvedenými v § 1“.
24.
V § 26 odst. 2 písm. c) se slovo „rozvoje,“ nahrazuje slovy „rozvoje a“ a slova „a při
vymezení zastavěného území“ a „nebo vymezení zastavěného území“ se zrušují.
25.
V § 26 odst. 2 písm. d) se slova „ , její ochranné pásmo“ zrušují.
26.
V § 26 odst. 2 písm. f) se slova „kulturně výchovné využívání národních kulturních
památek a kulturně výchovné využívání“ nahrazují slovy „využívání národních
kulturních památek a“ a na konci textu písmene se doplňují slova „a zásadami uvedenými
v § 1“.
27.
V § 26 odst. 3 se slova „závazné stanovisko“ nahrazují slovem „vyjádření“.
28.
Pod označení § 28 se vkládá nadpis, který zní: „Krajský úřad“.
29.
V § 28 odst. 2 písm. c) se slova „územního plánu,“ nahrazují slovy „územního plánu a“
a slova „a při vymezení zastavěného území“ se zrušují.
30.
V § 28 odst. 2 písm. d) se slova „nebo její ochranné pásmo“ zrušují.
31.
V § 29 odst. 2 písmeno b) zní:
„b) zabezpečuje předpoklady pro péči o kulturní památky a nemovitosti, které nejsou kulturní
památkou, ale jsou v památkové rezervaci nebo v památkové zóně, a v souvislosti s tím
vydává jako dotčený orgán pro kulturní památky závazné stanovisko podle § 14 odst. 1
a pro nemovitosti, které nejsou kulturní památkou, ale jsou v památkové rezervaci nebo
v památkové zóně, vyjádření podle § 14 odst. 2 a poskytuje další podklady do řízení
vedených jinými správními úřady než orgány státní památkové péče podle zvláštních
právních předpisů,“.
32.
V § 29 odst. 2 písm. c) se slova „územního plánu,“ nahrazují slovy „územního plánu a“
a slova „a při vymezení zastavěného území“ se zrušují.
33.
V § 29 odst. 2 písmeno i) zní:
„i) vykonává z hlediska státní památkové péče dozor při obnově kulturních památek,“.
34.
§ 31 včetně nadpisu zní:
„§ 31
Stavební úřad
(1) Stavební úřad jako orgán státní památkové péče
a) ověřuje v řízení o povolení záměru splnění podmínek podle tohoto zákona pro záměry,
které nejsou kulturní památkou, ale jsou v památkové rezervaci, v památkové zóně nebo
v ochranném pásmu,
b) dozírá v rozsahu své působnosti na dodržování tohoto zákona a předpisů vydaných k jeho
provedení,
c) plní další úkoly stanovené mu tímto zákonem.
(2) Stavební úřad může při plnění svých úkolů využívat odbornou pomoc odborné
organizace státní památkové péče.“.
Poznámka pod čarou č. 21 se zrušuje.
35.
V § 32 odst. 1 se slovo „veškeré“ zrušuje a slova „k zabezpečení jednoty kulturně
politických záměrů a ideově metodických, ekonomických a technických hledisek, jakož
i perspektivního rozvoje státní památkové péče“ se nahrazují slovy „v souladu se
zásadami uvedenými v § 1“.
36.
V § 32 odst. 2 písm. b) se slova „a metodiku společenského uplatnění kulturních památek“
zrušují.
37.
V § 32 odst. 2 písm. h) se slova „kulturně výchovné“ zrušují.
38.
Část pátá včetně nadpisu zní:
„ČÁST PÁTÁ
PŘESTUPKY
§ 35
(1) Přestupku se dopustí ten, kdo
a) nechrání věc nebo stavbu před poškozením, zničením nebo odcizením od doručení
vyrozumění o podání návrhu na prohlášení za kulturní památku nebo o tom, že ministerstvo
kultury hodlá věc nebo stavbu prohlásit za kulturní památku z vlastního podnětu, až do
rozhodnutí ministerstva kultury,
b) nesplní oznamovací povinnost stanovenou v § 3 odst. 5 nebo § 12,
c) kulturní památku nechrání před poškozením, znehodnocením, zničením nebo odcizením,
neudržuje ji v takovém stavu, aby se zachovala hodnota, pro kterou je chráněna, nebo ji
užívá způsobem, který neodpovídá její památkové hodnotě nebo technickému stavu, bez
přihlédnutí k současným potřebám, postupuje v rozporu se zásadami uvedenými v § 1 nebo
ji znehodnotí nebo zničí,
d) poruší podmínku ochranného pásma nemovité kulturní památky, nemovité národní kulturní
památky, památkové rezervace nebo památkové zóny,
e) provádí obnovu kulturní památky bez povolení stavebního úřadu nebo rozhodnutí obecního
úřadu obce s rozšířenou působností nebo nedodržuje podmínky určené v tomto povolení
nebo rozhodnutí,
f)
provádí restaurování, jde-li o kulturní památku, prostřednictvím fyzické osoby, která nemá
povolení ministerstva kultury, nejde-li o výkon restaurátorské činnosti podle § 14a odst.
12, prostřednictvím fyzické osoby, které byla restaurátorská činnost pozastavena podle
§ 14a odst. 11, anebo prostřednictvím fyzické osoby, která není osobou oprávněnou k
restaurování podle § 14b odst. 2, nebo která postupuje v rozporu se zákazem podle odstavce
3,
g) provádí restaurování, jde-li o kulturní památku, bez povolení ministerstva kultury, nejde-li
o výkon restaurátorské činnosti podle § 14a odst. 12, nebo přestože mu byla restaurátorská
činnost pozastavena podle § 14a odst. 11, anebo přestože není osobou oprávněnou
k restaurování podle § 14b odst. 2, nebo při zákazu uloženém podle odstavce 3,
h) provádí stavbu, změnu stavby, kterou se mění vnější vzhled stavby, odstranění stavby,
terénní úpravu nebo umístí zařízení nebo reklamní poutač na nemovitosti, která není
kulturní památkou, ale je v památkové rezervaci nebo v památkové zóně, bez povolení
stavebního úřadu nebo rozhodnutí obecního úřadu obce s rozšířenou působností nebo
nedodržuje podmínky určené v tomto povolení nebo rozhodnutí,
i)
provádí záměr na nemovitosti, která není kulturní památkou, ale je v ochranném pásmu,
bez povolení stavebního úřadu nebo nedodržuje podmínky určené v tomto povolení,
j)
provádí neoprávněné výkopy na území s archeologickými nálezy.
(2) Přestupku se dále dopustí ten, kdo
a) národní kulturní památku nechrání před poškozením, znehodnocením, zničením nebo
odcizením, neudržuje ji v takovém stavu, aby se zachovala hodnota, pro kterou je chráněna,
nebo ji užívá způsobem, který neodpovídá její památkové hodnotě nebo technickému
stavu, bez přihlédnutí k současným potřebám, postupuje v rozporu se zásadami uvedenými
v § 1 nebo ji znehodnotí nebo zničí,
b) provádí obnovu národní kulturní památky bez povolení stavebního úřadu nebo rozhodnutí
krajského úřadu nebo nedodržuje podmínky určené v tomto povolení nebo rozhodnutí,
c) provádí restaurování, jde-li o národní kulturní památku, prostřednictvím fyzické osoby,
která nemá povolení ministerstva kultury, nejde-li o výkon restaurátorské činnosti podle
§ 14a odst. 12, prostřednictvím fyzické osoby, které byla restaurátorská činnost
pozastavena podle § 14a odst. 11, anebo prostřednictvím fyzické osoby, která není osobou
oprávněnou k restaurování podle § 14b odst. 2, nebo která postupuje v rozporu se zákazem
podle odstavce 3,
d) provádí restaurování, jde-li o národní kulturní památku, bez povolení ministerstva kultury,
nejde-li o výkon restaurátorské činnosti podle § 14a odst. 12, nebo přestože mu byla
restaurátorská činnost pozastavena podle § 14a odst. 11, anebo přestože není osobou
oprávněnou k restaurování podle § 14b odst. 2, nebo při zákazu uloženém podle odstavce
3,
e) přemístí bez předchozího souhlasu krajského úřadu stavbu, která je kulturní památkou,
nebo trvale bez předchozího souhlasu krajského úřadu přemístí z veřejně přístupného místa
movitou věc, která je kulturní památkou,
f)
zapůjčí do zahraničí nebo se pokusí do zahraničí vyvézt nebo vyveze kulturní památku bez
předchozího souhlasu ministerstva kultury,
g) nesplní oznamovací povinnost stanovenou v § 21 odst. 4, § 22 odst. 2 nebo § 23 odst. 2,
h) provádí v rozporu s § 21 odst. 2 archeologický výzkum, nebo provádí archeologický
výzkum, přestože není osobou oprávněnou k výzkumům podle § 21a odst. 2, nebo
postupuje v rozporu se zákazem podle odstavce 4,
i)
poruší povinnost stanovenou v nařízení kraje vydaném na základě § 23a odst. 4.
(3) Osoba oprávněná k restaurování se dopustí přestupku tím, že hrubým způsobem nebo
méně závažným způsobem, ale opakovaně prokazatelně poškodila při restaurování kulturní
památku nebo její část, která je dílem výtvarných umění nebo uměleckořemeslnými pracemi.
(4) Osoba oprávněná k výzkumům se dopustí přestupku tím, že provádí archeologické
výzkumy, které archeologické nálezy ohrožují nebo poškozují.
(5) Za přestupek lze uložit pokutu do
a) 2 000 000 Kč, jde-li o přestupek podle odstavce 1,
b) 4 000 000 Kč, jde-li o přestupek podle odstavce 2.
(6) Za přestupek podle odstavce 3 nebo 4 lze uložit zákaz činnosti nejdéle na 2 roky.
§ 36
Přestupek projednává
a) obecní úřad obce s rozšířenou působností, jde-li o přestupek podle § 35 odst. 1, pokud jej
neprojednává stavební úřad,
b) krajský úřad, jde-li o přestupek podle § 35 odst. 2, pokud jej neprojednává stavební úřad,
c) stavební úřad, jde-li o přestupek podle § 35 odst. 1 písm. e), h) a i) a § 35 odst. 2 písm. b),
pokud byl stavební úřad příslušný k povolení stavby,
d) ministerstvo kultury, jde-li o přestupek podle § 35 odst. 3 nebo 4.“.
39.
§ 43 se včetně poznámek pod čarou č. 26 až 30 zrušuje.
40.
V § 45 se text „§ 6a odst. 6“ nahrazuje textem „§ 6a odst. 7“, text „§ 14 odst. 9“ se
nahrazuje textem „§ 14 odst. 11“ a slova „ , § 29 odst. 4 a § 31 odst. 6“ se nahrazují slovy
„a § 29 odst. 4“.
Čl. VIII
Přechodná ustanovení
1. Řízení a postupy zahájené a neskončené přede dnem nabytí účinnosti tohoto zákona se
dokončí podle zákona č. 20/1987 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona,
není-li stanoveno jinak.
2. Řízení a postupy zahájené a neskončené do dne vzniku Úřadu rozvoje území České
republiky (dále jen „Úřad“), k nimž je příslušný Úřad nebo jiný stavební úřad, převezme a
dokončí ode dne svého vzniku Úřad nebo jiný stavební úřad.
3. Řízení a postupy zahájené a neskončené do dne vzniku úřadů rozvoje území krajů, k
nimž je příslušný úřad rozvoje území kraje nebo jeho územní pracoviště, ode dne vzniku úřadů
rozvoje území krajů převezme a dokončí příslušný úřad rozvoje území kraje nebo jeho příslušné
územní pracoviště. Do dne vzniku úřadů rozvoje území krajů pokračují v těchto řízeních a
postupech podle zákona č. 20/1987 Sb., ve znění účinném ode dne nabytí účinnosti tohoto
zákona, správní orgány příslušné podle dosavadních právních předpisů. Pro ověření podmínek
podle zákona č. 20/1987 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona pro
záměr, který je v ochranném pásmu podle § 14 odst. 9 zákona č. 20/1987 Sb., ve znění účinném
ode dne nabytí účinnosti tohoto zákona, si stavební úřad příslušný podle dosavadních právních
předpisů do dne vzniku úřadů rozvoje území krajů vyžádá vyjádření obecního úřadu obce s
rozšířenou působností.
4. Ochranná pásma vymezená přede dnem 1. ledna 2007, která nebyla vydána územním
rozhodnutím ani opatřením obecné povahy, pozbývají platnosti dnem vydání opatření obecné
povahy, které je nahrazuje, nejpozději však 31. prosince 2028, nebo pokud v daném území
neobsahuje územní plán podmínky k zajištění zájmů státní památkové péče 31. prosince 2030.
5. Plán ochrany přijatý podle § 6a, ve znění účinném přede dnem nabytí účinnosti tohoto
zákona, se považuje za plán ochrany, péče a rozvoje podle § 6a, ve znění účinném ode dne
nabytí účinnosti tohoto zákona. Příslušný krajský úřad zajistí do 31. prosince 2030 aktualizaci
plánu ochrany, péče a rozvoje, aby splňoval požadavky podle § 6a odst. 2, jinak dosavadní plán
ochrany, péče a rozvoje dnem 31. prosince 2030 zanikne.
ČÁST PÁTÁ
Změna horního zákona
Čl. IX
Zákon č. 44/1988 Sb., o ochraně a využití nerostného bohatství (horní zákon), ve znění
zákona č. 541/1991 Sb., zákona č. 10/1993 Sb., zákona č. 168/1993 Sb., zákona č. 132/2000
Sb., zákona č. 258/2000 Sb., zákona č. 366/2000 Sb., zákona č. 315/2001 Sb., zákona č. 61/2002
Sb., zákona č. 320/2002 Sb., zákona č. 150/2003 Sb., zákona č. 3/2005 Sb., zákona č. 386/2005
Sb., zákona č. 186/2006 Sb., zákona č. 313/2006 Sb., zákona č. 296/2007 Sb., zákona
č. 157/2009 Sb., zákona č. 227/2009 Sb., zákona č. 281/2009 Sb., zákona č. 85/2012 Sb.,
zákona č. 350/2012 Sb., zákona č. 498/2012 Sb., zákona č. 257/2013 Sb., zákona č. 89/2016
Sb., zákona č. 264/2016 Sb., zákona č. 183/2017 Sb., zákona č. 225/2017 Sb., zákona č.
403/2020 Sb., zákona č. 609/2020 Sb., zákona č. 88/2021 Sb., zákona č. 261/2021 Sb., zákona
č. 284/2021 Sb., zákona č. 152/2023 Sb., zákona č. 349/2023 Sb., zákona č. 465/2023 Sb. a
zákona č. 218/2025 Sb., se mění takto:
1.
V § 3 odst. 4, § 6 odst. 2, § 11 odst. 6, § 12, § 14 odst. 3, § 14c odst. 1 a 5, § 14d odst. 3
a 4, § 15 odst. 2, § 17 odst. 1, § 24 odst. 2, § 29a odst. 2 a 5 až 8, § 31 odst. 2, § 33 odst. 3,
§ 33k odst. 3 a 4, § 33o odst. 1, § 33q, § 33w odst. 1 a 2, § 35 odst. 7, § 37a odst. 4, § 40b
odst. 1 se slova „průmyslu a obchodu“ nahrazují slovem „hospodářství“.
2.
V § 14d odst. 2 se za slovo „prostorů“ vkládají slova „ , rozhodování o změně využití
území, rozhodování o povolení hornické činnosti a činnosti prováděné hornickým
způsobem“.
3.
V § 14d se na začátek odstavce 4 vkládá věta „Naplňování surovinové politiky, zajištění
surovinové bezpečnosti a surovinové soběstačnosti je veřejným zájmem.“.
4.
V § 17 se odstavec 5 zrušuje.
Dosavadní odstavce 6 až 8 se označují jako odstavce 5 až 7.
5.
V § 17 odst. 6 se číslo „5“ nahrazuje číslem „4“.
6.
V § 26 odstavec 3 zní:
„(3) Povrchové hranice stanoveného dobývacího prostoru se vyznačí v územně plánovací
dokumentaci jako plochy těžby. V případě dobývacího prostoru pro hlubinnou těžbu nerostů
může být plocha těžby po předchozí dohodě s Ministerstvem hospodářství vyznačena pouze v
rozsahu nezbytném pro hospodárné vydobytí výhradního ložiska. Rozhodnutí o stanovení
dobývacího prostoru je pro územně plánovací dokumentaci závazné. V případě rozporu
rozhodnutí o stanovení dobývacího prostoru s územně plánovací dokumentací se k části územně
plánovací dokumentace, která je v rozporu s rozhodnutím o stanovení dobývacího prostoru,
nepřihlíží.“.
7.
§ 28a a 28b včetně nadpisů znějí:
„§ 28a
Zvláštní ustanovení o dobývacím prostoru pro dobývání kritického nerostu
(1) Řízení o stanovení nebo změně dobývacího prostoru pro dobývání kritického nerostu
se zahajuje na návrh organizace.
(2) Obvodní báňský úřad o návrhu rozhodne nejpozději do 60 dnů ode dne podání
bezvadného návrhu na stanovení nebo změnu dobývacího prostoru pro dobývání kritického
nerostu.
(3) Obvodní báňský úřad bezodkladně zašle návrh na stanovení nebo změnu dobývacího
prostoru pro dobývání kritického nerostu dotčeným orgánům a oznámí zahájení řízení
účastníkům. Bezodkladně nařídí ústní jednání spojené zpravidla s místním šetřením.
(4) Dotčený orgán vydá stanovisko, vyjádření nebo závazné stanovisko do 30 dnů ode dne
doručení bezvadné žádosti o stanovisko, vyjádření nebo závazné stanovisko nebo ode dne
vyžádání obvodním báňským úřadem. Ustanovení § 149 odst. 4 správního řádu věta poslední
se nepoužije.
(5) Nevydá-li dotčený orgán stanovisko, vyjádření nebo závazné stanovisko ve lhůtě pro
jeho vydání, považuje se za souhlasné a bez podmínek. Ustanovení věty první tohoto odstavce
se neuplatní na závazné stanovisko k posouzení vlivů provedení záměru na životní prostředí
podle zákona o posuzování vlivů na životní prostředí.
(6) Účastníci řízení jsou oprávněni navrhovat důkazy a činit jiné návrhy nejpozději na
ústním jednání. K námitkám o věcech, o kterých bylo rozhodnuto při vydání územně plánovací
dokumentace nebo v řízení o stanovení chráněného ložiskového území, se nepřihlíží.
(7) V řízení o stanovení nebo změně dobývacího prostoru pro dobývání kritického nerostu
se přiměřeně použijí ustanovení § 24 až 28.
(8) Neobsahuje-li odvolání proti rozhodnutí vydanému v řízení o stanovení nebo změně
dobývacího prostoru pro dobývání ložiska kritického nerostu údaj o tom, v čem je spatřován
rozpor s právními předpisy nebo nesprávnost rozhodnutí nebo řízení, jež mu předcházelo,
k odstranění tohoto nedostatku správní orgán podatele nevyzývá. Neodstranil-li podatel tento
nedostatek před uplynutím lhůty pro podání odvolání, přezkoumává Český báňský úřad pouze
soulad napadeného rozhodnutí a řízení, které vydání rozhodnutí předcházelo, s právními
předpisy. K doplnění důvodů odvolání po lhůtě stanovené pro jeho podání se nepřihlíží.
(9) Jestliže odvolání směřuje proti obsahu závazného stanoviska, vyžádá si Český báňský
úřad potvrzení nebo změnu závazného stanoviska od správního orgánu nadřízeného správnímu
orgánu příslušnému k vydání závazného stanoviska. Vyjádření správního orgánu prvního
stupně se nevyžaduje. Nadřízený správní orgán podle věty první potvrdí nebo změní závazné
stanovisko bezodkladně nebo, pokud to není možné, nejpozději do 30 dnů ode dne vyžádání
jeho potvrzení nebo změny. Lhůtu pro potvrzení nebo změnu závazného stanoviska nelze
prodloužit. Po dobu vyřizování žádosti o potvrzení nebo změnu závazného stanoviska lhůta pro
vydání rozhodnutí o odvolání neběží.
§ 28b
Dotčené orgány a součinnost orgánů veřejné správy v řízení o stanovení, změně nebo
zrušení dobývacího prostoru
(1) Dotčené orgány uplatňují stanoviska, vyjádření nebo závazná stanoviska ke stanovení,
změně nebo zrušení dobývacího prostoru pouze v mezích své působnosti a činí tak co nejdříve
a v nejranější fázi, kdy je to možné, přitom uplatňují nejmírnější prostředky, které jsou
dostatečné k ochraně jimi hájeného veřejného zájmu, a zvláště dbají zachování účelu tohoto
zákona.
(2) Obvodní báňské úřady postupují při výkonu své působnosti ve vzájemné součinnosti
s dotčenými orgány chránícími veřejné zájmy podle jiných právních předpisů.
(3) Obvodní báňský úřad projednává s dotčenými orgány jimi vydaná stanoviska,
vyjádření nebo závazná stanoviska. Za účelem projednání stanovisek, vyjádření nebo
závazných stanovisek nebo odstranění rozporů může obvodní báňský úřad svolat společné
jednání s dotčenými orgány. Společné jednání svolá obvodní báňský úřad i na žádost žadatele.
Společné jednání je neveřejné a o jeho průběhu a závěrech se sepisuje protokol. Obvodní
báňský úřad oznámí dotčeným orgánům jeho konání nejméně 5 dnů předem a ke společnému
jednání přizve žadatele.
(4) Na základě závěrů společného jednání může obvodní báňský úřad požádat dotčené
orgány o odstranění zjevných vad stanovisek, vyjádření nebo závazných stanovisek nebo
odstranění rozporů a určit jim za tímto účelem lhůtu, která nepřekročí 15 dnů ode dne konání
společného jednání; po dobu běhu této lhůty neběží lhůta pro vydání rozhodnutí o stanovení
dobývacího prostoru. K vyjádření nebo závaznému stanovisku vydanému po lhůtě podle věty
první se nepřihlíží.“.
8.
Za § 28b se vkládají nové § 28c a 28d, které včetně nadpisů znějí:
„§ 28c
Plánovací smlouva a námitky
(1) Za účelem stanovení podmínek pro stanovení dobývacího prostoru může organizace
uzavřít s obcí, krajem nebo hlavním městem Prahou, případně i dalšími osobami, plánovací
smlouvu, jejímž obsahem je zejména vzájemná povinnost stran poskytnout si součinnost při
vyhledávání a průzkumu, otvírce, přípravě a dobývání ložisek nerostů a dalších souvisejících
činnostech a postupovat při jejich uskutečňování ujednaným způsobem. Pro další obsah,
uzavírání a přezkum plánovací smlouvy se použijí § 130 až 132 stavebního zákona obdobně.
(2) Obvodní báňský úřad v řízení o stanovení, změně nebo zrušení dobývacího prostoru
nepřihlíží k námitkám účastníka řízení, které jsou v rozporu s uzavřenou plánovací smlouvou,
jejíž smluvní stranou je tento účastník řízení.
§ 28d
Postup odvolacího orgánu v řízení o stanovení dobývacího prostoru
(1) Je-li odvolání podáno účastníkem řízení, který udělil souhlas se stanovením
dobývacího prostoru, odvolací správní orgán nepřihlíží k části obsahu odvolání, která směřuje
proti tomu, s čím účastník řízení souhlasil.
(2) Odvolací správní orgán nepřihlíží k odvolacím námitkám, které mohl odvolatel uplatnit
dříve. Odvolací správní orgán dále nepřihlíží k části obsahu odvolání, které bylo podáno
odvolatelem, který je stranou plánovací smlouvy, pokud je obsah odvolání v rozporu s tím,
k čemu se odvolatel v plánovací smlouvě zavázal.“.
9.
V § 33 odst. 7 se slova „vymezení zastavěného území,“ zrušují.
Čl. X
Přechodná ustanovení
1. Řízení a postupy zahájené a neskončené přede dnem nabytí účinnosti tohoto zákona se
dokončí podle zákona č. 44/1988 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona.
2. Do zrušení zákona č. 148/2023 Sb., o jednotném environmentálním stanovisku, se § 28a
odst. 5 zákona č. 44/1988 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona,
neuplatní na jednotné environmentální stanovisko podle zákona č. 148/2023 Sb., o jednotném
environmentálním stanovisku.
ČÁST ŠESTÁ
Změna zákona o hornické činnosti, výbušninách a o státní báňské správě
Čl. XI
Zákon č. 61/1988 Sb., o hornické činnosti, výbušninách a o státní báňské správě, ve znění
zákona č. 425/1990 Sb., zákona č. 542/1991 Sb., zákona č. 169/1993 Sb., zákona č. 128/1999
Sb., zákona č. 71/2000 Sb., zákona č. 124/2000 Sb., zákona č. 315/2001 Sb., zákona č. 206/2002
Sb., zákona č. 320/2002 Sb., zákona č. 226/2003 Sb., zákona č. 227/2003 Sb., zákona č. 3/2005
Sb., zákona č. 386/2005 Sb., zákona č. 186/2006 Sb., zákona č. 313/2006 Sb., zákona
č. 342/2006 Sb., zákona č. 296/2007 Sb., zákona č. 376/2007 Sb., zákona č. 124/2008 Sb.,
zákona č. 189/2008 Sb., zákona č. 274/2008 Sb., zákona č. 223/2009 Sb., zákona č. 227/2009
Sb., zákona č. 281/2009 Sb., zákona č. 155/2010 Sb., zákona č. 184/2011 Sb., zákona
č. 375/2011 Sb., zákona č. 18/2012 Sb., zákona č. 64/2014 Sb., zákona č. 250/2014 Sb., zákona
č. 204/2015 Sb., zákona č. 206/2015 Sb., zákona č. 320/2015 Sb., zákona č. 91/2016 Sb., zákona
č. 243/2016 Sb., zákona č. 451/2016 Sb., zákona č. 183/2017 Sb., zákona č. 91/2018 Sb., zákona
č. 403/2020 Sb., zákona č. 609/2020 Sb., zákona č. 261/2021 Sb., zákona č. 284/2021 Sb.,
zákona č. 225/2022 Sb., zákona č. 152/2023 Sb., zákona č. 179/2023 Sb., zákona č. 465/2023
Sb. a zákona č. 220/2025 Sb., se mění takto:
1.
§ 18b a 18c včetně nadpisů znějí:
„§ 18b
Zvláštní ustanovení o povolení hornické činnosti pro dobývání kritických nerostů
(1) Řízení o povolení hornické činnosti otvírky, přípravy a dobývání kritických nerostů se
zahajuje na návrh organizace.
(2) Obvodní báňský úřad o návrhu rozhodne nejpozději do 60 dnů ode dne podání
bezvadného návrhu o povolení hornické činnosti otvírky, přípravy a dobývání kritických
nerostů.
(3) Obvodní báňský úřad bezodkladně zašle žádost o povolení hornické činnosti otvírky,
přípravy a dobývání kritických nerostů dotčeným orgánům a oznámí zahájení řízení
účastníkům. Bezodkladně nařídí ústní jednání spojené zpravidla s místním šetřením.
(4) Dotčený orgán vydá stanovisko, vyjádření nebo závazné stanovisko do 30 dnů ode dne
doručení bezvadné žádosti nebo ode dne vyžádání obvodním báňským úřadem. Ustanovení
§ 149 odst. 4 správního řádu věta poslední se nepoužije.
(5) Nevydá-li dotčený orgán stanovisko, vyjádření nebo závazné stanovisko ve lhůtě pro
jeho vydání, považuje se za souhlasné a bez podmínek. Ustanovení věty první tohoto odstavce
se neuplatní na závazné stanovisko k posouzení vlivů provedení záměru na životní prostředí
podle zákona o posuzování vlivů na životní prostředí.
(6) Účastníci řízení jsou oprávněni navrhovat důkazy a činit jiné návrhy nejpozději na
ústním jednání. K námitkám o věcech, o kterých bylo rozhodnuto při vydání územně plánovací
dokumentace, v řízení o stanovení chráněného ložiskového území nebo v řízení o stanovení
dobývacího prostoru, se nepřihlíží.
(7) V řízení o povolení hornické činnosti pro dobývání kritických surovin se přiměřeně
použijí ustanovení § 17 a 18.
(8) Neobsahuje-li odvolání proti rozhodnutí vydanému v řízení o povolení otvírky,
přípravy a dobývání ložiska kritického nerostu údaj o tom, v čem je spatřován rozpor s právními
předpisy nebo nesprávnost rozhodnutí nebo řízení, jež mu předcházelo, k odstranění tohoto
nedostatku správní orgán podatele nevyzývá. Neodstranil-li podatel tento nedostatek před
uplynutím lhůty pro podání odvolání, přezkoumává Český báňský úřad pouze soulad
napadeného rozhodnutí a řízení, které vydání rozhodnutí předcházelo, s právními předpisy.
K doplnění důvodů odvolání po lhůtě stanovené pro jeho podání se nepřihlíží.
(9) Jestliže odvolání směřuje proti obsahu závazného stanoviska, vyžádá si Český báňský
úřad potvrzení nebo změnu závazného stanoviska od správního orgánu nadřízeného správnímu
orgánu příslušnému k vydání závazného stanoviska. Vyjádření správního orgánu prvního
stupně se nevyžaduje. Nadřízený správní orgán podle věty první potvrdí nebo změní závazné
stanovisko bezodkladně nebo, pokud to není možné, nejpozději do 30 dnů ode dne vyžádání
jeho potvrzení nebo změny. Lhůtu pro potvrzení nebo změnu závazného stanoviska nelze
prodloužit. Po dobu vyřizování žádosti o potvrzení nebo změnu závazného stanoviska lhůta pro
vydání rozhodnutí o odvolání neběží.
(10) Odstavce 2 až 9 se použijí přiměřeně i pro zajištění a likvidaci důlních děl a lomů
v souvislosti s kritickými nerosty.
§ 18c
Dotčené orgány a součinnost orgánů veřejné správy
(1) Dotčené orgány uplatňují stanoviska, vyjádření nebo závazná stanoviska
k záležitostem podle tohoto zákona pouze v mezích své působnosti a činí tak co nejdříve
a v nejranější fázi, kdy je to možné, přitom uplatňují nejmírnější prostředky, které jsou
dostatečné k ochraně jimi hájeného veřejného zájmu, a zvláště dbají zachování účelu tohoto
zákona a horního zákona.
(2) Obvodní báňské úřady postupují při výkonu své působnosti ve vzájemné součinnosti
s dotčenými orgány chránícími veřejné zájmy podle jiných právních předpisů.
(3) Obvodní báňský úřad projednává s dotčenými orgány jimi vydaná stanoviska,
vyjádření nebo závazná stanoviska. Za účelem projednání stanovisek, vyjádření nebo
závazných stanovisek nebo odstranění rozporů může obvodní báňský úřad svolat společné
jednání s dotčenými orgány. Společné jednání svolá obvodní báňský úřad i na žádost žadatele.
Společné jednání je neveřejné a o jeho průběhu a závěrech se sepisuje protokol. Obvodní
báňský úřad oznámí dotčeným orgánům jeho konání nejméně 5 dnů předem a ke společnému
jednání přizve žadatele.
(4) Na základě závěrů společného jednání může obvodní báňský úřad požádat dotčené
orgány o odstranění zjevných vad stanovisek, vyjádření nebo závazných stanovisek nebo
odstranění rozporů a určit jim za tímto účelem lhůtu, která nepřekročí 15 dnů ode dne
konání společného jednání; po dobu běhu této lhůty neběží lhůta pro vydání rozhodnutí. Ke
stanovisku, vyjádření nebo závaznému stanovisku vydanému po lhůtě podle věty první se
nepřihlíží.“.
2.
Za § 18c se vkládají nové § 18d a 18e, které včetně nadpisů znějí:
„§ 18d
Plánovací smlouva a námitky
(1) Za účelem stanovení podmínek pro povolení hornické činnosti a činnosti prováděné
hornickým způsobem může organizace uzavřít s obcí, krajem nebo hlavním městem Prahou,
případně i dalšími osobami, plánovací smlouvu, jejímž obsahem je zejména vzájemná
povinnost stran poskytnout si součinnost při provádění hornické činnosti nebo činnosti
prováděné hornickým způsobem a dalších souvisejících činnostech a postupovat při jejich
uskutečňování ujednaným způsobem. Pro další obsah, uzavírání a přezkum plánovací smlouvy
se použijí § 130 až 132 stavebního zákona obdobně.
(2) Obvodní báňský úřad nepřihlíží k námitkám účastníka řízení, které jsou v rozporu
s uzavřenou plánovací smlouvou, jejíž smluvní stranou je tento účastník řízení.
§ 18e
Postup odvolacího orgánu v řízení o povolení hornické činnosti
(1) Je-li odvolání podáno účastníkem řízení, který udělil souhlas s povolením hornické
činnosti, odvolací správní orgán nepřihlíží k části obsahu odvolání, která směřuje proti tomu,
s čím účastník řízení souhlasil.
(2) Odvolací správní orgán nepřihlíží k odvolacím námitkám, které mohl odvolatel uplatnit
dříve. Odvolací správní orgán dále nepřihlíží k části obsahu odvolání, které bylo podáno
odvolatelem, který je stranou plánovací smlouvy, pokud je obsah odvolání v rozporu s tím,
k čemu se odvolatel v plánovací smlouvě zavázal.“.
3.
V § 19 odst. 3 větě první se slova „a 18“ nahrazují slovy „ , 18, 18c, 18d a 18e“.
4.
V § 40 odst. 6 písm. i) se slova „Ministerstvem pro místní rozvoj nebo radou kraje“
nahrazují slovy „Úřadem rozvoje území České republiky nebo krajem“.
Čl. XII
Přechodná ustanovení
1. Řízení a postupy zahájené a neskončené přede dnem nabytí účinnosti tohoto zákona se
dokončí podle zákona č. 61/1988 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona.
2. Do zrušení zákona č. 148/2023 Sb., o jednotném environmentálním stanovisku, se § 18b
odst. 5 zákona č. 61/1988 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona,
neuplatní na jednotné environmentální stanovisko podle zákona č. 148/2023 Sb., o jednotném
environmentálním stanovisku.
ČÁST SEDMÁ
Změna zákona o geologických pracích
Čl. XIII
Zákon č. 62/1988 Sb., o geologických pracích, ve znění zákona č. 543/1991 Sb., zákona
č. 369/1992 Sb., zákona č. 366/2000 Sb., zákona č. 320/2002 Sb., zákona č. 18/2004 Sb.,
zákona č. 3/2005 Sb., zákona č. 444/2005 Sb., zákona č. 186/2006 Sb., zákona č. 124/2008 Sb.,
zákona č. 223/2009 Sb., zákona č. 227/2009 Sb., zákona č. 281/2009 Sb., zákona č. 85/2012
Sb., zákona č. 64/2014 Sb., zákona č. 183/2017 Sb., zákona č. 225/2017 Sb., zákona č. 261/2021
Sb., zákona č. 284/2021 Sb. a zákona č. 149/2023 Sb., se mění takto:
1.
V § 13 odst. 3 se slova „územnímu rozhodnutí“ nahrazují slovy „žádosti o povolení
záměru“.
2.
V § 22a se odstavec 5 včetně poznámky pod čarou č. 23 zrušuje.
ČÁST OSMÁ
Změna zákona o ochraně přírody a krajiny
Čl. XIV
Zákon č. 114/1992 Sb., o ochraně přírody a krajiny, ve znění zákona č. 347/1992, zákona
č. 289/1995 Sb., nálezu Ústavního soudu, vyhlášeného pod č. 3/1997 Sb., zákona č. 16/1997
Sb., zákona č. 123/1998 Sb., zákona č. 161/1999 Sb., zákona č. 238/1999 Sb., zákona
č. 132/2000 Sb., zákona č. 76/2002 Sb., zákona č. 320/2002 Sb., zákona č. 100/2004 Sb.,
zákona č. 168/2004 Sb., zákona č. 218/2004 Sb., zákona č. 387/2005 Sb., zákona č. 444/2005
Sb., zákona č. 186/2006 Sb., zákona č. 222/2006 Sb., zákona č. 267/2006 Sb., zákona
č. 124/2008 Sb., zákona č. 167/2008 Sb., zákona č. 312/2008 Sb., zákona č. 223/2009 Sb.,
zákona č. 227/2009 Sb., zákona č. 281/2009 Sb., zákona č. 291/2009 Sb., zákona č. 349/2009
Sb., zákona č. 381/2009 Sb., zákona č. 350/2012 Sb., zákona č. 64/2014 Sb., zákona č. 175/2014
Sb., zákona č. 250/2014 Sb., zákona č. 15/2015 Sb., zákona č. 39/2015 Sb., zákona č. 319/2016
Sb., zákona č. 123/2017 Sb., zákona č. 183/2017 Sb., zákona č. 225/2017 Sb., zákona
č. 277/2019 Sb., zákona č. 403/2020 Sb., zákona č. 36/2021 Sb., zákona č. 261/2021 Sb.,
zákona č. 284/2021 Sb., zákona č. 364/2021 Sb., zákona č. 149/2023 Sb., zákona č. 465/2023
Sb., zákona č. 182/2024 Sb., zákona č. 196/2024 Sb., zákona č. 23/2025 Sb., zákona č. 36/2025
Sb., zákona č. 218/2025 Sb., zákona č. 250/2025 Sb. a zákona č. 287/2025 Sb., se mění takto:
1.
V § 1 větě druhé se za slovo „zohlednit“ vkládají slova „i jiné veřejné zájmy,“.
2.
§ 3 včetně nadpisu a poznámek pod čarou č. 69 a 70 zní:
„§ 3
Vymezení pojmů
(1) Pro účely tohoto zákona se vymezují některé základní pojmy takto
a) územní systém ekologické stability krajiny (dále jen „systém ekologické stability“) je
vzájemně propojený soubor přirozených i pozměněných, avšak přírodě blízkých
ekosystémů, které udržují přírodní rovnováhu. Rozlišuje se místní, regionální
a nadregionální systém ekologické stability,
b) významný krajinný prvek jako ekologicky, geomorfologicky nebo esteticky hodnotná část
krajiny utváří její typický vzhled nebo přispívá k udržení její stability. Významnými
krajinnými prvky jsou lesy, rašeliniště, vodní toky, rybníky, jezera, údolní nivy. Dále jsou
jimi jiné části krajiny, které zaregistruje podle § 6 orgán ochrany přírody jako významný
krajinný prvek, zejména mokřady, stepní trávníky, remízy, meze, trvalé travní plochy,
naleziště nerostů a zkamenělin, umělé i přirozené skalní útvary, výchozy a odkryvy
a území, na nichž probíhá přírodě blízká obnova těžbou narušeného území podle plánu
nebo dokumentace uvedených v § 4 odst. 6. Mohou jimi být i cenné plochy porostů
sídelních útvarů včetně historických zahrad a parků,
c) zvláště chráněná část přírody je velmi významná nebo jedinečná část živé či neživé přírody;
může jí být část krajiny, geologický útvar, strom, živočich, rostlina a nerost, vyhlášený ke
zvláštní ochraně státním orgánem podle části třetí nebo páté tohoto zákona,
d) dřevina rostoucí mimo les (dále jen „dřevina“) je strom či keř rostoucí jednotlivě i ve
skupinách ve volné krajině i v sídelních útvarech na pozemcích mimo pozemky určené
k plnění funkcí lesa podle lesního zákona,
e) paleontologický nález je věc, která je významným dokladem nebo pozůstatkem života
v geologické minulosti a jeho vývoje do současnosti,
f)
biotop je soubor veškerých neživých a živých činitelů, které ve vzájemném působení
vytvářejí životní prostředí určitého jedince, druhu, populace, společenstva. Biotop je
takové místní prostředí, které splňuje nároky charakteristické pro druhy rostlin a živočichů,
g) ekosystém je funkční soustava živých a neživých složek životního prostředí, jež jsou
navzájem spojeny výměnou látek, tokem energie a předáváním informací a které se
vzájemně ovlivňují a vyvíjejí v určitém prostoru a čase,
h) krajina je část zemského povrchu s charakteristickým reliéfem, tvořená souborem funkčně
propojených ekosystémů a civilizačními prvky,
i)
přírodní stanoviště je přírodní nebo polopřírodní, lidskou činností pozměněná nebo
podmíněná, suchozemská nebo vodní plocha, která je vymezena na základě geografických
charakteristik a charakteristik živé a neživé přírody,
j)
přírodní stanoviště v zájmu Evropských společenství (dále jen „evropská stanoviště“) jsou
přírodní stanoviště na evropském území členských států Evropských společenství těch
typů, které jsou ohroženy vymizením ve svém přirozeném areálu rozšíření nebo mají malý
přirozený areál rozšíření v důsledku svého ústupu či v důsledku svých přirozených
vlastností nebo představují výjimečné příklady typických charakteristik jedné nebo více
z biogeografických oblastí, a která jsou stanovena právními předpisy Evropských
společenství1d); jako prioritní se označují ty typy evropských stanovišť, které jsou na
evropském území členských států Evropských společenství ohrožené vymizením, za
jejichž zachování mají Evropská společenství zvláštní odpovědnost, a které jsou stanovené
právními předpisy Evropských společenství1g),
k) druhy v zájmu Evropských společenství (dále jen „evropsky významné druhy“) jsou druhy
na evropském území členských států Evropských společenství, které jsou ohrožené,
zranitelné, vzácné nebo endemické, a které jsou stanovené právními předpisy Evropských
společenství1e); jako prioritní se označují evropsky významné druhy, vyžadující zvláštní
územní ochranu, za jejichž zachování mají Evropská společenství zvláštní odpovědnost,
a které jsou stanovené právními předpisy Evropských společenství1e),
l)
evropsky významná lokalita je lokalita vyžadující zvláštní územní ochranu1g) a splňující
podmínky podle § 45a odst. 1, která
1. byla zařazena do seznamu lokalit nacházejících se na území České republiky
vybraných na základě kritérií stanovených právními předpisy Evropských
společenství1g) a vyžadujících územní ochranu (dále jen „národní seznam“), a to až do
doby jejího zařazení do seznamu lokalit významných pro Evropská společenství (dále
jen „evropský seznam“),
2. splňuje podmínky pro zařazení do národního seznamu, ale nebyla tam zařazena,
a vyskytuje se na ní prioritní typ přírodního stanoviště nebo prioritní druh, a o jejímž
zařazení do evropského seznamu se s Evropskou komisí (dále jen „Komise“) jedná,
a to až do doby, kdy se o zařazení nebo nezařazení lokality dohodne Česká republika
s Komisí nebo do rozhodnutí Rady Evropské unie (dále jen „sporná lokalita“), nebo
3. byla zařazena do evropského seznamu,
m) Natura 20001g) je celistvá evropská soustava území se stanoveným stupněm ochrany, která
umožňuje zachovat typy evropských stanovišť1d) a stanoviště evropsky významných
druhů1f) v jejich přirozeném areálu rozšíření ve stavu příznivém z hlediska ochrany nebo
popřípadě umožní tento stav obnovit. Na území České republiky je Natura 2000 tvořena
vymezenými ptačími oblastmi a vyhlášenými evropsky významnými lokalitami,
n) stav přírodního stanoviště z hlediska ochrany se považuje za „příznivý“, pokud jeho
přirozený areál rozšíření a plochy, které v rámci tohoto areálu pokrývá, jsou stabilní nebo
se zvětšují a specifická struktura a funkce, které jsou nezbytné pro jeho dlouhodobé
zachování, existují a budou pravděpodobně v dohledné době i nadále existovat, a stav jeho
typických druhů z hlediska ochrany je příznivý,
o) stav druhu z hlediska ochrany je považován za „příznivý“, jestliže údaje o populační
dynamice příslušného druhu naznačují, že se dlouhodobě udržuje jako životaschopný prvek
svého přírodního stanoviště, a přirozený areál rozšíření druhu není a pravděpodobně
nebude v dohledné budoucnosti omezen, a existují a pravděpodobně budou v dohledné
době i nadále existovat dostatečně velká stanoviště k dlouhodobému zachování jeho
populací,
p) celistvostí evropsky významné lokality anebo ptačí oblasti se rozumí soudržnost
ekologických struktur a funkcí evropsky významné lokality anebo ptačí oblasti posuzovaná
ve vztahu k předmětům jejich ochrany,
q) přírodě blízkou obnovou těžbou narušeného území se rozumí obnova přírodně hodnotných
ekosystémů na území narušeném těžbou ponecháním území samovolnému vývoji,
popřípadě pomocí citlivých zásahů usměrňujících tento vývoj příznivě pro zvláště chráněné
druhy organismů.
(2) Pro účely tohoto zákona se dále vymezují některé základní pojmy takto
a) planě rostoucí rostlina (dále jen „rostlina“) je jedinec nebo kolonie rostlinných druhů
včetně lišejníků a hub, jejichž populace se udržují v přírodě samovolně. Rostlinou jsou
všechny její podzemní i nadzemní části, semena nebo jiná vývojová stádia a jejich části,
b) volně žijící živočich (dále jen „živočich“) je jedinec živočišného druhu, jehož populace se
udržují v přírodě samovolně, a to včetně jedince odchovaného v lidské péči vypuštěného
v souladu s právními předpisy do přírody; živočichem se rozumí všechna vývojová stadia
daného jedince; jedinec zdivočelé populace domestikovaného druhu se za živočicha
nepovažuje,
c) živočich odchovaný v lidské péči je jedinec živočišného druhu narozený a odchovaný
v kontrolovaném prostředí69) jako potomek rodičů získaných v souladu s tímto zákonem
a právními předpisy v oblasti obchodování s ohroženými druhy70),
d) živočišný nebo rostlinný druh je rovněž systematická jednotka nižšího řádu,
e) populace druhu je skupina jedinců téhož druhu rostliny nebo živočicha obývající stejnou
geografickou oblast a samovolně se udržující společnou reprodukcí,
f)
místní populace druhu je část populace druhu žijící na území vymezeném hranicemi
souvislého biotopu daného druhu, případně ohraničeném spojitým výskytem tohoto druhu
v daném místě,
g) biotop druhu je takový biotop, který vytváří životní prostředí splňující nároky
charakteristické pro daný druh rostliny nebo živočicha a je místem trvalého nebo
opakovaného výskytu jedinců tohoto druhu,
h) záchranná stanice je zařízení, které na konkrétně vymezeném území zajišťuje komplexní
péči o všechny živočichy dočasně neschopné přežít ve volné přírodě s cílem navrátit je do
přírody, živočichům trvale neschopným přežít ve volné přírodě poskytuje, je-li to vhodné
a účelné vzhledem k jejich zdravotnímu stavu, odpovídající dlouhodobou péči, poskytuje
informace o příčinách ohrožení a vhodných způsobech ochrany živočichů a může
spolupracovat při provádění opatření k předcházení zraňování nebo úhynu živočichů.
(3) Typy evropských stanovišť a evropsky významné druhy, které se vyskytují na území
České republiky, stanoví Ministerstvo životního prostředí prováděcím právním předpisem.
U evropsky významných druhů označí ty, které vyžadují podle právních předpisů Evropských
společenství zvláštní územní ochranu1f).
_________________
69)
Čl. 1 bod 4 nařízení Komise (ES) č. 865/2006.
70)
Zákon č. 100/2004 Sb.
Nařízení Rady (ES) č. 338/97 o ochraně druhů volně žijících živočichů a planě
rostoucích rostlin regulováním obchodu s nimi.
Nařízení Komise (ES) č. 865/2006.“.
Poznámky pod čarou č. 1, 1a a 1b se zrušují.
3.
V § 4 odst. 1 a 2 se za slova „Ministerstvo životního prostředí“ vkládají slova „po dohodě
s Úřadem rozvoje území České republiky“.
4.
V § 4 odst. 3 se číslo „23“ nahrazuje číslem „21“.
5.
V § 4 odstavec 6 zní:
„(6) Ke stanovení dobývacího prostoru, povolení hornické činnosti, povolení dobývání
ložiska nevyhrazeného nerostu nebo povolení likvidace důlních děl a lomů je nezbytné
vyjádření orgánu ochrany přírody. Při vydávání vyjádření podle věty první, jakož i v dalších
řízeních a při vydávání dalších závazných stanovisek a vyjádření podle tohoto zákona, pokud
se týkají hornické činnosti a sanací a rekultivací území po hornické činnosti, orgány ochrany
přírody prověřují možnosti rekultivace území přírodě blízkou obnovou těžbou narušeného
území, a je-li to možné a účelné, ve svých rozhodnutích, závazných stanoviscích a vyjádřeních
takovou obnovu podporují. Těžbou narušená území, na kterých probíhá přírodě blízká obnova,
zaregistruje orgán ochrany přírody jako významný krajinný prvek.“.
6.
V § 5 odst. 1 se věta druhá zrušuje.
7.
V § 5 odstavec 3 zní:
„(3) Fyzické a právnické osoby jsou povinny při provádění zemědělských, a lesnických
prací, při plánování, provádění a užívání staveb, plánování a provádění terénních úprav, činnosti
prováděné hornickým způsobem, ve vodním hospodářství, v dopravě a energetice postupovat
tak, aby nedocházelo ke zbytečnému úhynu rostlin a zraňování nebo úhynu živočichů nebo
ničení biotopů druhů, včetně narušení migračních tras živočichů, kterému lze zabránit technicky
i ekonomicky dostupnými postupy a opatřeními. Orgán ochrany přírody uloží zajištění či
použití takovýchto postupů nebo opatření, neučiní-li tak povinná osoba sama.“.
8.
V § 5 odst. 4 a 5 se slovo „zastavěném“ nahrazuje slovem „zastavitelném“.
9.
V § 5 odst. 10 se slova „volně žijících“ a „planě rostoucích“ zrušují.
10.
V § 5 odstavec 11 zní:
„(11) Ujmout se živočicha neschopného v důsledku zranění, nemoci nebo jiných okolností
přežít ve volné přírodě, je možné pouze v případě, že nedojde k významnému narušení
přirozených přírodních procesů a vzájemných interakcí mezi živočichy. Kdo se takového
živočicha ujme, musí postupovat tak, aby nebyl znemožněn jeho návrat do přírody. Vyžaduje-
li stav takového živočicha odbornou péči nebo jde-li o ptáka druhu, který volně žije na
evropském území členských států Evropské unie (dále jen „pták“) anebo zvláště chráněného
živočicha, může být ošetření a péče o ně zajištěny pouze prostřednictvím záchranné stanice.“.
11.
V § 5 se odstavce 12 až 14 zrušují.
12.
Poznámka pod čarou č. 4b, která zní: „4b)
Zákon č. 246/1992 Sb., na ochranu zvířat
proti týrání, ve znění pozdějších předpisů.
Zákon č. 449/2001 Sb.
Zákon č. 102/1963 Sb.“, se zrušuje.
13.
V nadpisu § 5a se slova „volně žijících“ zrušují.
14.
V § 5a odst. 1 úvodní části ustanovení se slova „druhů ptáků, kteří volně žijí na evropském
území členských států Evropských společenství (dále jen „ptáci“)“ nahrazují slovem
„ptáků“.
15.
V § 5a odst. 6 se slova „§ 50 až 57“ nahrazují slovy „§ 49 až 56“.
16.
V § 5b odst. 1 se slova „volně žijících“ a „planě rostoucích“ zrušují.
17.
V § 5b odst. 3 písmeno d) zní:
„d) způsob kontrol uplatňování odchylného postupu.“.
18.
V § 5b se na konci odstavce 4 doplňuje věta „Orgán ochrany přírody následně informuje
na úřední desce, případně rovněž dalšími vhodnými způsoby, že podmínky pro uplatnění
postupu povoleného opatřením obecné povahy nastaly.“.
19.
Za § 5b se vkládá nový § 5c, který včetně nadpisu a poznámky pod čarou č. 71 zní:
„§ 5c
Podpora opylovačů
(1) Při provádění zemědělských a lesnických prací, údržbě veřejné zeleně, plánování,
provádění a užívání staveb, plánování a provádění terénních úprav a při údržbě ploch zeleně
v rámci vodního hospodářství a v dopravě a energetice je každý povinen postupovat tak, aby
nedocházelo k zbytečnému poškození biotopů opylovačů71) důležitých zejména z hlediska
získávání potravy, jejich rozmnožování nebo možností úkrytu. Neučiní-li tak povinná osoba
sama, orgán ochrany přírody uloží provedení technicky a ekonomicky dostupných opatření
k zabránění nebo zmírnění poškození biotopů opylovačů; opatření vyžadující povolení změny
dokončené stavby nelze uložit.
(2) Za účelem podpory opylovačů se při zakládání a údržbě veřejné zeleně, provádění
vegetačních úprav a údržbě vegetačních prvků u staveb ve vlastnictví státu, územního
samosprávného celku nebo jimi zřizovaných anebo zakládaných právnických osob využívají
opatření k obnově biotopů opylovačů v rámci této veřejné zeleně, vegetačních úprav nebo
vegetačních prvků u staveb, v rozsahu který charakter jejich využití umožňuje.
(3) Za účelem podpory opylovačů se dále při zatravňování a obnově travních porostů
přednostně využívá takových směsí osiv a postupů, které přispívají k zachování a podpoře
pestrého druhového složení travních porostů s dostatečným zastoupením bylin odpovídajících
přiměřeně podmínkám a přirozené druhové skladbě a genetické diverzitě rostlin v rámci
přírodních stanovišť v daném místě. Využití nepůvodních druhů rostlin a kříženců, včetně směsí
osiv, v nichž jsou obsaženy nepůvodní druhy nebo kříženci, je možné pouze za podmínek
stanovených v § 5 odst. 4 až 6.
(4) Prodej a nabízení za účelem prodeje živých jedinců druhů čmeláků a pačmeláků rodu
Bombus, nejde-li o zvláště chráněný druh živočicha, stejně jako vypouštění a rozšiřování živých
jedinců těchto druhů, pokud jde o jedince, kteří nemají původ ve volné přírodě České republiky,
je možné jen se souhlasem orgánu ochrany přírody. Orgán ochrany přírody souhlas vydá
v případě, že nehrozí riziko narušení genofondu druhů čmeláků a pačmeláků rodu Bombus,
nebo jsou přijaty účinné prostředky anebo opatření k omezení úniku pohlavních jedinců, kteří
nemají původ ve volné přírodě, do přírody. Souhlas předává orgán ochrany přírody do evidence
druhové ochrany.
________________
71)
Čl. 3 odst. 12 nařízení Evropského parlamentu a Rady (EU) 2024/1991 ze dne 24. června
2024 o obnově přírody a o změně nařízení (EU) 2022/869.“.
20.
V § 6 odst. 1 větě poslední se slova „ , úřadu územního plánování“ zrušují.
21.
V § 8 odst. 2 větě první se za slova „těchto zařízení“ vkládají slova „ , k odstraňování
dřevin v ochranném pásmu vodovodu nebo kanalizace prováděném při provozování
těchto zařízení“ a ve větě druhé se číslo „15“ nahrazuje číslem „30“.
22.
V § 12 odst. 2 se slova „obecně závazným právním předpisem“ nahrazují slovy „po
dohodě s Úřadem rozvoje území České republiky vyhláškou“.
23.
V § 12 odst. 4 se slovo „zastavěném“ nahrazuje slovem „zastavitelném“, slova
„a v zastavitelných plochách, pro které je územním plánem nebo regulačním plánem
stanoveno plošné a prostorové uspořádání a podmínky ochrany krajinného rázu
dohodnuté s orgánem ochrany přírody9a)“ se nahrazují slovy „ , koridoru pro stavební
záměr nebo ploše těžby vymezeném v souladu se stanoviskem orgánu ochrany přírody v
územně plánovací dokumentaci“ a slova „a slouží k plnění podmínek podle § 22 odst. 2
písm. c) zákona o elektronických komunikacích69)“ se zrušují.
Poznámka pod čarou č. 9a se zrušuje.
24.
V § 13g se doplňují odstavce 3 a 4, které znějí:
„(3) Stanoví-li Ministerstvo životního prostředí opatření k odstranění invazního
nepůvodního druhu na unijním seznamu podle odstavce 2 rozhodnutím a hrozí-li nebezpečí
z prodlení, lze toto rozhodnutí vydat jako první úkon v řízení. Odvolání proti rozhodnutí
o stanovení opatření k odstranění invazního nepůvodního druhu na unijním seznamu podle
odstavce 2 nemá odkladný účinek.
(4) Stanoví-li Ministerstvo životního prostředí opatření k odstranění invazního
nepůvodního druhu na unijním seznamu podle odstavce 2 opatřením obecné povahy, lhůta pro
uplatnění připomínek podle § 172 odst. 4 správního řádu činí 5 dnů a lhůta pro uplatnění
námitek podle § 172 odst. 5 správního řádu činí 10 dnů. Opatření obecné povahy podle odstavce
2 nabývá účinnosti dnem jeho vyvěšení na úřední desce Ministerstva životního prostředí;
opatření obecné povahy podle odstavce 2 se zveřejní rovněž na úředních deskách krajských
úřadů, jejichž správních obvodů se týká. Hrozí-li nebezpečí z prodlení, lze opatření obecné
povahy podle odstavce 2 vydat bez řízení o návrhu opatření obecné povahy.“.
25.
V § 13h odst. 3 se za slovo „možné“ vkládají slova „ , pokud jej umožňují zásady regulace
nebo bližší podmínky uplatňování zásad regulace,“ a na konci odstavce se doplňuje věta
„Žadatel o povolení je povinen zpracovat pohotovostní plán, a to v souladu s prováděcím
právním předpisem vydaným podle § 13d odst. 1; výrok o schválení pohotovostního
plánu je součástí povolení.“.
26.
V § 13j odst. 1 se za text „čl. 8 odst. 1“ vkládají slova „nebo podle čl. 19 odst. 2“.
27.
V § 13j se na konci odstavce 2 doplňují věty „Dojde-li po provedení registrace ke změně
v osobě vlastníka nebo držitele jedince invazního nepůvodního druhu živočicha na
unijním seznamu, oznámí tuto změnu nový vlastník nebo držitel prostřednictvím
evidence druhové ochrany nejpozději do 30 dnů ode dne, kdy k ní došlo. Nový vlastník
nebo držitel jedince invazního nepůvodního druhu živočicha na unijním seznamu je
povinen zabezpečit splnění podmínek stanovených v čl. 31 odst. 1 nařízení Evropského
parlamentu a Rady (EU) č. 1143/2014 a jedná-li se o jedince, který je zároveň druhem
zvířete vyžadujícího zvláštní péči podle zákona na ochranu zvířat proti týrání, musí být
v době předání jedince držitelem povolení k chovu druhu zvířat vyžadujících zvláštní péči
podle tohoto zákona, ve kterém je tento druh živočicha uveden.“.
28.
V § 13j odstavec 3 zní:
„(3) Vlastník nebo držitel jedince invazního nepůvodního druhu živočicha na unijním
seznamu, u něhož byl stanoven zákaz takový druh držet nebo chovat, je oprávněn umístit jej do
zařízení určeného k tomu Ministerstvem životního prostředí nebo do zařízení, které je
oprávněno využívat jedince daného invazního nepůvodního druhu živočicha na unijním
seznamu na základě povolení vydaného podle čl. 8 odst. 1 nařízení Evropského parlamentu
a Rady (EU) č. 1143/2014 podle § 13d odst. 1. Toto zařízení může jedince invazního
nepůvodního druhu živočicha na unijním seznamu přijmout, pokud disponuje dostatečnou
kapacitou a je schopno splnit podmínky pro jeho držení a využívání stanovené v čl. 31 odst. 1
nařízení Evropského parlamentu a Rady (EU) č. 1143/2014. Umístěním do tohoto zařízení
přechází vlastnické právo k jedinci invazního nepůvodního druhu živočicha na unijním
seznamu na toto zařízení.“.
29.
V § 16 odst. 2 úvodní části ustanovení se slovo „zastavěná“ nahrazuje slovem
„zastavitelná“ a slova „a zastavitelné plochy obcí“ se zrušují.
30.
V § 16a odst. 2 se slovo „zastavěná“ nahrazuje slovem „zastavitelná“.
31.
V § 16a odst. 3 písm. d), § 16b písm. a), § 16c odst. 1 písm. a) a § 16d písm. b) a c) se
slovo „zastavěné“ nahrazuje slovem „zastavitelná“ a slova „a zastavitelné plochy obcí“
se zrušují.
32.
V § 18 odst. 1 písm. d) se slova „zastavěných územích, zastavitelných plochách,
popřípadě zastavitelném území“ nahrazují slovy „zastavitelných územích“.
33.
V § 18 odst. 7 se slovo „zastavěná“ nahrazuje slovem „zastavitelná“ a slova
„a zastavitelné plochy obcí“ se zrušují.
34.
V § 26 odst. 1 písm. a) se slova „se souhlasem orgánu“ nahrazují slovem „orgánem“.
35.
V § 26 odst. 1 se písmeno b) zrušuje.
Dosavadní písmena c) až i) se označují jako písmena b) až h).
36.
V § 26 odst. 1 se na začátek písmene b) vkládají slova „mimo zastavitelné území obce“.
37.
V § 26 odst. 1 písm. b) se slova „se souhlasem orgánu“ nahrazují slovem „orgánem“
a slova „kromě vjezdu a setrvávání vozidel orgánů státní správy, vozidel potřebných pro
lesní a zemědělské hospodaření, obranu státu a ochranu státních hranic, požární ochranu
a zdravotní a veterinární službu,“ se nahrazují slovy „s výjimkou vjezdu a setrvávání
vozidel základních složek integrovaného záchranného systému, obecní policie,
ozbrojených sil České republiky, Celní správy České republiky, Vězeňské služby České
republiky, dalších orgánů veřejné moci, veterinární služby, vozidel správců vodních toků
a správců povodí, provozovatelů vodovodů a kanalizací, energetických soustav,
ropovodů, produktovodů a veřejných komunikačních sítí při plnění jejich úkolů
a povinností nebo vozidel potřebných pro lesní a zemědělské hospodaření v chráněné
krajinné oblasti a vozidel vlastníků a nájemců nemovitých věcí v souvislosti s jejich
užíváním, pokud nejde o obytná vozidla a obytné přívěsy v souvislosti s jejich rekreačním
nebo komerčním využíváním,“.
38.
V § 26 odst. 1 se na konci textu písmene g) doplňují slova „mimo zastavitelná území obcí
nebo dálnice a silnice I. a II. třídy“.
39.
V § 26 odst. 2 písm. c) se slova „současnou skladbu a plochy kultur“ nahrazují slovy
„stávající druh pozemku a způsob využití pozemku“.
40.
V § 26 odst. 3 písm. a) se slovo „zastavěná“ nahrazuje slovem „zastavitelná“.
41.
V § 26 odst. 3 písm. c) se slova „se souhlasem orgánu“ nahrazují slovem „orgánem“.
42.
V § 26 se na konci odstavce 3 tečka nahrazuje čárkou a doplňuje se písmeno d), které zní:
„d) tábořit a rozdělávat ohně mimo zastavitelná území obcí a místa vyhrazená orgánem
ochrany přírody, s výjimkou vlastníků a oprávněných uživatelů pozemků při jejich běžném
obhospodařování.“.
43.
V § 37 odst. 2 se za slovo „území“ vkládají slova „s výjimkou zastavitelného území
ochranného pásma národního parku a území do vzdálenosti 150 m od hranice
zastavitelného území“.
44.
V § 37 odst. 3 úvodní části ustanovení se slovo „dále“ zrušuje.
45.
V § 37 odst. 3 písm. a) a d) se slovo „zastavěná“ nahrazuje slovem „zastavitelná“.
46.
V § 37 odst. 4 se za slovo „odstavců“ vkládá číslo „1,“ a za slovo „rozhodnutím,“ se
vkládají slova „závazným stanoviskem,“.
47.
V § 39 odst. 1 se věta druhá nahrazuje větou „Pro evropsky významné lokality lze namísto
vyhlášení národní přírodní rezervace, národní přírodní památky, přírodní rezervace nebo
přírodní památky, včetně jejich ochranných pásem, prohlásit území za chráněné, pokud
již není zvláště chráněno podle tohoto zákona, na základě písemné smlouvy uzavřené
mezi vlastníkem dotčeného pozemku a příslušným orgánem ochrany přírody.“ a ve větě
třetí se slova „chránit i“ nahrazují slovy „namísto vydání rozhodnutí podle § 46 odst. 1
prohlásit strom za památný nebo chránit i jiné“.
48.
V § 43 odst. 3 se za slovo „tras“ vkládají slova „a vyznačení cest“ a za text „§ 17 odst. 2,“
se vkládá text „§ 26,“.
49.
V § 44 odst. 1 se slova „ , její užívání, kolaudaci nebo“ nahrazují slovy „nebo její“.
50.
V § 44 odst. 3 písm. a) se slovo „zastavěném“ nahrazuje slovem „zastavitelném“.
51.
V § 44 odst. 3 písmeno b) zní:
„b) v zastavitelném území, pokud byly v tomto území stanoveny prvky regulačního plánu,
nebo byl pro ně vydán regulační plán.“.
52.
V § 44 odst. 5 se za slovo „rozhodnutím,“ vkládají slova „závazným stanoviskem,“.
53.
Za § 44a se vkládá nový § 44b, který včetně nadpisu a poznámky pod čarou č. 72 zní:
„§ 44b
Povinnosti provozovatele motorového vozidla ve zvláště chráněném území
Provozovatel motorového vozidla zajistí, aby při jeho užití ve zvláště chráněném území
byly dodržovány zákazy vjezdu a setrvávání motorových vozidel stanovené tímto zákonem
nebo aby nedošlo k vjezdu nebo setrvání motorového vozidla, k němuž je nezbytný souhlas
orgánu ochrany přírody, bez tohoto souhlasu. Provozovatel motorového vozidla a osoba, které
provozovatel svěřil motorové vozidlo do užívání, nejde-li se o motorové vozidlo evidované ve
zvláštním registru podle zákona o podmínkách provozu vozidel na pozemních komunikacích72),
jsou povinni na výzvu orgánu ochrany přírody sdělit mu skutečnosti potřebné k určení
totožnosti řidiče motorového vozidla podezřelého z porušení ustanovení tohoto zákona; tímto
ustanovením není dotčeno ustanovení jiného právního předpisu upravující právo odepřít
výpověď nebo podání vysvětlení.
__________
72)
§ 7h zákona č. 56/2001 Sb., o podmínkách provozu vozidel na pozemních
komunikacích.“.
54.
V § 45f odst. 1 se za číslo „54“ vkládá text „ , 55, 55a“.
55.
V § 45f odst. 2 se slova „q) a r)“ nahrazují slovy „l) a m)“.
56.
V § 45i odst. 1 se písmeno c) zrušuje.
Dosavadní písmena d) a e) se označují jako písmena c) a d).
57.
V § 46 odst. 1 se slova „ , jejich skupiny a stromořadí“ nahrazují slovy „rostoucí
samostatně, ve skupinách nebo ve stromořadí“.
58.
V § 46 odstavce 2 až 4 znějí:
„(2) K zabezpečení ochrany památného stromu před škodlivými vlivy z okolí stanoví orgán
ochrany přírody v rozhodnutí o vyhlášení památného stromu ochranné pásmo. Jako ochranné
pásmo památného stromu stanoví orgán ochrany přírody část území zpravidla ve tvaru kruhu,
jehož střed tvoří střed kmene památného stromu a jehož poloměr činí desetinásobek průměru
kmene měřeného ve výši 130 cm nad zemí. Při vyhlašování památných stromů rostoucích ve
skupině a ve stromořadí tvoří ochranné pásmo soubor ochranných pásem stanovených pro
jednotlivé památné stromy tvořících skupinu nebo stromořadí. Orgán ochrany přírody je
oprávněn vymezit ochranné pásmo památného stromu rostoucího samostatně, památných
stromů rostoucích ve skupině a památných stromů rostoucích ve stromořadí odchylně,
vyžaduje-li to zabezpečení ochrany památného stromu nebo jiné důvody plynoucí z místních
podmínek.
(3) Památné stromy je zakázáno poškozovat, ničit nebo škodlivě zasahovat do jejich
přirozeného vývoje. Výjimku ze zákazů na ochranu památného stromu může orgán ochrany
přírody povolit na žádost toho, kdo zamýšlí uskutečnit škodlivý zásah, v případě, kdy jiný
veřejný zájem převažuje nad zájmem ochrany památného stromu. Ošetřování památného
stromu lze provádět jen se souhlasem orgánu ochrany přírody; ošetřováním památného stromu
se rozumí provádění zásahů k udržení nebo zlepšení stavu památného stromu, zejména
provádění nezbytných řezů, stabilizace koruny stromu nebo zlepšování stanovištních podmínek
v kořenovém prostoru stromu za účelem jeho zachování.
(4) Jakoukoliv činnost v ochranném pásmu, která by mohla mít na památný strom škodlivý
vliv, zejména výstavbu, terénní úpravy, odvodňování nebo chemizaci, lze provádět jen se
souhlasem orgánu ochrany přírody. V pochybnostech o škodlivosti činnosti lze orgán ochrany
přírody požádat o poskytnutí předběžné informace podle správního řádu.“.
59.
V § 46 se doplňuje odstavec 5, který zní:
„(5) Zrušit ochranu památného stromu může orgán ochrany přírody z důvodu, pro který lze
povolit výjimku podle odstavce 3, nebo pokud památný strom zanikl anebo byl poškozen do
takové míry, že důvod jeho ochrany pominul. Dnem nabytí právní moci rozhodnutí o zrušení
ochrany památného stromu zaniká rovněž jeho ochranné pásmo. Ruší-li se ochrana památného
stromu, který je součástí skupiny stromů nebo stromořadí, dnem nabytí právní moci rozhodnutí
o zrušení ochrany památného stromu zaniká pouze ochranné pásmo tohoto jednotlivého
stromu.“.
60.
V § 47 odst. 1 se za slovo „stromy“ vkládají slova „a jejich ochranná pásma“.
61.
V § 47 se na konci odstavce 2 doplňuje věta „Označení památného stromu a odstranění
označení památného stromu, jehož ochrana byla zrušena, zajistí orgán ochrany přírody.“.
62.
V § 48 odstavce 2 až 5 znějí:
„(2) Zvláště chráněné druhy rostlin a živočichů se zařazují do
a) I. kategorie ochrany, kam se zařadí zvláště chráněné druhy rostlin a živočichů, které je
s ohledem na míru jejich ohrožení a vzácnost zapotřebí chránit nejpřísněji prostřednictvím
ochrany jednotlivých jedinců,
b) II. kategorie ochrany, kam se zařadí ostatní zvláště chráněné druhy rostlin a živočichů
vyžadující s ohledem na převládající příčiny jejich ohrožení ochranu jedinců, u nichž však
současně jejich ohrožení není spojeno s běžným obhospodařováním pozemků nebo je pro
jejich ochranu vhodný způsob obhospodařování pozemků potřebný; do II. kategorie
ochrany se zařadí rovněž zvláště chráněné druhy rostlin a živočichů, u nichž potřeba
ochrany jedinců vyplývá z požadavků mezinárodních úmluv nebo předpisů Evropské unie,
pokud nebyly zařazeny do I. kategorie, nebo
c) III. kategorie ochrany, kam se zařadí zvláště chráněné druhy rostlin a živočichů, které
s ohledem na jejich nároky a způsob života není nezbytné chránit na úrovni jednotlivých
jedinců, ale potřebná je ochrana jejich místních populací nebo biotopů.
(3) Seznam zvláště chráněných druhů rostlin a živočichů a jejich zařazení do příslušné
kategorie ochrany stanoví Ministerstvo životního prostředí vyhláškou. Ministerstvo vyhláškou
rovněž stanoví, při zohlednění jiných veřejných zájmů, zejména energetické a surovinové
bezpečnosti, rozvoje obcí a naplňování cílů a úkolů územního plánování a zájmu na
obhospodařování zemědělských a lesních pozemků, kritéria pro vymezení místních populací
a biotopů zvláště chráněných druhů rostlin a živočichů či jejich skupin zejména na základě
a) aktuálního výskytu a jeho charakteru se zohledněním přirozených či umělých překážek
limitujících výskyt a přirozené šíření,
b) charakteristických ekologických a biotopových nároků nebo nároků na klíčové části
biotopů nezbytných zejména pro rozmnožování, růst a vývoj, zajištění živin nebo zdrojů
potravy, možností úkrytu, nocování, zimování nebo pro shromažďování či odpočinek
jedinců,
c) charakteristických životních projevů, schopnosti přirozeného šíření a prostorových nároků
či odlišnosti populací na úrovni jejich genetické diverzity.
(4) Agentura ve spolupráci s ostatními orgány ochrany přírody průběžně shromažďuje
informace o výskytu zvláště chráněných druhů rostlin a živočichů a vytváří podmínky pro
využití informací rovněž od odborných institucí i veřejnosti. Informace o výskytu zvláště
chráněných druhů rostlin a živočichů poskytuje Agentura prostřednictvím informačního
systému ochrany přírody; pro zajištění informování vlastníků pozemků o výskytu zvláště
chráněných druhů rostlin a živočichů při tom vytváří technické podmínky, které umožňují
přístup k aktuálním údajům.
(5) Zpracovatel lesního hospodářského plánu při zpracování plánu převezme informaci
o výskytu zvláště chráněných druhů rostlin a živočichů z informačního systému ochrany
přírody k navrhovanému počátku platnosti plánu; výskyt zjištěný po schválení lesního
hospodářského plánu, který by mohl být významný z hlediska lesního hospodaření, oznámí
orgán ochrany přírody vlastníkovi pozemku písemně nebo dle dohody jinou vhodnou formou.“.
63.
V § 48 se doplňuje odstavec 6, který zní:
„(6) Pro účely územního plánování podle stavebního zákona poskytuje Agentura vymezení
biotopu vybraných zvláště chráněných druhů rostlin a živočichů.“.
64.
Za § 48 se vkládá nový § 48a, který včetně nadpisu zní:
„§ 48a
Předcházení ohrožení zvláště chráněných druhů
Každý je při své činnosti povinen postupovat tak, aby nedocházelo ke zbytečnému úhynu
zvláště chráněných rostlin nebo zraňování a úhynu zvláště chráněných živočichů. Neučiní-li tak
povinná osoba sama, orgán ochrany přírody uloží provedení technicky a ekonomicky
dostupných opatření k zabránění takovému úhynu a zraňování; nejde-li o opatření vyžadující
povolení změny dokončené stavby.“.
65.
§ 49 včetně nadpisu zní:
„§ 49
Společná ochrana zvláště chráněných druhů
Zakazuje se poškození a ničení biotopu nebo místní populace zvláště chráněného druhu
rostliny nebo živočicha a jejího genofondu. Za poškození biotopu zvláště chráněného druhu
rostliny nebo živočicha se považuje takový zásah, který vede k jeho významnému nebo
trvalému poškození, v jehož důsledku přestane splňovat nároky daného druhu nebo vede
k významnému nebo trvalému ohrožení, poškození nebo zničení jeho místní populace.“.
66.
Za § 49 se vkládají nové § 49a až 49c, které včetně nadpisů znějí:
„§ 49a
Základní ochranné podmínky zvláště chráněných druhů
(1) U zvláště chráněných druhů rostlin zařazených v I. nebo II. kategorii ochrany se
zakazuje škodlivě zasahovat do jejich přirozeného vývoje, nejde-li o jedince pěstovaného
v kulturách získaných povoleným způsobem, zejména jedince těchto druhů nebo jeho část
a) sbírat, trhat, poškozovat, ničit a
b) držet, pěstovat, dopravovat, prodávat, vyměňovat nebo nabízet za účelem prodeje anebo
výměny.
(2) U zvláště chráněných druhů živočichů zařazených v I. nebo II. kategorii ochrany se
zakazuje škodlivě zasahovat do jejich přirozeného vývoje, zejména
a) jedince těchto druhů ve všech vývojových stádiích nebo jeho část sbírat, chytat, rušit, ničit,
zraňovat, usmrcovat,
b) poškozovat nebo ničit místa jejich rozmnožování a odpočinku, zejména hnízda, hnízdiště,
nory, jiná jejich přirozená nebo umělá sídla, nocoviště a shromaždiště, u zvláště
chráněných druhů ptáků odebírat nebo sbírat jejich vejce ve volné přírodě a držet tato vejce,
i jsou-li prázdná,
c) jedince těchto druhů ve všech vývojových stádiích nebo jeho část držet, chovat,
dopravovat, prodávat, vyměňovat nebo nabízet za účelem prodeje anebo výměny; jedná-li
se o jedince odchovaného v lidské péči, postupuje se podle § 55.
(3) Zákazy podle odstavců 1 a 2 se nevztahují na poddruh zvláště chráněného druhu
rostliny nebo živočicha zařazeného do I. nebo II. kategorie ochrany, který není evropsky
významným druhem, pokud se na území České republiky přirozeně nevyskytuje.
(4) Zákazy podle odstavce 1 písm. a) a odstavce 2 písm. a) se nevztahují na nezáměrné
zásahy do přirozeného vývoje jedince zvláště chráněného druhu rostliny nebo živočicha
zařazeného v II. kategorii ochrany uskutečněné v rámci povolené stavby splňující požadavky
na ochranu zvláštně chráněných druhů rostlin nebo živočichů podle § 148 odst. 2 stavebního
zákona nebo běžného lesnického nebo zemědělského obhospodařování na k tomu určených
plochách nebo při obdobných činnostech v rámci péče o veřejnou zeleň, pokud jimi nedochází
k poškození a ničení jejich biotopu nebo místní populace. Za běžné obhospodařování se
nepovažují změny druhu a způsobu využití pozemku, nejde-li o změny povolené podle
stavebního zákona, a poškozování ekologicky významných prvků. Za běžné obhospodařování
se dále nepovažují činnosti, kterými dochází k podstatné změně hydrologických půdních
poměrů nebo vodního režimu území, půdního povrchu nebo chemických vlastností prostředí.
Ministerstvo životního prostředí stanoví vyhláškou podrobnější charakteristiku podstatných
změn hydrologických půdních poměrů a vodního režimu území, půdního povrchu
a chemických vlastností prostředí s ohledem na nároky jednotlivých zvláště chráněných druhů
rostlin nebo živočichů anebo jejich skupin.
(5) Zákazy podle odstavce 1 písm. a) a odstavce 2 písm. a) se nevztahují na nezáměrné
zásahy způsobené provozem vozidla nebo jiného dopravního prostředku nebo průchodem
volnou krajinou, pokud taková činnost není v místě zakázána.
(6) Orgán ochrany přírody může s vlastníkem nebo uživatelem pozemku, na němž se
vyskytuje zvláště chráněný druh rostliny nebo živočicha, uzavřít dohodu o způsobu
hospodaření nebo péči o pozemek, které přispěje k zachování místní populace druhu a jeho
biotopu. Pokud dohodnutý způsob hospodaření nebo péče o pozemek zahrnuje činnosti, pro
které by jinak bylo vyžadováno povolení výjimky ze zákazů na ochranu zvláště chráněných
druhů podle § 56 odst. 1, a orgán ochrany přírody ověří naplnění důvodů pro povolení této
výjimky, uzavřená dohoda o způsobu hospodaření tuto výjimku nahrazuje; v dohodě se tato
skutečnost uvede.
§ 49b
Nakládání s mrtvými jedinci zvláště chráněných druhů
(1) Zákazy podle § 49a odst. 1 a 2 se vztahují rovněž na mrtvého jedince zvláště
chráněného druhu rostliny nebo živočicha zařazeného v I. nebo II. kategorii ochrany, jeho část
a výrobek, u něhož je z průvodního dokumentu, obalu, značky, etikety nebo jiných okolností
patrné, že je vyroben z jedince takového druhu. To neplatí pro zákaz držení a dopravy, jedná-li
se o
a) mrtvého jedince, jeho část nebo výrobek z něj dovezené do České republiky, prokáže-li
držitel zákonný původ takového jedince, jeho části nebo výrobku z něj podle § 54 odst. 1
a nakládání s tímto jedincem, jeho částí nebo výrobkem z něj je v souladu s účelem dovozu,
b) mrtvého jedince odebraného z přírody před datem přistoupení České republiky k Evropské
unii, jeho část nebo výrobek z něj, nebo
c) nalezené pero zvláště chráněného druhu ptáka držené pro vlastní potřebu.
(2) Držitel mrtvého jedince zvláště chráněného druhu rostliny nebo živočicha zařazeného
v I. nebo II. kategorii ochrany podle odstavce 1 písm. a) nebo b), jeho části nebo výrobku z něj
je povinen provést jeho registraci prostřednictvím evidence druhové ochrany do 30 dnů ode dne
jeho nabytí; jedná-li se o mrtvého jedince druhu, který v době nabytí držitelem nebyl zařazen
v I. nebo II. kategorii ochrany, je jeho držitel povinen provést registraci do 1 roku ode dne
zařazení druhu na seznam zvláště chráněných druhů rostlin a živočichů v I. nebo II. kategorii
ochrany. Registrace se nevyžaduje, jedná-li se o jedince zvláště chráněného druhu, jeho část
nebo výrobek z něj držený jako součást sbírky muzejní povahy ve vlastnictví České republiky,
územního samosprávného celku, veřejné vysoké školy nebo veřejné výzkumné instituce
zapsané v centrální evidenci sbírek vedené podle zákona o ochraně sbírek muzejní povahy nebo
držený jako součást souboru chráněného jako kulturní památka.
(3) Podmínkou registrace mrtvého jedince zvláště chráněného druhu rostliny nebo
živočicha zařazeného v I. nebo II. kategorii ochrany je jeho nezaměnitelné a trvalé označení
nebo jiná jeho nezaměnitelná a trvalá identifikace jeho držitelem. Bližší podmínky
nezaměnitelného a trvalého označení a jiného způsobu nezaměnitelné a trvalé identifikace
mrtvých jedinců zvláště chráněných druhů rostlin a živočichů zařazených v I. nebo II. kategorii
ochrany stanoví Ministerstvo životního prostředí vyhláškou.
§ 49c
Ochrana evropsky významných druhů
Ustanovení § 49a odst. 1 a 2 a § 49b se obdobně použijí rovněž na jedince evropsky
významného druhu rostliny nebo živočicha, u nějž je předpisy Evropské unie vyžadována
ochrana na úrovni jedince, který se nevyskytuje jako volně žijící v České republice; v případě,
že pro jedince byla vydána obdobná výjimka ze zákazů v jiném členském státě Evropské unie,
postupuje se podle § 56 odst. 6.“.
67.
§ 50 včetně nadpisu a poznámky pod čarou č. 73 zní:
„§ 50
Ochrana zvláště chráněných druhů zařazených v III. kategorii ochrany
(1) Každý, kdo odebere z přírody jedince zvláště chráněného druhu rostliny nebo živočicha
zařazeného v III. kategorii ochrany, je povinen tento odběr bez zbytečného odkladu zaznamenat
do nálezové databáze ochrany přírody. Tyto jedince je dovoleno odebrat, držet a využívat jen
v rozsahu a způsobem, které neohrozí místní populaci a nepoškodí biotop druhu, není-li takové
držení nebo využívání v rozporu s jinými právními předpisy73); prodej nebo nabízení za účelem
prodeje jedince, jeho části nebo výrobku z něj se zakazuje.
(2) Orgán ochrany přírody je oprávněn omezit odběr jedinců zvláště chráněného druhu
rostliny nebo živočicha zařazeného v III. kategorii ochrany z přírody, pokud by mohlo dojít
k ohrožení místní populace druhu nebo je odebírání a využívání zvláště chráněného druhu
rostliny nebo živočicha zařazeného v III. kategorii ochrany z přírody nezbytné upravit
s ohledem na zachování stavu druhu z hlediska ochrany; orgán ochrany přírody je oprávněn
stanovit množství jedinců odebíraných z přírody, období, místo a postup tohoto odebírání
a další podmínky pro odebírání a využívání těchto jedinců.
________________
73)
Například zákon č. 246/1992 Sb., ve znění pozdějších předpisů, zákon č. 449/2001 Sb.,
ve znění pozdějších předpisů.“.
68.
§ 52 včetně skupinového nadpisu zní:
„Nástroje aktivní péče o ohrožené druhy a biotopy
§ 52
(1) Orgány ochrany přírody při provádění aktivní péče o vzácné a ohrožené druhy rostlin
a živočichů a biotopy vychází z Červených seznamů ohrožených druhů a biotopů (dále jen
„Červený seznam“).
(2) Červené seznamy vydává Agentura pro území České republiky podle kritérií
stanovených Mezinárodní unií ochrany přírody za účelem vyjádření míry ohrožení druhů
rostlin, živočichů a biotopů na základě odborných podkladů o změnách stavu druhů
a životaschopnosti jejich populací nebo stavu a míře ohrožení biotopů.
(3) Červené seznamy se zveřejňují v informačním systému ochrany přírody.“.
69.
Za § 52 se vkládají nové § 52a a 52b, které znějí:
„§ 52a
(1) Za účelem snížení míry ohrožení vybraných vzácných a ohrožených druhů rostlin
a živočichů a biotopů se zpracovávají záchranné programy na celostátní úrovni a regionální
akční plány jako odborné koncepční dokumenty, které stanoví souhrn opatření aktivní péče.
(3) Za účelem zmírnění střetů mezi zájmy člověka na využívání krajiny a životními projevy
vybraných zvláště chráněných druhů živočichů se zpracovávají programy péče.
(4) Záchranné programy, regionální akční plány a programy péče se evidují v ústředním
seznamu a zveřejňují v informačním systému ochrany přírody. Informace o schválení
záchranného programu a programu péče se zveřejňuje rovněž ve Věstníku Ministerstva
životního prostředí.
(5) Záchranné programy, regionální akční plány a programy péče jsou podkladem pro jiné
plánovací dokumenty a pro vydávání rozhodnutí, závazných stanovisek a dalších správních
úkonů podle tohoto zákona; orgány ochrany přírody postupují při výkonu své působnosti tak,
aby přispívaly k naplňování záchranných programů, regionálních akčních plánů a programů
péče.
§ 52b
(1) Vypustit zvláště chráněného živočicha odchovaného v lidské péči do přírody nebo vysít
anebo vysadit uměle vypěstovanou20a) zvláště chráněnou rostlinu mimo kulturu a zastavitelné
území obce lze pouze se souhlasem orgánu ochrany přírody.
(2) Orgán ochrany přírody může souhlas udělit v případě, že
a) nehrozí riziko zhoršení stavu volně žijící nebo planě rostoucí populace druhu,
b) jde o vypuštění, vysetí nebo vysazení v areálu původního výskytu daného druhu za účelem
obnovy jeho populace nebo stabilizace nebo posílení populací stávajících a
c) vypuštění, vysetí nebo vysazení je v souladu se záchranným programem nebo regionálním
akčním plánem schváleným pro daný druh, pokud byly schváleny.
(3) Orgán ochrany přírody souhlas neudělí, pokud by
a) k vypuštění, vysetí nebo vysazení mělo dojít v ploše nebo koridoru pro veřejnou dopravní
anebo technickou infrastrukturu vymezené v územně plánovací dokumentaci, nebo
b) vypuštění, vysetí nebo vysazení bylo v rozporu s budoucím využitím území vymezeným
v územně plánovací dokumentaci a toto budoucí využití území by neumožňovalo
dlouhodobé zachování populace tohoto druhu.“.
70.
§ 54 včetně nadpisu zní:
„§ 54
Prokazování zákonného původu
(1) Kdo drží, chová, pěstuje, dopravuje, prodává, vyměňuje, nabízí za účelem prodeje nebo
výměny nebo zpracovává zvláště chráněnou rostlinu, zvláště chráněného živočicha, ptáka nebo
jedince invazního nepůvodního druhu na unijním seznamu, u kterých je v § 5a, 49a, 49b, 49c
nebo 50 anebo v čl. 7 nařízení Evropského parlamentu a Rady (EU) č. 1143/2014 stanoven
zákaz takového způsobu nakládání, nebo rostlinu a živočicha chráněného podle mezinárodních
úmluv nebo podle zvláštního právního předpisu4a) o dovozu a vývozu ohrožených druhů, je
povinen prokázat jejich zákonný původ. V případě jedinců poddruhu zvláště chráněného druhu
rostliny nebo živočicha zařazeného do I. nebo II. kategorie ochrany, který se na území České
republiky přirozeně nevyskytuje, se za prokázání zákonného původu považuje prokázání
způsobu nabytí takového jedince a jeho příslušnost k danému poddruhu.
(2) U nezaměnitelně označených nebo identifikovatelných jedinců odebraných podle § 89
nebo zákona upravujícího obchodování s ohroženými druhy4a) se za zákonný původ považuje
smlouva o převodu odebrané věci podle § 89 odst. 6.
(3) Kdo drží, nabízí k prodeji či zpracovává věc uvedenou v odstavci 1 nebo s ní jinak
nakládá podle odstavce 1, je povinen
a) na vyžádání orgánů ochrany přírody nebo stráže přírody prokázat svoji totožnost a
b) poskytnout orgánu ochrany přírody nezbytnou součinnost pro účely prokázání zákonného
původu této věci, včetně umožnění její prohlídky a identifikace, prohlídky místa jejího
držení nebo jiného nakládání s ní anebo jejího předvedení na určené místo.“.
71.
V části páté se pod označení hlavy druhé vkládá nadpis, který zní: „DRŽENÍ
ŽIVOČICHŮ ODCHOVANÝCH V LIDSKÉ PÉČI“.
72.
§ 55 zní:
„§ 55
(1) Orgány ochrany přírody vydávají rozhodnutí o tom, že se jedná o živočicha
odchovaného v lidské péči (dále jen „osvědčení“)20c). Účastníkem řízení o vydání osvědčení je
pouze žadatel, § 70 odst. 2 a 3 a § 71 odst. 3 se nepoužijí. Orgán ochrany přírody předá vydané
osvědčení do evidence druhové ochrany.
(2) O vydání osvědčení může požádat orgán ochrany přírody ten, kdo
a) odchoval živočicha odchovaného v lidské péči a nezaměnitelně a trvale jej označil
značkovací metodou v souladu s přímo použitelným předpisem Evropské unie upravujícím
obchodování s ohroženými druhy20e) (dále jen „nezaměnitelné a trvalé označení“), nebo
pokud fyzické vlastnosti exempláře neumožňují označit ho touto metodou, zajistil jiný
způsob nezaměnitelné a trvalé identifikace,
b) získal do držení nezaměnitelně a trvale označeného nebo nezaměnitelně identifikovaného
živočicha odchovaného v lidské péči z jiného členského státu Evropské unie v souladu
s právem tohoto členského státu, nebo
c) v souladu s předpisy v oblasti obchodování s ohroženými druhy70) dovezl ze třetí země
nezaměnitelně a trvale označeného nebo nezaměnitelně identifikovaného živočicha
odchovaného v lidské péči.
(3) Žádost o vydání osvědčení podle odstavce 2 písm. a) je třeba podat nejpozději do 90
dnů ode dne narození živočicha odchovaného v lidské péči. Pokud se jedná o živočicha
odchovaného v lidské péči dovezeného nebo získaného podle odstavce 2 písm. b) nebo c), musí
být žádost podána do 30 dnů ode dne, kdy k dovozu nebo získání došlo. Spolu s žádostí o vydání
osvědčení musí být předloženy informace o provedeném nezaměnitelném a trvalém označení,
popřípadě další údaje upřesňující identifikaci živočicha odchovaného v lidské péči a doklady
osvědčující odchov v lidské péči v souladu s tímto zákonem nebo zákonný způsob nabytí
živočicha odchovaného v lidské péči. Nelze-li ve lhůtě podle věty první s ohledem na velikost
nebo jiné vlastnosti živočicha zajistit jeho nezaměnitelné a trvalé označení nebo jinou jeho
nezaměnitelnou identifikaci, žadatel tuto skutečnost uvede v žádosti a doplní nezbytné údaje
nejpozději do 3 měsíců ode dne podání žádosti; do doby doplnění nezbytných údajů lhůta pro
vydání osvědčení neběží. Zákaz držení uvedený v § 5a odst. 1 písm. e) a v § 49a odst. 2 písm.
c) nebo § 49c se po dobu stanovenou pro podání žádosti o osvědčení v případech podle vět
první a druhé a po dobu od podání žádosti do vydání osvědčení na živočicha odchovaného
v lidské péči nevztahuje.
(4) Na živočicha odchovaného v lidské péči, ke kterému bylo vydáno osvědčení, se § 5a
odst. 1 a 2, § 49a odst. 2 a § 49c nepoužijí. Potvrzení o výjimce ze zákazu obchodních činností
vydané pro jednoznačně identifikovaný nebo nezaměnitelně trvale označený exemplář
živočišného druhu narozený a odchovaný v zajetí v souladu s přímo použitelným předpisem
Evropské unie upravujícím obchodování s ohroženými druhy20d) nahrazuje osvědčení.
(5) Držitel živočicha odchovaného v lidské péči je povinen zajistit, aby po celou dobu
života živočicha bylo zajištěno jeho nezaměnitelné a trvalé označení nebo jiný způsob jeho
jednoznačné identifikace v souladu s vydaným osvědčením. Podléhá-li použitý způsob
jednoznačné identifikace přirozeným změnám v průběhu času v závislosti na tělesných
změnách živočicha nebo jiných okolnostech, je držitel živočicha odchovaného v lidské péči
povinen provádět aktualizaci informací a dokladů nezbytných pro identifikaci živočicha
a požádat orgán ochrany přírody o aktualizaci údajů v osvědčení. Orgán ochrany přírody je při
vydání osvědčení oprávněn v osvědčení vyznačit lhůtu, ve které je držitel živočicha
odchovaného v lidské péči nejpozději povinen aktualizaci informací a dokladů provést.
(6) Ten, kdo drží živočicha odchovaného v lidské péči, pro kterého bylo vydáno osvědčení,
je povinen na požádání orgánu ochrany přírody předložit osvědčení ke kontrole a umožnit
prohlídku označení živočicha odchovaného v lidské péči. Je-li důvodná pochybnost
o zákonném původu jedince, je jeho vlastník nebo držitel povinen umožnit orgánu ochrany
přírody, s poskytnutím aktivní součinnosti, jeho ověření, včetně provedení testu paternity.
V případě potvrzení nezákonného původu uhradí náklady na ověření zákonného původu
vlastník nebo držitel živočicha odchovaného v lidské péči; výši nákladů stanoví rozhodnutím
orgán ochrany přírody. V opačném případě uhradí náklady na ověření zákonného původu
živočicha odchovaného v lidské péči orgán ochrany přírody.
(7) Ministerstvo životního prostředí stanoví vyhláškou vzor žádosti o osvědčení, vzor
osvědčení, způsoby ověřování zákonného původu jedince a podmínky jeho provádění.“.
Poznámka pod čarou č. 21 se zrušuje.
73.
Za § 55 se vkládá nový § 55a, který zní:
„§ 55a
(1) Orgán ochrany přírody rozhodnutím zruší osvědčení, v případě
a) úmyslného předložení nesprávných údajů v žádosti o vydání osvědčení nebo v žádosti
o aktualizaci údajů v osvědčení,
b) změně označení živočicha odchovaného v lidské péči; za změnu označení se pro účely
tohoto ustanovení nepovažuje změna provedená z důvodu závažného ohrožení života nebo
zdraví živočicha, pokud byla s odůvodněním oznámena orgánu ochrany přírody do 3 dnů
ode dne, kdy k ní došlo,
c) přenosu označení na jiného jedince, nebo
d) neprovedení aktualizace informací a dokladů nezbytných pro identifikaci živočicha
odchovaného v lidské péči.
(2) Rozhodnutí o zrušení osvědčení předá orgán ochrany přírody do evidence druhové
ochrany.
(3) V případě změny vlastníka nebo držitele živočicha odchovaného v lidské péči přechází
osvědčení současně s živočichem odchovaným v lidské péči na nového vlastníka nebo držitele;
původní vlastník nebo držitel je povinen předat novému nabyvateli spolu s živočichem
odchovaným v lidské péči také osvědčení.
(4) V případě úhynu nebo vypuštění živočicha odchovaného v lidské péči do volné přírody
je jeho držitel povinen tuto skutečnost ohlásit prostřednictvím evidence druhové ochrany, a to
do 30 pracovních dnů ode dne, kdy tato skutečnost nastala nebo kdy se o ní dozvěděl. Osvědčení
pozbývá platnosti dnem, kdy uvedená skutečnost nastala, popřípadě kdy byla zjištěna.
(5) Pokud se držitel jedince živočicha odchovaného v lidské péči rozhodl ponechat si po
jeho úhynu tohoto jedince nebo jeho část i nadále ve svém držení a dosavadní způsob označení
nebo identifikace jedince nelze dále použít, je povinen do 30 pracovních dnů ode dne, kdy tato
skutečnost nastala nebo kdy se o ní dozvěděl, mrtvého jedince nebo jeho část nezaměnitelně
a trvale označit nebo zajistit jiný způsob jeho nezaměnitelné a trvalé identifikace a požádat
o vydání nového osvědčení. Ustanovení § 55 odst. 3 věty třetí se na žádost o vydání nového
osvědčení použije obdobně; k žádosti se dále přiloží původní osvědčení.
(6) V případě ztráty nebo odcizení živočicha odchovaného v lidské péči je jeho držitel
povinen tuto skutečnost ohlásit prostřednictvím evidence druhové ochrany, a to do 30
pracovních dnů ode dne, kdy tato skutečnost nastala nebo kdy se o ní dozvěděl. Osvědčení
v takovém případě pozbývá platnosti do 1 roku ode dne, kdy ke ztrátě nebo odcizení živočicha
odchovaného v lidské péči došlo, pokud nedojde k jeho nálezu.“.
74.
V nadpisu § 56 se slova „památných stromů a“ zrušují.
75.
V § 56 odst. 1 se slova „památných stromů a“ zrušují, slova „§ 46 odst. 2, § 49 a 50
v případech, kdy jiný veřejný zájem převažuje nad zájmem ochrany přírody, nebo v zájmu
ochrany přírody,“ se nahrazují slovy „§ 49 až 50“ a věta druhá se nahrazuje větou „Na
povolení výjimky má žadatel po splnění zákonem stanovených podmínek právní nárok.“.
76.
V § 56 odst. 2 úvodní časti ustanovení se slova „lze povolit“ nahrazují slovy „podle
odstavce 1 orgán ochrany přírody povolí, pokud neexistuje jiné uspokojivé řešení daného
záměru, zamýšlený škodlivý zásah neovlivní dosažení nebo udržení příznivého stavu
zvláště chráněného druhu z hlediska jeho ochrany a současně zamýšlený škodlivý zásah
je povolován“.
77.
V § 56 odst. 2 písm. a) se slova „volně žijících“ a slova „planě rostoucích“ zrušují.
78.
V § 56 odst. 2 se na konci textu písmene b) doplňují slova „ , pokud tento zájem převažuje
nad zájmem ochrany dotčeného druhu rostliny nebo živočicha“.
79.
V § 56 odst. 2 písm. d) se slova „opětovného osídlení určitého území populací druhu nebo
opětovného vysazení v původním areálu druhu a chovu a pěstování nezbytných pro tyto
účely, včetně umělého rozmnožování rostlin“ nahrazují slovy „které jsou v zájmu ochrany
rostlin a živočichů nebo pokud zájem na jejich uskutečnění převažuje nad zájmem
ochrany dotčeného druhu rostliny nebo živočicha“.
80.
V § 56 odst. 2 písmeno e) zní:
„e) pro účely opětovného osídlení určitého území populací druhu nebo opětovného vysazení
v původním areálu druhu a chovu nebo pěstování nezbytných pro tyto účely, včetně
umělého rozmnožování rostlin, nebo“.
81.
V § 56 se na konci odstavce 2 doplňuje písmeno f), které zní:
„f) pro účely odebrání nebo držení omezeného počtu jedinců, není-li v rozporu s jinými
právními předpisy73); orgán ochrany přírody stanoví v rozhodnutí podmínky tohoto
odebrání nebo držení a způsob jejich kontroly.“.
82.
V § 56 odstavec 3 zní:
„(3) Orgán ochrany přírody stanoví v povolení výjimky podmínky pro provedení
zamýšleného škodlivého zásahu a, jedná-li se o výjimku ze zákazu odebrání a držení jedince
zvláště chráněného druhu živočicha, rovněž způsob jeho nezaměnitelného a trvalého označení
nebo jiný způsob jeho jednoznačné identifikace.“.
83.
V § 56 odst. 4 se slova „odstavcích 1 a“ nahrazují slovem „odstavci“ a na konci odstavce
se doplňuje věta „Orgán ochrany přírody následně informuje na úřední desce, případně
rovněž dalšími vhodnými způsoby, že podmínky pro uplatnění výjimky povolené
opatřením obecné povahy nastaly.“.
84.
V § 56 odst. 5 větě první se slova „a) a d)“ nahrazují slovy „a), d) a e)“.
85.
V § 56 odst. 6 se text „§ 49 odst. 4“ nahrazuje textem „§ 49a odst. 6“.
86.
V § 56 se doplňuje odstavec 7, který zní:
„(7) Pro jedince zvláště chráněného druhu rostliny nebo živočicha, který byl dovezen na
území České republiky z jiného členského státu Evropské unie, se nevyžaduje výjimka podle
odstavce 1, pokud pro něj byla obdobná výjimka vydána v tomto jiném členském státě; platnost
takové výjimky vydané v jiném členském státu Evropské unie potvrdí orgán ochrany přírody
na úředně ověřený překlad předložený držitelem jedince.“.
87.
V nadpisu § 57 se slova „druhů rostlin, živočichů a“ zrušují.
88.
V § 57 se slova „druhů rostlin či živočichů (§ 50 odst. 5) a“ zrušují.
89.
V části páté se doplňuje hlava třetí, která včetně nadpisu zní:
„HLAVA TŘETÍ
ZÁCHRANNÉ STANICE
§ 57a
(1) Záchrannou stanici lze provozovat pouze na základě rozhodnutí Ministerstva životního
prostředí o povolení k provozování záchranné stanice. Ministerstvo životního prostředí předává
rozhodnutí o povolení k provozování záchranné stanice do evidence druhové ochrany.
(2) Označení „záchranná stanice“ může v souvislosti s držením a péčí o živočichy používat
pouze ten, kdo je držitelem povolení k provozování záchranné stanice (dále jen „provozovatel
záchranné stanice“). Ministerstvo životního prostředí vede seznam záchranných stanic a
zveřejňuje jej na svých internetových stránkách.
(3) V žádosti o povolení k provozování záchranné stanice žadatel kromě obecných
náležitostí stanovených správním řádem dále uvede
a) rozsah poskytované péče z hlediska určení druhů živočichů, jejich množství a délky
poskytované péče,
b) vymezení území, pro které zamýšlí péči poskytovat,
c) personální, organizační a technické zajištění péče o živočichy, včetně podkladů
dokládajících splnění požadavků právních předpisů upravujících ochranu zvířat proti týrání
a veterinární péči na velikost a vybavení prostor pro držení živočichů a odbornou
způsobilost osoby odpovědné za péči o živočichy.
(4) Ministerstvo životního prostředí si k žádosti o povolení k provozování záchranné
stanice vyžádá vyjádření místně příslušného orgánu státní správy myslivosti a krajské
veterinární správy.
(5) Ministerstvo může provozování záchranné stanice povolit, pokud
a) personální, organizační a technické zajištění péče o živočichy je odpovídající rozsahu péče
navrhovanému v žádosti o povolení a přirozeným nárokům živočichů,
b) velikost a vybavení prostor pro držení živočichů a odborná způsobilost osoby odpovědné
za péči o živočichy splňují podmínky právních předpisů upravujících ochranu zvířat proti
týrání a veterinární péči a
c) na území vymezeném v žádosti je dána potřeba zajištění péče o druhy živočichů uvedené
v žádosti; dostatečné zajištění potřeby péče o konkrétní druhy živočichů na dotčeném
území stávajícími provozovateli záchranné stanice může být důvodem pro zamítnutí
žádosti o povolení k provozování nové záchranné stanice nebo povolení takového
provozování v omezeném rozsahu, než jak byl vymezen v žádosti.
(6) V rozhodnutí o povolení k provozování záchranné stanice stanoví Ministerstvo
životního prostředí místo, kde se záchranná stanice nachází, území, v němž je oprávněna péči
poskytovat, rozsah péče, kterou je záchranná stanice oprávněna poskytovat s ohledem na její
vybavení a odborné zázemí, a další podmínky vztahující se k provozování záchranné stanice.
(7) Součástí rozhodnutí o povolení k provozování záchranné stanice nebo o změně tohoto
rozhodnutí může být rovněž v rozsahu povolené činnosti záchranné stanice rozhodnutí
Ministerstva životního prostředí o stanovení odchylného postupu podle § 5b odst. 1 a o povolení
výjimky ze zákazů na ochranu zvláště chráněných druhů rostlin a živočichů podle § 56 odst. 1,
pokud o to žadatel v žádosti o povolení k provozování záchranné stanice nebo o změnu tohoto
povolení požádal.
(8) Ministerstvo životního prostředí může z moci úřední změnit nebo zrušit povolení
k provozování záchranné stanice, jestliže se změnily nebo zanikly podmínky, za jakých bylo
povolení vydáno, a to podmínky týkající se záchranné stanice nebo podmínky týkající se
potřeby zajištění péče o živočichy v dotčeném území, nebo jestliže provozovatel záchranné
stanice při péči o živočichy porušuje ustanovení tohoto zákona nebo předpisy na ochranu zvířat
proti týrání anebo předpisy upravující veterinární péči. Ministerstvo životního prostředí změní
nebo zruší povolení k provozování záchranné stanice na žádost provozovatele záchranné
stanice. V rozhodnutí o změně nebo zrušení povolení k provozování záchranné stanice
Ministerstvo životního prostředí stanoví, je-li to nezbytné, způsob zabezpečení další péče
o živočichy držené v záchranné stanici.
§ 57b
(1) Záchranná stanice zajišťuje péči o přijatého živočicha dočasně neschopného přežít ve
volné přírodě způsobem a za podmínek odpovídajících přirozeným nárokům daného druhu
a zdravotnímu stavu přijatého živočicha tak, aby byly zachovány jeho přirozené vlastnosti
a schopnosti a bylo možné jej navrátit do přírody, nevylučuje-li to jeho zdravotní stav.
Záchranná stanice dále vhodným způsobem zajišťuje v potřebném rozsahu přípravu přijatého
živočicha na jeho návrat do přírody.
(2) Pečuje-li záchranná stanice o živočicha, pro kterého byl přijat záchranný program nebo
program péče, postupuje při poskytování péče takovému živočichovi a při jeho návratu do
přírody v součinnosti s Agenturou; pečuje-li o živočicha, pro kterého byl schválen regionální
akční plán, postupuje v součinnosti s orgánem ochrany přírody, který tento plán schválil.
(3) Není-li návrat živočicha přijatého do záchranné stanice do přírody s ohledem na jeho
zdravotní stav možný, využije jej záchranná stanice přednostně pro účely ochrany přírody,
zejména náhradní péče o jiné jedince nebo informování a vzdělávání veřejnosti o příčinách
ohrožení a vhodných způsobech ochrany živočichů. Není-li takové využití možné, může být
takový živočich na základě posouzení veterinárního lékaře, že již nevyžaduje další odbornou
péči, předán záchrannou stanicí do péče jiné osobě, která splňuje požadavky stanovené tímto
zákonem a jinými právními předpisy.
(4) Přijme-li záchranná stanice živočicha, který je invazním nepůvodním druhem,
postupuje v souladu se zásadami regulace a vydanými správními akty podle § 13g a 13h.
Jedince invazního nepůvodního druhu nelze navrátit do přírody; předán do péče podle odstavce
3 může být pouze osobě, která je držitelem povolení podle § 13d nebo § 13h odst. 3.
(5) Záchranná stanice přijme do dočasné péče rovněž jedince zvláště chráněného druhu
živočicha, ptáka nebo jedince invazního nepůvodního druhu zajištěného nebo odebraného podle
§ 89, exemplář zadržený nebo zabavený podle zákona o obchodování s ohroženými druhy
anebo jedince vydaného nebo odňatého v trestním řízení, pokud disponuje potřebnou kapacitou
a technickým a odborným zázemím.
(6) Záchranná stanice vede evidenci přijatých živočichů a záznamy o průběhu jejich
ošetření a péči poskytnutou jim po dobu jejich pobytu v záchranné stanici. Součástí evidence je
rovněž datum, místo a způsob návratu vyléčeného živočicha do přírody. Údaje z evidence
předávají záchranné stanice každoročně do evidence druhové ochrany.
(7) Ministerstvo životního prostředí stanoví vyhláškou bližší podmínky pro poskytování
péče živočichům v záchranných stanicích s ohledem na zachování jejich přirozených vlastností
a možnost jejich návratu do přírody a podmínky pro poskytování dlouhodobé péče živočichům,
jejichž návrat do přírody není možný, a jejich využití pro osvětové a vzdělávací účely.“.
90.
V § 58 odstavec 2 zní:
„(2) Pokud vlastníku zemědělské půdy21b) nebo lesního pozemku21c) nebo rybníka s chovem
ryb nebo vodní drůbeže21f), nebo nájemci, pachtýři, podpachtýři nebo uživateli dílu půdního
bloku zařazeného do evidence půdy podle zákona o zemědělství, který tyto pozemky nebo díly
půdního bloku oprávněně užívá, vznikne nebo trvá v důsledku omezení vyplývajícího z části
třetí až páté tohoto zákona včetně prováděcích právních předpisů nebo rozhodnutí vydaného na
jejich základě a nebo z omezení vyplývajícího z opatření v plánech systémů ekologické stability
krajiny podle § 4 odst. 1 újma, má nárok na její finanční náhradu.“.
91.
V § 58 se za odstavec 2 vkládají nové odstavce 3 a 4, které znějí:
 „(3) Nárok na finanční náhradu trvá i v případě převodu nebo přechodu vlastnického práva
nebo práva nájmu, pachtu nebo podpachtu; obdobně se nárok uplatní i v případě oprávněně
užívaného pozemku podle vodního zákona. Nájemce pozemku, pachtýř, podpachtýř nebo
uživatel dílu půdního bloku zařazeného do evidence půdy podle zákona o zemědělství může
nárok uplatnit v případě zachovaného nároku vlastníka pozemku.
(4) Finanční náhradu nelze poskytnout současně vlastníkovi a nájemci, pachtýři nebo
podpachtýři téhož pozemku anebo uživateli půdního bloku zařazeného do evidence půdy podle
zákona o zemědělství. Požádají-li o náhradu včas oba, poskytne se finanční náhrada pouze
vlastníkovi pozemku. Nárok na finanční náhradu náleží oprávněnému podle odstavce 2, který
tyto pozemky užívá, též v případě, že mu vznikne nebo trvá újma v důsledku omezení
vyplývajícího z rozhodnutí, závazného stanoviska nebo souhlasu vydaného podle tohoto
zákona.“.
Dosavadní odstavce 3 až 6 se označují jako odstavce 5 až 8.
92.
V § 58 odst. 5 větě první se slova „vlastníka zemědělské půdy nebo lesního pozemku
nebo rybníka s chovem ryb nebo vodní drůbeže nebo nájemce“ nahrazují slovem
„oprávněného“.
93.
V § 58 odst. 5 se věty druhá a třetí zrušují.
94.
V § 58 odst. 6 větě první se slova „vlastníku uvedenému v odstavci 2 nebo nájemci“
nahrazují slovem „oprávněnému“ a věty druhá a poslední se zrušují.
95.
V § 61 odst. 1 a § 63 odst. 5 se slovo „zastavěná“ nahrazuje slovem „zastavitelná“.
96.
V § 61b odst. 2 písm. a) se slova „zastavěný stavební pozemek69)“ nahrazují slovy
„pozemek zázemí stavby76)“.
Poznámka pod čarou č. 76 zní:
 „76)
§ 12 písm. c) zákona č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů.“.
97.
V § 63 odst. 1 a § 77 odst. 1 písm. q) se slovo „zastavěné“ nahrazuje slovem
„zastavitelné“.
98.
V § 63 se doplňují odstavce 6 a 7, které znějí:
„(6) Při provádění preventivních opatření podle občanského zákoníku, jejichž účelem je
předejít vzniku újmy na životě, zdraví nebo majetku osob, nebo tuto újmu odvrátit, si vlastníci
pozemků počínají tak, aby nedošlo k nedovolené změně obecně nebo zvláště chráněných částí
přírody. Cesty nebo trasy vyhrazené orgánem ochrany přírody v klidových územích národního
parku a turistické trasy na území národního parku udržuje vlastník pozemku tak, aby byla
zajištěna jejich průchodnost v souladu se zásadami péče; tím nejsou dotčena práva a povinnosti
vlastníka pozemní komunikace podle zákona o pozemních komunikacích.
(7) V úseku vyznačené nebo vyhrazené turistické trasy, kde hrozí trvale zvýšené riziko
újmy na životě, zdraví nebo majetku osob z důvodu uplatňování ochranného režimu zvláště
chráněného území, evropsky významné lokality nebo ptačí oblasti podle tohoto zákona nebo
jiné neobvyklé riziko újmy na životě, zdraví nebo majetku osob z důvodu stavu přírodního
prostředí v obecně nebo zvláště chráněných částech přírody, kterými trasa prochází, zajistí
vlastník pozemku na přístupových místech vhodným způsobem informování osob,
pohybujících se po této trase, o existujícím riziku.“.
99.
V § 69 se odstavec 2 zrušuje.
Dosavadní odstavce 3 a 4 se označují jako odstavce 2 a 3.
100. V § 70 odst. 1 se slova „přímé účasti občanů, prostřednictvím jejich občanských
sdružení34) a dobrovolných sborů či aktivů“ nahrazují slovy „účasti občanů
prostřednictvím právnických osob soukromého práva podle odstavce 2“.
Poznámka pod čarou č. 34 se zrušuje.
101. V § 70 odstavce 2 a 3 znějí:
„(2) Právnická osoba soukromého práva, jejímž předmětem činnosti je podle
zakladatelského právního jednání ochrana životního prostředí, přírody a krajiny nebo veřejného
zdraví, a jejíž hlavní činností není podnikání nebo jiná výdělečná činnost, může požádat orgán
ochrany přírody, aby ji informoval o zahajovaných správních řízeních, v nichž mohou být
dotčeny zájmy chráněné tímto zákonem, s výjimkou řízení navazujících na posuzování vlivů
na životní prostředí podle § 3 písm. g) zákona o posuzování vlivů na životní prostředí. Žádost
musí být co do předmětu a místa řízení specifikována. Tato žádost je platná jeden rok od jejího
podání.
(3) Právnická osoba podle odstavce 2, která vznikla alespoň 3 roky před dnem oznámení
o zahájení řízení podle tohoto ustanovení nebo kterou podporuje svými podpisy nejméně 200
osob na podporující listině, je účastníkem řízení podle odstavce 2, pokud jde o řízení vedené
podle tohoto zákona jiným orgánem než stavebním úřadem nebo o řízení podle jiného právního
předpisu, v němž se rozhoduje na základě společného závazného stanoviska (§ 83 odst. 9) nebo
pokud se v něm rozhoduje o povolení kácení dřevin podle § 8 odst. 1 nebo udělení výjimky ze
zákazů u památných stromů podle § 46 odst. 3 nebo zvláště chráněných druhů rostlin
a živočichů podle § 56 odst. 1, pokud do 10 dnů ode dne sdělení informace podle odstavce 2
písemně oznámí svou účast v řízení orgánu ochrany přírody. Dnem sdělení informace o zahájení
řízení se rozumí den doručení jejího písemného vyhotovení právnické osobě nebo první den
jejího zveřejnění na úřední desce správního orgánu.“.
102. V § 70 se doplňuje odstavec 4, který zní:
„(4) V záhlaví podporující podpisové listiny a na každém jejím očíslovaném podpisovém
archu se uvedou identifikační údaje právnické osoby, na jejíž podporu je podporující podpisová
listina určena, a skutečnost, že listina je určena na účasti právnické osoby v řízení podle
odstavce 3. Každá osoba podporující účast právnické osoby v řízení podle odstavce 3 uvede na
podpisový arch své jméno, příjmení, datum narození a adresu místa pobytu a připojí
vlastnoruční podpis.“.
103. V § 72 písm. e) se slova „a 55“ zrušují.
104. V § 72a se na konci odstavce 1 tečka nahrazuje čárkou a doplňuje se písmeno l), které
zní:
„l) registrované významné krajinné prvky.“.
105. V § 72b se doplňuje odstavec 12, který zní:
„(12) O registrovaném významném krajinném prvku se v registru územní identifikace
vedou
a) identifikační údaje, kterými jsou
1. kód, který je registrovanému významnému krajinnému prvku přiřazen v registru
územní identifikace,
2. název a evidenční číslo registrovaného významného krajinného prvku, pod kterým je
veden v registru krajiny v informačním systému ochrany přírody,
b) lokalizační údaje, kterými jsou hranice a definiční bod registrovaného významného
krajinného prvku,
c) údaje o vazbách na ostatní územní prvky,
d) údaje o rozhodnutí o vyhlášení registrovaného krajinného prvku.“.
106. V § 72d odst. 3 písmena a) a b) znějí:
„a) nálezová databáze ochrany přírody,
1. v níž se ukládají data a zveřejňují informace o rozšíření a stavu druhů rostlin
a živočichů, zejména zvláště chráněných, invazních nepůvodních a evropsky
významných, a přírodních stanovišť,
2. jejímž prostřednictvím se ohlašuje odběr jedince zvláště chráněného druhu rostliny
nebo živočicha zařazeného v III. kategorii ochrany z přírody podle § 50 odst. 1,
b) evidence druhové ochrany, jejímž prostřednictvím
1. orgán ochrany přírody zajišťuje evidenci rozhodnutí a opatření obecné povahy
o odchylném postupu podle § 5b, souhlasů podle § 5c odst. 4, dohod o způsobu
hospodaření a péče o pozemek podle § 49a odst. 6, rozhodnutí a opatření obecné
povahy k omezení odběru jedinců zvláště chráněného druhu rostliny nebo živočicha
zařazeného v III. kategorii ochrany podle § 50 odst. 2, souhlasů podle § 52b odst. 1,
osvědčení podle § 55 odst. 1, rozhodnutí o zrušení osvědčení podle § 55a odst. 1,
rozhodnutí, opatření obecné povahy a dohod podle § 56 a rozhodnutí o povolení
k provozování záchranné stanice podle § 57a odst. 1; současně orgán ochrany přírody
plní prostřednictvím evidence druhové ochrany informační povinnost podle § 5b odst.
5 a § 56 odst. 6 a vede informace stanovené čl. 23 nařízení Rady (ES) č. 708/2007
a čl. 24 odst. 1 písm. f) a h) nařízení Evropského parlamentu a Rady (EU)
č. 1143/2014,
2. vlastník nebo držitel jedince invazního nepůvodního druhu živočicha na unijním
seznamu provádí jeho registraci podle § 13j odst. 2,
3. vlastník nebo držitel mrtvého jedince zvláště chráněného druhu živočicha zařazeného
v I. nebo II. kategorii ochrany, jeho části nebo výrobku z něj provádí jeho registraci
podle § 49b odst. 2,
4. vlastník nebo držitel živočicha odchovaného v lidské péči ohlašuje jeho ztrátu nebo
odcizení podle § 55a odst. 6,
5. se přebírá evidence živočichů přijatých záchrannou stanicí a záznamů podle § 57b
odst. 6,“.
107. V § 72d odst. 3 písm. c) se slova „a 47“ nahrazují slovy „ , 47 a § 52a odst. 3“.
108. V § 72d se na konci odstavce 3 tečka nahrazuje čárkou a doplňuje se písmeno f), které
zní:
„f) registr krajiny, který shromažďuje a zpřístupňuje informace o krajině, a který slouží
k zobrazování významného krajinného prvku podle § 6 odst. 1 a k evidenci rozhodnutí o
jeho registraci, zobrazování přírodního parku podle § 12 odst. 3 a evidenci nařízení o jeho
zřízení nebo zrušení, zobrazování vyhlášené přechodně chráněné plochy podle § 13 odst. 1
a evidenci opatření obecné povahy o jejím vyhlášení a který zobrazuje informace
o vymezeném systému ekologické stability.“.
109. V § 75 odst. 1 se za písmeno c) vkládá nové písmeno d), které zní:
„d) stavební úřady,“.
Dosavadní písmena d) až h) se označují jako písmena e) až i).
110. V § 76 odst. 1 se na konci úvodní části ustanovení doplňují slova „nebo nejde-li o záměr
povolení kácení pro účely záměru vyžadujícího stavební povolení,“.
111. V § 76 se odstavec 2 zrušuje a zároveň se zrušuje označení odstavce 1.
112. V § 77 odst. 1 se na konci textu písmene a) doplňují slova „a předávají rozhodnutí
o registraci do registru krajiny“.
113. V § 77 odst. 1 se písmeno b) zrušuje.
Dosavadní písmena c) až u) se označují jako písmena b) až t).
114. V § 77 odst. 1 písm. b) se slovo „prostředků“ nahrazuje slovy „postupů nebo opatření“,
slovo „nadměrnému“ se nahrazuje slovem „zbytečnému“, slova „jejich biotopů“ se
nahrazují slovy „biotopů druhů“ a slova „ , pokud se nejedná o zvláště chráněné druhy“
se zrušují.
115. V § 77 odst. 1 se na konci textu písmene e) doplňují slova „ , a podílejí se ve spolupráci
s příslušnými orgány ochrany přírody na zajištění provedení opatření k odstranění nebo
izolaci invazního nepůvodního druhu na unijním seznamu podle § 13g odst. 2 a opatření
k regulaci invazního nepůvodního druhu na unijním seznamu podle § 13j odst. 4“.
116. V § 77 odst. 1 se na konci textu písmene f) doplňují slova „ , nejde-li o stanovení
odchylného postupu v rámci rozhodnutí o povolení k provozování záchranné stanice nebo
jeho změně podle § 57a odst. 7“.
117. V § 77 odst. 1 se za písmeno f) vkládá nové písmeno g), které zní:
„g) rozhodují o uložení opatření k zabránění nebo zmírnění poškození biotopů opylovačů podle
§ 5c odst. 1,“.
Dosavadní písmena g) až t) se označují jako písmena h) až u).
118. V § 77 odst. 1 se na konci textu písmene l) doplňují slova „a předávají jej do registru
krajiny“.
119. V § 77 odst. 1 písmena m) a n) znějí:
„m) sjednávají a zrušují smlouvy o smluvně chráněném památném stromu podle § 39 a § 45
odst. 2, vydávají rozhodnutí o vyhlášení památných stromů podle § 46 odst. 1, včetně
stanovení jejich ochranných pásem podle § 46 odst. 2, a zrušení ochrany památných stromů
podle § 46 odst. 5, předávají dokumentaci o památných stromech a jejich ochranných
pásmech a smluvně chráněných památných stromech do ústředního seznamu podle § 47
odst. 1 a zajišťují označení památného stromu a jeho odstranění podle § 47 odst. 2,
n) vydávají souhlasy ke stanoveným činnostem v ochranných pásmech památných stromů
podle § 46 odst. 4, povolují výjimky ze zákazů u památných stromů podle § 46 odst. 3
a poskytují předběžnou informaci o škodlivosti činnosti podle § 46 odst. 4,“.
120. V § 77 odst. 1 písm. o) se slova „zvláště chráněných rostlin, zvláště chráněných živočichů,
ptáků nebo rostlin nebo živočichů chráněných podle mezinárodních úmluv“ zrušují a text
„odst. 2“ se nahrazuje textem „odst. 3 písm. a)“.
121. V § 77 odst. 1 písm. p) se slova „§ 54 odst. 4 až 11“ nahrazují slovy „§ 55 odst. 1 až 6“,
slova „§ 54 odst. 4 až 10“ se nahrazují slovy „§ 55 odst. 1 až 3“, za slovo „ověřují“ se
vkládá slovo „zákonný“ a text „§ 54 odst. 10“ se nahrazuje textem „§ 55 odst. 6“.
122. V § 77 odst. 1 písm. r) a § 77a odst. 4 písm. t) se za slovo „ukládají“ vkládají slova
„rozhodnutím nebo opatřením obecné povahy, pokud jde o blíže neurčený okruh osob,“.
123. V § 77 odst. 1 písm. u) se slovo „zastavěného“ nahrazuje slovem „zastavitelného“.
124. V § 77a odst. 3 se za slova „chráněných území“ vkládají slova „a na území chráněných
na základě smlouvy podle § 39“ a věta druhá se zrušuje.
125. V §77a odst. 4 úvodní části ustanovení se za slovo „úřad“ vkládají slova „ , stavební
úřad“.
126. V § 77a odst. 4 se na konci textu písmene c) doplňují slova „a předávají jej do registru
krajiny“.
127. V § 77a odst. 4 se na konci textu písmene j) doplňují slova „a předávají dokumentaci o
vyhlášených přírodních parcích do registru krajiny,“.
128. V § 77a odst. 4 se písmeno q) zrušuje.
Dosavadní písmena r) až z) se označují jako písmena q) až y).
129. V § 77a odst. 4 písm. q) se slova „zvláště chráněných rostlin, zvláště chráněných
živočichů, ptáků nebo rostlin nebo živočichů chráněných podle mezinárodních úmluv“
zrušují a text „odst. 2“ se nahrazuje textem „odst. 3 písm. a)“.
130. V § 77a odst. 4 písmeno y) zní:
„y) uplatňují stanoviska k návrhu zásad územního rozvoje, územního plánu, regulačního plánu,
vymezení zastavitelného území a územního opatření z hlediska zájmů chráněných tímto
zákonem, není-li příslušný jiný orgán ochrany přírody, a jsou dotčeným orgánem při jejich
pořizování.“.
131. V § 77a odst. 5 úvodní části ustanovení se za slovo „úřad“ vkládají slova „ , stavební
úřad“.
132. V § 77a odst. 5 písmeno b) zní:
„b) vydávají souhlas k prodeji a nabízení za účelem prodeje živých jedinců druhů čmeláků
a pačmeláků rodu Bombus, k jejich vypouštění a rozšiřování podle § 5c odst. 4,“.
133. V § 77a odst. 5 se na konci textu písmene d) doplňují slova „a mohou vydat opatření
obecné povahy, kterým se stanoví opatření k regulaci nepůvodního druhu nebo křížence
podle § 5 odst. 6, týká-li se takové opatření území zasahujícího správní obvody nejméně
dvou podřízených obecních úřadů obcí s rozšířenou působností“.
134. V § 77a odst. 5 se za písmeno f) vkládá nové písmeno g), které zní:
„g) vydávají rozhodnutí o uložení provedení opatření podle § 13c odst. 1,“.
Dosavadní písmena g) až r) se označují jako písmena h) až s).
135. V § 77a odst. 5 písm. k) se text „§ 49 odst. 4“ nahrazuje textem „§ 49a odst. 6“.
136. V § 77a odst. 5 písmena l) a m) znějí:
„l) ukládají rozhodnutím provedení technicky a ekonomicky dostupných opatření
k předcházení úhynu zvláště chráněných rostlin a úhynu a zraňování zvláště chráněných
živočichů podle § 48a,
m) omezují rozhodnutím nebo opatřením obecné povahy, pokud jde o blíže neurčený okruh
osob, odebírání nebo využívání jedinců zvláště chráněného druhu rostliny nebo živočicha
zařazeného v III. kategorii ochrany z přírody podle § 50 odst. 2,“.
137. V § 77a odst. 5 se za písmeno m) vkládá nové písmeno n), které zní:
„n) zajišťují zpracování, schválení a realizaci regionálních akčních plánů podle § 52a odst. 1
a jejich předání do ústředního seznamu podle § 52a odst. 3, podílí se na realizaci
záchranných programů podle § 52a odst. 1 a programů péče podle § 52a odst. 2 ve
spolupráci s Agenturou a při výkonu své působnosti postupují v souladu s těmito
dokumenty a zajišťují další potřebnou péči o zvláště chráněné druhy rostlin a živočichů,“.
Dosavadní písmena n) až s) se označují jako písmena o) až t).
138. V § 77a odst. 5 písm. o) se text „§ 54 odst. 3“ nahrazuje textem „§ 52b odst. 1“.
139. V § 77a odst. 5 písm. p) se slova „§ 54 odst. 4 až 10“ nahrazují slovy „§ 55 odst. 1 až 3“,
za slovo „ověřují“ se vkládá slovo „zákonný“ a text „§ 54 odst. 10“ se nahrazuje textem
„§ 55 odst. 6“.
140. V § 77a odst. 5 se na konci textu písmene q) doplňují slova „ , nejde-li o povolení výjimky
v rámci rozhodnutí o povolení k provozování záchranné stanice nebo jeho změně podle
§ 57a odst. 7“.
141. V § 77a odst. 5 písm. s) se slova „druhů rostlin a živočichů“ nahrazují slovem „nerostů“
a na konci písmene se slovo „a“ nahrazuje čárkou.
142. V § 77a odst. 5 se za písmeno s) vkládá nové písmeno t), které zní:
„t) uzavírají dohody k provádění péče o pozemek podle § 68 odst. 2 a provádějí zásahy ke
zlepšení přírodního a krajinného prostředí podle § 68 odst. 3 v rozsahu své působnosti, a“.
Dosavadní písmeno t) se označuje jako písmeno u).
143. V § 77a se doplňují odstavce 8 a 9, které znějí:
„(8) Krajské úřady vydávají závazná stanoviska z hlediska vysazování nepůvodních druhů
k řízením o povolení výkonu rybářského práva podle zákona o rybářství.
(9) Krajské úřady vydávají společná závazná stanoviska podle § 83 odst. 9 pro záměry
vyžadující povolení podle stavebního zákona, a to včetně posouzení povolení kácení podle § 8
odst. 1 a uložení náhradní výsadby podle § 9, pokud se záměr nebo jeho část nachází na území
přírodní rezervace, přírodní památky nebo ochranných pásem těchto zvláště chráněných území,
anebo na území evropsky významné lokality nebo ptačí oblasti, není-li podle tohoto zákona
příslušná Agentura, správa národního parku nebo újezdní úřad. V případě, že se záměr nachází
na území přírodní rezervace, přírodní památky nebo ochranných pásem těchto zvláště
chráněných území, anebo na území evropsky významné lokality nebo ptačí oblasti jen zčásti,
krajské úřady vydávají společné závazné stanovisko podle § 83 odst. 9 pro celý záměr.“.
144. Za § 77a se vkládá nový § 77b, který včetně nadpisu zní:
„§ 77b
Působnost stavebních úřadů
(1) Stavební úřady ve svém správním obvodu, nejde-li o zvláště chráněná území a jejich
ochranná pásma, evropsky významné lokality, ptačí oblasti a vojenské újezdy a jedná-li se
o záměry podle stavebního zákona, v rámci řízení podle stavebního zákona posoudí splnění
podmínek stanovených tímto zákonem pro
a) vydání souhlasu k zásahům, které by mohly vést k poškození nebo zničení významného
krajinného prvku nebo ohrožení či oslabení jeho ekologicko-stabilizační funkce podle § 4
odst. 2,
b) stanovení odchylného postupu při ochraně ptáků podle § 5b odst. 1,
c) povolení kácení dřevin podle § 8 odst. 1 a uložení náhradní výsadby podle § 9 odst. 1,
d) povolení výjimky ze zákazů stanovených v § 10 odst. 2 pro jeskyně,
e) vydání souhlasu k umisťování a povolování staveb a k jiným činnostem, které by mohly
snížit nebo změnit krajinný ráz podle § 12 odst. 2,
f)
povolení výjimky ze zákazů u památných stromů a souhlas s ošetřováním památného
stromu podle § 46 odst. 3, vydání souhlasu ke stanoveným činnostem v ochranných
pásmech památných stromů podle § 46 odst. 2, zrušení ochrany památného stromu podle
§ 46 odst. 5,
g) povolení výjimky ze zákazů u zvláště chráněných druhů rostlin a živočichů podle § 56;
k povolení výjimky ze zákazů u zvláště chráněných druhů rostlin a živočichů zařazených
v I. kategorii ochrany je nezbytné závazné stanovisko příslušného orgánu ochrany přírody
a k povolení výjimky ze zákazů u zvláště chráněných druhů rostlin a živočichů zařazených
v II. kategorii ochrany je nezbytné vyjádření příslušného orgánu ochrany přírody,
h) vydání souhlasu k činnostem a zásahům týkajícím se zvláště chráněných nerostů podle
§ 57,
i)
vydání souhlasu ke zřizování nebo rušení veřejně přístupných účelových komunikací,
stezek a pěšin mimo zastavěné území obcí podle § 63 odst. 1.
Souhlas nebo povolení podle písmene a) až h) se v těchto případech samostatně nevydává a je
součástí výrokové části rozhodnutí o povolení záměru, změně záměru před dokončením,
případně o povolení užívání stavby podle stavebního zákona, jsou-li zájmy chráněné podle
písmen a) až h) dotčeny.
(2) Ustanovení odstavce 1 písm. a) a e) se nepoužije, jde-li o záměr vyžadující posouzení
vlivů na životní prostředí podle zákona o posuzování vlivů na životní prostředí.
(3) Stavební úřady v rozsahu své působnosti podle odstavce 1
a) ukládají podmínky pro výkon činností, které by mohly způsobit nedovolenou změnu
obecně nebo zvláště chráněných částí přírody nebo takové činnosti zakazují podle § 66,
b) vykonávají státní dozor v ochraně přírody a krajiny podle § 85 odst. 1 a rozhodují
o možnostech a podmínkách uvedení do původního stavu podle § 86 odst. 1,
c) ukládají provedení přiměřených náhradních opatření podle § 86 odst. 2, a
d) projednávají přestupky podle § 87 odst. 1 písm. a), b), d), e), i) a j), § 87 odst. 2 písm. b),
l), m), n) a o), § 87 odst. 3 písm. a) až e), l) a m), § 88 odst. 1 písm. b), c), d), g), k), n), s),
§ 88 odst. 2 písm. a), b), d), f) až i), p) a w) vyplývající z porušení povinností uložených
jimi vydanými rozhodnutími nebo opatřeními.“.
145. V § 78 odst. 3 se na konci úvodní části ustanovení doplňují slova „ , není-li příslušný jiný
orgán“.
146. V § 78 odst. 3 písm. a) a b) se slova „vydávají souhlasy k vyhrazení míst“ nahrazují slovy
„vyhrazují místa“.
147. V § 78 odst. 3 písm. c) se slova „vydávají souhlasy k vyznačení cest“ nahrazují slovy
„vyznačují cesty“.
148. V § 78 odst. 3 písm. h) se slova „ ; po vyhlášení přírodních rezervací, přírodních památek
nebo jejich ochranných pásem ohlašují příslušnému katastrálnímu úřadu údaje, popřípadě
změny těchto údajů, týkající se ochrany nemovitých věcí podle tohoto zákona k zápisu
do katastru nemovitostí“ zrušují.
149. V § 78 odst. 3 písm. j) se za slovo „vyhrazují“ vkládají slova „a vyznačují“ a za slovo
„místa“ se vkládají slova „ , cesty a trasy“.
150. V § 78 odst. 3 písm. o) se za slovo „vydávají“ vkládají slova „rozhodnutí nebo“ a za slovo
„zákazu“ se vkládají slova „činnosti podle § 66 odst. 1 a k“.
151. V § 78 odst. 3 písm. p) se slova „ , vymezení zastavěného území“ zrušují.
152. V § 78 odstavec 6 zní:
„(6) Agentura na celém území České republiky, mimo území vojenských újezdů, zvláště
chráněná území a jejich ochranná pásma, evropsky významné lokality a ptačí oblasti, vydává
pro záměry podle stavebního zákona závazná stanoviska k povolení výjimky podle § 56 ze
zákazů u zvláště chráněných druhů rostlin a živočichů zařazených v I. kategorii ochrany
a vyjádření k povolení výjimky podle § 56 ze zákazů u zvláště chráněných druhů rostlin
a živočichů zařazených v II. kategorii ochrany, není-li podle tohoto zákona příslušné
Ministerstvo životního prostředí.“.
Poznámka pod čarou č. 62 se zrušuje.
153. V § 78 odst. 7 se za slovo „pískovce“ vkládají slova „a vojenských újezdů“, za slova
„odstavce 2“ se vkládají slova „mimo území vojenských újezdů“ a za slovo „republiky“
se vkládají slova „uzavírá dohody podle § 68 odst. 2 a“.
154. V § 78 odst. 9 se za slova „odstavce 1“ vkládají slova „a podle odstavce 19 po projednání
s Ministerstvem obrany rovněž na pozemcích a stavbách, které tvoří součást objektů
důležitých pro obranu státu mimo vojenské újezdy“.
155. V § 78 odst. 11 se slova „nebo záchranné programy zvláště chráněných druhů podle § 52“
zrušují.
156. V § 78 odst. 13 písm. a) se na konci textu bodu 1 doplňují slova „podle § 13a odst. 1“.
157. V § 78 odst. 13 písm. a) se na konci bodu 3 doplňuje slovo „nebo“.
158. V § 78 odst. 13 písm. a) se bod 4 zrušuje.
Dosavadní bod 5 se označuje jako bod 4.
159. V § 78 se za odstavec 13 vkládá nový odstavec 14, který zní:
„(14) Agentura na celém území České republiky vydává Červené seznamy podle § 52.
Agentura na celém území České republiky zajišťuje zpracování a realizaci záchranných
programů podle § 52a odst. 1 a programů péče podle § 52a odst. 2; schválené záchranné
programy a programy péče předává Agentura do ústředního seznamu. Agentura dále na celém
území České republiky koordinuje zpracování regionálních akčních plánů zpracovaných
příslušnými orgány ochrany přírody.“.
Dosavadní odstavce 14 až 18 se označují jako odstavce 15 až 19.
160. V § 78 odst. 15 se slova „zvláště chráněných druhů“ nahrazují slovy „ , regionálními
akčními plány a programy péče“.
161. V § 78 se doplňuje odstavec 20, který zní:
„(20) Agentura a správy národních parků vydávají společná závazná stanoviska podle § 83
odst. 9 pro záměry vyžadující povolení podle stavebního zákona, a to včetně posouzení
povolení kácení podle § 8 odst. 1 a uložení náhradní výsadby podle § 9, pokud se záměr nebo
jeho část nachází v obvodu jejich územní působnosti podle odstavců 1 a 2. V případě, že se
záměr nachází v obvodu územní působnosti podle odstavců 1 a 2 jen zčásti, Agentura a správy
národních parků vydávají společné závazné stanovisko podle § 83 odst. 9 pro celý záměr.“.
162. V § 78a odst. 1 se za slovo „působností“ vkládají slova „ , stavebních úřadů“.
163. V § 79 odst. 3 písmeno c) zní:
„c) rozhoduje o povolení k provozování záchranné stanice podle § 57a odst. 1 a jeho změně
nebo zrušení podle § 57a odst. 8, v rámci rozhodnutí o povolení k provozování záchranné
stanice nebo jeho změny stanovuje odchylný postup podle § 5b odst. 1 a povoluje výjimku
ze zákazů u zvláště chráněných druhů rostlin a zvláště chráněných druhů živočichů podle
§ 56 odst. 1, vede seznam záchranných stanic a zveřejňuje jej na svých internetových
stránkách podle § 57a odst. 2,“.
164. V § 79 odst. 3 se za písmeno c) vkládá nové písmeno d), které zní:
„d) vydává pro stavby pro energetickou bezpečnost77), s výjimkou staveb výroben elektřiny
z obnovitelných zdrojů, závazná stanoviska k povolení výjimky podle § 56 ze zákazů
u zvláště chráněných druhů rostlin a živočichů zařazených v I. kategorii ochrany
a vyjádření k povolení výjimky podle § 56 ze zákazů u zvláště chráněných druhů rostlin
a živočichů zařazených v II. kategorii ochrany,“.
Poznámka pod čarou č. 77 zní:
„77)
§ 1 odst. 5 zákona č. 416/2009 Sb., o urychlení výstavby strategicky významné
infrastruktury, ve znění pozdějších předpisů.“.
Dosavadní písmena d) až v) se označují jako písmena e) až w).
165. V § 79 odst. 3 písmeno q) zní:
„q) schvaluje a ukončuje záchranné programy podle § 52a odst. 1 a programy péče podle § 52a
odst. 2 a společně s Agenturou zajišťuje koordinaci jejich realizace,“.
166. V § 79 odst. 3 se za písmeno q) vkládají nová písmena r) a s), která znějí:
„r) může vydat, pokud jde o blíže neurčený okruh osob, opatření obecné povahy ke stanovení
odchylného postupu při ochraně ptáků podle § 5b odst. 4, opatření obecné povahy, kterým
se vydává souhlas k prodeji a nabízení za účelem prodeje živých jedinců druhů čmeláků a
pačmeláků rodu Bombus, k jejich vypouštění a rozšiřování podle § 5c odst. 4, opatření
obecné povahy, kterým stanoví podmínky odebírání nebo využívání jedinců zvláště
chráněného druhu rostliny nebo živočicha zařazeného v III. kategorii ochrany z přírody
podle § 50 odst. 2 a opatření obecné povahy, kterým se povoluje výjimka ze zákazů u
zvláště chráněných druhů rostlin a živočichů podle § 56 odst. 1 a 4, týká-li se takové
opatření území zasahujícího správní obvody nejméně 2 příslušných orgánů ochrany
přírody,
s) může uzavírat dohody podle § 56 odst. 5, pokud se mají vztahovat na území zasahující
správní obvody nejméně 2 příslušných orgánů ochrany přírody,“.
Dosavadní písmena r) až w) se označují jako písmena t) až y).
167. V § 79 odst. 3 písm. u) se text „odst. 2 písm. b)“ zrušuje.
168. V § 79 odst. 4 se slova „pověřených obecních úřadů,“ zrušují.
169. V § 79 odst. 5 písm. d) se slova „jestliže rostou na pozemcích ve vlastnictví fyzických
osob, které tyto pozemky užívají,“ zrušují.
170. V § 79 odst. 5 písmeno n) zní:
„n) stanoví seznam zvláště chráněných druhů rostlin a živočichů a jejich zařazení do příslušné
kategorie ochrany podle § 48 odst. 3, podrobnější charakteristiku podstatných změn
hydrologických půdních poměrů a vodního režimu území, půdního povrchu a chemických
vlastností prostředí s ohledem na nároky jednotlivých zvláště chráněných druhů rostlin
nebo živočichů anebo jejich skupin podle § 49a odst. 4, bližší podmínky nezaměnitelného
a trvalého označení a jiného způsobu nezaměnitelné a trvalé identifikace mrtvých jedinců
zvláště chráněných druhů rostlin a živočichů zařazených v I. nebo II. kategorii ochrany
podle § 49b odst. 3, seznam zvláště chráněných nerostů podle § 51 a míst jejich přirozeného
výskytu a dále bližší podmínky jejich ochrany,“.
171. V § 79 odst. 5 písm. o) se za slovo „ověřování“ vkládá slovo „zákonného“, slovo
„náležitosti“ se nahrazuje slovem „vzor“ a text „§ 54 odst. 11“ se nahrazuje textem „§ 55
odst. 7“.
172. V § 79 odst. 5 se za písmeno o) vkládá nové písmeno p), které zní:
„p) stanoví bližší podmínky pro poskytování péče živočichům v záchranných stanicích
s ohledem na zachování jejich přirozených vlastností a možnost jejich návratu do přírody
a podmínky pro poskytování dlouhodobé péče živočichům, jejichž návrat do přírody není
možný, a jejich využití pro osvětové a vzdělávací účely podle § 57b odst. 7 a výši nákladů
na krmivo, energie a chovatelskou péči o jedince hrazené Ministerstvem životního
prostředí podle § 89 odst. 7,“.
Dosavadní písmena p) až x) se označují jako písmena q) až y).
173. V § 79 odst. 5 písm. q) se číslo „4“ nahrazuje číslem „7“.
174. V § 79 odst. 5 písm. t) se číslo „3“ nahrazuje číslem „2“.
175. V § 79 odst. 7 se slova „splňují podmínky stanovené v čl. 8 odst. 2 a 3 nařízení
Evropského parlamentu a Rady (EU) č. 1143/2014“ nahrazují slovy „jsou schopna zajistit
potřebnou odbornou péči a zabránit úniku a rozmnožování invazních nepůvodních
živočichů“.
176. V § 80 odst. 2 se za slovo „jedinců“ vkládají slova „a odstranění jedinců invazního
nepůvodního druhu na unijním seznamu“.
177. V § 80 odst. 3 se za slovo „prokazování“ vkládá slovo „zákonného“.
178. V § 80 odst. 4 větě druhé se za slovo „již“ vkládají slova „stavební úřad,“, ve větě třetí se
za slovo „zahájí“ vkládají slova „stavební úřad,“ a za slovo „přestupku“ se vkládají slova
„stavební úřad,“ a ve větě čtvrté se za slovo „a“ vkládají slova „stavební úřad,“.
179. V § 80 se doplňuje odstavec 5, který zní:
„(5) Jedná-li se o kontrolu dodržování ustanovení tohoto zákona týkajících se ochrany
zvláště chráněných druhů rostlin a živočichů, ochrany ptáků nebo ochrany před invazními
nepůvodními druhy, je inspekce oprávněna po právnických, podnikajících fyzických
a fyzických osobách požadovat prokázání zákonného původu podle § 54 odst. 1, prokázání
jejich totožnosti podle § 54 odst. 3 písm. a) a odebrat jim nedovoleně držené jedince nebo uložit
jim odstranění jedince invazního nepůvodního druhu na unijním seznamu podle § 89. Inspekce
rovněž projednává přestupky právnických, podnikajících fyzických a fyzických osob, pokud
jimi byly porušeny povinnosti podle tohoto zákona týkající se ochrany zvláště chráněných
druhů rostlin a živočichů, ochrany ptáků nebo ochrany před invazními nepůvodními druhy.“.
180. V § 81 se na konci odstavce 7 tečka nahrazuje slovem „ , a“ a doplňuje se písmeno g),
které zní:
„g) pořídit zvukový, obrazový nebo jiný záznam osob a věcí nacházejících se na veřejně
přístupném místě a zvukový, obrazový nebo jiný záznam průběhu úkonu, je-li to nezbytné
pro plnění jejich úkolů.“.
181. V § 81 odstavec 8 zní:
„(8) V případě bezprostředního ohrožení zájmů chráněných podle částí druhé až páté tohoto
zákona je strážce přírody oprávněn k pozastavení rušivé činnosti. O svém opatření bezodkladně
vyrozumí orgán ochrany přírody, který strážce ustanovil. Opatření potvrdí, změní nebo zruší
orgán ochrany přírody, který strážce ustanovil, rozhodnutím nejpozději do 15 dnů od jeho
provedení strážcem. Vydání rozhodnutí je prvním úkonem v řízení.“.
182. V § 82a se odstavec 3 zrušuje.
183. V § 83 odstavec 8 zní:
„(8) V případě řízení o žádosti o povolení záměru podle stavebního zákona se odstavce 1
až 7 nepoužijí.“.
184. V § 83 odst. 9 se slova „jednotné environmentální stanovisko62)“ nahrazují slovy
„povolení podle stavebního zákona“, za slova „chráněném území“ se vkládají slova „nebo
jeho ochranném pásmu“, slova „ve společném řízení“ se zrušují, slova „společné
rozhodnutí, které zahrnuje“ se nahrazují slovy „společné závazné stanovisko, které
nahrazuje“, za slova „anebo vyjádření“ se vkládají slova „podle tohoto zákona“ a slova
„ , společné rozhodnutí“ se nahrazují slovy „nebo jeho ochranného pásma, společné
závazné stanovisko“.
185. V § 83a odst. 1 úvodní části ustanovení se slova „nebo jednotného environmentálního
stanoviska“ zrušují a za slovo „záměru“ se vkládají slova „v rozsahu nezbytném pro
vydání souhlasu, povolení nebo jiného rozhodnutí, závazného stanoviska, vyjádření
anebo jiného správního úkonu“.
186. V § 83a se na konci odstavce 1 doplňuje závěrečná část ustanovení, která zní:
„Obsah jednotlivých částí dokumentace musí odpovídat druhu, účelu a významu záměru, jeho
vlivu na území, podmínkám v území, vlivu na životní prostředí, popřípadě době trvání záměru.
Části dokumentace, které nejsou předmětem navrhovaného záměru, se neuvádějí.“.
187. V § 83a se odstavec 3 zrušuje.
188. V § 85 odst. 1 se slova „Krajské úřady, obecní úřady obcí s rozšířenou působností, újezdní
úřady, Agentura a správy národních parků“ nahrazují slovy „Orgány ochrany přírody
v obvodu své působnosti“.
189. V § 87 odst. 1 písmena b) a c) znějí:
„b) poruší povinnost obecné ochrany rostlin a živočichů podle § 5 odst. 1,
c) neprovede postupy nebo opatření uložené orgánem ochrany přírody podle § 5 odst. 3 nebo
§ 5c odst. 1,“.
190. V § 87 odst. 1 se za písmeno c) vkládají nová písmena d) a e), která znějí:
„d) poruší některý ze zákazů na ochranu ptáků podle § 5a odst. 1 písm. c) až e) nebo § 5a
odst. 2,
e) prodá nebo nabídne za účelem prodeje živého jedince druhu čmeláka nebo pačmeláka rodu
Bombus anebo vypustí nebo rozšíří takového jedince, který nemá původ ve volné přírodě
České republiky, bez souhlasu podle § 5c odst. 4 nebo v rozporu s ním,“.
Dosavadní písmena d) až m) se označují jako písmena f) až o).
191. V § 87 odst. 1 písm. g) se za slovo „ohlašovací“ vkládají slova „ , oznamovací nebo
registrační“.
192. V § 87 se na konci odstavce 1 tečka nahrazuje čárkou a doplňuje se písmeno p), které zní:
„p) v rozporu s § 57a odst. 2 používá označení „záchranná stanice“.“.
193. V § 87 odst. 2 úvodní části ustanovení se za slovo „se“ vkládá slovo „dále“.
194. V § 87 odst. 2 písmena b) a c) znějí:
„b) poruší některý ze zákazů na ochranu ptáků podle § 5a odst. 1 písm. a) nebo b),
c) neprovede opatření uložená orgánem ochrany přírody podle § 48a,“.
195. V § 87 odst. 2 se za písmeno c) vkládají nová písmena d) až l), která znějí:
„d) v rozporu s § 49 poškodí biotop nebo místní populaci zvláště chráněného druhu rostliny
nebo živočicha anebo její genofond,
e) v rozporu s § 49a odst. 1 písm. a) úmyslně sbírá, trhá, poškodí nebo zničí zvláště chráněný
druh rostliny zařazený v I. nebo II. kategorii ochrany,
f)
poruší některý ze zákazů na ochranu zvláště chráněných druhů rostlin zařazených v I. nebo
II. kategorii ochrany anebo evropsky významného druhu rostliny podle § 49a odst. 1 písm.
b) nebo § 49c,
g) v rozporu s § 49a odst. 2 písm. a) úmyslně sbírá, chytá, ruší, zničí, zraňuje nebo usmrtí
jedince zvláště chráněných druhů živočichů zařazených v I. nebo II. kategorii ochrany,
h) poruší zákaz na ochranu zvláště chráněných druhů živočichů zařazených v I. nebo
II. kategorii ochrany anebo evropsky významného druhu živočicha podle § 49a odst. 2
písm. b) nebo c) nebo § 49c,
i)
poruší některý ze zákazů na ochranu zvláště chráněných druhů živočichů a rostlin
zařazených v I. nebo II. kategorii ochrany vztahujících se na mrtvé jedince, jejich části
nebo výrobky z nich podle § 49b odst. 1,
j)
poruší zákaz prodeje nebo nabízení za účelem prodeje jedince zvláště chráněného druhu
rostliny nebo živočicha zařazeného v III. kategorii ochrany, jeho části nebo výrobku z něj
podle § 50 odst. 1,
k) odebere z přírody jedince zvláště chráněného druhu rostliny nebo živočicha zařazeného
v III. kategorii ochrany v rozporu s omezením orgánu ochrany přírody podle § 50 odst. 2,
l)
v rozporu s § 52b odst. 1 vypustí zvláště chráněného živočicha odchovaného v lidské péči
do přírody nebo vyseje anebo vysadí uměle vypěstovanou zvláště chráněnou rostlinu mimo
kulturu nebo zastavěné území obce bez souhlasu orgánu ochrany přírody,“.
Dosavadní písmena d) až m) se označují jako písmena m) až v).
196. V § 87 odst. 2 se písmeno r) zrušuje.
Dosavadní písmena s) až v) se označují jako písmena r) až u).
197. V § 87 odst. 3 úvodní části ustanovení se za slovo „se“ vkládá slovo „dále“.
198. V § 87 odst. 3 písmena b) a c) znějí:
„b) v rozporu s § 49 zničí biotop nebo místní populaci zvláště chráněného druhu rostliny nebo
živočicha anebo její genofond; za přestupek podle tohoto ustanovení se nepovažují zásahy
do biotopu nebo místní populace zvláště chráněného druhu v rámci lesnického
hospodaření, které byly provedeny mimo místa výskytu uvedená v lesním hospodářském
plánu nebo místa výskytu, o nichž po schválení lesního hospodářského plánu informoval
orgán ochrany přírody podle § 48 odst. 5; to platí pouze v případě, že výskyt druhu nebyl
zřejmý,
c) v rozporu s § 49a odst. 1 písm. a) nebo § 49c úmyslně zničí jedince zvláště chráněného
druhu rostliny zařazeného v I. nebo II. kategorii ochrany anebo evropsky významného
druhu; za přestupek podle tohoto ustanovení se nepovažují zásahy do biotopu nebo místní
populace zvláště chráněného druhu v rámci lesnického hospodaření, které byly provedeny
mimo místa výskytu uvedená v lesním hospodářském plánu nebo místa výskytu, o nichž
po schválení lesního hospodářského plánu informoval orgán ochrany přírody podle § 48
odst. 5; to platí pouze v případě, že výskyt druhu nebyl zřejmý,“.
199. V § 87 odst. 3 se za písmeno c) vkládá nové písmeno d), které zní:
„d) v rozporu s § 49a odst. 2 písm. a) úmyslně usmrtí jedince zvláště chráněného druhu
živočicha zařazeného v I. nebo II. kategorii ochrany anebo evropsky významného druhu;
za přestupek podle tohoto ustanovení se nepovažují zásahy do biotopu nebo místní
populace zvláště chráněného druhu v rámci lesnického hospodaření, které byly provedeny
mimo místa výskytu uvedená v lesním hospodářském plánu nebo místa výskytu, o nichž
po schválení lesního hospodářského plánu informoval orgán ochrany přírody podle § 48
odst. 5; to platí pouze v případě, že výskyt druhu nebyl zřejmý,“.
Dosavadní písmena d) až r) se označují jako písmena e) až s).
200. V § 87 odst. 3 se písmeno h) zrušuje.
Dosavadní písmena i) až s) se označují jako písmena h) až r).
201. V § 87 odst. 3 písm. l) se slova „56 nebo“ nahrazují slovy „§ 56 odst. 1 nebo 5, podmínky
dohody uzavřené podle § 49a odst. 6 nebo § 56 odst. 5 nahrazující výjimku podle § 56
odst. 1 anebo“.
202. V § 87 odst. 3 se na konci textu písmene o) doplňují slova „ , 55 nebo 55a“.
203. V § 87 se za odstavec 3 vkládá nový odstavec 4, který zní:
„(4) Fyzická osoba se jako provozovatel motorového vozidla dopustí přestupku tím, že v
rozporu s § 44b nezajistí, aby při užití tohoto vozidla ve zvláště chráněném území byly
dodržovány zákazy vjezdu a setrvávání motorových vozidel stanovené tímto zákonem nebo aby
nedošlo k vjezdu nebo setrvání motorového vozidla, k němuž je nezbytný souhlas orgánu
ochrany přírody, bez tohoto souhlasu. K odpovědnosti fyzické osoby za tento přestupek se
nevyžaduje zavinění. Provozovatel motorového vozidla za tento přestupek neodpovídá, jestliže
prokáže, že v době před porušením povinností podle tohoto zákona bylo vozidlo, jehož je
provozovatelem, odcizeno nebo byla odcizena jeho tabulka s přidělenou registrační značkou,
nebo pokud podal žádost o zápis změny provozovatele vozidla v registru silničních vozidel, jíž
bylo následně vyhověno.“.
Dosavadní odstavce 4 až 6 se označují jako odstavce 5 až 7.
204. V § 87 odst. 5 se na konci textu písmene a) doplňují slova „nebo 4“.
205. V § 88 odst. 1 písmena d) a e) znějí:
„d) poruší povinnost obecné ochrany rostlin a živočichů podle § 5 odst. 1,
e) neprovede postupy nebo opatření uložené orgánem ochrany přírody podle § 5 odst. 3 nebo
§ 5c odst. 1,“.
206. V § 88 odst. 1 se za písmeno e) vkládají nová písmena f) a g), která znějí:
„f) poruší některý ze zákazů na ochranu ptáků podle § 5a odst. 1 písm. c) až e) nebo § 5a
odst. 2,
g) prodá nebo nabídne za účelem prodeje živého jedince druhu čmeláka nebo pačmeláka rodu
Bombus anebo vypustí nebo rozšíří takového jedince, který nemá původ ve volné přírodě
České republiky, bez souhlasu podle § 5c odst. 4 nebo v rozporu s ním,“.
Dosavadní písmena f) až s) se označují jako písmena h) až u).
207. V § 88 odst. 1 písm. j) se za slovo „ohlašovací“ vkládají slova „ , oznamovací nebo
registrační“, slovo „nebo“ se nahrazuje čárkou a za slovo „výsadby“ se vkládají slova
„nebo nezajistí následnou péči o vysazené dřeviny“.
208. V § 88 se na konci odstavce 1 tečka nahrazuje čárkou a doplňuje se písmeno v), které zní:
„v) v rozporu s § 57a odst. 2 používá označení „záchranná stanice“.“.
209. V § 88 odst. 2 úvodní části ustanovení se za slovo „se“ vkládá slovo „dále“.
210. V § 88 odst. 2 písmena d) a e) znějí:
„d) poruší některý ze zákazů na ochranu ptáků podle § 5a odst. 1 písm. a) nebo b),
e) neprovede opatření uložená orgánem ochrany přírody podle § 48a,“.
211. V § 88 odst. 2 se za písmeno e) vkládají nová písmena f) až l), která znějí:
„f) v rozporu s § 49 poškodí nebo zničí biotop nebo místní populaci zvláště chráněného druhu
rostliny nebo živočicha anebo její genofond; za přestupek podle tohoto ustanovení se
nepovažují zásahy do biotopu nebo místní populace zvláště chráněného druhu v rámci
lesnického hospodaření, které byly provedeny mimo místa výskytu uvedená v lesním
hospodářském plánu nebo místa výskytu, o nichž po schválení lesního hospodářského
plánu informoval orgán ochrany přírody podle § 48 odst. 5; to platí pouze v případě, že
výskyt druhu nebyl zřejmý,
g) poruší některý ze zákazů na ochranu zvláště chráněných druhů rostlin zařazených v I. nebo
II. kategorii ochrany anebo evropsky významného druhu rostliny podle § 49a odst. 1 nebo
§ 49c; za přestupek podle tohoto ustanovení se nepovažují zásahy do biotopu nebo místní
populace zvláště chráněného druhu v rámci lesnického hospodaření, které byly provedeny
mimo místa výskytu uvedená v lesním hospodářském plánu nebo místa výskytu, o nichž
po schválení lesního hospodářského plánu informoval orgán ochrany přírody podle § 48
odst. 5; to platí pouze v případě, že výskyt druhu nebyl zřejmý,
h) poruší některý ze zákazů na ochranu zvláště chráněných druhů živočichů zařazených v
I. nebo II. kategorii ochrany anebo evropsky významného druhu živočicha podle § 49a
odst. 2 nebo § 49c; za přestupek podle tohoto ustanovení se nepovažují zásahy do biotopu
nebo místní populace zvláště chráněného druhu v rámci lesnického hospodaření, které byly
provedeny mimo místa výskytu uvedená v lesním hospodářském plánu nebo místa výskytu,
o nichž po schválení lesního hospodářského plánu informoval orgán ochrany přírody podle
§ 48 odst. 5; to platí pouze v případě, že výskyt druhu nebyl zřejmý,
i)
poruší některý ze zákazů na ochranu zvláště chráněných druhů živočichů a rostlin
zařazených v I. nebo II. kategorii ochrany vztahujících se na mrtvé jedince, jejich části
nebo výrobky z nich podle § 49b odst. 1,
j)
poruší zákaz prodeje nebo nabízení za účelem prodeje jedince zvláště chráněného druhu
rostliny nebo živočicha zařazeného v III. kategorii ochrany, jeho části nebo výrobku z něj
podle § 50 odst. 1,
k) odebere z přírody jedince zvláště chráněného druhu rostliny nebo živočicha zařazeného v
III. kategorii ochrany v rozporu s omezením orgánu ochrany přírody podle § 50 odst. 2,
l)
v rozporu s § 52b odst. 1 vypustí zvláště chráněného živočicha odchovaného v lidské péči
do přírody nebo vyseje anebo vysadí uměle vypěstovanou zvláště chráněnou rostlinu mimo
kulturu nebo zastavěné území obce bez souhlasu orgánu ochrany přírody,“.
Dosavadní písmena f) až s) se označují jako písmena m) až z).
212. V § 88 odst. 2 se na konci textu písmene v) doplňují slova „ , 55 nebo 55a“.
213. V § 88 odst. 2 písm. w) se slova „56 nebo“ nahrazují slovy „§ 56 odst. 1 nebo 5, podmínky
dohody uzavřené podle § 49a odst. 6 nebo § 56 odst. 5 nahrazující výjimku podle § 56
odst. 1 anebo“.
214. V § 88 se za odstavec 2 vkládá nový odstavec 3, který zní:
„(3) Právnická nebo podnikající fyzická osoba se jako provozovatel motorového vozidla
dopustí přestupku tím, že v rozporu s § 44b nezajistí, aby při užití motorového vozidla ve
zvláště chráněném území byly dodržovány zákazy vjezdu a setrvávání motorových vozidel
stanovené tímto zákonem nebo aby nedošlo k vjezdu nebo setrvání motorového vozidla,
k němuž je nezbytný souhlas orgánu ochrany přírody, bez tohoto souhlasu. Provozovatel
motorového vozidla za tento přestupek neodpovídá, jestliže prokáže, že v době před porušením
povinností podle tohoto zákona bylo vozidlo, jehož je provozovatelem, odcizeno nebo byla
odcizena jeho tabulka s přidělenou registrační značkou, nebo pokud podal žádost o zápis změny
provozovatele vozidla v registru silničních vozidel, jíž bylo následně vyhověno.“.
Dosavadní odstavce 3 a 4 se označují jako odstavce 4 a 5.
215. V § 88 se na konci odstavce 4 tečka nahrazuje čárkou a doplňuje se písmeno c), které zní:
„c) 10 000 Kč, jde-li o přestupek podle odstavce 3.“.
216. § 88a včetně nadpisu zní:
„§ 88a
Společná ustanovení k přestupkům
(1) Výnosy pokut uložených obecním úřadem obce s rozšířenou působností jsou příjmem
rozpočtu obce a výnosy pokut uložených krajským úřadem jsou příjmem rozpočtu kraje.
Výnosy pokut uložených stavebním úřadem, Agenturou, správou národního parku a inspekcí
se dělí způsobem upraveným zvláštním zákonem7), s výjimkou území vojenských újezdů, kde
je výnos pokut příjmem státního rozpočtu. Výnosy z pokut může obec užít jen pro zlepšení
životního prostředí a pro ochranu přírody a krajiny v obci.
(2) Pravomocná rozhodnutí o přestupku podle § 87 odst. 2 písm. f), § 87 odst. 3 písm. d) a
§ 88 odst. 2 písm. h) se zapisují do evidence přestupků spravované Ministerstvem spravedlnosti.
(3) Orgán ochrany přírody přestupek podle § 87 odst. 4 nebo § 88 odst. 3 projedná, pouze
pokud učinil nezbytné kroky ke zjištění pachatele přestupku, jehož znaky porušení povinností
řidiče vykazuje, a
a) nezahájil řízení o tomto přestupku a věc odložil, protože nezjistil skutečnosti odůvodňující
zahájení řízení proti určité osobě, nebo
b) řízení o tomto přestupku zastavil, protože obviněnému z přestupku nebylo spáchání skutku
prokázáno.
(4) Je-li zahájeno řízení o uložení pokuty za přestupek podle § 87 odst. 4 nebo § 88 odst. 3,
nelze již zahájit řízení o přestupku pro stejné porušení povinností řidiče; to neplatí, pokud se
provozovatel vozidla zprostí odpovědnosti za přestupek podle § 87 odst. 4 nebo § 88 odst. 3.
Do promlčecí doby přestupku podle § 87 odst. 4 nebo § 88 odst. 3 se nezapočítává doba,
po kterou bylo vedeno řízení o přestupku podle odstavce 3 písm. b). Do promlčecí doby
přestupku, jehož znaky porušení povinností řidiče vykazuje, se nezapočítává doba, po kterou
bylo pro stejné porušení povinností řidiče nebo pravidel provozu na pozemních komunikacích
vedeno řízení o přestupku podle § 87 odst. 4 nebo § 88 odst. 3.“.
217. V § 89 odst. 1 větě druhé se slova „živočichů nebo“ nahrazují slovy „živočichů, ptáků
nebo“.
218. V § 89 se na konci odstavce 2 tečka nahrazuje slovem „ , nebo“ a doplňuje se písmeno c),
které zní:
„c) jde-li o osobu, která jej má v držení, jej využívá bez povolení podle čl. 8 odst. 1 nebo čl. 19
odst. 2 nařízení Evropského parlamentu a Rady (EU) č. 1143/2014 nebo v rozporu
s podmínkami stanovenými v tomto povolení.“.
219. V § 89 se za odstavec 2 vkládají nové odstavce 3 a 4, které znějí:
„(3) Doručením oznámení o zahájení řízení o odebrání vzniká držiteli jedince zvláště
chráněného druhu rostliny nebo živočicha, druhu rostliny nebo živočicha chráněného podle
mezinárodních úmluv, ptáka nebo jedince invazního nepůvodního druhu živočicha na unijním
seznamu, jeho části nebo výrobku z něj povinnost do doby, než bude řízení pravomocně
ukončeno, zdržet se jednání, které by mohlo zmařit účel řízení o odebrání, zejména drženého
jedince prodat, darovat nebo s ním jinak nakládat. Je-li důvodné podezření, že jej osoba drží
nedovoleně, a zároveň hrozí, že jeho držitel zmaří účel řízení o odebrání, nebo to vyžaduje
zájem na ochraně drženého jedince, může orgán ochrany přírody jedince předběžným
opatřením zajistit.
(4) Rozhodnutí o odebrání jedince podle odstavce 3 zašle orgán ochrany přírody do 10 dnů
ode dne nabytí právní moci rozhodnutí Ministerstvu životního prostředí. Současně orgán
ochrany přírody informuje Ministerstvo životního prostředí o tom, kde se jedinec ke dni nabytí
právní moci tohoto rozhodnutí nachází.“.
Dosavadní odstavce 3 a 4 se označují jako odstavce 5 a 6.
220. V § 89 se na konci odstavce 6 doplňuje věta „Odebranou věc nelze převést na osobu,
které byla odebrána, a ve smlouvě o převodu odebrané věci se stanoví podmínka, že tu
věc nesmí osoba, které byla odebrána, získat ani žádným dalším následným převodem;
získá-li osoba, které byla věc odebrána, tuto věc opět do své držby, je tento převod
neplatný a orgán ochrany přírody věc opětovně odebere.“.
221. V § 89 se doplňují odstavce 7 a 8, které znějí:
„(7) Náklady spojené se zajištěním, odebráním a dalším nakládáním s jedincem,
které
nese správní orgán nebo které musí vynaložit, hradí Ministerstvo životního prostředí. Náklady
na krmivo, energie a chovatelskou péči o jedince hradí Ministerstvo životního prostředí ve výši
stanovené vyhláškou.
(8) Orgán ochrany přírody je oprávněn namísto odebrání podle odstavce 2 uložit odstranění
jedince invazního nepůvodního druhu na unijním seznamu, pokud je takový postup vhodnější
z hlediska předcházení dalšího rozšíření takového druhu nebo z jiného důvodu účelnější. Uložit
odstranění je orgán ochrany přírody oprávněn rovněž v případě jedince invazního nepůvodního
druhu rostliny na unijním seznamu.“.
222. Za § 89 se vkládá nový § 89a, který zní:
„§ 89a
Na správu jedinců zvláště chráněných druhů a ptáků předaných inspekci podle zákona
o výkonu zajištění majetku a věcí v trestním řízení se přiměřeně použijí ustanovení tohoto
zákona upravující nakládání s odebranými jedinci.“.
223. V § 90 odst. 2 se slovo „přímé“ zrušuje, slovo „zajištěním“ se nahrazuje slovem
„zajišťováním“ a slova „anebo ozbrojených“ se nahrazují slovem „anebo“.
224. V § 90 odst. 5 se slova „volně žijících“ a slova „planě rostoucích“ zrušují.
225. V § 90 odstavec 18 zní:
„(18) Povolení, souhlasy a jiné správní úkony podle části druhé až páté tohoto zákona se
nevyžadují k provádění
a) činností orgánem ochrany přírody při zajišťování výkonu své působnosti podle tohoto
zákona v oblasti péče o přírodní a krajinné prostředí, ekosystémy a jejich složky, provádění
inventarizačních přírodovědných průzkumů, monitoringu, dokumentace a šetření
v ochraně přírody, provádění opatření k regulaci, odstranění nebo izolaci invazního
nepůvodního druhu na unijním seznamu, provádění záchranných programů, regionálních
akčních plánů a programů péče a vykonávání informační a osvětové činnosti, a to
prostřednictvím svých pracovníků nebo prostřednictvím jiných osob v souladu s dohodou
uzavřenou za tímto účelem,
b) činností vlastníky nebo nájemci v rámci péče o pozemky v souladu s dohodou podle § 68
odst. 2, nebo
c) zásahů ke zlepšení přírodního a krajinného prostředí podle § 68 odst. 3 pracovníky orgánů
ochrany přírody nebo prostřednictvím jiné osoby.“.
226. V § 90 se odstavec 19 zrušuje.
Dosavadní odstavce 20 až 23 se označují jako odstavce 19 až 22.
227. V § 90 odst. 19 se slova „odstavců 18 a 19“ nahrazují slovy „odstavce 18“ a na konci
textu odstavce se doplňují slova „a předmětů ochrany evropsky významných lokalit
a ptačích oblastí. V případě činností podle odstavce 18 prováděných prostřednictvím
jiných osob musí být v dohodě uzavřené orgánem ochrany přírody za účelem zajištění
jeho působnosti stanoven účel uzavírané dohody a podmínky zajišťující splnění
požadavků uvedených ve větě první“.
228. V § 90 se odstavec 20 zrušuje.
Dosavadní odstavce 21 a 22 se označují jako odstavce 20 a 21.
229. V § 90 odst. 20 se na konci textu věty první doplňují slova „ ; to neplatí, jedná-li se o lesní
porosty75)“ a věta třetí se nahrazuje větou „Záměr na provedení vypalování porostů včetně
navrhovaných opatření jsou orgány ochrany přírody povinny předem dohodnout s místně
příslušným hasičským záchranným sborem kraje.“.
Poznámka pod čarou č. 75 zní:
„75)
§ 2 písm. c) zákona č. 289/1995 Sb., ve znění pozdějších předpisů.“.
230. V § 90 se doplňuje odstavec 22, který zní:
„(22) Smlouva o ochraně území evropsky významné lokality, prohlášení stromu za
památný nebo o ochraně jiného stromu nebo jiného území se soustředěnými přírodními
hodnotami podle § 39 odst. 1, smlouva o způsobu hospodaření v ptačí oblasti podle § 45e odst.
4, dohoda o způsobu hospodaření nebo péči o pozemek podle § 49a odst. 6, dohoda
k zajišťování činností uvedených v § 56 odst. 2 písm. a), d) nebo e) podle § 56 odst. 5 a dohoda
k provádění péče o pozemky z důvodů ochrany přírody nebo o způsobu hospodaření ve zvláště
chráněných územích podle § 68 odst. 2 jsou veřejnoprávními smlouvami.“.
Čl. XV
Přechodná ustanovení
1. Řízení a postupy zahájené a neskončené přede dnem nabytí účinnosti tohoto zákona se
dokončí podle zákona č. 114/1992 Sb., ve znění účinném ode dne nabytí účinnosti tohoto
zákona, není-li stanoveno jinak.
2. Řízení a postupy zahájené a neskončené do dne vzniku Úřadu rozvoje území České
republiky (dále jen „Úřad“), k nimž je příslušný Úřad nebo jiný stavební úřad, převezme
a dokončí ode dne svého vzniku Úřad nebo jiný stavební úřad.
3. Řízení a postupy zahájené a neskončené do dne vzniku úřadů rozvoje území krajů,
k nimž je příslušný úřad rozvoje území kraje nebo jeho územní pracoviště, ode dne vzniku
úřadů rozvoje území krajů převezme a dokončí příslušný úřad rozvoje území kraje nebo jeho
příslušné územní pracoviště. Do dne vzniku úřadů rozvoje území krajů pokračují v těchto
řízeních a postupech správní orgány příslušné podle dosavadních právních předpisů, a to podle
zákona č. 114/1992 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona, s výjimkou
§ 75, § 76, § 77a odst. 3, § 77b, § 78 odst. 6, 78a, § 83 odst. 8 a § 88a, a dále podle § 75, § 76,
§ 77a odst. 3, § 78 odst. 6, 78a, § 83 odst. 8 a § 88a zákona č. 114/1992 Sb., ve znění účinném
přede dnem nabytí účinnosti tohoto zákona.
4. Řízení o žádosti o vydání společného rozhodnutí podle § 83 odst. 9 zákona č. 114/1992
Sb., ve znění účinném přede dnem nabytí účinnosti tohoto zákona, ve věcech záměrů, k nimž
je jako stavební úřad příslušný úřad rozvoje území, zahájená a neskončená do dne vzniku úřadů
rozvoje území, se zastaví a vyřízení žádosti se dokončí podle zákona č. 114/1992 Sb., ve znění
účinném ode dne nabytí účinnosti tohoto zákona, a to ve lhůtě počínající dnem nabytí účinnosti
tohoto zákona; to platí i pro řízení o opravných prostředcích.
5. Ustanovení § 48 odst. 5 zákona č. 114/1992 Sb., ve znění účinném ode dne nabytí
účinnosti tohoto zákona, se použije pro správní řízení o schválení lesních hospodářských plánů
zahájená po dni nabytí účinnosti tohoto zákona.
6. Ustanovení § 70 zákona č. 114/1992 Sb., ve znění účinném ode dne nabytí účinnosti
tohoto zákona, se použije až pro správní řízení zahájená po dni nabytí účinnosti tohoto zákona.
7. Rozhodnutí o povolení k provozování záchranné stanice vydaná Ministerstvem
životního prostředí podle § 5 odst. 12 zákona č. 114/1992 Sb., ve znění účinném přede dnem
nabytí účinnosti tohoto zákona, se považují za rozhodnutí vydaná podle § 57a odst. 1 zákona
č. 114/1992 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona, a zůstávají
v platnosti po dobu a za podmínek v nich stanovených.
8. Rozhodnutí o vyhlášení památného stromu a jeho ochranného pásma vydaná podle § 46
odst. 1 zákona č. 114/1992 Sb., ve znění účinném přede dnem nabytí účinnosti tohoto zákona,
včetně stanovení činností a zásahů v ochranném pásmu památného stromu, které lze provádět
jen se souhlasem orgánu ochrany přírody, podle § 46 odst. 3 zákona č. 114/1992 Sb., ve znění
účinném přede dnem nabytí účinnosti tohoto zákona, se považují za rozhodnutí vydaná podle
§ 46 odst. 1 zákona č. 114/1992 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona,
a činnosti a zásahy v ochranném pásmu, které lze provádět jen se souhlasem orgánu ochrany
přírody, stanovené podle § 46 odst. 4 zákona č. 114/1992 Sb., ve znění účinném ode dne nabytí
účinnosti tohoto zákona.
9. Za ochranné pásmo památného stromu vyhlášeného přede dnem nabytí účinnosti tohoto
zákona se považuje ochranné pásmo památného stromu zapsané Agenturou ochrany přírody a
krajiny České republiky do informačního systému územní identifikace podle čl. II bodu 6
zákona č. 364/2021 Sb., kterým se mění některé zákony v souvislosti s implementací předpisů
Evropské unie v oblasti invazních nepůvodních druhů.
10. Výjimka ze zákazů na ochranu u památných stromů vydaná podle § 56 odst. 1 zákona
č. 114/1992 Sb., ve znění účinném přede dnem nabytí účinnosti tohoto zákona, se považuje za
výjimku podle § 46 odst. 3 zákona č. 114/1992 Sb., ve znění účinném ode dne nabytí účinnosti
tohoto zákona. Souhlas k činnosti nebo zásahu v ochranném pásmu památného stromu vydaný
podle § 46 odst. 3 zákona č. 114/1992 Sb., ve znění účinném přede dnem nabytí účinnosti tohoto
zákona, se považuje za souhlas podle § 46 odst. 4 zákona č. 114/1992 Sb., ve znění účinném
ode dne nabytí účinnosti tohoto zákona.
11. V případě, kdy orgán ochrany přírody zruší ochranu památného stromu, který byl jako
památný strom vyhlášen přede dnem nabytí účinnosti tohoto zákona jako součást skupiny nebo
stromořadí památných stromů, pro které bylo vyhlášeno jedno společné ochranné pásmo,
ochranné pásmo dnem nabytí právní moci rozhodnutí o zrušení ochrany památného stromu
nezaniká.
12. Dohody o způsobu hospodaření uzavřené podle § 49 odst. 4 zákona č. 114/1992 Sb.,
ve znění účinném přede dnem nabytí účinnosti tohoto zákona, se považují za dohody o způsobu
hospodaření podle § 49a odst. 6 zákona č. 114/1992 Sb., ve znění účinném ode dne nabytí
účinnosti tohoto zákona, a zůstávají v platnosti po dobu v nich stanovenou.
13. Držitel mrtvého jedince zvláště chráněného druhu rostliny nebo živočicha zařazeného
v I. nebo II. kategorii ochrany, jeho části nebo výrobku z něj, který jej má v držení v den nabytí
účinnosti tohoto zákona, provede jeho registraci podle § 49b odst. 2 zákona č. 114/1992 Sb., ve
znění účinném ode dne nabytí účinnosti tohoto zákona, do 1 roku ode dne nabytí účinnosti
tohoto zákona. Pokud držitel mrtvého jedince zvláště chráněného druhu rostliny nebo živočicha
zařazeného v I. nebo II. kategorii ochrany, jeho části nebo výrobku z něj, nesplní podmínky
registrace, může jej ve lhůtě podle věty první odevzdat státu prostřednictvím Agentury ochrany
přírody a krajiny České republiky nebo správy národního parku; na odevzdané jedince se
z hlediska jejich dalšího nakládání hledí jako jedince odebrané podle § 89 zákona č. 114/1992
Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona.
14. Rozhodnutí o povolení výjimky ze zákazů u zvláště chráněných druhů rostlin
a živočichů vydaná podle § 56 odst. 1 zákona č. 114/1992 Sb., ve znění účinném přede dnem
nabytí účinnosti tohoto zákona, se považují za rozhodnutí vydaná podle § 56 odst. 1 zákona
č. 114/1992 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona, a zůstávají
v platnosti po dobu a za podmínek v nich stanovených.
15. Dohody uzavřené podle § 56 odst. 5 zákona č. 114/1992 Sb., ve znění účinném přede
dnem nabytí účinnosti tohoto zákona, pokud nahrazují výjimku podle § 56 odst. 1 zákona
č. 114/1992 Sb., ve znění účinném přede dnem nabytí účinnosti tohoto zákona, ze zákazů
u památných stromů, zůstávají v platnosti po dobu a za podmínek v nich stanovených.
16. Ustanovení § 12 odst. 4 zákona č. 114/1992 Sb., ve znění účinném ode dne nabytí
účinnosti tohoto zákona, se použije ve vztahu k zastavitelnému území, koridoru pro stavební
záměr nebo ploše těžby, které již byly v souladu se stanoviskem orgánu ochrany přírody
vymezeny v územně plánovací dokumentaci vydané po 1. lednu 2007 jako zastavitelné území,
koridor pro stavební záměr nebo plocha těžby.
17. Ustanovení § 77b odst. 2 zákona č. 114/1992 Sb., ve znění účinném ode dne nabytí
účinnosti tohoto zákona, se nepoužije pro záměry, jejichž posuzování podle zákona
o posuzování vlivů na životní prostředí bylo zahájeno přede dnem nabytí účinnosti tohoto
zákona.
18. Žádost o vydání souhlasu ve formě závazného stanoviska podle § 4 odst. 6 zákona
č. 114/1992 Sb., ve znění účinném přede dnem nabytí účinnosti tohoto zákona, které nebylo
vydáno do dne účinnosti tohoto zákona, se považuje za žádost o vydání vyjádření; lhůta pro
vydání vyjádření běží ode dne podání původní žádosti o vydání souhlasu. Přezkum souhlasu ve
formě závazného stanoviska podle § 4 odst. 6 zákona č. 114/1992 Sb., ve znění účinném přede
dnem nabytí účinnosti tohoto zákona, podle § 149 odst. 7 nebo 8 správního řádu, zahájený
a neskončený do dne účinnosti tohoto zákona, dokončí nadřízený orgán ochrany přírody podle
dosavadních právních předpisů.
19. Vymezení zón kulturní krajiny na zastavěných územích, zastavitelných plochách,
popřípadě zastavitelném území obcí na území národních parků podle § 18 odst. 1 písm. d)
zákona č. 114/1992 Sb., ve znění účinném přede dnem nabytí účinnosti tohoto zákona, zůstává
v platnosti.
20. Řízení o souhlasu k užívání nebo kolaudaci stavby zahájené podle § 44 odst. 1 zákona
č. 114/1992 Sb., ve znění účinném přede dnem nabytí účinnosti tohoto zákona, a k tomuto dni
neskončené, orgán ochrany přírody usnesením zastaví; proti tomuto usnesení se nelze odvolat.
21. Dokumentaci k přechodně chráněné ploše, přírodnímu parku nebo registrovanému
významnému krajinnému prvku, vyhlášeným přede dnem nabytí účinnosti tohoto zákona,
předají příslušné orgány ochrany přírody do registru krajiny do 31. prosince 2027.
ČÁST DEVÁTÁ
Změna zákona o ochraně zemědělského půdního fondu
Čl. XVI
Zákon č. 334/1992 Sb., o ochraně zemědělského půdního fondu, ve znění zákona
č. 10/1993 Sb., zákona č. 98/1999 Sb., zákona č. 132/2000 Sb., zákona č. 76/2002 Sb., zákona
č. 320/2002 Sb., zákona č. 444/2005 Sb., zákona č. 186/2006 Sb., zákona č. 222/2006 Sb.,
zákona č. 167/2008 Sb., zákona č. 9/2009 Sb., zákona č. 227/2009 Sb., zákona č. 281/2009 Sb.,
zákona č. 402/2010 Sb., zákona č. 375/2011 Sb., zákona č. 503/2012 Sb., zákona č. 64/2014
Sb., zákona č. 41/2015 Sb., zákona č. 184/2016 Sb., zákona č. 183/2017 Sb., zákona
č. 225/2017 Sb., zákona č. 403/2020 Sb., zákona č. 544/2020 Sb., zákona č. 609/2020 Sb.,
zákona č. 261/2021 Sb., zákona č. 284/2021 Sb., zákona č. 149/2023 Sb., zákona č. 183/2024
Sb., zákona č. 87/2025 Sb., zákona č. 218/2025 Sb. a zákona č. 287/2025 Sb., se mění takto:
1.
V § 4 odst. 1 úvodní části ustanovení se slovo „zastavěném“ nahrazuje slovem
„zastavitelném“ a slova „nebo v zastavitelných plochách“ se zrušují.
2.
V § 4 odst. 1 písm. b) se na začátek vkládají slova „při určování zemědělské půdy
k jinému než zemědělskému účelu v územně plánovací dokumentaci“ a slovo „zastavěné“
se nahrazuje slovem „zastavitelné“.
3.
V § 4 odst. 2 se za slovo „prospěšnost“ vkládají slova „ , veřejný zájem, ekonomické
a sociální dopady“.
4.
V § 4 odst. 3 větě druhé se za slovo „nemění“ vkládá slovo „základní“.
5.
V § 4 odstavec 4 zní:
„(4) Zemědělskou půdu I. a II. třídy ochrany nelze odejmout ze zemědělského půdního
fondu pro záměry pro obchod nebo skladování o rozsahu větším než 1 ha s výjimkou záměrů
umístěných do 500 m od staveb nebo tras dálnic, silnic I. třídy, drah, leteckých staveb nebo
vodních cest nebo pro záměry energetického zařízení pro přeměnu energie slunečního záření
na elektřinu s výjimkou záměrů podle § 8a. Vznikne-li v důsledku odnětí zemědělské půdy ze
zemědělského půdního fondu pro záměr energetického zařízení pro přeměnu energie
slunečního záření na elektřinu jako stavby dočasné plocha tvořená zemědělskou půdou I. nebo
II. třídy ochrany, na které je ztíženo zemědělské obhospodařování, lze zemědělskou půdu I.
a II. třídy ochrany ze zemědělského půdního fondu dočasně odejmout.“.
6.
V § 4 odst. 5 větě první se slova „transformačních a zastavitelných“ zrušují.
7.
V § 5 odst. 2 se slova „a k návrhu vymezení zastavěného území“ zrušují a na konci textu
odstavce se doplňují slova „při respektování cílů a úkolů územního plánování
a s přihlédnutím k zájmu územních samosprávných celků a státu na rozvoji svého území“.
8.
V § 7 odstavce 1 a 2 znějí:
„(1) Dokumentace pro povolení záměru podle stavebního zákona, který vyžaduje souhlas
podle § 8b nebo 9, musí být zpracována se zohledněním zásad plošné ochrany zemědělského
půdního fondu (§ 4), s výjimkou zásad, které se podle § 9 odst. 10 neposuzují.
(2) Umístění záměru podle § 8a, 8b a 9 musí být navrženo tak, aby z hlediska ochrany
zemědělského půdního fondu a ostatních zákonem chráněných veřejných zájmů došlo k co
nejmenším ztrátám zemědělského půdního fondu, a zároveň musí být vyhodnoceny důsledky
navrhovaného řešení na zemědělský půdní fond.“.
9.
V § 7 odst. 4 se za číslo „6“ vkládají slova „nebo k žádosti o povolení záměru podle
stavebního zákona“ a za slovo „území“ se vkládají slova „k prokázání splnění podmínek“.
10.
V § 8a odst. 8 se slovo „nezastavěném“ nahrazuje slovem „nezastavitelném“.
11.
V § 8a se doplňuje odstavec 10, který zní:
„(10) Jedná-li se o záměr vyžadující povolení podle stavebního zákona, stavební úřad vydá
souhlas podle odstavce 2 nebo 9 v rozhodnutí o povolení záměru podle stavebního zákona.
Žádost o povolení záměru podle stavebního zákona obsahuje vedle náležitostí požadovaných
stavebním zákonem náležitosti vyžadované v odstavci 3. Povolení záměru podle stavebního
zákona obsahuje také náležitosti podle odstavce 4.“.
12.
V § 8b se doplňuje odstavec 4, který zní:
„(4) Jedná-li se o záměr vyžadující povolení podle stavebního zákona, stavební úřad vydá
souhlas podle odstavce 1 v rozhodnutí o povolení záměru podle stavebního zákona. Žádost
o povolení záměru podle stavebního zákona obsahuje vedle náležitostí požadovaných
stavebním zákonem náležitosti vyžadované v odstavci 2. Povolení záměru podle stavebního
zákona obsahuje také náležitosti podle odstavce 3.“.
13.
V § 9 odst. 2 písmena a) až d) znějí:
„a) v zastavitelném území pro
1. stavbu včetně souvisejících zastavěných ploch o výměře do 25 m2,
2. veřejně prospěšnou stavbu umísťovanou v proluce o velikosti do 0,5 ha, nebo
3. drobnou stavbu,
b) pro umístění
1. signálů, stabilizačních kamenů a jiných značek pro geodetické účely, vstupních šachet
podzemního vedení a stožárů nadzemních vedení, pokud v jednotlivých případech
nejde o plochu větší než 30 m2,
2. přečerpávacích stanic, vrtů, studní a stanic nadzemního nebo podzemního vedení
a větrných jam, pokud v jednotlivých případech nejde o plochu větší než 55 m2, nebo
3. záměrů na pozemku zázemí stavby,
4. základnové stanice sítí elektronických komunikací, pokud v jednotlivých případech
nejde o plochu větší než 100 m2, a související elektrické a optické přípojné vedení,
5. zařízení sloužící pro ukládání elektřiny ze zařízení pro přeměnu energie slunečního
záření na elektřinu s výjimkou záměrů podle § 8a, pokud se nachází na zemědělské
půdě v areálu tohoto zařízení pro přeměnu energie nebo v jeho blízkosti,
6. záměrů souvisejících s provozováním zoologické zahrady provozované podle jiného
právního předpisu a na základě licence udělené Ministerstvem životního prostředí,
7. zařízení, která jsou součástí přenosové soustavy, přepravní soustavy, distribuční
soustavy v elektroenergetice a plynárenství a soustavy zásobování tepelnou energií,
včetně technologických objektů, systémů měřicí, ochranné, řídicí, zabezpečovací,
informační a telekomunikační techniky, pokud v jednotlivých případech nejde
o plochu větší než 100 m2, a související elektrické, telekomunikační přípojné vedení,
c) pro obnovu přirozených a přírodě blízkých koryt vodních toků,
d) k nezemědělským účelům po dobu kratší než jeden rok včetně doby potřebné k uvedení
zemědělské půdy do původního stavu, je-li termín zahájení nezemědělského využívání
zemědělské půdy nejméně 15 dní předem písemně oznámen orgánu ochrany zemědělského
půdního fondu uvedenému v § 15; v případě, že následně vyvstane potřeba
nezemědělského využívání zemědělské půdy včetně doby potřebné k uvedení zemědělské
půdy do původního stavu na dobu delší než 1 rok, je třeba požádat orgán ochrany
zemědělského půdního fondu o souhlas k odnětí půdy ze zemědělského půdního fondu,“.
14.
V § 9 odst. 5 se písmena a) až d) včetně poznámky pod čarou č. 6 zrušují.
Dosavadní písmena e) až g) se označují jako písmena a) až c).
15.
V § 9 odst. 6 písm. f) se slova „a návrh alternativ“ zrušují.
16.
V § 9 odst. 8 písm. c) se slova „ , jsou-li pro to zvláštní důvody při lomové (povrchové)
těžbě uhlí a kaolinu nebo při geologicko-průzkumných pracích, zejména u velmi
hlubokých vrtů,“ zrušují.
17.
V § 9 odstavec 9 zní:
„(9) Jedná-li se o záměr vyžadující povolení podle stavebního zákona, stavební úřad vydá
souhlas s odnětím zemědělské půdy ze zemědělského půdního fondu v rozhodnutí o povolení
záměru podle stavebního zákona. Žádost o povolení záměru podle stavebního zákona obsahuje
vedle náležitostí požadovaných stavebním zákonem náležitosti vyžadované v odstavci 6,
případně 7. Povolení záměru podle stavebního zákona obsahuje také náležitosti podle odstavce
8.“.
18.
V § 9 se doplňuje odstavec 10, který zní:
„(10) Zásady plošné ochrany podle § 4 odst. 1 až 5 se neposuzují v zastavitelném území,
koridoru pro stavební záměr nebo ploše těžby vymezených v územně plánovací dokumentaci
v souladu se stanoviskem orgánu ochrany zemědělského půdního fondu.“.
19.
V § 11 se na konci odstavce 3 doplňuje věta „Rozhodnutí se vydává jako první úkon
v řízení.“.
20.
V § 11 odst. 4 písm. a) se za slovo „souhlasu“ vkládají slova „anebo rozhodnutí o povolení
záměru stavebním úřadem“.
21.
V § 11a se na konci odstavce 1 tečka nahrazuje čárkou a doplňuje se písmeno s), které
zní:
„s) stavby pro bydlení ve stavební proluce.“.
22.
V § 13 se na konci odstavce 1 tečka nahrazuje čárkou a doplňuje se písmeno f), které zní:
„f) stavební úřad.“.
23.
V § 15 se na konci úvodní části ustanovení doplňují slova „ , není-li příslušný stavební
úřad,“.
24.
V § 15 se na konci textu písmene m) doplňují slova „nebo stavební úřad“.
25.
V § 17 písm. a) se slova „a k návrhům na vymezení zastavěného území samostatným
postupem pro území hlavního města Prahy a obcí, ve kterých je sídlo kraje,“ zrušují.
26.
V § 17a se na konci úvodní části ustanovení doplňují slova „ , není-li příslušný stavební
úřad,“.
27.
V § 17a písm. a) se slova „a k návrhům na vymezení zastavěného území samostatným
postupem, s výjimkou zastavěného území hlavního města Prahy a obcí, ve kterých je sídlo
kraje,“ zrušují.
28.
§ 17c včetně nadpisu zní:
„§ 17c
Stavební úřad
(1) Jedná-li se o záměr povolovaný podle stavebního zákona mimo území národních parků,
stavební úřad v rozhodnutí o povolení záměru
a) vydává souhlas s realizací agrovoltaické výrobny elektřiny nebo zařízení sloužícího pro
ukládání elektřiny z agrovoltaické výrobny elektřiny podle § 8a odst. 10,
b) vydává souhlas s realizací záměru nebo opatření realizovaného na zemědělské půdě podle
§ 8b odst. 4,
c) vydává souhlas s odnětím zemědělské půdy ze zemědělského půdního fondu podle § 9
odst. 9.
(2) Stavební úřad ve vztahu k záměrům povoleným podle odstavce 1 dále
a) zasílá podle § 3b odst. 4 údaje související s odnětím zemědělské půdy ze zemědělského
půdního fondu do evidence odnětí zemědělské půdy,
b) přijímá oznámení podle § 8a odst. 5 a 6,
c) kontroluje plnění podmínek stanovených podle tohoto zákona a opatření k nápravě jím
uložených,
d) ukládá opatření k nápravě závadného stavu vzniklého neplněním podmínek stanovených
podle tohoto zákona,
e) projednává přestupky podle § 20 odst. 1 písm. g) a i) až n) a odst. 2 písm. f) až i) a § 20a
odst. 1 písm. g) a i) až n) a odst. 2 písm. f) až i), vyplývající z porušení povinností uložených
jím vydanými rozhodnutími či opatřeními.“.
29.
V § 18 odst. 1 větě první se za slova „fondu se“ vkládají slova „v případě záměrů, které
nepodléhají povolení záměru podle stavebního zákona,“.
30.
V § 18 se na konci odstavce 6 doplňuje věta „Vydal-li souhlas s odnětím zemědělské
půdy ze zemědělského půdního fondu stavební úřad, zašle obecnímu úřadu obce
s rozšířenou působností stejnopis písemného vyhotovení rozhodnutí o povolení záměru
včetně dokumentace připojené k žádosti o povolení záměru v rozsahu podkladů podle § 9
odst. 6, případně 7.“.
31.
V § 19 se doplňuje odstavec 3, který zní:
„(3) Je-li to potřebné pro účely zápisu do katastru nemovitostí, potvrdí orgán ochrany
zemědělského půdního fondu na žádost vlastníka pozemku nebo katastrálního úřadu, že
pozemek je zastavěn stavbou dálnice, silnice nebo místní komunikace nebo stavbou, kterou lze
provést bez souhlasu s odnětím zemědělské půdy ze zemědělského půdního fondu.“.
32.
V § 20 odst. 1 se na konci textu písmene j) doplňují slova „anebo povolením záměru
podle stavebního zákona“.
33.
V § 20a odst. 1 se na konci textu písmene j) doplňují slova „anebo povolením záměru
podle stavebního zákona“.
34.
V § 21 odst. 4 se věta první zrušuje, slova „jednotné environmentální stanovisko“ se
nahrazují slovy „povolení podle stavebního zákona“ a slovo „rozhodnutí“ se nahrazuje
slovy „závazného stanoviska“.
Poznámka pod čarou č. 40 se zrušuje.
35.
V příloze k zákonu v části B se skupina faktorů E včetně poznámky pod čarou č. 45
zrušuje.
36.
V příloze k zákonu se v části D odst. 2 písm. a) slova „průmyslu a obchodu“ nahrazují
slovem „hospodářství“.
Čl. XVII
Přechodná ustanovení
1. Řízení a postupy zahájené a neskončené přede dnem nabytí účinnosti tohoto zákona se
dokončí podle zákona č. 334/1992 Sb., ve znění účinném ode dne nabytí účinnosti tohoto
zákona, není-li stanoveno jinak.
2. Řízení a postupy zahájené a neskončené do dne vzniku Úřadu rozvoje území České
republiky (dále jen „Úřad“), k nimž je příslušný Úřad nebo jiný stavební úřad, převezme a
dokončí ode dne svého vzniku Úřad nebo jiný stavební úřad.
3. Řízení a postupy zahájené a neskončené do dne vzniku úřadů rozvoje území krajů, k
nimž je příslušný úřad rozvoje území kraje nebo jeho územní pracoviště, ode dne vzniku úřadů
rozvoje území krajů převezme a dokončí příslušný úřad rozvoje území kraje nebo jeho příslušné
územní pracoviště. Do dne vzniku úřadů rozvoje území krajů pokračují v těchto řízeních a
postupech správní orgány příslušné podle dosavadních právních předpisů, a to podle zákona č.
334/1992 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona, s výjimkou § 8a
odst. 10, § 8b odst. 4, § 9 odst. 9, § 13 písm. f) a § 17c, a dále podle § 21 odst. 4 zákona č.
334/1992 Sb., ve znění účinném přede dnem nabytí účinnosti tohoto zákona.
4. Byl-li vydán souhlas s odnětím zemědělské půdy ze zemědělského půdního fondu podle
§ 9 zákona č. 334/1992 Sb., ve znění účinném přede dnem nabytí účinnosti tohoto zákona,
formou závazného stanoviska pro záměr, který vyžadoval rozhodnutí nebo jiný úkon podle
zákona č. 283/2021 Sb., stavební zákon, ve znění účinném přede dnem nabytí účinnosti tohoto
zákona, a do tohoto dne se nestal závaznou součástí rozhodnutí nebo jiného úkonu podle zákona
č. 283/2021 Sb., stavební zákon, ve znění účinném přede dnem nabytí účinnosti tohoto zákona,
přičemž tento záměr nevyžaduje povolení podle právních předpisů účinných ode dne nabytí
účinnosti tohoto zákona, má toto závazné stanovisko účinky pravomocného rozhodnutí. Za
okamžik nabytí právní moci se považuje okamžik nabytí právní účinnosti souhlasu s odnětím.
5. U souhlasu s odnětím zemědělské půdy ze zemědělského půdního fondu vydaného přede
dnem nabytí účinnosti tohoto zákona, který se stal před tímto dnem závaznou součástí
rozhodnutí nebo jiného úkonu podle stavebního zákona, stavební úřad
a) kontroluje plnění podmínek daných tímto souhlasem, včetně provádění rekultivace, a
b) ukládá opatření k nápravě závadného stavu vzniklého neplněním podmínek daných tímto
souhlasem.
6. U záměrů, pro něž přede dnem nabytí účinnosti tohoto zákona nabyl právní účinnosti
první povolovací akt vydaný ve věci podle jiných právních předpisů, a u nichž do dne nabytí
účinnosti tohoto zákona nebylo vydáno rozhodnutí o odvodech podle § 11 odst. 2 zákona
č. 334/1992 Sb., se při výpočtu odvodů nepoužije faktor životního prostředí uvedený v části B
skupině E přílohy k zákonu č. 334/1992 Sb., ve znění účinném přede dnem nabytí účinnosti
tohoto zákona. Rozhodnutí o odvodech vydaná přede dnem nabytí účinnosti tohoto zákona
zůstávají nedotčena.
7. Ustanovení § 9 odst. 10 zákona č. 334/1992 Sb., ve znění účinném ode dne nabytí
účinnosti tohoto zákona, se použije pouze ve vztahu k zastavitelnému území, koridoru pro
stavební záměr nebo ploše těžby vymezeným v územně plánovací dokumentaci, k jejímuž
návrhu bylo vydáno stanovisko orgánu ochrany zemědělského půdního fondu podle § 5 zákona
č. 334/1992 Sb. ode dne nabytí účinnosti zákona č. 41/2015 Sb., kterým se mění zákon
č. 334/1992 Sb., o ochraně zemědělského půdního fondu, a zákon č. 388/1991 Sb., o Státním
fondu životního prostředí České republiky; to platí obdobně i pro zastavitelné území, koridory
pro stavební záměry a plochy těžby vymezené změnou územně plánovací dokumentace,
k jejímuž návrhu bylo takové stanovisko vydáno od tohoto dne.
8. Byla-li přede dnem nabytí účinnosti tohoto zákona zemědělská půda náležející do
zemědělského půdního fondu dotčena záměrem, který byl proveden bez souhlasu orgánu
ochrany zemědělského půdního fondu, a jedná-li se o záměr, který podle § 9 odst. 2 zákona
č. 334/1992 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona, souhlas s odnětím
zemědělské půdy ze zemědělského půdního fondu nevyžaduje, hledí se na takový záměr, jako
by k němu souhlasu nebylo třeba. Řízení o uložení odvodu za odnětí zemědělské půdy ze
zemědělského půdního fondu, která nebyla pravomocně skončena přede dnem nabytí účinnosti
tohoto zákona, se v takovém případě zastaví. Pravomocná rozhodnutí o odvodech vydaná přede
dnem nabytí účinnosti tohoto zákona zůstávají nedotčena. Ustanovení § 19 odst. 3 zákona
č. 334/1992 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona, se použije obdobně.
ČÁST DESÁTÁ
Změna zákona o dani z nemovitých věcí
Čl. XVIII
Zákon č. 338/1992 Sb., o dani z nemovitých věcí, ve znění zákona č. 315/1993 Sb., zákona
č. 242/1994 Sb., zákona č. 248/1995 Sb., zákona č. 65/2000 Sb., zákona č. 492/2000 Sb., zákona
č. 239/2001 Sb., zákona č. 483/2001 Sb., zákona č. 576/2002 Sb., zákona č. 237/2004 Sb.,
zákona č. 669/2004 Sb., zákona č. 179/2005 Sb., zákona č. 217/2005 Sb., zákona č. 342/2005
Sb., zákona č. 545/2005 Sb., zákona č. 112/2006 Sb., zákona č. 186/2006 Sb., zákona
č. 261/2007 Sb., zákona č. 296/2007 Sb., zákona č. 1/2009 Sb., zákona č. 281/2009 Sb., zákona
č. 362/2009 Sb., zákona č. 199/2010 Sb., zákona č. 30/2011 Sb., zákona č. 212/2011 Sb., zákona
č. 375/2011 Sb., zákona č. 457/2011 Sb., zákona č. 350/2012 Sb., zákona č. 503/2012 Sb.,
zákonného opatření Senátu č. 344/2013 Sb., zákona č. 23/2015 Sb., zákona č. 84/2015 Sb.,
zákona č. 225/2017 Sb., zákona č. 364/2019 Sb., zákona č. 283/2020 Sb., zákona č. 299/2020
Sb., zákona č. 609/2020 Sb., zákona č. 36/2021 Sb., zákona č. 284/2021 Sb., zákona č. 251/2023
Sb., zákona č. 349/2023 Sb., zákona č. 183/2024 Sb. a zákona č. 152/2025 Sb., se mění takto:
1.
V § 4 odst. 1 písm. v) se slovo „zastavěném“ nahrazuje slovem „zastavitelném“ a slova
„nebo v zastavitelné ploše podle stavebního zákona“ se zrušují.
2.
Za § 19b se vkládá nový § 19c, který zní:
„§ 19c
(1) Zastavěnou plochou u stavby, která byla dokončena podle právních předpisů účinných
přede dnem nabytí účinnosti zákona č. …/2026 Sb. nebo jejíž užívání bylo zahájeno přede dnem
nabytí účinnosti zákona č. …/2026 Sb., se rozumí zastavěná plocha podle stavebního zákona
ve znění účinném přede dnem nabytí účinnosti zákona č. …/2026 Sb.
(2) Pro účely odstavce 1 se stavba považuje za dokončenou nabytím právní moci
kolaudačního rozhodnutí, kolaudačního souhlasu, oznámením dokončení stavby nebo úkonem
s obdobným účinkem. Pokud došlo k dokončení změny dokončené stavby podle stavebního
zákona ve znění účinném ode dne nabytí účinnosti zákona č. …/2026 Sb., tak se stavba
považuje za dokončenou podle stavebního zákona ode dne účinnosti zákona č. …/2026 Sb.
(3) Zahájením užívání stavby se také rozumí zahájení užívání stavby, u které došlo ke
změně dokončené stavby a u které tato změna spočívá ve změně výměry zastavěné plochy.
(4) Pokud bylo zahájeno užívání stavby přede dnem nabytí účinnosti zákona č. …/2026
Sb., a stavba nebo změna dokončené stavby byly dokončeny podle stavebního zákona ve znění
účinném ode dne nabytí účinnosti zákona č. …/2026 Sb., odstavec 1 se pro zdaňovací období
započaté ode dne dokončení stavby nepoužije.“.
Čl. XIX
Přechodné ustanovení
Obecně závazná vyhláška podle § 4 odst. 1 písm. v) zákona č. 338/1992 Sb., ve znění
účinném přede dnem nabytí účinnosti tohoto zákona, se považuje za obecně závaznou vyhlášku
vydanou podle § 4 odst. 1 písm. v) zákona č. 338/1992 Sb., ve znění účinném ode dne nabytí
účinnosti tohoto zákona. Pokud tato obecně závazná vyhláška vymezuje pozemky v zastavěném
území nebo zastavitelné ploše, hledí se na ně jako na vymezené pozemky v zastavitelném
území.
ČÁST JEDENÁCTÁ
Změna autorizačního zákona
Čl. XX
Zákon č. 360/1992 Sb., o výkonu povolání autorizovaných architektů a o výkonu povolání
autorizovaných inženýrů a techniků činných ve výstavbě (autorizační zákon), ve znění zákona
č. 164/1993 Sb., zákona č. 275/1994 Sb., zákona č. 224/2003 Sb., zákona č. 189/2008 Sb.,
zákona č. 153/2011 Sb., zákona č. 350/2012 Sb., zákona č. 126/2016 Sb., zákona č. 459/2016
Sb., zákona č. 277/2019 Sb., zákona č. 47/2020 Sb., zákona č. 284/2021 Sb. a zákona
č. 152/2023 Sb., se mění takto:
1.
V § 22 se doplňuje odstavec 4, který zní:
„(4) Komora bezodkladně uvědomí Úřad rozvoje území České republiky o pravomocném
rozhodnutí o uložení disciplinárního opatření spočívajícího v pozastavení nebo odnětí
autorizace autorizované osobě.“.
2.
V § 29 odst. 3 písm. b) bodu 2 se slova „průmyslu a obchodu“ nahrazují slovem
„hospodářství“.
ČÁST DVANÁCTÁ
Změna zákona o zeměměřictví
Čl. XXI
V § 4b odst. 8 zákona č. 200/1994 Sb., o zeměměřictví a o změně a doplnění některých
zákonů souvisejících s jeho zavedením, ve znění zákona č. 47/2020 Sb., zákona č. 202/2023
Sb., zákona č. 287/2025 Sb. a zákona č. 330/2025 Sb., se za větu první vkládá věta „Podkladem
pro zápis údajů podle odstavce 4 písm. a) je dokumentace o zaměření prostorové polohy,
rozměru a tvaru dokončené stavby nebo technologického zařízení stavby.“.
Čl. XXII
Přechodné ustanovení
Ustanovení § 4b odst. 9 zákona č. 200/1994 Sb., ve znění účinném ode dne nabytí účinnosti
tohoto zákona, se použije pro zápis údajů o objektech a zařízeních dopravní a technické
infrastruktury, jejichž výstavba byla dokončena počínaje dnem nabytí účinnosti tohoto zákona.
Pokud výstavba probíhá po částech či etapách, povinnost podle věty první se vztahuje pouze na
část či etapu záměru, která byla dokončena počínaje dnem nabytí účinnosti tohoto zákona.
ČÁST TŘINÁCTÁ
Změna zákona o dráhách
Čl. XXIII
V § 7 odst. 1 zákona č. 266/1994 Sb., o dráhách, ve znění zákona č. 23/2000 Sb., zákona
č. 186/2006 Sb., zákona č. 225/2017 Sb., zákona č. 367/2019 Sb., zákona č. 284/2021 Sb.
a zákona č. 426/2021 Sb., se slova „Dopravní a energetický stavební úřad“ nahrazují slovy
„Úřad rozvoje území České republiky“.
ČÁST ČTRNÁCTÁ
Změna zákona o vnitrozemské plavbě
Čl. XXIV
V § 22a odst. 4 zákona č. 114/1995 Sb., o vnitrozemské plavbě, ve znění zákona
č. 187/2014 Sb., se slovo „zastavěném“ nahrazuje slovem „zastavitelném“.
ČÁST PATNÁCTÁ
Změna lesního zákona
Čl. XXV
Zákon č. 289/1995 Sb., o lesích a o změně a doplnění některých zákonů (lesní zákon), ve
znění zákona č. 238/1999 Sb., zákona č. 67/2000 Sb., zákona č. 132/2000 Sb., zákona
č. 76/2002 Sb., zákona č. 320/2002 Sb., zákona č. 149/2003 Sb., zákona č. 1/2005 Sb., zákona
č. 444/2005 Sb., zákona č. 186/2006 Sb., zákona č. 222/2006 Sb., zákona č. 124/2008 Sb.,
zákona č. 167/2008 Sb., zákona č. 223/2009 Sb., zákona č. 227/2009 Sb., zákona č. 281/2009
Sb., zákona č. 501/2012 Sb., zákona č. 503/2012 Sb., zákona č. 280/2013 Sb., zákonného
opatření Senátu č. 344/2013 Sb., zákona č. 64/2014 Sb., zákona č. 15/2015 Sb., zákona
č. 250/2016 Sb., zákona č. 62/2017 Sb., zákona č. 183/2017 Sb., zákona č. 225/2017 Sb.,
zákona č. 90/2019 Sb., zákona č. 314/2019 Sb., zákona č. 403/2020 Sb., zákona č. 609/2020
Sb., zákona č. 261/2021 Sb., zákona č. 284/2021 Sb., zákona č. 364/2021 Sb., zákona
č. 149/2023 Sb., zákona č. 465/2023 Sb., zákona č. 23/2025 Sb., zákona č. 173/2025 Sb.,
zákona č. 218/2025 Sb. a zákona č. 250/2025 Sb., se mění takto:
1.
V § 12 se odstavec 3 včetně poznámky pod čarou č. 46 zrušuje.
2.
V § 13 odst. 1 se za větu třetí vkládají věty „Pokud je důvodem udělení výjimky záměr
vyžadující povolení podle stavebního zákona, je rozhodnutí orgánu státní správy lesů
nahrazeno rozhodnutím o záměru podle stavebního zákona. Splnění podmínek podle
tohoto zákona posoudí stavební úřad v rozhodnutí o záměru podle stavebního zákona po
vydání vyjádření orgánu státní správy lesů. Pokud se záměr nebo jeho část nachází na
území národního parku, ověří splnění podmínek pro udělení výjimky správa národního
parku v rámci společného závazného stanoviska podle zákona o ochraně přírody a krajiny.
Žádost o povolení záměru podle stavebního zákona, ke kterému je třeba udělení výjimky
podle věty třetí, obsahuje vedle náležitostí požadovaných stavebním zákonem také
náležitosti vyžadované v § 16.“.
3.
V § 14 se na konci odstavce 2 doplňuje věta „K dotčení vzdálenějších pozemků se
závazné stanovisko nevydává.“.
4.
V § 14 odstavec 3 zní:
„(3) Jde-li o řízení o povolení záměru podle stavebního zákona, závazné stanovisko podle
odstavce 2 se s výjimkou území národních parků nevydává. Splnění podmínek podle tohoto
zákona posoudí stavební úřad v rozhodnutí o záměru podle stavebního zákona po vydání
vyjádření orgánu státní správy lesů vydaného v rozsahu dotčení pozemků podle odstavce 2.“.
5.
V § 15 odst. 3 se na konci textu písmene c) doplňují slova „ , a související elektrické
a optické přípojné vedení“.
6.
V § 16 se odstavec 7 zrušuje.
Dosavadní odstavec 8 se označuje jako odstavec 7.
7.
V § 17 se na konci odstavce 3 doplňuje věta „Rozhodnutí se vydává jako první úkon
v řízení.“.
8.
V § 47 odst. 1 se za písmeno b) vkládá nové písmeno c), které zní:
„c) stavební úřady,“.
Dosavadní písmeno c) se označuje jako písmeno d).
9.
V § 48 odst. 1 se na konci textu písmene d) doplňují slova „ , s výjimkou případů, kdy je
důvodem odnětí nebo omezení záměr povolovaný podle stavebního zákona“.
10.
V § 48 odst. 2 se na konci textu písmene b) doplňují slova „ , s výjimkou řízení o povolení
záměru podle stavebního zákona“.
11.
V § 48 odst. 2 se na konci písmen h) a i) slovo „a“ zrušuje.
12.
V § 48 se na konci odstavce 2 tečka nahrazuje slovem „a“ a doplňuje se písmeno k), které
zní:
„k) vydávají vyjádření k
1. žádosti o odnětí nebo o omezení, pokud je důvodem odnětí nebo omezení záměr
vyžadující povolení podle stavebního zákona (§ 13 odst. 1) a
2. řízení o povolení záměru podle stavebního zákona, jímž mají být dotčeny pozemky
určené k plnění funkcí lesa do výměry 1 ha, není-li příslušný krajský úřad, a k dotčení
pozemků do vzdálenosti 30 m od okraje lesa (§ 14 odst. 2).“.
13.
V § 48a odst. 1 se na konci textu písmene b) doplňují slova „ , s výjimkou případů, kdy
je důvodem odnětí nebo omezení záměr povolovaný podle stavebního zákona; v takovém
případě vydá vyjádření“.
14.
V § 48a odst. 2 se na konci textu písmene c) doplňují slova „ , s výjimkou řízení o povolení
záměru podle stavebního zákona; v takovém případě vydá vyjádření“.
15.
Za § 48a se vkládá nový § 48b, který včetně nadpisu zní:
„§ 48b
Stavební úřad
(1) Jedná-li se o záměr povolovaný podle stavebního zákona stavební úřad v rozhodnutí
o povolení záměru
a) mimo území národních parků posuzuje splnění podmínek pro souhlas s povolením záměrů,
jimiž mají být dotčeny pozemky určené k plnění funkcí lesa a pozemky do vzdálenosti
30 m od okraje lesa (§ 14 odst. 2),
b) rozhoduje o odnětí lesních pozemků plnění funkcí lesa nebo o omezení jejich využívání
pro plnění funkcí lesa (§ 13 odst. 1).
(2) Stavební úřad ve vztahu k záměrům povolovaným podle odstavce 1 dále
a) přijímá žádosti o odnětí lesních pozemků plnění funkcí lesa nebo o omezení jejich
využívání pro plnění funkcí lesa,
b) kontroluje plnění podmínek stanovených podle tohoto zákona a opatření k nápravě jím
uložených,
c) ukládá opatření k nápravě závadného stavu vzniklého neplněním podmínek stanovených
podle tohoto zákona,
d) zasílá rozhodnutí o povolení záměru orgánu státní správy lesů, od něhož si vyžádal
vyjádření.“.
Čl. XXVI
Přechodná ustanovení
1. Řízení a postupy zahájené a neskončené přede dnem nabytí účinnosti tohoto zákona se
dokončí podle zákona č. 289/1995 Sb., ve znění účinném ode dne nabytí účinnosti tohoto
zákona, není-li stanoveno jinak.
2. Řízení a postupy zahájené a neskončené přede dnem nabytí účinnosti tohoto zákona, k
nimž je podle zákona č. 289/1995 Sb., ve znění účinném ode dne nabytí účinnosti tohoto
zákona, jako stavební úřad příslušný Úřad rozvoje území České republiky (dále jen „Úřad“),
převezme a dokončí Úřad.
3. Řízení a postupy podle zákona č. 289/1995 Sb., ve znění účinném ode dne nabytí
účinnosti tohoto zákona, zahájené a neskončené do dne vzniku úřadů rozvoje území krajů, k
nimž je jako stavební úřad příslušný úřad rozvoje území kraje nebo jeho územní pracoviště, ode
dne vzniku úřadů rozvoje území krajů převezme a dokončí příslušný úřad rozvoje území kraje
nebo jeho územní pracoviště podle zákona č. 289/1995 Sb., ve znění účinném ode dne nabytí
účinnosti tohoto zákona. Do dne vzniku úřadů rozvoje území krajů pokračují v těchto řízeních
a postupech správní orgány příslušné podle dosavadních právních předpisů podle zákona č.
289/1995 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona. Žádost o vydání
závazného stanoviska orgánu státní správy lesů podle zákona č. 289/1995 Sb., ve znění účinném
přede dnem nabytí účinnosti tohoto zákona, které mělo být podkladem pro rozhodnutí
stavebního úřadu podle stavebního zákona a které nebylo vydáno do dne vzniku úřadů rozvoje
území krajů, se považuje za žádost o vydání vyjádření; lhůta pro vydání vyjádření běží ode dne
podání původní žádosti o vydání závazného stanoviska. Přezkum závazného stanoviska, které
bylo podle zákona č. 289/1995 Sb., ve znění účinném přede dnem nabytí účinnosti tohoto
zákona, vydáno jako podklad pro rozhodnutí stavebního úřadu podle stavebního zákona, podle
§ 149 odst. 8 správního řádu, zahájený a neskončený do dne vzniku úřadů rozvoje území krajů,
dokončí příslušný nadřízený orgán státní správy lesů podle dosavadních právních předpisů.
4. Byl-li vydán souhlas s odnětím pozemků plnění funkcí lesa formou závazného
stanoviska pro záměr, který vyžadoval rozhodnutí nebo jiný úkon podle zákona č. 283/2021
Sb., stavební zákon, ve znění účinném přede dnem nabytí účinnosti tohoto zákona, a do tohoto
dne se nestal závaznou součástí rozhodnutí nebo jiného úkonu podle zákona č. 283/2021 Sb.,
stavební zákon, ve znění účinném přede dnem nabytí účinnosti tohoto zákona, přičemž tento
záměr nevyžaduje povolení podle právních předpisů účinných ode dne nabytí účinnosti tohoto
zákona, má toto závazné stanovisko účinky pravomocného rozhodnutí. Za okamžik nabytí
právní moci se považuje okamžik nabytí právní moci souhlasu s odnětím.
ČÁST ŠESTNÁCTÁ
Změna zákona o pozemních komunikacích
Čl. XXVII
Zákon č. 13/1997 Sb., o pozemních komunikacích, ve znění zákona č. 102/2000 Sb.,
zákona č. 132/2000 Sb., zákona č. 489/2001 Sb., zákona č. 256/2002 Sb., zákona č. 259/2002
Sb., zákona č. 320/2002 Sb., zákona č. 358/2003 Sb., zákona č. 186/2004 Sb., zákona č. 80/2006
Sb., zákona č. 186/2006 Sb., zákona č. 311/2006 Sb., zákona č. 342/2006 Sb., zákona č. 97/2009
Sb., zákona č. 227/2009 Sb., zákona č. 347/2009 Sb., zákona č. 152/2011 Sb., zákona
č. 288/2011 Sb., zákona č. 329/2011 Sb., zákona č. 341/2011 Sb., zákona č. 375/2011 Sb.,
zákona č. 18/2012 Sb., zákona č. 119/2012 Sb., zákona č. 196/2012 Sb., zákona č. 64/2014 Sb.,
zákona č. 268/2015 Sb., zákona č. 243/2016 Sb., zákona č. 319/2016 Sb., zákona č. 370/2016
Sb., zákona č. 151/2017 Sb., zákona č. 183/2017 Sb., zákona č. 225/2017 Sb., zákona
č. 169/2018 Sb., zákona č. 193/2018 Sb., zákona č. 227/2019 Sb., zákona č. 162/2020 Sb.,
zákona č. 403/2020 Sb., zákona č. 543/2020 Sb., zákona č. 609/2020 Sb., zákona č. 261/2021
Sb., zákona č. 284/2021 Sb., zákona č. 365/2021 Sb., zákona č. 374/2021 Sb., zákona
č. 418/2021 Sb., zákona č. 178/2022 Sb., zákona č. 217/2022 Sb., zákona č. 432/2022 Sb.,
zákona č. 152/2023 Sb., zákona č. 184/2023 Sb., zákona č. 349/2023 Sb., zákona č. 464/2023
Sb., zákona č. 465/2023 Sb., zákona č. 82/2024 Sb., zákona č. 183/2024 Sb., zákona č. 130/2025
Sb., zákona č. 218/2025 Sb., zákona č. 232/2025 Sb. a zákona č. 330/2025 Sb., se mění takto:
1.
V § 8 odst. 1 se slovo „zastavěným“ nahrazuje slovem „zastavitelným“ a slova „nebo
zastavitelnými plochami“ se zrušují.
2.
V § 11 odst. 2 se slovo „zastavěné“ nahrazuje slovem „zastavitelné“ a slova „nebo
zastavitelné plochy“ se zrušují.
3.
V § 11 odst. 5 se slovo „zastavěné“ nahrazuje slovem „zastavitelné“.
4.
V § 18g odst. 1 písm. d), § 24 odst. 2 písm. b), § 26 odst. 2, § 30 odst. 5, § 35 odst. 3, § 36
odst. 4 a § 37 odst. 5 písm. b) se slovo „zastavěném“ nahrazuje slovem „zastavitelném“.
5.
V § 25 odst. 7 písm. d) bodě 1 se slovo „zastavěném“ nahrazuje slovem „zastavitelném“
a slovo „zastavěné“ se nahrazuje slovem „zastavitelné“.
6.
V § 30 odst. 2 úvodní části ustanovení se slovo „zastavěné“ nahrazuje slovem
„zastavitelné“.
7.
V § 30 odst. 3 se slovo „zastavěného“ nahrazuje slovem „zastavitelného“.
8.
V § 40 odst. 11 písm. a) se slova „Dopravní a energetický stavební úřad“ nahrazují slovy
„Úřad rozvoje území České republiky“.
ČÁST SEDMNÁCTÁ
Změna zákona o civilním letectví
Čl. XXVIII
Zákon č. 49/1997 Sb., o civilním letectví, ve znění pozdějších předpisů, ve znění zákona
č. 189/1999 Sb., zákona č. 146/2000 Sb., zákona č. 258/2002 Sb., zákona č. 167/2004 Sb.,
zákona č. 413/2005 Sb., zákona č. 186/2006 Sb., zákona č. 225/2006 Sb., zákona č. 124/2008
Sb., zákona č. 274/2008 Sb., zákona č. 227/2009 Sb., zákona č. 281/2009 Sb., zákona č.
301/2009 Sb., zákona č. 407/2010 Sb., zákona č. 137/2011 Sb., zákona č. 375/2011 Sb., zákona
č. 127/2014 Sb., zákona č. 250/2014 Sb., zákona č. 298/2016 Sb., zákona č. 319/2016 Sb.,
zákona č. 183/2017 Sb., zákona č. 225/2017 Sb., zákona č. 261/2017 Sb., zákona č. 111/2019
Sb., zákona č. 277/2019 Sb., zákona č. 261/2021 Sb., zákona č. 284/2021 Sb., zákona č.
240/2022 Sb., zákona č. 431/2022 Sb., zákona č. 152/2023 Sb., zákona č. 464/2023 Sb., zákona
č. 218/2025 Sb. a zákona č. 370/2025 Sb., se mění takto:
1.
V § 35 odst. 1 se slova „využití území“ nahrazují slovy „povolení záměru“.
2.
V § 36 odst. 2 se slova „Dopravní a energetický stavební úřad“ nahrazují slovy „Úřad
rozvoje území České republiky“.
3.
V § 37 odst. 1 větě druhé a třetí se slova „úřadem územního plánování“ nahrazují slovem
„obcí“.
4.
V § 87 odst. 1 se za slovo „Ústav“ vkládají slova „ , Úřad rozvoje území České republiky“.
ČÁST OSMNÁCTÁ
Změna zákona o odpovědnosti za škodu způsobenou při výkonu veřejné moci
rozhodnutím nebo nesprávným úředním postupem
Čl. XXIX
V § 8 zákona č. 82/1998 Sb., o odpovědnosti za škodu způsobenou při výkonu veřejné
moci rozhodnutím nebo nesprávným úředním postupem a o změně zákona České národní rady
č. 358/1992 Sb., o notářích a jejich činnosti (notářský řád), ve znění zákona č. 160/2006 Sb.
a zákona č. 396/2012 Sb., se doplňuje odstavec 4, který zní:
„(4) Nárok na náhradu škody způsobené nezákonným rozhodnutím lze uplatnit i tehdy,
pokud soud ve správním soudnictví zamítl žalobu nebo návrh na zrušení opatření obecné
povahy podle § 309 odst. 5 stavebního zákona a v odůvodnění rozsudku uvedl, že tak učinil
proto, že by jeho zrušení představovalo pro jiné osoby nebo pro veřejný zájem nepoměrně větší
újmu v porovnání s újmou vzniklou navrhovateli zamítnutím návrhu.“.
ČÁST DEVATENÁCTÁ
Změna veterinárního zákona
Čl. XXX
Zákon č. 166/1999 Sb., o veterinární péči a o změně některých souvisejících zákonů
(veterinární zákon), ve znění zákona č. 29/2000 Sb., zákona č. 154/2000 Sb., zákona
č. 102/2001 Sb., zákona č. 76/2002 Sb., zákona č. 120/2002 Sb., zákona č. 320/2002 Sb.,
zákona č. 131/2003 Sb., zákona č. 316/2004 Sb., zákona č. 444/2005 Sb., zákona č. 48/2006
Sb., zákona č. 186/2006 Sb., zákona č. 182/2008 Sb., zákona č. 223/2009 Sb., zákona
č. 227/2009 Sb., zákona č. 281/2009 Sb., zákona č. 291/2009 Sb., zákona č. 298/2009 Sb.,
zákona č. 308/2011 Sb., zákona č. 18/2012 Sb., zákona č. 359/2012 Sb., zákona č. 279/2013
Sb., zákona č. 64/2014 Sb., zákona č. 139/2014 Sb., zákona č. 250/2014 Sb., zákona č. 264/2014
Sb., zákona č. 126/2016 Sb., zákona č. 243/2016 Sb., zákona č. 183/2017 Sb., zákona
č. 225/2017 Sb., zákona č. 302/2017 Sb., zákona č. 368/2019 Sb., zákona č. 238/2020 Sb.,
zákona č. 543/2020 Sb., zákona č. 36/2021 Sb., zákona č. 261/2021 Sb., zákona č. 284/2021
Sb., zákona č. 246/2022 Sb., zákona č. 70/2025 Sb., zákona č. 218/2025 Sb., zákona č. 220/2025
Sb., zákona č. 251/2025 Sb. a zákona č. 331/2025 Sb., se mění takto:
1.
V § 48 odst. 1 písm. h) a § 49 odst. 1 písm. i) se slova „závazné posudky a“ zrušují.
2.
Nadpis § 56 zní: „Vyjádření“.
3.
V § 56 se odstavec 1 zrušuje.
Dosavadní odstavce 2 až 4 se označují jako odstavce 1 až 3.
Poznámka pod čarou č. 36a se zrušuje.
4.
V § 56 odst. 1 písm. a) se slova „nejde-li o stavby nebo zařízení podle odstavce 1,“ zrušují.
5.
V § 56 odst. 2 a 3 se slova „Závazné posudky a vyjádření“ nahrazují slovem „Vyjádření“
a věta druhá se nahrazuje větou „Odstavec 1 se použije obdobně.“.
6.
V § § 77a větě první se slova „Závazný posudek a vyjádření“ nahrazují slovem
„Vyjádření“, slovo „nevydají“ se nahrazuje slovem „nevydává“ a slovo „jejich“ se
nahrazuje slovem „jeho“.
Čl. XXXI
Přechodná ustanovení
1. Řízení a postupy zahájené a neskončené přede dnem nabytí účinnosti tohoto zákona se
dokončí podle zákona č. 166/1999 Sb., ve znění účinném ode dne nabytí účinnosti tohoto
zákona.
2. Žádost o vydání závazného posudku podle § 56 odst. 1 zákona č. 166/1999 Sb., ve znění
účinném přede dnem nabytí účinnosti tohoto zákona, který nebyl vydán do dne nabytí účinnosti
tohoto zákona, se považuje za žádost o vydání vyjádření; lhůta pro vydání vyjádření běží ode
dne podání původní žádosti o vydání závazného posudku. Přezkum závazného posudku podle
§ 56 odst. 1 zákona č. 166/1999 Sb., ve znění účinném přede dnem nabytí účinnosti tohoto
zákona, podle § 149 odst. 8 správního řádu, zahájený a neskončený do dne účinnosti tohoto
zákona, dokončí Ústřední veterinární správa podle dosavadních předpisů.
ČÁST DVACÁTÁ
Změna zákona o zajišťování obrany České republiky
Čl. XXXII
Zákon č. 222/1999 Sb., o zajišťování obrany České republiky, ve znění zákona č. 320/2002
Sb., zákona č. 436/2004 Sb., zákona č. 413/2005 Sb., zákona č. 112/2006 Sb., zákona
č. 186/2006 Sb., zákona č. 306/2008 Sb., zákona č. 281/2009 Sb., zákona č. 73/2011 Sb.,
zákona č. 375/2011 Sb., zákona č. 15/2015 Sb., zákona č. 47/2016 Sb., zákona č. 183/2017 Sb.,
zákona č. 261/2021 Sb., zákona č. 284/2021 Sb., zákona č. 152/2023 Sb., zákona č. 178/2023
Sb., zákona č. 39/2025 Sb. a zákona č. 173/2025 Sb., se mění takto:
1.
Za § 6 se vkládá nový § 6a, který zní:
„§ 6a
Státní příspěvková organizace k zajišťování obrany
(1) Ministerstvo může za účelem zajišťování obrany státu zřídit státní příspěvkovou
organizaci. Ministerstvo vydá zřizovací listinu státní příspěvkové organizace. Státní
příspěvková organizace vzniká dnem stanoveným ve zřizovací listině. Zřizovací listina musí
dále obsahovat
a) označení zřizovatele státní příspěvkové organizace,
b) název, sídlo a identifikační číslo osoby státní příspěvkové organizace,
c) vymezení účelu, pro který se státní příspěvková organizace zřizuje,
d) předmět hlavní činnosti, popřípadě jiné činnosti státní příspěvkové organizace,
e) označení statutárního orgánu a vymezení základní organizační struktury státní příspěvkové
organizace,
f)
vymezení majetku České republiky, který ministerstvo svěřuje státní příspěvkové
organizaci při jejím zřízení.
(2) Je-li hlavní činností státní příspěvkové organizace zřízené podle odstavce 1
poskytování zdravotních služeb vojákům v činné službě, lze ji zřídit až po projednání s
Ministerstvem zdravotnictví. Neomezí-li to poskytování zdravotní péče pacientům uvedeným
ve větě první, může tato státní příspěvková organizace v rozsahu oprávnění k poskytování
zdravotních služeb poskytovat zdravotní služby také dalším osobám.
(3) Statutární orgán státní příspěvkové organizace zřízené podle odstavce 1 jmenuje a
odvolává ministr.
(4) Ministerstvo může rozhodnout o rozdělení státní příspěvkové organizace zřízené podle
odstavce 1, o jejím sloučení nebo splynutí s jinou státní příspěvkovou organizací nebo o jiných
změnách takové státní příspěvkové organizace. Současně vydá zřizovací listinu nově vznikající
státní příspěvkové organizace nebo dodatek zřizovací listiny. Státní příspěvková organizace
zaniká dnem stanoveným v rozhodnutí o jejím rozdělení nebo splynutí, popřípadě dnem
stanoveným v rozhodnutí o jejím sloučení, je-li právním nástupcem jiná státní příspěvková
organizace.
(5) Ministerstvo může rozhodnout o zrušení státní příspěvkové organizace zřízené podle
odstavce 1. Současně rozhodne o způsobu vypořádání práv a povinností vykonávaných státní
příspěvkovou organizací, včetně příslušnosti hospodařit s majetkem České republiky, a zruší
zřizovací listinu. Nerozhodne-li, přechází dnem zániku zrušované státní příspěvkové
organizace příslušnost k hospodaření s majetkem České republiky včetně práv, s nímž tato
organizace dosud hospodařila, na ministerstvo. Současně přecházejí na Českou republiku
závazky, jakož i práva a povinnosti z pracovněprávních vztahů, jejichž nositelem byla tato
organizace, a ministerstvo se stává příslušné k plnění těchto závazků, jakož i k výkonu práv
a povinností z těchto pracovněprávních vztahů. Státní příspěvková organizace zaniká dnem
stanoveným v rozhodnutí o jejím zrušení.
(6) Zřízení, rozdělení, sloučení, splynutí nebo zrušení státní příspěvkové organizace, o
nichž bylo rozhodnuto podle odstavců 1, 4 a 5, oznamuje ministerstvo v Ústředním věstníku
České republiky do 30 dnů ode dne, kdy k uvedené skutečnosti došlo. Oznámení obsahuje
označení zřizovatele státní příspěvkové organizace, její název, sídlo, identifikační číslo osoby
a den, měsíc a rok vzniku, rozdělení, sloučení, splynutí nebo zániku.“.
2.
V § 29b odstavec 1 zní:
„(1) Ministerstvo může za Českou republiku při úplatném nabývání pozemků a staveb pro
zajišťování obrany státu sjednat cenu do výše obvyklé ceny určené podle zákona o oceňování
majetku; nelze-li obvyklou cenu určit, do výše tržní hodnoty určené podle téhož zákona.
V případech hodných zvláštního zřetele lze sjednat cenu až do výše čtyřnásobku takto určené
obvyklé ceny nebo tržní hodnoty.“.
3.
V § 47 větě první se slova „krajský úřad“ nahrazují slovy „Úřad rozvoje území České
republiky“ a věta druhá se zrušuje.
4.
V § 51 odstavec 2 zní:
„(2) Byla-li předmětem vyvlastnění nemovitost, Úřad rozvoje území České republiky podá
návrh na zápis do katastru nemovitostí u příslušného katastrálního úřadu.“.
Čl. XXXIII
Přechodné ustanovení
Ustanovení § 6a odst. 2 věty druhé se použije i na právnické osoby zřízené Ministerstvem
obrany, jimž bylo oprávnění k poskytování zdravotních služeb uděleno přede dnem nabytí
účinnosti tohoto zákona.
ČÁST DVACÁTÁ PRVNÍ
Změna zákona o obcích
Čl. XXXIV
V § 39b odst. 1 písm. a) a d) zákona č. 128/2000 Sb., o obcích (obecní zřízení), ve znění
zákona č. 36/2025 Sb., se slova „zastavěného stavebního“ zrušují a za slovo „pozemku“ se
vkládají slova „zázemí stavby“.
ČÁST DVACÁTÁ DRUHÁ
Změna zákona o krajích
Čl. XXXV
V § 18b odst. 1 písm. b) a d) zákona č. 129/2000 Sb., o krajích (krajské zřízení), ve znění
zákona č. 36/2025 Sb., se slova „zastavěného stavebního“ zrušují a za slovo „pozemku“ se
vkládají slova „zázemí stavby“.
ČÁST DVACÁTÁ TŘETÍ
Změna zákona o hlavním městě Praze
Čl. XXXVI
Zákon č. 131/2000 Sb., o hlavním městě Praze, ve znění zákona č. 145/2001 Sb., zákona
č. 273/2001 Sb., zákona č. 320/2001 Sb., zákona č. 450/2001 Sb., zákona č. 311/2002 Sb.,
zákona č. 312/2002 Sb., zákona č. 320/2002 Sb., zákona č. 22/2004 Sb., zákona č. 216/2004
Sb., zákona č. 257/2004 Sb., zákona č. 387/2004 Sb., zákona č. 421/2004 Sb., zákona
č. 499/2004 Sb., zákona č. 501/2004 Sb., zákona č. 626/2004 Sb., zákona č. 109/2006 Sb.,
zákona č. 186/2006 Sb., zákona č. 234/2006 Sb., zákona č. 261/2007 Sb., zákona č. 66/2008
Sb., zákona č. 169/2008 Sb., zákona č. 298/2008 Sb., zákona č. 305/2008 Sb., zákona
č. 477/2008 Sb., zákona č. 227/2009 Sb., zákona č. 281/2009 Sb., zákona č. 326/2009 Sb.,
zákona č. 199/2010 Sb., zákona č. 347/2010 Sb., zákona č. 424/2010 Sb., zákona č. 246/2011
Sb., zákona č. 364/2011 Sb., zákona č. 457/2011 Sb., zákona č. 142/2012 Sb., zákona
č. 239/2012 Sb., zákona č. 350/2012 Sb., zákona č. 303/2013 Sb., zákona č. 64/2014 Sb.,
zákona č. 24/2015 Sb., zákona č. 298/2015 Sb., zákona č. 106/2016 Sb., zákona č. 99/2017 Sb.,
zákona č. 183/2017 Sb., zákona č. 225/2017 Sb., zákona č. 257/2017 Sb., zákona č. 32/2019
Sb., zákona č. 263/2019 Sb., zákona č. 36/2021 Sb., zákona č. 261/2021 Sb., zákona č. 330/2021
Sb., zákona č. 152/2023 Sb., nálezu Ústavního soudu, vyhlášeného pod č. 160/2023 Sb., zákona
č. 418/2023 Sb., zákona č. 89/2024 Sb., zákona č. 196/2024 Sb., zákona č. 36/2025 Sb., zákona
č. 57/2025 Sb., zákona č. 176/2025 Sb. a zákona č. 232/2025 Sb., se mění takto:
1.
V § 18 odst. 1 písm. h) se slova „těch řízeních, v nichž se vydává územní rozhodnutí,
společné povolení, kterým se stavba umisťuje a povoluje, nebo dodatečné povolení stavby
územní rozhodnutí nahrazující“ nahrazují slovy „řízeních o povolení záměru“.
2.
Poznámka pod čarou č. 6b zní:
„6b)
Zákon č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů.“.
3.
V § 36b odst. 1 písm. b) a d) se slova „zastavěného stavebního“ zrušují a za slovo
„pozemku“ se vkládají slova „zázemí stavby“.
ČÁST DVACÁTÁ ČTVRTÁ
Změna zákona o majetku České republiky
Čl. XXXVII
Zákon č. 219/2000 Sb., o majetku České republiky a jejím vystupování v právních vztazích,
ve znění zákona č. 492/2000 Sb., zákona č. 229/2001 Sb., zákona č. 320/2001 Sb., zákona
č. 501/2001 Sb., zákona č. 202/2002 Sb., zákona č. 280/2002 Sb., zákona č. 476/2002 Sb.,
zákona č. 88/2003 Sb., zákona č. 354/2003 Sb., zákona č. 480/2003 Sb., zákona č. 41/2004 Sb.,
zákona č. 218/2004 Sb., zákona č. 217/2005 Sb., zákona č. 359/2005 Sb., zákona č. 22/2006
Sb., zákona č. 140/2006 Sb., zákona č. 342/2006 Sb., zákona č. 296/2007 Sb., zákona
č. 139/2008 Sb., zákona č. 274/2008 Sb., zákona č. 457/2008 Sb., zákona č. 153/2009 Sb.,
zákona č. 227/2009 Sb., zákona č. 457/2011 Sb., zákona č. 18/2012 Sb., zákona č. 239/2012
Sb., zákona č. 407/2012 Sb., zákona č. 503/2012 Sb., zákona č. 311/2013 Sb., zákona č. 86/2015
Sb., zákona č. 320/2015 Sb., zákona č. 375/2015 Sb., zákona č. 51/2016 Sb., zákona č. 135/2016
Sb., zákona č. 185/2016 Sb., zákona č. 192/2016 Sb., zákona č. 264/2016 Sb., zákona č. 55/2017
Sb., zákona č. 65/2017 Sb., zákona č. 104/2017 Sb., zákona č. 118/2020 Sb., zákona č. 261/2021
Sb., zákona č. 225/2022 Sb., zákona č. 362/2022 Sb., zákona č. 422/2022 Sb., zákona
č. 326/2023 Sb., zákona č. 349/2023 Sb., nálezu Ústavního soudu, vyhlášeného pod č. 221/2024
Sb., zákona č. 36/2025 Sb., zákona č. 220/2025 Sb. a zákona č. 232/2025 Sb., se mění takto:
1.
V § 21b odst. 1 písm. d) se slova „zastavěného stavebního“ zrušují a za slovo
„pozemku99)“ se vkládají slova „zázemí stavby“.
2.
V § 21b odst. 1 písm. g) se slovo „zastavěném“ nahrazuje slovem „zastavitelném“ a slova
„nebo v zastavitelné ploše“ se zrušují.
ČÁST DVACÁTÁ PÁTÁ
Změna zákona o integrovaném záchranném systému
Čl. XXXVIII
Zákon č. 239/2000 Sb., o integrovaném záchranném systému a o změně některých zákonů,
ve znění zákona č. 320/2002 Sb., zákona č. 20/2004 Sb., zákona č. 186/2006 Sb., zákona
č. 306/2008 Sb., zákona č. 151/2010 Sb., zákona č. 375/2011 Sb., zákona č. 303/2013 Sb.,
zákonného opatření Senátu č. 344/2013 Sb., zákona č. 64/2014 Sb., zákona č. 183/2017 Sb.,
zákona č. 225/2017 Sb., zákona č. 277/2019 Sb., zákona č. 403/2020 Sb., zákona č. 284/2021
Sb., zákona č. 374/2021 Sb., zákona č. 415/2021 Sb., zákona č. 152/2023 Sb. a zákona č.
266/2025 Sb., se mění takto:
1.
V § 7 odst. 7 písm. d) se slova „průmyslu a obchodu“ nahrazují slovem „hospodářství“.
2.
V § 10 odstavce 7 a 8 znějí:
„(7) Požadavky ochrany obyvatelstva jsou uplatňovány posuzováním
a) dokumentace pro povolení stavby, zařízení nebo udržovacích prací podle stavebního
zákona, včetně změn této dokumentace,
b) dokumentace pro provádění stavby,
c) dokumentace nebo jiného podkladu ke změně v účelu užívání stavby.
(8) Výsledkem posuzování dokumentace a podkladů podle odstavce 7 je
a) závazné stanovisko dotčeného orgánu na úseku ochrany obyvatelstva u stavby podle § 39
odst. 1 písm. d) zákona o požární ochraně,
b) vyjádření dotčeného orgánu na úseku ochrany obyvatelstva u stavby podle § 39 odst. 1
písm. c) zákona o požární ochraně,
které slouží jako podklad pro řízení nebo jiný postup vedený podle stavebního zákona.“.
3.
V § 10 se za odstavec 8 vkládá nový odstavec 9, který zní:
„(9) Nadřízeným správním orgánem příslušným ke zrušení, potvrzení nebo změně
vyjádření nebo závazného stanoviska vydaného podle odstavce 8 hasičským záchranným
sborem kraje je u stavby
a) v rozsahu § 39 odst. 1 písm. c) zákona o požární ochraně ředitel hasičského záchranného
sboru kraje,
b) v rozsahu § 39 odst. 1 písm. d) zákona o požární ochraně generální ředitelství.“.
Dosavadní odstavce 9 až 11 se označují jako odstavce 10 až 12.
4.
V § 27 se doplňuje odstavec 3, který zní:
„(3) Na kontrolu podle odstavců 1 a 2 se použije kontrolní řád, nevyplývá-li z povahy
kontroly nebo z jiného právního předpisu odlišný postup.“.
5.
V § 33 odst. 1 se slova „územní souhlas anebo ohlášení stavby“ nahrazují slovy
„rozhodnutí o povolení záměru podle stavebního zákona“ a za slovo „stanoviskem“ se
vkládají slova „nebo vyjádřením“.
6.
V § 35 odst. 3 se slova „Ministerstvem pro místní rozvoj“ nahrazují slovy „Úřadem
rozvoje území České republiky“.
Čl. XXXIX
Přechodná ustanovení
1. Řízení a postupy zahájené a neskončené přede dnem nabytí účinnosti tohoto zákona se
dokončí podle zákona č. 239/2000 Sb., ve znění účinném ode dne nabytí účinnosti tohoto
zákona.
2. Žádost o vydání závazného stanoviska u stavby podle § 39 odst. 1 písm. c) zákona
č. 133/1985 Sb., o požární ochraně, které nebylo vydáno do dne nabytí účinnosti tohoto zákona,
se považuje za žádost o vydání vyjádření; lhůta pro vydání vyjádření běží ode dne podání
původní žádosti o vydání závazného stanoviska. Přezkum závazného stanoviska u stavby podle
§ 39 odst. 1 písm. c) zákona 133/1985 Sb., o požární ochraně, podle § 149 odst. 8 správního
řádu, zahájený a neskončený do dne účinnosti tohoto zákona, dokončí ředitel hasičského
záchranného sboru kraje podle dosavadních právních předpisů.
ČÁST DVACÁTÁ ŠESTÁ
Změna zákona o ochraně veřejného zdraví
Čl. XL
Zákon č. 258/2000 Sb., o ochraně veřejného zdraví a o změně některých souvisejících
zákonů, ve znění zákona č. 254/2001 Sb., zákona č. 274/2001 Sb., zákona č. 13/2002 Sb.,
zákona č. 76/2002 Sb., zákona č. 86/2002 Sb., zákona č. 120/2002 Sb., zákona č. 320/2002 Sb.,
zákona č. 274/2003 Sb., zákona č. 356/2003 Sb., zákona č. 362/2003 Sb., zákona č. 167/2004
Sb., zákona č. 326/2004 Sb., zákona č. 562/2004 Sb., zákona č. 125/2005 Sb., zákona
č. 253/2005 Sb., zákona č. 381/2005 Sb., zákona č. 392/2005 Sb., zákona č. 444/2005 Sb.,
zákona č. 59/2006 Sb., zákona č. 74/2006 Sb., zákona č. 186/2006 Sb., zákona č. 189/2006 Sb.,
zákona č. 222/2006 Sb., zákona č. 264/2006 Sb., zákona č. 342/2006 Sb., zákona č. 110/2007
Sb., zákona č. 296/2007 Sb., zákona č. 378/2007 Sb., zákona č. 124/2008 Sb., zákona
č. 130/2008 Sb., zákona č. 274/2008 Sb., zákona č. 227/2009 Sb., zákona č. 281/2009 Sb.,
zákona č. 301/2009 Sb., zákona č. 151/2011 Sb., zákona č. 298/2011 Sb., zákona č. 375/2011
Sb., zákona č. 466/2011 Sb., zákona č. 115/2012 Sb., zákona č. 333/2012 Sb., zákona
č. 223/2013 Sb., zákona č. 64/2014 Sb., zákona č. 247/2014 Sb., zákona č. 250/2014 Sb.,
zákona č. 252/2014 Sb., zákona č. 82/2015 Sb., zákona č. 267/2015 Sb., zákona č. 243/2016
Sb., zákona č. 250/2016 Sb., zákona č. 298/2016 Sb., zákona č. 183/2017 Sb., zákona
č. 193/2017 Sb., zákona č. 202/2017 Sb., zákona č. 225/2017 Sb., zákona č. 277/2019 Sb.,
zákona č. 205/2020 Sb., zákona č. 238/2020 Sb., zákona č. 403/2020 Sb., zákona č. 544/2020
Sb., zákona č. 36/2021 Sb., zákona č. 94/2021 Sb., zákona č. 261/2021 Sb., zákona č. 284/2021
Sb., zákona č. 363/2021 Sb., zákona č. 314/2022 Sb., zákona č. 384/2022 Sb., zákona
č. 152/2023 Sb., zákona č. 167/2023 Sb., zákona č. 281/2023 Sb., zákona č. 412/2023 Sb.,
zákona č. 242/2024 Sb., zákona č. 77/2025 Sb., zákona č. 152/2025 Sb., zákona č. 218/2025
Sb., zákona č. 236/2025 Sb., zákona 251/2025 Sb., zákona č. 270/2025 Sb., zákona č. 290/2025
Sb. a zákona č. 314/2025 Sb., se mění takto:
1.
V § 7 odst. 1 se slova „byly splněny hygienické požadavky upravené prováděcím právním
předpisem na prostorové podmínky, vybavení, provoz, osvětlení, vytápění,
mikroklimatické podmínky, zásobování vodou, úklid a nakládání s prádlem“ nahrazují
slovy „při jejich provozu byly splňovány hygienické požadavky na jejich vybavení, úklid
a nakládání s prádlem a mikroklimatické podmínky, které stanoví prováděcí právní
předpis“.
2.
V § 13 odst. 1 se slova „odpovídalo hygienickým limitům chemických, fyzikálních
a biologických ukazatelů, upravených prováděcími právními předpisy“ nahrazují slovy
„při jejich provozu splňovalo hygienické požadavky na mikroklimatické podmínky, které
jsou stanoveny v prováděcím právním předpisu“.
3.
V § 41 se doplňuje odstavec 8, který zní:
„(8) Pokud práce s azbestem spočívá v odstranění stavby vyžadující povolení odstranění
stavby podle stavebního zákona, je povolení práce s azbestem podle odstavce 3 nahrazeno
povolením odstranění stavby. Stavebník, nebo osoba, která bude pro stavebníka práce
s azbestem skutečně vykonávat, je před započetím práce s azbestem povinna postupovat podle
odstavce 1 až 3.“.
4.
V § 77 odst. 1 se na konci textu věty první doplňují slova „ , s výjimkou řízení podle
stavebního zákona“.
5.
V § 77 se odstavec 2 zrušuje.
Dosavadní odstavce 3 až 6 se označují jako odstavce 2 až 5.
6.
V § 77 odst. 2 se slova „ke stavbě“ nahrazují slovem „stavbu“ a slova „vydat kladné
stanovisko orgánu ochrany veřejného zdraví“ se nahrazují slovem „povolit“.
7.
V § 77 se odstavec 3 zrušuje.
Dosavadní odstavce 4 a 5 se označují jako odstavce 3 a 4.
8.
V § 78 odst. 1 písmeno h) zní:
„h) stavební úřady.“.
9.
V § 80 odst. 2 se slovo „zastavěných“ nahrazuje slovem „zastavitelných“.
10.
§ 82b včetně nadpisu zní:
„§ 82b
Stavební úřady
Stavební úřady rozhodnutím o záměru nahrazují závazná stanoviska, stanoviska, vyjádření
a jiné úkony vydávané podle tohoto zákona, pokud se týkají záměru povolovaného podle
stavebního zákona.“.
11.
V § 108 odst. 1 se text „§ 7 odst. 1,“ a text „§ 13,“ zrušuje.
12.
V § 108 odst. 2 se slova „prostory a“ zrušují.
13.
V § 108 se odstavec 3 zrušuje.
Dosavadní odstavce 4 až 6 se označují jako odstavce 3 až 5.
14.
V § 108 odst. 3 se za slovo „provedení“ vkládá text „§ 6c odst. 3, § 6f odst. 4, § 7 odst. 1,
§ 13,“ a slova „§ 41 odst. 1 věty třetí, § 77 odst. 5“ se nahrazují slovy „§ 39 odst. 3 a 4,
§ 77 odst. 4“.
Čl. XLI
Přechodná ustanovení
1. Řízení a postupy zahájené a neskončené přede dnem nabytí účinnosti tohoto zákona se
dokončí podle zákona č. 258/2000 Sb., ve znění účinném ode dne nabytí účinnosti tohoto
zákona, není-li stanoveno jinak.
2. Řízení a postupy zahájené a neskončené do dne vzniku Úřadu rozvoje území České
republiky (dále jen „Úřad“), k nimž je příslušný Úřad nebo jiný stavební úřad, převezme a
dokončí ode dne svého vzniku Úřad nebo jiný stavební úřad.
3. Řízení a postupy zahájené a neskončené do dne vzniku úřadů rozvoje území krajů, k
nimž je příslušný úřad rozvoje území kraje nebo jeho územní pracoviště, ode dne vzniku úřadů
rozvoje území krajů převezme a dokončí příslušný úřad rozvoje území kraje nebo jeho příslušné
územní pracoviště. Do dne vzniku úřadů rozvoje území krajů pokračují v těchto řízeních a
postupech krajské hygienické stanice, a to podle zákona č. 258/2000 Sb., ve znění účinném ode
dne nabytí účinnosti tohoto zákona s výjimkou § 77, a dále podle § 77 zákona č. 258/2000 Sb.,
ve znění účinném přede dnem nabytí účinnosti tohoto zákona.
ČÁST DVACÁTÁ SEDMÁ
Změna zákona o hospodaření energií
Čl. XLII
V § 11 odst. 1 písm. j) zákona č. 406/2000 Sb., o hospodaření energií, ve znění zákona
č. 177/2006 Sb., zákona č. 165/2012 Sb., zákona č. 318/2012 Sb., zákona č. 310/2013 Sb.,
zákona č. 103/2015 Sb., zákona č. 3/2020 Sb., zákona č. 403/2020 Sb., zákona č. 284/2021 Sb.,
zákona č. 152/2023 Sb. a zákona č. 469/2023 Sb., se slova „Ministerstvem pro místní rozvoj“
nahrazují slovy „Úřadem rozvoje území České republiky“.
ČÁST DVACÁTÁ OSMÁ
Změna energetického zákona
Čl. XLIII
Zákon č. 458/2000 Sb., o podmínkách podnikání a o výkonu státní správy v energetických
odvětvích a o změně některých zákonů (energetický zákon), ve znění zákona č. 151/2002 Sb.,
zákona č. 262/2002 Sb., zákona č. 278/2003 Sb., zákona č. 356/2003 Sb., zákona č. 670/2004
Sb., zákona č. 186/2006 Sb., zákona č. 342/2006 Sb., zákona č. 296/2007 Sb., zákona
č. 124/2008 Sb., zákona č. 158/2009 Sb., zákona č. 223/2009 Sb., zákona č. 227/2009 Sb.,
zákona č. 281/2009 Sb., zákona č. 155/2010 Sb., zákona č. 211/2011 Sb., zákona č. 299/2011
Sb., zákona č. 420/2011 Sb., zákona č. 165/2012 Sb., zákona č. 350/2012 Sb., zákona č. 90/2014
Sb., zákona č. 250/2014 Sb., zákona č. 104/2015 Sb., zákona č. 131/2015 Sb., zákona
č. 152/2017 Sb., zákona č. 183/2017 Sb., zákona č. 225/2017 Sb., zákona č. 277/2019 Sb.,
zákona č. 1/2020 Sb., zákona č. 403/2020 Sb., zákona č. 609/2020 Sb., zákona č. 261/2021 Sb.,
zákona č. 284/2021 Sb., zákona č. 362/2021 Sb., zákona č. 382/2021 Sb., zákona č. 176/2022
Sb., zákona č. 232/2022 Sb., zákona č. 287/2022 Sb., zákona č. 365/2022 Sb., zákona č. 19/2023
Sb., zákona č. 427/2023 Sb., zákona č. 465/2023 Sb., zákona č. 469/2023 Sb., zákona
č. 265/2024 Sb., zákona č. 87/2025 Sb., zákona č. 152/2025 Sb., zákona č. 218/2025 Sb.,
zákona č. 223/2025 Sb., zákona č. 249/2025 Sb. a zákona č. 330/2025 Sb., se mění takto:
1.
V § 2 odst. 2 písm. a) bodě 4 se za slovo „včetně“ vkládají slova „vývodových vedení“.
2.
V § 2 odst. 2 písm. a) se za bod 18 vkládá nový bod 19, který zní:
„19. vývodovým vedením vedení elektřiny spojující výrobnu elektřiny nebo zařízení pro
ukládání elektřiny s místem připojení k přenosové nebo distribuční soustavě,“.
Dosavadní body 19 až 34 se označují jako body 20 až 35.
3.
V § 3 odst. 2 se věta poslední nahrazuje větou „Pro zřízení a provozování stavby
přenosové soustavy, přepravní soustavy, vodíkové přepravní soustavy, distribuční
soustavy, výrobny elektřiny o celkovém instalovaném elektrickém výkonu 100 MW
a více s možností poskytovat podpůrné služby k zajištění provozu elektrizační soustavy,
stavby pro energetickou bezpečnost podle § 1 odst. 5 písm. a) až c) zákona o urychlení
výstavby strategicky významné infrastruktury, vývodového vedení výrobny elektřiny
o celkovém instalovaném elektrickém výkonu 100 MW a více s možností poskytovat
podpůrné služby k zajištění provozu elektrizační soustavy nebo stavby pro energetickou
bezpečnost podle zákona o urychlení výstavby strategicky významné infrastruktury,
zásobníku plynu, těžebního plynovodu, výrobny plynu s výkonem nad 1 MW připojené
k plynárenské soustavě, rozvodného tepelného zařízení nebo zdroje tepelné energie
připojeného k rozvodnému tepelnému zařízení anebo pro zřízení a provozování stavby
související lze odejmout nebo omezit vlastnické právo k pozemku nebo ke stavbě podle
jiného právního předpisu4e).“.
4.
V § 3a odst. 1, § 17b odst. 2 a 10 až 12 se slova „průmyslu a obchodu“ nahrazují slovem
„hospodářství“.
5.
V § 4 se doplňuje odstavec 5, který zní:
„(5) Požádá-li držitel licence v případě licence, jejíž platnost končí uplynutím 25 let od
doby jejího udělení, nejpozději 30 dní před uplynutím doby, na kterou byla licence udělena, o
udělení nové licence ve vztahu k energetickým zařízením provozovaným na základě této
licence, licence zaniká až právní mocí rozhodnutí Energetického regulačního úřadu o nové
žádosti.“.
6.
V § 10c se slova „Ministerstva průmyslu a obchodu (dále jen „ministerstvo“)“ nahrazují
slovem „ministerstva“.
7.
V § 17 odst. 7 písm. j) bodě 9 se slova „Ministerstvem pro místní rozvoj“ nahrazují slovy
„Úřadem rozvoje území České republiky“.
8.
§ 17a zní:
„§ 17a
(1) Energetický regulační úřad na základě žádosti Agentury opatří doložkou
vykonatelnosti rozhodnutí Agentury o uložení penále podle čl. 13g Nařízení o velkoobchodním
trhu s energií. Energetický regulační úřad opatří rozhodnutí Agentury doložkou vykonatelnosti
po ověření pravosti titulu, aniž by prováděl kontrolu či vydával rozhodnutí.
(2) Penále podle odstavce 1 vymáhá celní úřad. Při vymáhání penále postupuje celní úřad
podle daňového řádu v režimu dělené správy. Energetický regulační úřad se pro účely správy
placení penále považuje za orgán veřejné moci, který toto penále uložil. Lhůta pro placení
penále začne běžet dnem opatření rozhodnutí Agentury doložkou vykonatelnosti podle
odstavce 1.“.
9.
V § 17b odst. 1 se slova „5 členů“ nahrazují slovy „3 členy“.
10.
V § 17b odst. 2 se číslo „5“ nahrazuje číslem „6“, slova „každý rok“ se nahrazují slovy
„každé dva roky“ a slova „odstavců 10 a 11“ se nahrazují slovy „odstavce 10“.
11.
V § 17b se na konci odstavce 6 doplňují věty „Předseda Energetického regulačního úřadu
musí být držitelem platného osvědčení fyzické osoby pro stupeň utajení Důvěrné nebo
vyšší. Není-li držitelem osvědčení podle věty druhé, požádá bez zbytečného odkladu po
svém jmenování do funkce o vydání tohoto osvědčení podle zákona upravujícího ochranu
utajovaných informací74).“.
Poznámka pod čarou č. 74 zní:
„74)
§ 94 zákona č. 412/2005 Sb., o ochraně utajovaných informací a o bezpečnostní
způsobilosti, ve znění pozdějších předpisů.“.
12.
V § 17b se odstavec 11 zrušuje.
Dosavadní odstavce 12 až 17 se označují jako odstavce 11 až 16.
13.
V § 17b odst. 11 se za větu první vkládá věta „Nezíská-li předseda Energetického
regulačního úřadu osvědčení podle odstavce 6 věty třetí nebo dojde-li k zániku platnosti
tohoto osvědčení, ministr průmyslu a obchodu bezodkladně navrhne vládě odvolání
předsedy Energetického regulačního úřadu z jeho funkce.“.
14.
V § 17b odst. 12 se číslo „3“ nahrazuje číslem „2“.
15.
V § 17e se za odstavec 9 vkládá nový odstavec 10, který zní:
„(10) Navrhuje-li se změna metodiky cenové regulace v průběhu regulačního období,
Energetický regulační úřad zveřejní návrh změny na svých internetových stránkách a stanoví
lhůtu pro podání připomínek veřejnosti, která nesmí být kratší než 30 dnů. Energetický
regulační úřad umožní podávání připomínek prostřednictvím diskusního místa podle odstavce
3. Zveřejnění návrhu změny metodiky cenové regulace Energetický regulační úřad oznámí
osobám podle odstavce 9, vyzve je k uplatnění připomínek a stanoví lhůtu pro jejich podání,
která nesmí být kratší než 30 dnů. K připomínkám podaným po stanovené lhůtě se nepřihlíží.“.
Dosavadní odstavce 10 až 12 se označují jako odstavce 11 až 13.
16.
V § 18 se doplňuje odstavec 8, který zní:
„(8) Je-li při výkonu kontroly podle Nařízení o velkoobchodním trhu s energií důvodné
podezření, že se obchodní knihy nebo jiné záznamy nacházejí v jiných než obchodních
prostorách, včetně bytů fyzických osob, které jsou členy statutárních orgánů nebo zaměstnanci
kontrolované osoby, nebo dalších obydlí těchto osob, která nejsou užívána k podnikání nebo
provozování jiné hospodářské činnosti (dále jen „jiné než obchodní prostory“), může kontrola
s předchozím souhlasem soudu probíhat i v takových prostorách. Odstavec 5 písm. c) se při
výkonu kontroly v jiných než obchodních prostorách nepoužije.“.
17.
V § 19a odst. 2 a § 22 odst. 3 se za slova „systémové služby,“ vkládají slova „cenu za
kapacitní mechanismus,“.
18.
V § 19a odst. 4 se věty druhá a třetí nahrazují větami „Věcné usměrňování ceny tepelné
energie se nevztahuje na stanovení ceny nižší, než je limitní cena, jejíž výši a podmínky
použití
může
Energetický
regulační
úřad
stanovit
cenovým
výměrem.
Při stanovení limitní ceny Energetický regulační úřad zohlední náklady na tepelnou
energii z jiného zdroje vytápění.“.
19.
V § 19a se za odstavec 8 vkládá nový odstavec 9, který zní:
„(9) Cenu za kapacitní mechanismus reguluje Energetický regulační úřad tak, aby
pokrývala alespoň ekonomicky oprávněné náklady provozovatele přenosové soustavy na
zajištění kapacitního mechanismu. Cenu za kapacitní mechanismus stanoví Energetický
regulační úřad pro regulované roky nebo i část regulovaného roku, ve kterém bude poskytován
sjednaný rozsah dostupnosti výkonu. V případě potřeby změny ceny za kapacitní mechanismus
v průběhu regulovaného roku stanoví Energetický regulační úřad cenu za kapacitní
mechanismus do 3 měsíců ode dne poskytnutí údajů pro stanovení ceny za kapacitní
mechanismus operátorem trhu a provozovatelem přenosové soustavy.“.
Dosavadní odstavce 9 a 10 se označují jako odstavce 10 a 11.
20.
Za § 19ca se vkládá nový § 19cb, který včetně nadpisu zní:
„§ 19cb
Cena za kapacitní mechanismus
Cenu za kapacitní mechanismus hradí účastníci trhu s elektřinou provozovateli přenosové
soustavy v ceně za související služby v elektroenergetice přímo nebo prostřednictvím
provozovatele regionální distribuční soustavy.“.
21.
V § 20a odst. 4 písm. za) se slova „národní energetický mix a“ zrušují.
22.
V § 20a se na konci odstavce 4 tečka nahrazuje čárkou a doplňuje se písmeno zf), které
zní:
„zf) poskytnout provozovateli přenosové soustavy na jeho žádost údaje stanovené opatřením
obecné povahy vydaným ministerstvem nezbytné pro přípravu a fungování kapacitního
mechanismu, je-li zaveden.“.
23.
V § 23 odst. 3 písm. r) se za slovo „instalaci“ vkládají slova „podle technické normy
upravující požární bezpečnost staveb75)“ a slova „z obnovitelných zdrojů energie“ se
nahrazují slovy „využívajících energii slunečního záření“.
Poznámka pod čarou č. 75 zní:
„75)
ČSN P 73 0847 Požární bezpečnost staveb - Fotovoltaické (PV) systémy.“.
24.
V § 25 odst. 11 písm. c) se slova „ministerstvu a“ zrušují.
25.
V § 27da písm. f) bodě 5 se za slova „aktivace flexibility“ vkládají slova „a ukládání
elektřiny“ a slova „poskytujícího flexibilitu“ se zrušují.
26.
V § 30a odst. 1 se číslo „1“ nahrazuje číslem „100“.
27.
V § 30a odst. 3 se na konci textu písmene c) doplňují slova „ , ledaže předpokládaná
výrobna elektřiny je stavbou pro energetickou bezpečnost podle zákona upravujícího
urychlení výstavby strategicky významné infrastruktury“.
28.
V § 35 odst. 1 se text „čl. 21“ zrušuje a slova „podle čl. 22 Nařízení o vnitřním trhu
s elektřinou“ se nahrazují slovy „a uloží účastníkům trhu s elektřinou povinnosti v
souvislosti se zavedením kapacitního mechanismu“.
29.
V § 35 se za odstavec 1 vkládá nový odstavec 2, který zní:
„(2) Ministerstvo stanoví opatřením obecné povahy podle odstavce 1 po projednání s
Energetickým regulačním úřadem rovněž způsob určení rozsahu potřebné dostupnosti výkonu
výroben elektřiny nebo jiných energetických zařízení.“.
Dosavadní odstavce 2 až 6 se označují jako odstavce 3 až 7.
30.
V § 35 odst. 4 se slovo „regulačního“ zrušuje a na konci textu odstavce 4 se doplňují
slova „a předloží ho ministerstvu ke schválení“.
31.
V § 35 odst. 5 se slovo „regulačního“ zrušuje a za slovo „zařízení“ se vkládají slova „v
aukci“.
32.
V § 35 odstavec 6 zní:
„(6) Ministerstvo rozsah potřebné dostupnosti výkonu výroben elektřiny nebo jiných
energetických zařízení podle odstavce 4 a návrh podle odstavce 5 schválí, jestliže jsou v souladu
s podmínkami kapacitního mechanismu stanovenými ministerstvem. Před schválením si
ministerstvo může vyžádat vyjádření Energetického regulačního úřadu.“.
33.
Za § 35 se vkládá nový § 35a, který včetně nadpisu zní:
„§ 35a
Provádění kapacitního mechanismu
(1) Provozovatel přenosové soustavy je povinen zajišťovat potřebnou dostupnost výkonu
výroben elektřiny nebo jiných energetických zařízení v souladu s postupem a podmínkami
zajištění potřebné dostupnosti výkonu výroben elektřiny nebo jiných energetických zařízení v
aukci a v souladu s podmínkami kapacitního mechanismu stanovenými ministerstvem.
(2) Provozovatel přenosové soustavy má právo zrušit aukci na zajištění potřebné
dostupnosti výkonu výroben elektřiny nebo jiných energetických zařízení jen se souhlasem
ministerstva.
(3) Provozovatel přenosové soustavy má právo přistoupit k uzavření smluv o zajištění
potřebné dostupnosti výkonu s předkladateli nabídek, které uspěly v aukci na zajištění potřebné
dostupnosti výkonu výroben elektřiny nebo jiných energetických zařízení, jen se souhlasem
ministerstva.“.
34.
V § 45 odst. 2 písm. a) se slovo „zastavěném“ nahrazuje slovem „zastavitelném“ a za
slovo „předpisu4d)“ se vkládají slova „ , je-li její délka do 50 m včetně,“.
35.
Poznámka pod čarou č. 4d zní:
 „4d)
Zákon č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů.“.
36.
V § 45 odst. 2 písm. b) a c) se slovo „zastavěné“ nahrazuje slovem „zastavitelné“.
37.
V § 47 odst. 2 se slovo „zastavěném“ nahrazuje slovem „zastavitelném“.
38.
V § 50 se za odstavec 13 vkládá nový odstavec 14, který zní:
„(14) Smlouvou o zajištění potřebné dostupnosti výkonu se účastník kapacitního
mechanismu zavazuje poskytovat provozovateli přenosové soustavy dostupnost výkonu a
provozovatel přenosové soustavy se zavazuje zaplatit účastníkovi kapacitního mechanismu
cenu.“.
Dosavadní odstavce 14 až 16 se označují jako odstavce 15 až 17.
39.
V § 68 odst. 2 písm. a) a h) se slovo „zastavěném“ nahrazuje slovem „zastavitelném“
a slovo „zastavěné“ se nahrazuje slovem „zastavitelné“.
40.
V § 68 odst. 2 písm. a) se slova „plynovodů a“ nahrazují slovem „plynovodů,“ a za slovo
„včetně“ se vkládají slova „s výjimkou regulačních stanic“.
41.
V § 68 odst. 2 písm. d) se za slovo „objektů“ vkládají slova „o tlakové úrovni nad 4 bary
a regulačních stanic o tlakové úrovni do 4 bar včetně“.
42.
V nadpisu § 79 se slova „a předávací stanice“ nahrazují slovy „ , předávací stanice
a tepelná síť“.
43.
V § 79 odstavec 2 zní:
„(2) Tepelná přípojka, předávací stanice a tepelná síť, popřípadě část tepelné sítě oddělená
od jiné části tepelné sítě tlakovou či redukční stanicí nebo jiným funkčně obdobným zařízením,
jsou samostatnými věcmi. Vlastníkem tepelné sítě nebo její části, tepelné přípojky nebo
předávací stanice je ten, kdo ji zřídil, není-li dohodnuto jinak.“.
44.
V § 79 odst. 3 se slova „nebo předávací stanice“ nahrazují slovy „ , předávací stanice
nebo tepelné sítě“.
45.
V § 91 odst. 1 písm. r) se slovo „nebo“ zrušuje.
46.
V § 91 se na konci odstavce 1 tečka nahrazuje slovem „ , nebo“ a doplňuje se písmeno t),
které zní:
„t) poruší opatření stanovené formou opatření obecné povahy podle § 35.“.
47.
V § 91 odst. 3 písm. s) se slovo „nebo“ zrušuje.
48.
V § 91 se na konci odstavce 3 tečka nahrazuje slovem „ , nebo“ a doplňuje se písmeno
u), které zní:
„u) nesplní povinnost poskytnout nezbytnou součinnost podle § 35 odst. 3 nebo nezajišťuje
potřebnou dostupnost výkonu podle § 35a odst. 1.“.
49.
V § 91 odst. 17 písm. b) se za text „o)“ vkládají slova „nebo t)“, slova „l) nebo“ se
nahrazují textem „l),“ a za slova „až s)“ se vkládají slova „nebo u)“.
50.
V § 91a odst. 2 písm. l) se slovo „nebo“ zrušuje.
51.
V § 91a se na konci odstavce 2 tečka nahrazuje slovem „ , nebo“ a doplňuje se písmeno
n), které zní:
„n) poruší opatření stanovené formou opatření obecné povahy podle § 35.“.
52.
V § 91a odst. 9 se za text „k)“ vkládají slova „nebo n)“ a za slova „do 50 000 000 Kč“ se
vkládá slovo „ , a“.
53.
V § 97b odst. 1 se slova „a držiteli licence na výrobu elektřiny provozujícímu výrobnu
elektřiny z obnovitelných zdrojů energie zřizovanou a provozovanou ve veřejném zájmu“
nahrazují slovy „stavebníkovi, jemuž bylo vydáno pravomocné rozhodnutí o povolení
záměru umožňující umístit stavbu vývodového vedení výrobny elektřiny z obnovitelných
zdrojů energie zřizované a provozované ve veřejném zájmu nebo vývodového vedení
zařízení pro ukládání elektřiny zřizovaného a provozovaného ve veřejném zájmu,“, slova
„výrobny elektřiny na“ se nahrazují slovy „stavbu příslušného vývodového vedení na“,
slova „nebo výrobny elektřiny a“ se nahrazují slovem „a“ a na konci textu odstavce se
doplňují slova „nebo stavbu příslušného vývodového vedení“.
54.
V § 97b odst. 2 se slova „stavbu nebo zařízení příslušné soustavy nebo výrobny elektřiny“
nahrazují slovy „stavbu nebo zařízení příslušné soustavy nebo stavbu příslušného
vývodového vedení“, slova „stavba nebo zařízení příslušné soustavy nebo výrobny
elektřiny“ se nahrazují slovy „stavba nebo zařízení příslušné soustavy nebo stavba
příslušného vývodového vedení“, slova „stavby nebo zařízení příslušné soustavy nebo
výrobny elektřiny“ se nahrazují slovy „stavby nebo zařízení příslušné soustavy nebo
stavby příslušného vývodového vedení“ a slova „předchozí věty“ se nahrazují slovy „věty
první“.
55.
V § 97b odst. 5 se slova „výrobny elektřiny“ nahrazují slovy „stavby příslušného
vývodového vedení“.
56.
V § 97b se odstavec 6 zrušuje.
Dosavadní odstavce 7 a 8 se označují jako odstavce 6 a 7.
57.
V § 98a odst. 1 písm. i) se slova „národního energetického mixu a“ zrušují.
58.
V § 98a odst. 1 se písmeno j) zrušuje.
Dosavadní písmeno k) se označuje jako písmeno j).
59.
V § 98a odst. 2 písm. f) se slova „ , stanovení limitní ceny pro věcné usměrňování cen
v teplárenství“ zrušují.
Čl. XLIV
Přechodná ustanovení
1. Délka funkčního období členů Rady Energetického regulačního úřadu a předsedy
Energetického regulačního úřadu jmenovaných přede dnem nabytí účinnosti tohoto zákona se
řídí zákonem č. 458/2000 Sb., ve znění účinném do dne nabytí účinnosti tohoto zákona.
2. Funkční období člena Rady Energetického regulačního úřadu jmenovaného do funkce
ode dne 1. ledna 2028 končí dnem 31. prosince 2032.
3. Právní povaha tepelné přípojky, předávací stanice nebo tepelné sítě zřízených před
nabytím účinnosti tohoto zákona, jakož i vznik a trvání právních poměrů týkajících se těchto
tepelných zařízení, se posuzují podle zákona č. 458/2000 Sb., ve znění účinném ode dne nabytí
účinnosti tohoto zákona.
4. Řízení zahájená přede dnem nabytí účinnosti tohoto zákona se dokončí podle zákona
č. 458/2000 Sb., ve znění účinném přede dnem nabytí účinnosti tohoto zákona.
5. Předseda Energetického regulačního úřadu vykonávající funkci ke dni nabytí účinnosti
tohoto zákona je povinen splnit požadavek podle § 17b odst. 6 věty druhé zákona č. 458/2000
Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona, nejpozději do 6 měsíců ode dne
nabytí účinnosti tohoto zákona.
ČÁST DVACÁTÁ DEVÁTÁ
Změna zákona o posuzování vlivů na životní prostředí
Čl. XLV
Zákon č. 100/2001 Sb., o posuzování vlivů na životní prostředí a o změně některých
souvisejících zákonů (zákon o posuzování vlivů na životní prostředí), ve znění zákona
č. 93/2004 Sb., zákona č. 163/2006 Sb., zákona č. 186/2006 Sb., zákona č. 216/2007 Sb.,
zákona č. 124/2008 Sb., zákona č. 223/2009 Sb., zákona č. 227/2009 Sb., zákona č. 436/2009
Sb., zákona č. 38/2012 Sb., zákona č. 85/2012 Sb., zákona č. 167/2012 Sb., zákona č. 350/2012
Sb., zákona č. 39/2015 Sb., zákona č. 268/2015 Sb., zákona č. 256/2016 Sb., zákona č. 298/2016
Sb., zákona č. 225/2017 Sb., zákona č. 326/2017 Sb., zákona č. 403/2020 Sb., zákona
č. 261/2021 Sb., zákona č. 284/2021 Sb., zákona č. 413/2021 Sb., zákona č. 149/2023 Sb.,
zákona č. 465/2023 Sb., zákona č. 87/2025 Sb., zákona č. 223/2025 Sb. a zákona č. 249/2025
Sb., se mění takto:
1.
V § 1 odstavec 4 včetně poznámek pod čarou č. 24 a 25 zní:
„(4) Jde-li o záměr vyžadující souhlas orgánu ochrany přírody k zásahu do významného
krajinného prvku24) nebo ke snížení nebo změně krajinného rázu25), je účelem posuzování vlivů
podle tohoto zákona také vyhodnocení vlivů záměru na významný krajinný prvek nebo krajinný
ráz.
_____________
24)
§ 4 odst. 2 zákona č. 114/1992 Sb., o ochraně přírody a krajiny, ve znění pozdějších
předpisů.
25)
§ 12 zákona č. 114/1992 Sb., o ochraně přírody a krajiny, ve znění pozdějších
předpisů.“.
Poznámka pod čarou č. 19 se zrušuje.
2.
Poznámka pod čarou č. 15, která zní: „15)
§ 94d odst. 1 a § 94t odst. 1 zákona č.
183/2006 Sb., o územním plánování a stavebním řádu (stavební zákon), ve znění
pozdějších předpisů.“, se zrušuje.
3.
V § 3 písm. e) se slova „a správní orgán příslušný podle jiného právního předpisu k vydání
správního aktu, namísto nějž se vydává jednotné environmentální stanovisko“ zrušují.
4.
V § 3 písm. g) se bod 3 zrušuje.
Dosavadní body 4 až 10 se označují jako body 3 až 9.
5.
V § 3 písm. g) bodě 8 se číslo „8“ nahrazuje číslem „7“.
6.
V § 3 písm. g) bodě 9 a § 3 písm. m) se číslo „9“ nahrazuje číslem „8“.
7.
V § 4 odst. 3 písm. c) se slova „umístění nebo provedení záměru“ nahrazují slovem
„záměr“.
8.
V § 4 odst. 4 se slova „§ 45i odst. 8 až 11“ nahrazují slovy „§ 45i odst. 3 až 6“.
9.
V § 6 odst. 6 se slova „zákona o jednotném environmentálním stanovisku“ nahrazují
slovy „jiného právního předpisu26)“.
Poznámka pod čarou č. 26 zní:
 „26)
Například zákon č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů.“.
10.
V § 7 odst. 1 písm. d) se slova „hlediska dotčených složek životního prostředí za účelem
vydání jednotného environmentálního stanoviska podle zákona o jednotném
environmentálním stanovisku“ nahrazují slovy „hledisek uvedených v § 1 odst. 4“.
11.
V § 7 odst. 5 se věta první nahrazuje větou „V případě záměru podle odstavce 1 vydá
příslušný úřad odůvodněný písemný závěr obsahující základní údaje o záměru v rozsahu
bodů B.I.1. až B.I.4. a B.I.6. přílohy č. 3 k tomuto zákonu, úvahy, kterými se řídil při
hodnocení kritérií uvedených v příloze č. 2 k tomuto zákonu, a upřesnění informací, které
je vhodné uvést do dokumentace. Dojde-li příslušný úřad k závěru, že záměr podle
odstavce 2 podléhá posouzení vlivů záměru na životní prostředí podle tohoto zákona,
vydá o tom odůvodněný písemný závěr, pro jehož obsah se věta první použije obdobně.“.
12.
V § 7 odst. 5 větě druhé a § 7 odst. 6 větě třetí se slova „jednotné environmentální
stanovisko“ nahrazují slovy „povolení záměru podle jiného právního předpisu26)“.
13.
V § 7 se na konci odstavce 8 doplňuje věta „Oznamovatel, dotčená veřejnost uvedená
v § 3 písm. i) bodě 2 a dotčené územní samosprávné celky mají právo podat odvolání
pouze proti výroku podle odstavce 6.“.
14.
V § 8 odst. 1 se věta třetí zrušuje.
15.
V § 8 odst. 3 se věta poslední včetně poznámky pod čarou č. 20 zrušuje.
16.
V § 9a odst. 1 se věta poslední nahrazuje větou „Jde-li o záměr vyžadující souhlas orgánu
ochrany přírody k zásahu do významného krajinného prvku24) nebo ke snížení nebo
změně krajinného rázu25), nahrazuje stanovisko tyto souhlasy; stanovisko v takovém
případě obsahuje návrh opatření pro snížení nebo kompenzaci negativních vlivů záměru
na významný krajinný prvek nebo krajinný ráz.“.
17.
V § 9a odst. 4 se číslo „7“ nahrazuje číslem „10“ a číslo „5“ se nahrazuje číslem „7“.
18.
V § 9a odst. 5 větě poslední se slova „věty čtvrté“ nahrazují slovy „věty páté“.
19.
V § 9a se na konci odstavce 6 doplňuje věta „V případě mezistátního navazujícího řízení
předloží oznamovatel příslušnému úřadu, který vydal stanovisko, dokumenty podle věty
první vždy před podáním žádosti o zahájení mezistátního navazujícího řízení a závazné
stanovisko podle odstavce 7 přiloží k žádosti o zahájení mezistátního navazujícího
řízení.“.
20.
V § 9a odst. 7 větě první se za slovo „ověří“ vkládají slova „na základě dokumentů
předaných podle odstavce 6 a v případě navazujícího řízení, které není mezistátním
navazujícím řízením, i“, ve větě šesté se slova „jednotného environmentálního
stanoviska, je součástí souhlasného závazného stanoviska příslušného úřadu rovněž
změna podle § 8 zákona o jednotném environmentálním stanovisku“ nahrazují slovy
„správního úkonu podle jiného právního předpisu, které stanovisko nahrazuje podle
odstavce 1, nahrazuje souhlasné závazné stanovisko příslušného úřadu rovněž změnu
tohoto správního úkonu“ a věta poslední se zrušuje.
21.
§ 9f včetně nadpisu zní:
„§ 9f
Mezistátní navazující řízení
(1) Pokud je předmětem navazujícího řízení záměr podléhající mezistátnímu posouzení
podle § 13, popřípadě jeho část nebo etapa, správní orgán příslušný k vedení navazujícího řízení
spolu s oznámením o zahájení řízení informuje dotčený stát o možnosti jeho veřejnosti, dotčené
veřejnosti a dotčených územních samosprávných celků uplatnit v tomto navazujícím řízení
práva uvedená v § 9c odst. 1 až 3; právo podle § 9c odst. 1 náleží také dotčeným orgánům
dotčeného státu. Správní orgán příslušný k vedení navazujícího řízení spolu s oznámením podle
předchozí věty v českém jazyce a v úředním jazyce dotčeného státu zašle dotčenému státu
v českém jazyce a v úředním jazyce dotčeného státu rovněž informace podle § 9b odst. 1,
závazné stanovisko podle § 9a odst. 7 a informaci o způsobu zpřístupnění podkladů podle § 9b
odst. 4 písm. a), a to spolu s výzvou k jejich zveřejnění na území dotčeného státu. Podklady
podle § 9b odst. 4 písm. a) je správní orgán příslušný k vedení navazujícího řízení povinen
zpřístupnit způsobem umožňujícím dálkový přístup. Zároveň správní orgán příslušný k vedení
navazujícího řízení požádá dotčený stát o potvrzení přijetí oznámení a o zaslání vyjádření, zda
mají subjekty a správní orgány zájem o uplatnění práv podle věty první. Neobdrží-li správní
orgán příslušný k vedení navazujícího řízení vyjádření podle předchozí věty ve lhůtě pro
uplatnění práv subjektů a dotčených orgánů dotčeného státu podle odstavce 3, má se za to, že
o uplatnění práv podle § 9c odst. 1 až 3 nemají tyto subjekty a správní orgány dotčeného státu
zájem.
(2) Rozhodnutí, kterým se končí navazující řízení, jehož předmětem je záměr podléhající
mezistátnímu posouzení podle § 13, popřípadě jeho část nebo etapa, se oznamuje i dotčeným
státům. Spolu s oznámením rozhodnutí podle předchozí věty správní orgán příslušný k vedení
navazujícího řízení zašle dotčenému státu informaci o možnosti jeho dotčené veřejnosti uplatnit
práva uvedená v § 9c odst. 4. Rozhodnutí spolu s jeho překladem do úředního jazyka dotčeného
státu a informacemi podle předchozí věty v českém jazyce a v úředním jazyce dotčeného státu
zašle správní orgán příslušný k vedení navazujícího řízení dotčenému státu spolu s výzvou
k jejich zveřejnění na území dotčeného státu.
(3) Lhůty pro uplatnění práv subjektů a správních orgánů dotčeného státu vyplývající
z § 9c odst. 1 až 3 začnou běžet okamžikem zveřejnění informací v § 9b odst. 1 na úřední desce
správního orgánu příslušného k vedení navazujícího řízení. Lhůty pro uplatnění práv subjektů
a správních orgánů dotčeného státu vyplývající z § 9c odst. 4 začnou běžet okamžikem
oznámení rozhodnutí vydaného v navazujícím řízení na úřední desce správního orgánu
příslušného k vedení navazujícího řízení. Lhůty pro uplatnění práv subjektů a správních orgánů
dotčeného státu stanovené v § 9c odst. 1 až 4 či zvláštním právním předpisem nebo správním
orgánem podle § 9c odst. 1 se prodlužují o 20 dní.
(4) Pokud je předmětem navazujícího řízení pouze část nebo etapa záměru podléhajícího
mezistátnímu posuzování podle § 13 a tato část nebo etapa nemůže sama o sobě mít významný
vliv na životní prostředí na území dotčeného státu, odstavce 1 až 3 se nepoužijí. Část nebo etapa
záměru nemůže sama o sobě mít významný vliv na území dotčeného státu v případě, že
nevyvolává ty vlivy záměru, které byly v procesu posuzování vlivů na životní prostředí
vyhodnoceny jako přeshraniční. V případě pochybností žadatele o vydání rozhodnutí
v navazujícím řízení nebo správního orgánu příslušného k vedení navazujícího řízení o tom,
zda může mít část nebo etapa záměru podle věty první významný přeshraniční vliv na životní
prostředí na území dotčeného státu, vydá příslušný úřad vyjádření, a to do 15 dnů ode dne, kdy
mu byla žádost o vyjádření doručena.
(5) Správní orgán příslušný k vedení navazujícího řízení postupuje při úkonech podle
odstavců 1 až 4 ve spolupráci s ministerstvem.“.
22.
V § 10f odst. 4 se za větu třetí vkládá věta „Příslušný úřad jej zveřejní podle § 16.“.
23.
V § 10g odst. 2 se slova „kompenzační opatření“ nahrazují slovy „opatření pro
předcházení, vyloučení, snížení nebo kompenzaci těchto vlivů“.
24.
V § 10h odst. 1 se za slova „orgány a“ vkládá slovo „popřípadě“.
25.
V § 10i odst. 2 se věta poslední nahrazuje větou „Při pořizování změny politiky územního
rozvoje, změny územního rozvojového plánu, změny zásad územního rozvoje a při
pořizování územního plánu a jeho změny stanoví ministerstvo nebo orgán kraje na
základě kritérií uvedených v příloze č. 8 k tomuto zákonu případný požadavek na
zpracování vyhodnocení vlivů na životní prostředí včetně návrhu zpracování možných
variant řešení.“.
26.
V § 11 odst. 3 se text „KÚ“ nahrazuje slovy „Orgán kraje“.
27.
V § 16 odst. 1 se za písmeno k) vkládá nové písmeno l), které zní:
„l) zápis z veřejného projednání návrhu koncepce, bylo-li konáno,“.
Dosavadní písmena l) až n) se označují jako písmena m) až o).
28.
V § 16 odst. 2 se text „m)“ nahrazuje textem „n)“ a slova „a druhé“ se nahrazují slovy
„až třetí“.
29.
V § 21 písm. c) se na konci textu bodu 1 doplňují slova „a jejich změn“.
30.
V § 21 písm. c) bodě 3 se slovo „infrestruktury“ nahrazuje slovem „infrastruktury“ a slova
„Dopravní a energetický stavební úřad“ se nahrazují slovy „Úřad rozvoje území České
republiky“.
31.
V § 21 písmeno k) zní:
„k) vydává stanovisko k posouzení vlivů provádění politiky územního rozvoje nebo její změny,
stanovisko k posouzení vlivů provádění územního rozvojového plánu nebo jeho změny
a stanovisko k posouzení vlivů provádění zásad územního rozvoje nebo jejich změn a je
dotčeným orgánem při jejich pořizování, a“.
32.
V § 22 písm. a) se slova „d) nebo“ nahrazují slovy „f) nebo“.
33.
V § 23 odst. 5 se na konci textu věty první doplňují slova „ ; v případě posuzování záměru
trvá vyhrazení pouze do právní moci rozhodnutí podle § 7 odst. 6 nebo vydání závazného
stanoviska k posouzení vlivů provedení záměru na životní prostředí podle § 9a odst. 1“.
34.
Poznámka pod čarou č. 16, která zní: „16)
§ 94f odst. 1 a § 94v odst. 1 zákona č.
183/2006 Sb., o územním plánování a stavebním řádu (stavební zákon), ve znění
pozdějších předpisů.“, se zrušuje.
35.
V Příloze č. 1 sloupci 2 se na konci textu bodu 1 doplňují slova „s kapacitou od
stanoveného limitu“, v kategorii I, sloupci 4 se text „x“ nahrazuje textem „500 t/den“
a v kategorii II, sloupci 6 se doplňuje text „50 t/den“.
36.
V Příloze č. 1 bodě 6, kategorii II, sloupci 6 se číslo „10“ nahrazuje číslem „20“.
37.
V Příloze č. 1 bodě 7, sloupci 2 se text „(a)“ nahrazuje textem „a)“, text „(b)“ se nahrazuje
textem „b)“, text „(c)“ se nahrazuje textem „c)“ a text „(d)“ se nahrazuje textem „d)“,
v písm. c) se slova „od jiné“ nahrazují slovy „k jiné“ a slova „elektrárny“ se nahrazují
slovem „elektrárně“.
38.
V Příloze č. 1 bodě 14, sloupci 2 se slova „stanoveného limitu“ nahrazují textem „400 m“
a v kategorii II, sloupci 6 se text „200 m“ nahrazuje textem „x“.
39.
V Příloze č. 1 bodě 17, kategorii II, sloupci 6 se text „x“ nahrazuje textem „2,5 t/hod.“.
40.
V Příloze č. 1 bod 18 zní: „
18
Zařízení na zpracování železných kovů: slévárny železných
kovů o výrobní kapacitě od stanoveného limitu (a), válcovny
za tepla s kapacitou zpracované surové oceli od stanoveného
limitu (b), kovárny s buchary o energii od 50 kJ na jeden
buchar, kde je tepelný výkon od stanoveného limitu (c) a
zařízení k nanášení ochranných povlaků z roztavených kovů se
zpracovávaným množstvím surové oceli od stanovaného
limitu (d).

a) 20
t/den
b) 20
t/hod.
c) 20
MW
d) 2
t/hod.
.“.
41.
V Příloze č. 1 sloupci 2 se na konci textu bodu 20 doplňují slova „o kapacitě tavení od
stanoveného limitu u olova a kadmia (a) a kapacitě tavení od stanoveného limitu u všech
ostatních kovů (b)“ a v kategorii II, sloupci 6 se text „x“ nahrazuje textem „a) 4 t/den
b) 20 t/den“.
42.
V Příloze č. 1 bodě 22, kategorii II, sloupci 6 se číslo „15“ nahrazuje číslem „30“.
43.
V Příloze č. 1 bodě 23, kategorii II, sloupci 6 se číslo „75“ nahrazuje číslem „150“ a číslo
„100“ se nahrazuje číslem „200“.
44.
V Příloze č. 1 bod 34 zní: „
34
Výroba chemických látek a směsí a zpracování meziproduktů
(například pesticidy a farmaceutické produkty, nátěrové hmoty
a peroxidy) od stanoveného limitu (a); výroba vodíku
elektrolýzou vody o celkovém instalovaném výkonu
elektrolyzérů od stanoveného limitu (b); výroba vodíku
rozkladem zemního plynu, bioplynu nebo biometanu
pyrolýzou nebo plazmalýzou o celkovém instalovaném
výkonu
pyrolýzních
jednotek
nebo
plazmalyzérů
od
stanoveného limitu (c).

(a) 400
t/rok
(b) 40
MW
(c) 5
MW
.“.
45.
V Příloze č. 1 bodě 36, kategorii II, sloupci 6 se text „x“ nahrazuje textem „100 t/rok“.
46.
V Příloze č. 1 bodě 42, kategorii II, sloupci 6 se číslo „1“ nahrazuje číslem „1,5“.
47.
V Příloze č. 1 bodě 45, kategorii II, sloupci 6, písm. a) a b) se čísla „2“ nahrazují čísly
„5“.
48.
V Příloze č. 1 bodě 46, kategorii II, sloupci 6 se číslo „1“ nahrazuje číslem „5“.
49.
V Příloze č. 1 bodě 48, kategorii II, sloupci 6 se číslo „2“ nahrazuje číslem „3“.
50.
V Příloze č. 1 bodě 49, sloupci 2 se slova „stanovené délky (a); ostatní pozemní
komunikace od stanovené délky (a) a od stanovené návrhové intenzity dopravy
předpokládané pro novostavby a ročního průměru denních intenzit pro stávající stavby
(b)“ nahrazují slovy „stanoveného limitu“ a v kategorii II, sloupci 6 se text „a) 2 km b)
1000 voz/24 hod“ nahrazuje textem „3 km“.
51.
V Příloze č. 1 bodě 51, kategorii II, sloupci 6 se číslo „200“ nahrazuje číslem „400“.
52.
V Příloze č. 1 bodě 55, kategorii II, sloupci 6 se číslo „250“ nahrazuje textem „1 tis.“.
53.
V Příloze č. 1 bodě 56, kategorii II, sloupci 6 se číslo „2500“ nahrazuje textem „10 tis.“.
54.
V Příloze č. 1 bodě 62, kategorii II, sloupci 6, písm. a) se číslo „5“ nahrazuje číslem „10“.
55.
V Příloze č. 1 bodě 63, kategorii II, sloupci 6 se číslo „10“ nahrazuje číslem „15“.
56.
V Příloze č. 1 bodě 65, kategorii II, sloupci 6 se text „100 tis.“ nahrazuje textem „1 mil.“.
57.
V Příloze č. 1 bodě 67, kategorii II, sloupci 6 se číslo „8“ nahrazuje číslem „20“.
58.
V Příloze č. 1 bodě 69, kategorii II, sloupci 6 se číslo „50“ nahrazuje číslem „120“.
59.
V Příloze č. 1 bodě 72, kategorii II, sloupci 6 se číslo „10“ nahrazuje číslem „20“.
60.
V Příloze č. 1 bodě 76, kategorii II, sloupci 6 se číslo „200“ nahrazuje číslem „300“.
61.
V Příloze č. 1 bodě 79 sloupci 2 se slova „Stanovení dobývacího prostoru a v něm
navržená povrchová“ nahrazují slovem „Povrchová“, v kategorii II, sloupci 6, písm. a) se
číslo „5“ nahrazuje číslem „10“ a v písm. b) se číslo „10“ nahrazuje číslem „50“.
62.
V Příloze č. 1 bodě 80 sloupci 2 se slova „Stanovení dobývacího prostoru a v něm
navržená těžba uranu, těžba“ nahrazují slovem „Těžba“.
63.
V Příloze č. 1 bodě 81 sloupci 2 se slova „Stanovení dobývacího prostoru a v něm
navržená hlubinná těžba, hlubinná“ nahrazují slovem „Hlubinná“.
64.
V Příloze č. 1 bodě 85 sloupci 2 se za slovo „Nadzemní“ vkládá slovo „přenosové“
a v kategorii II, sloupci 6 se číslo „2“ nahrazuje číslem „10“.
65.
V Příloze č. 1 bodě 86, kategorii II, sloupci 6 se číslo „200“ nahrazuje textem „1 tis.“.
66.
V Příloze č. 1 bodě 87, kategorii II, sloupci 6 se číslo „10“ nahrazuje číslem „20“.
67.
V Příloze č. 1 bodě 88, kategorii II, sloupci 6 se číslo „10“ nahrazuje číslem „20“.
68.
V Příloze č. 1 bodě 93, kategorii II, sloupci 6 se číslo „10“ nahrazuje číslem „50“.
69.
V Příloze č. 1 bodě 94, kategorii II, sloupci 6 se číslo „10“ nahrazuje číslem „50“.
70.
V Příloze č. 1 bodě 95, kategorii II, sloupci 6, písm. a) se číslo „25“ nahrazuje číslem
„50“ a v písm. b) se číslo „10“ nahrazuje číslem „20“.
71.
V Příloze č. 1 bodě 96, kategorii II, sloupci 6 se číslo „10“ nahrazuje číslem „20“.
72.
V Příloze č. 1 sloupci 2 se v bodě 97 za slovo „rostlinných“ vkládají slova „olejů nebo
tuků s kapacitou od stanoveného limitu (a)“, na konec textu bodu 97 se vkládá text „(b)“
a v kategorii II, sloupci 6 se text „20 tis. t/rok“ nahrazuje textem „a) 50 tis. t/rok b) 25 tis.
t/rok“.
73.
V Příloze č. 1 bodě 99, kategorii II, sloupci 6 se číslo „200“ nahrazuje číslem „400“.
74.
V Příloze č. 1 bodě 100, sloupci 2 se text „a lihovary nebo pálenice s kapacitou od
stanoveného limitu (c)“ zrušuje a v kategorii II, sloupci 6 se písm. c) zrušuje.
75.
V Příloze č. 1 bod 101 zní: „
101 Lihovary nebo pálenice s kapacitou od stanoveného limitu.

100 tis.
hl/rok
.“.
76.
V Příloze č. 1 bodě 102, kategorii II, sloupci 6 se číslo „10“ nahrazuje číslem „20“.
77.
V Příloze č. 1 bodě 106, kategorii II, sloupci 6 se číslo „10“ nahrazuje číslem „15“.
78.
V Příloze č. 1 bodě 107, kategorii II, sloupci 6 se číslo „20“ nahrazuje číslem „30“.
79.
V Příloze č. 1 bodě 108, kategorii II, sloupci 6 se číslo „5“ nahrazuje číslem „10“.
80.
V Příloze č. 1 bodě 109, kategorii II, sloupci 6 se číslo „500“ nahrazuje číslem „800“.
81.
V Příloze č. 1 bodě 110, kategorii II, sloupci 6 se číslo „6“ nahrazuje číslem „15“.
82.
V Příloze č. 1 bodě 113, kategorii II, sloupci 6 se číslo „1“ nahrazuje číslem „2“.
83.
V Příloze č. 1 sloupci 2 se na konci textu bodu 114 doplňují slova „od stanovené plochy
(a) nebo od stanovené kapacity (b)“ a v kategorii II, sloupci 6 se text „x“ nahrazuje textem
„a) 2 ha b) 1 000 osob/hod.“.
84.
V Příloze č. 1 bodě 115, kategorii II, sloupci 6, písm. a) se číslo „1“ nahrazuje číslem „2“
a v písm. b) se číslo „25“ nahrazuje číslem „50“.
85.
V Příloze č. 1 bodě 116, kategorii II, sloupci 6, písm. a) se číslo „1“ nahrazuje číslem „2“
a v písm. b) se číslo „100“ nahrazuje číslem „200“.
86.
V Příloze č. 1 bodě 117, kategorii II, sloupci 6 se číslo „100“ nahrazuje číslem „200“.
87.
V Příloze č. 1 bodě 118, kategorii II, sloupci 6 se číslo „2“ nahrazuje číslem „4“.
88.
V příloze č. 6 hlavě I se doplňuje bod 10, který zní:
„10. Informace o tom, zda jde o záměr vyžadující souhlas orgánu ochrany přírody k zásahu
do významného krajinného prvku24) nebo ke snížení nebo změně krajinného rázu25), a je-li tomu
tak, informace o tom, že stanovisko tyto souhlasy nahrazuje“.
89.
V příloze č. 6 hlavě II se na konci bodu 1 doplňují slova „ , a to v potřebném rozsahu také
ve vztahu k správním úkonům stanoveným jinými právními předpisy, které stanovisko
nahrazuje“.
Čl. XLVI
Přechodná ustanovení
1. Posuzování vlivů záměrů nebo koncepcí zahájené a neskončené přede dnem nabytí
účinnosti tohoto zákona se dokončí podle zákona č. 100/2001 Sb., ve znění účinném ode dne
nabytí účinnosti tohoto zákona, není-li stanoveno jinak.
2. Ustanovení § 1 odst. 4, § 7 odst. 1 písm. d) a § 9a odst. 1 věty poslední zákona
č. 100/2001 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona, se použijí až pro
posuzování vlivů zahájené ode dne nabytí účinnosti tohoto zákona.
3. Pokud oznamovatel přede dnem nabytí účinnosti tohoto zákona požádal o vydání
jednotného environmentálního stanoviska současně se závazným stanoviskem podle § 9a,
použijí se při posuzování vlivů záměru § 1 odst. 4, § 3 písm. e), § 6 odst. 6, § 7 odst. 1 písm.
d), § 7 odst. 5 věta poslední, § 7 odst. 6 věta třetí, § 8 odst. 1 věta třetí, § 8 odst. 3 věta poslední
a § 9a odst. 1 věta třetí zákona č. 100/2001 Sb., ve znění účinném přede dnem nabytí účinnosti
tohoto zákona.
4. Posouzení vlivů záměrů a zajišťovací řízení zahájená přede dnem nabytí účinnosti tohoto
zákona, která se týkají záměrů, u nichž podle zákona č. 100/2001 Sb., ve znění účinném ode
dne nabytí účinnosti tohoto zákona, není vyžadováno posouzení jejich vlivů nebo provedení
zajišťovacího řízení, příslušný úřad ukončí.
5. Platnost stanoviska k posouzení vlivů provedení záměru na životní prostředí podle § 10
zákona č. 100/2001 Sb., ve znění účinném do 31. března 2015, nebo závazného stanoviska k
posouzení vlivů provedení záměru na životní prostředí podle § 9a zákona č. 100/2001 Sb., ve
znění účinném od 1. dubna 2015 do dne nabytí účinnosti tohoto zákona, vydaného pro záměry
na území hlavního města Prahy, a to konkrétně Městského okruhu, Libeňské spojky a Radlické
radiály přede dnem nabytí účinnosti tohoto zákona lze prodloužit opakovaně.
6. Platnost závazného stanoviska k posouzení vlivů provedení záměru na životní prostředí
podle zákona č. 100/2001 Sb., ve znění účinném přede dnem nabytí účinnosti tohoto zákona,
které je platné ke dni nabytí účinnosti tohoto zákona a jehož platnost nebyla do dne nabytí
účinnosti tohoto zákona prodloužena, je 10 let.
7. U závazného stanoviska k posouzení vlivů provedení záměru na životní prostředí podle
§ 9a zákona č. 100/2001 Sb., ve znění účinném od 1. dubna 2015, nebo u stanoviska k posouzení
vlivů provedení záměru na životní prostředí podle § 10 zákona č. 100/2001 Sb., ve znění
účinném do 31. března 2015, u kterého již přede dnem nabytí účinnosti tohoto zákona došlo
k prodloužení jeho platnosti, platí, že nejnovějším prodloužením platnosti došlo k jejímu
prodloužení o 7 let.
8. Postupy zahájené přede dnem nabytí účinnosti tohoto zákona na základě žádosti o
prodloužení platnosti závazného stanoviska k posouzení vlivů provedení záměru na životní
prostředí podle § 9a zákona č. 100/2001 Sb., ve znění účinném od 1. dubna 2015, nebo
stanoviska k posouzení vlivů provedení záměru na životní prostředí podle § 10 zákona č.
100/2001 Sb., ve znění účinném do 31. března 2015, příslušný úřad ukončí, pokud platnost
stanoviska, kterého se žádost týká, určená podle zákona č. 100/2001 Sb., ve znění účinném ode
dne nabytí účinnosti tohoto zákona, neuplyne dříve než 12 měsíců ode dne nabytí účinnosti
tohoto zákona. Ustanovení § 9a odst. 4 věty čtvrté zákona č. 100/2001 Sb., ve znění účinném
přede dnem nabytí účinnosti tohoto zákona tím není dotčeno.
ČÁST TŘICÁTÁ
Změna vodního zákona
Čl. XLVII
Zákon č. 254/2001 Sb., o vodách a o změně některých zákonů (vodní zákon), ve znění
zákona č. 76/2002 Sb., zákona č. 320/2002 Sb., zákona č. 274/2003 Sb., zákona č. 20/2004 Sb.,
zákona č. 413/2005 Sb., zákona č. 444/2005 Sb., zákona č. 186/2006 Sb., zákona č. 222/2006
Sb., zákona č. 342/2006 Sb., zákona č. 25/2008 Sb., zákona č. 167/2008 Sb., zákona č. 181/2008
Sb., zákona č. 157/2009 Sb., zákona č. 227/2009 Sb., zákona č. 281/2009 Sb., zákona
č. 150/2010 Sb., zákona č. 77/2011 Sb., zákona č. 151/2011 Sb., zákona č. 85/2012 Sb., zákona
č. 350/2012 Sb., zákona č. 501/2012 Sb., zákona č. 275/2013 Sb., zákona č. 303/2013 Sb.,
zákona č. 61/2014 Sb., zákona č. 64/2014 Sb., zákona č. 187/2014 Sb., zákona č. 39/2015 Sb.,
zákona č. 250/2016 Sb., zákona č. 183/2017 Sb., zákona č. 225/2017 Sb., zákona č. 113/2018
Sb., zákona č. 312/2019 Sb., zákona č. 403/2020 Sb., zákona č. 544/2020 Sb., zákona
č. 261/2021 Sb., zákona č. 284/2021 Sb., zákona č. 364/2021 Sb., zákona č. 149/2023 Sb.,
zákona č. 182/2024 Sb., zákona č. 70/2025 Sb. a zákona č. 266/2025 Sb., se mění takto:
1.
V § 5a se slovo „zastavěných“ nahrazuje slovem „zastavitelných“ a slova
„ , zastavitelných plochách a transformačních plochách“ se zrušují.
2.
V § 8 odst. 1 písm. b) se na konci textu bodu 3 doplňují slova „ , s výjimkou jejich čerpání
a řízeného odvádění do kanalizace při provádění stavby“.
3.
V § 8 se na konci odstavce 3 tečka nahrazuje čárkou a doplňují se písmena i) a j), která
znějí:
„i) k vsakování srážkové vody,
j)
k akumulaci srážkové vody a jejímu následnému využití nebo řízenému odvádění do
kanalizace.“.
4.
V § 8 se doplňuje odstavec 5, který zní:
„(5) O nakládání s vodami se nejedná, je-li srážková voda nebo odpadní voda odváděna do
kanalizace k tomu určené.“.
5.
V § 9 odstavec 10 včetně poznámky pod čarou č. 71 zní:
„(10) U vodních děl určených pro čištění odpadních vod do kapacity 50 ekvivalentních
obyvatel, jejichž podstatnou součástí jsou výrobky označované CE podle jiného právního
předpisu71), se nakládání s vodami podle § 8 odst. 1 písm. c) považuje za povolené dnem právní
moci povolení záměru tohoto vodního díla podle stavebního zákona; ustanovení odstavce 2 se
nepoužije, ustanovení § 38 odst. 8 se použije obdobně.
_____________
71)
Zákon č. 22/1997 Sb., o technických požadavcích na výrobky a o změně a doplnění
některých zákonů, ve znění pozdějších předpisů.“.
6.
V § 9 se doplňuje odstavec 11, který zní:
„(11) Žádost o povolení záměru podle stavebního zákona, jejímž předmětem je vodní dílo
podle odstavce 10, obsahuje vedle náležitostí požadovaných stavebním zákonem také
náležitosti vyžadované v § 9a odst. 2 písm. e) nebo h).“.
7.
V § 13 písm. b) se slovo „vodoprávní“ nahrazuje slovem „stavební“.
8.
V § 17 odst. 4 se slova „stavebního zákona a podle“ zrušují a na konci odstavce se
doplňuje věta „Pokud jsou záměry uvedené v odstavci 1 povolovány podle stavebního
zákona, je souhlas vydáván jako vyjádření, které je podkladem pro rozhodnutí o záměru
podle stavebního zákona.“.
9.
V § 17 odstavec 7 zní:
„(7) Jedná-li se o záměr povolovaný podle stavebního zákona a dojde-li vodoprávní úřad
k závěru, že provedení záměru může vést ke zhoršení stavu nebo ekologického potenciálu
útvaru povrchové vody nebo ke zhoršení stavu útvaru podzemní vody nebo znemožnění
dosažení dobrého stavu nebo dobrého ekologického potenciálu útvaru povrchové vody nebo
dobrého stavu útvaru podzemní vody, uvede ve vyjádření podle odstavce 4 věty druhé, že bez
výjimky podle § 23a odst. 8 není možné záměr povolit ani provést.“.
Poznámka pod čarou č. 65 se zrušuje.
10.
V § 19 odst. 1 se slova „ , souhlasů a jim podaných ohlášení, k nimž daly souhlas“
nahrazují slovy „a vyjádření“.
11.
V § 19 odst. 3 se za slovo „stanoviska“ vkládají slova „a vyjádření“.
12.
V § 19 odst. 4 se slovo „vodoprávních“ nahrazuje slovy „a vyjádření správních“.
13.
V § 20 odst. 3 se slovo „Vodoprávní“ nahrazuje slovem „Správní“ a za slovo „rozhodnutí“
se vkládají slova „nebo účinnosti opatření obecné povahy“.
14.
V § 23b se odstavec 2 zrušuje a zároveň se zrušuje označení odstavce 1.
15.
V § 38 se doplňuje odstavec 15, který zní:
„(15) Na toho, kdo zneškodňuje odpadní vody prostřednictvím vodního díla určeného pro
čištění odpadních vod do kapacity 50 ekvivalentních obyvatel, jehož podstatnou součástí je
výrobek označovaný CE, se nevztahuje povinnost podle odstavce 6. Výčet a klasifikaci výrobků
označovaných CE včetně minimální účinnosti čištění pro kategorie výrobků označovaných CE
v procentech stanoví vláda nařízením.“.
16.
V § 38a se na konci odstavce 1 doplňuje věta „Věta první dále neplatí, pokud jsou odpadní
vody vypouštěny ze zařízení, ve kterém probíhá průmyslová činnost podle přílohy č. 1
k zákonu o integrované prevenci a jeho provozovatel
a) disponuje záchytnou nádrží o dostatečné kapacitě, která v případě vzniku havárie nebo jiné
nestandardní provozní situace umožní zachytit objem vyprodukovaných odpadních vod po
dobu až 6 hodin, nebo
b) má zajištěna technická a organizační opatření, která umožňují indikaci vzniku havárie;
dostatečnost těchto opatření posoudí vodoprávní úřad v řízení o povolení k vypouštění
odpadních vod.“.
17.
V § 38a odst. 2 větě první se za slova „těchto technologií“ vkládají slova „a k době
nezbytné pro jejich realizaci“.
18.
V § 38a se za odstavec 4 vkládá nový odstavec 5, který zní:
„(5) Má-li vodoprávní úřad nebo Česká inspekce životního prostředí informace o
skutečnostech nasvědčujících možnému vzniku havárie, je znečišťovatel povinen na jejich
vyžádání zpřístupnit výsledky kontinuálního sledování. Výsledky kontinuálního sledování se
nezpřístupňují podle zákona o právu na informace o životním prostředí ani neposkytují podle
zákona o svobodném přístupu k informacím.“.
Dosavadní odstavec 5 se označuje jako odstavec 6.
19.
V § 38a odst. 6 se slova „a náležitosti technických prostředků pro jeho provádění“
nahrazují slovy „ , způsob a rozsah uchovávání výsledků kontinuálního sledování,
náležitosti technických prostředků pro jeho provádění a kritéria pro posouzení
dostatečnosti opatření podle odstavce 1 písm. b)“.
20.
V § 39 odst. 2 písm. a) se za slova „vloží havarijní plán“ doplňují slova „ , s výjimkou
údajů o objektech důležitých pro obranu státu,“.
21.
V § 47 odst. 4 písm. c), § 55 odst. 4, § 59 odst. 1 písm. d), § 59 odst. 4 větě první a § 62
odst. 5 písm. b) se slovo „vodoprávní“ nahrazuje slovem „stavební“.
22.
V § 49 odst. 1 písm. c) se za slovo „úřadu“ vkládají slova „nebo stavebního úřadu“.
23.
V § 50 písm. g) a § 51 odst. 1 písm. c) se slovo „zastavěném“ nahrazuje slovem
„zastavitelném“.
24.
V § 54 odst. 4 se za text „odst. 3“ vkládají slova „ , vyjádření podle § 104 odst. 4“.
25.
V § 55c odst. 1 se slova „zastavěné území nebo zastavitelnou plochu“ nahrazují slovy
„zastavitelné území“.
26.
V § 56 odst. 4 písm. c) a § 62 odst. 5 písm. a) a c) až e) se slovo „vodoprávnímu“ nahrazuje
slovem „stavebnímu“.
27.
V § 56 odst. 5, § 59a odst. 3 větě první a druhé a § 62 odst. 1 větě druhé se slovo
„Vodoprávní“ nahrazuje slovem „Stavební“.
28.
V § 59 odst. 1 písm. g) se slovo „vodočet,“ nahrazuje slovy „vodočet nebo“ a slova „nebo
zajistit zvláštní úpravu přelivu nebo výpusti“ se zrušují.
29.
V § 59 se na konci odstavce 1 tečka nahrazuje čárkou a doplňují se písmena k) a l), která
znějí:
„k) zajistit zvláštní úpravu přelivu nebo výpusti podle rozhodnutí stavebního úřadu,
l)
provést poprvé nejpozději do 6 měsíců od zprovoznění vodního díla určeného pro čištění
odpadních vod do kapacity 50 ekvivalentních obyvatel, jehož podstatnou součástí je
výrobek označovaný CE, a pak jedenkrát za dva roky prostřednictvím osoby odborně
způsobilé, pověřené Ministerstvem životního prostředí, technické revize tohoto vodního
díla a výsledky těchto revizí předávat do 30 pracovních dnů od provedení revize
vodoprávnímu úřadu; vlastník vodního díla je povinen odstranit zjištěné závady ve lhůtě
do 60 dnů od provedení revize.“.
30.
V § 59 se doplňuje odstavec 8, který zní:
„(8) Pověření k provádění technické revize vodního díla určeného pro čištění odpadních
vod do kapacity 50 ekvivalentních obyvatel, jehož podstatnou součástí je výrobek označovaný
CE, lze udělit osobě, která má dostatečnou odbornou úroveň, technické, administrativní
a organizační zázemí a splňuje předpoklady pro kvalifikované provedení revize.“.
31.
V § 59a odst. 2 a § 59a odst. 3 větě poslední se slovo „vodoprávního“ nahrazuje slovem
„stavebního“.
32.
V § 66 odst. 2 se slova „zastavěných územích, v zastavitelných plochách podle územně
plánovací dokumentace“ nahrazují slovy „zastavitelných územích“.
33.
V § 67 odst. 1 se slova „a technické infrastruktury“ nahrazují slovy „ , technické a zelené
infrastruktury, stavebních úprav veřejných prostranství a dále drobných a jednoduchých
staveb pro volnočasové aktivity, pokud nebudou oploceny a které lze v případě
povodňového nebezpečí neprodleně odstranit“ a na konci odstavce se doplňují věty
„Omezení podle věty první se nevztahuje na mobiliář, který není stavbou podle
stavebního zákona. V aktivní zóně záplavových území lze zřizovat drobné a jednoduché
stavby pro volnočasové aktivity na veřejných prostranstvích, pokud nemohou zhoršit
průběh povodně a nebudou oploceny nebo pokud je lze v případě povodňového nebezpečí
neprodleně odstranit. Odstranění staveb podle věty druhé nepodléhá povolení stavebního
úřadu a zajistí je jejich vlastník, případně obec k výzvě vodoprávního úřadu v řízení na
místě.“.
34.
V § 67 se doplňuje odstavec 4, který zní:
„(4) V aktivní zóně záplavového území lze povolit stavbu nebo nestavební záměr, pokud
pozemek, na němž se taková stavba nebo nestavební záměr umisťuje, bude chráněn v důsledku
povolené ucelené části trvalých či mobilních protipovodňových opatření; práva a povinnosti
vyplývající z povolení stavby nebo nestavebního záměru lze vykonávat ode dne dokončení
stavby protipovodňové ochrany, nejpozději však do 5 let ode dne nabytí právní moci tohoto
povolení. Pro záměry v záplavovém území mimo aktivní zónu se použije věta první obdobně.“.
35.
V § 68 odst. 1 se text „§ 55a“ nahrazuje slovy „zákona o vyvlastnění“.
36.
V § 104 odst. 1 se za slovo „úřady“ vkládají slova „ , stavební úřady“.
37.
V § 104 odst. 2 se písmeno e) zrušuje.
Dosavadní písmeno f) se označuje jako písmeno e).
38.
V § 104 odst. 3 se slova „a při povolování záměru podle stavebního zákona“ zrušují.
39.
V § 104 odstavec 4 zní:
„(4) Jedná-li se o záměr vyžadující povolení podle stavebního zákona, kterým při jeho
provádění nebo po jeho dokončení mohou být dotčeny zájmy podle tohoto zákona, vodoprávní
úřad vydá vyjádření, které je podkladem pro rozhodnutí o záměru podle stavebního zákona.
Dojde-li vodoprávní úřad k závěru, že provedení záměru může vést ke zhoršení stavu nebo
ekologického potenciálu útvaru povrchové vody nebo ke zhoršení stavu útvaru podzemní vody
nebo znemožnění dosažení dobrého stavu nebo dobrého ekologického potenciálu útvaru
povrchové vody nebo dobrého stavu útvaru podzemní vody, uvede ve vyjádření podle věty
první, že bez výjimky podle § 23a odst. 8 není možné záměr povolit ani provést.“.
40.
V § 104 se doplňuje odstavec 5, který zní:
„(5) Při rozhodování podle stavebního zákona o záměrech staveb pro energetickou
bezpečnost podle § 1 odst. 5 písm. a) nebo b) zákona o urychlení výstavby strategicky
významné infrastruktury a záměru staveb podle bodu 3 písm. a) přílohy č. 1 k zákonu o
urychlení výstavby strategicky významné infrastruktury, které vyžadují povolení podle § 8
nebo § 16 nebo rozhodnutí o výjimce podle § 23a odst. 8, lze vydat rozhodnutí nebo učinit jiný
úkon podle stavebního zákona jen na základě závazného stanoviska vodoprávního úřadu,
kterým jsou stanoveny podmínky a limity pro povolení podle § 8, 16 nebo rozhodnutí o výjimce
podle § 23a odst. 8.“.
41.
V § 107 odst. 1 písm. c) se slova „§ 17 a“ nahrazují textem „§ 17,“, za číslo „3“ se vkládají
slova „a vyjádření podle § 104 odst. 4“ a slova „nebo závazné stanovisko“ se nahrazují
slovy „ , závazné stanovisko nebo vyjádření“.
42.
V § 107 se na konci odstavce 1 tečka nahrazuje čárkou a doplňují se písmena v) a w),
která znějí:
„v) ve věcech staveb pro energetickou bezpečnost podle § 1 odst. 5 písm. a) nebo b) zákona
o urychlení výstavby strategicky významné infrastruktury a záměru staveb podle bodu 3
písm. a) přílohy č. 1 k zákonu o urychlení výstavby strategicky významné infrastruktury
vydávat souhlas podle § 17, vyjádření podle § 104 odst. 4 a závazné stanovisko podle § 104
odst. 5,
w) pro stavby pro energetickou bezpečnost podle § 1 odst. 5 písm. a) nebo b) zákona
o urychlení výstavby strategicky významné infrastruktury a záměr staveb podle bodu 3
písm. a) přílohy č. 1 k zákonu o urychlení výstavby strategicky významné infrastruktury
vydávat povolení podle § 8 nebo 16 nebo rozhodnutí o výjimce podle § 23a odst. 8, pokud
se o nich nerozhoduje v rámci rozhodnutí o záměru podle stavebního zákona.“.
43.
V § 107 odst. 2 se za číslo „3“ vkládají slova „a 4“ a za slovo „stanovisko“ se vkládají
slova „nebo vyjádření podle § 104 odst. 4“.
44.
§ 107a včetně nadpisu zní:
„§ 107a
Stavební úřady
Stavební úřady vykonávají působnost ve věcech vodních děl v rozsahu stanoveném tímto
zákonem.“.
45.
V § 108 odst. 2 se slova „krajský úřad jako úřad územního plánování nebo Ministerstvo
pro místní rozvoj“ nahrazují slovy „kraj nebo Úřad rozvoje území České republiky“.
46.
V § 115 se odstavec 1 zrušuje.
Dosavadní odstavce 2 až 20 se označují jako odstavce 1 až 19.
47.
V § 115 odst. 5 se slova „osoba podle odstavce 6“ nahrazují slovy „osoba podle odstavce
4“.
48.
V § 115 odst. 13 se slova „4 a 7“ nahrazují slovy „2 a 5“.
49.
V § 115 odst. 17 se slovo „nebo“ nahrazuje čárkou a za číslo „3“ se vkládají slova „nebo
vyjádření podle § 104 odst. 4“.
50.
V § 115 se odstavec 19 zrušuje.
51.
V § 115b odst. 2 úvodní části ustanovení se slova „povahy a“ nahrazují slovem „povahy,“
za slovo „stanoviska“ se vkládají slova „a ve vyjádření“ a za text „odst. 3“ se vkládají
slova „a 4“.
52.
V § 119 odst. 4 písm. e) se slova „nebo nezajistí zvláštní úpravu přelivu nebo výpusti“
zrušují.
53.
V § 119 odst. 4 se na konci písmene g) slovo „nebo“ zrušuje.
54.
V § 119 odst. 4 se na konci písmene h) tečka nahrazuje čárkou a doplňují se písmena i)
a j), která znějí:
„i) nezajistí zvláštní úpravu přelivu nebo výpusti podle § 59 odst. 1 písm. k) nebo
j)
neprovede technickou revizi vodního díla, nepředá výsledky revize vodoprávnímu úřadu
nebo neodstraní zjištěné závady podle § 59 odst. 1 písm. l).“.
55.
V § 119 odst. 7 se na konci textu písmene a) doplňuje text „ , j)“.
56.
V § 125c odst. 1 se na konci písmene c) slovo „nebo“ zrušuje, na konci písmene d) se
tečka nahrazuje slovem „ , nebo“ a doplňuje se písmeno e), které zní:
„e) nezpřístupní výsledky kontinuálního sledování vodoprávnímu úřadu nebo České inspekci
životního prostředí podle § 38a odst. 5.“.
57.
V § 125c odst. 5 se na konci textu písmene c) doplňují slova „nebo e)“.
58.
V § 125d odst. 5 písm. e) se slova „nebo nezajistí zvláštní úpravu přelivu nebo výpusti“
zrušují.
59.
V § 125d odst. 5 se na konci písmene h) slovo „nebo“ zrušuje.
60.
V § 125d se na konci odstavce 5 tečka nahrazuje čárkou a doplňují se písmena j) a k),
která znějí:
„j) nezajistí zvláštní úpravu přelivu nebo výpusti podle § 59 odst. 1 písm. k) nebo
k) neprovede technickou revizi vodního díla, nepředá výsledky revize vodoprávnímu úřadu
nebo neodstraní zjištěné závady podle § 59 odst. 1 písm. l).“.
61.
V § 125d odst. 8 se na konci textu písmene a) doplňuje text „ , k)“.
62.
V § 125d odst. 8 písm. b) se slova „nebo i)“ nahrazují slovy „až j)“.
63.
V § 125l odst. 4 se za větu první vkládá věta „Stavební úřad projednává přestupky podle
§ 119 odst. 1 až 3, § 119 odst. 4 písm. a) a i), § 119 odst. 5, § 125d odst. 1 až 4, § 125d
odst. 5 písm. a) a j) a § 125d odst. 6.“.
64.
V § 125l odst. 5 se za slovo „děl“ vkládají slova „ , které nejsou uvedené v odstavci 4,“.
65.
Za §126b se vkládá nový § 126c, který zní:
„§ 126c
(1) Ustanovení § 38a se do dne 1. července 2027 nepoužije.
(2) Ustanovení § 125c odst. 1 písm. d) a e) a § 125c odst. 5 písm. c) v části týkající se
přestupku podle § 125c odst. 1 písm. e), jakož i § 125c odst. 5 písm. d) a f) se do dne 1. července
2027 nepoužijí.“.
Čl. XLVIII
Přechodná ustanovení
1. Řízení a postupy zahájené a neskončené přede dnem nabytí účinnosti tohoto zákona se
dokončí podle zákona č. 254/2001 Sb., ve znění účinném ode dne nabytí účinnosti tohoto
zákona, není-li stanoveno jinak.
2. Řízení a postupy zahájené a neskončené do dne vzniku Úřadu rozvoje území České
republiky (dále jen „Úřad“), k nimž je příslušný Úřad nebo jiný stavební úřad, převezme a
dokončí ode dne svého vzniku Úřad nebo jiný stavební úřad.
3. Řízení a postupy zahájené a neskončené do dne vzniku úřadů rozvoje území krajů, k
nimž je příslušný úřad rozvoje území kraje nebo jeho územní pracoviště, ode dne vzniku úřadů
rozvoje území krajů převezme a dokončí příslušný úřad rozvoje území kraje nebo jeho příslušné
územní pracoviště. Do dne vzniku úřadů rozvoje území krajů pokračují v těchto řízeních a
postupech správní orgány příslušné podle dosavadních právních předpisů, a to podle zákona č.
254/2001 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona, s výjimkou § 125l
odst. 4 a 5, a dále podle § 125l odst. 4 a 5 zákona č. 254/2001 Sb., ve znění účinném přede
dnem nabytí účinnosti tohoto zákona.
4. Řízení a postupy zahájené přede dnem nabytí účinnosti tohoto zákona, které se týkají
způsobů nakládání s vodami, u nichž není vyžadováno povolení, vodoprávní úřad usnesením
zastaví; proti tomuto usnesení se nelze odvolat.
5. Vodoprávní řízení ve věcech uvedených v § 104 odst. 5 zákona č. 254/2001 Sb., ve znění
účinném ode dne 1. ledna 2027, zahájená a neskončená přede dnem 1. ledna 2027, se dokončí
podle dosavadních právních předpisů.
ČÁST TŘICÁTÁ PRVNÍ
Změna zákona o pohřebnictví
Čl. XLIX
Zákon č. 256/2001 Sb., o pohřebnictví a o změně některých zákonů, ve znění zákona
č. 479/2001 Sb., zákona č. 320/2002 Sb., zákona č. 274/2003 Sb., zákona č. 122/2004 Sb.,
zákona č. 67/2006 Sb., zákona č. 41/2009 Sb., zákona č. 227/2009 Sb., zákona č. 375/2011 Sb.,
zákona č. 202/2015 Sb., zákona č. 193/2017 Sb., zákona č. 609/2020 Sb., zákona č. 261/2021
Sb., zákona č. 284/2021 Sb., zákona č. 149/2023 Sb. a zákona č. 218/2025 Sb., se mění takto:
1.
V § 12 se věta druhá nahrazuje větou „Splnění podmínek z hlediska ochrany veřejného
zdraví posuzuje stavební úřad v řízení o záměru podle stavebního zákona.“.
2.
V § 17 odst. 1 větě druhé se za slovo „pohřebiště“ vkládají slova „z hlediska ochrany
veřejného zdraví, z hlediska ochrany podzemních vod,“ a za slova „dokumentací a“ se
vkládají slova „ , nemá-li obec vydán územní plán, také“.
3.
V § 17 odstavec 2 zní:
„(2) Vodoprávní úřad vydá k záměru zřízení veřejného pohřebiště vyjádření z hlediska
ochrany podzemních vod.“.
Poznámka pod čarou č. 30 se zrušuje.
Čl. L
Přechodná ustanovení
1. Řízení a postupy zahájené a neskončené přede dnem nabytí účinnosti tohoto zákona se
dokončí podle zákona č. 256/2001 Sb., ve znění účinném ode dne nabytí účinnosti tohoto
zákona, není-li stanoveno jinak.
2. Splnění podmínek z hlediska ochrany veřejného zdraví podle § 12 a 17 zákona
č. 256/2001 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona, posuzují stavební
úřady ode dne vzniku úřadů rozvoje území krajů. Do dne vzniku úřadů rozvoje území krajů
vydávají ke zřízení krematoria a ke zřízení veřejného pohřebiště z hlediska ochrany veřejného
zdraví stanoviska krajské hygienické stanice.
ČÁST TŘICÁTÁ DRUHÁ
Změna zákona o vodovodech a kanalizacích
Čl. LI
Zákon č. 274/2001 Sb., o vodovodech a kanalizacích pro veřejnou potřebu a o změně
některých zákonů (zákon o vodovodech a kanalizacích), ve znění zákona č. 320/2002 Sb.,
zákona č. 274/2003 Sb., zákona č. 20/2004 Sb., zákona č. 167/2004 Sb., zákona č. 127/2005
Sb., zákona č. 76/2006 Sb., zákona č. 186/2006 Sb., zákona č. 222/2006 Sb., zákona č. 281/2009
Sb., zákona č. 275/2013 Sb., zákona č. 39/2015 Sb., zákona č. 250/2016 Sb., zákona č. 183/2017
Sb., zákona č. 193/2017 Sb., zákona č. 225/2017 Sb., zákona č. 403/2020 Sb., zákona
č. 544/2020 Sb., zákona č. 609/2020 Sb., zákona č. 284/2021 Sb., zákona č. 152/2023 Sb.,
zákona č. 167/2023 Sb. a zákona č. 218/2025 Sb., se mění takto:
1.
V § 4 odst. 6 se slova „úřadu územního“ nahrazují slovy „orgánu územního“.
2.
V § 23 se na konci odstavce 3 tečka nahrazuje čárkou a doplňuje se závěrečná část
ustanovení, která zní: „pokud nebylo stanoveno jinak postupem podle stavebního
zákona.“.
3.
V § 40 odst. 2 se slova „Ministerstvo pro místní rozvoj vydá vyhlášku“ nahrazují slovy
„Vláda na návrh Úřadu rozvoje území České republiky vydá prováděcí právní předpis“.
ČÁST TŘICÁTÁ TŘETÍ
Změna zákona o pozemkových úpravách
Čl. LII
Zákon č. 139/2002 Sb., o pozemkových úpravách a pozemkových úřadech a o změně
zákona č. 229/1991 Sb., o úpravě vlastnických vztahů k půdě a jinému zemědělskému majetku,
ve znění pozdějších předpisů, ve znění zákona č. 53/2004 Sb., zákona č. 186/2006 Sb., zákona
č. 124/2008 Sb., zákona č. 227/2009 Sb., zákona č. 503/2012 Sb., zákona č. 280/2013 Sb.,
zákona č. 185/2016 Sb., zákona č. 193/2017 Sb., zákona č. 225/2017 Sb., zákona č. 295/2017
Sb., zákona č. 481/2020 Sb., zákona č. 284/2021 Sb., zákona č. 152/2023 Sb., zákona č. 36/2025
Sb. a zákona č. 287/2025 Sb., se mění takto:
1.
V § 3 odst. 3 větě čtvrté se slova „ , pozemky v zastavěném území, pozemky
v zastavitelných plochách4)“ zrušují.
Poznámka pod čarou č. 4 zní:
„4)
Zákon č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů.“.
2.
V § 9 odst. 17 větě druhé se slovo „zastavěném“ nahrazuje slovem „zastavitelném“
a slova „ , pozemky v zastavitelných plochách“ se zrušují.
3.
V § 12 odstavec 3 zní:
„(3) Změny druhů pozemků a dělení a scelování pozemků nevyžadují povolení záměru
podle stavebního zákona, pokud jsou zahrnuty do schváleného návrhu pozemkových úprav.
Rozhodnutí o schválení návrhu pozemkových úprav se v případě staveb, zařízení, a terénních
úprav a dalších společných zařízení schválených dotčeným orgánem (§ 9 odst. 10) vyžadujících
povolení podle stavebního zákona4) považuje za rozhodnutí v části věci pro účely řízení
o povolení záměru. Schváleným návrhem pozemkových úprav jsou vymezeny pozemky pro
realizaci záměru, umístěna stavba nebo zařízení a stanoveny podmínky pro jeho umístění.“.
4.
V § 14 odst. 8 písm. a) se slovo „zastavěném“ nahrazuje slovem „zastavitelném“ a slova
„nebo v zastavitelných plochách“ se zrušují.
ČÁST TŘICÁTÁ ČTVRTÁ
Změna soudního řádu správního
Čl. LIII
Zákon č. 150/2002 Sb., soudní řád správní, ve znění zákona č. 192/2003 Sb., zákona
č. 22/2004 Sb., zákona č. 237/2004 Sb., zákona č. 436/2004 Sb., zákona č. 555/2004 Sb.,
zákona č. 127/2005 Sb., zákona č. 350/2005 Sb., zákona č. 357/2005 Sb., zákona č. 413/2005
Sb., zákona č. 79/2006 Sb., zákona č. 112/2006 Sb., zákona č. 159/2006 Sb., zákona č. 165/2006
Sb., zákona č. 189/2006 Sb., zákona č. 216/2008 Sb., zákona č. 301/2008 Sb., zákona
č. 314/2008 Sb., zákona č. 7/2009 Sb., zákona č. 320/2009 Sb., zákona č. 118/2010 Sb., nálezu
Ústavního soudu, vyhlášeného pod č. 294/2010 Sb., nálezu Ústavního soudu, vyhlášeného pod
č. 130/2011 Sb., zákona č. 303/2011 Sb., zákona č. 275/2012 Sb., zákona č. 396/2012 Sb.,
zákona č. 250/2014 Sb., zákona č. 87/2015 Sb., zákona č. 375/2015 Sb., zákona č. 298/2016
Sb., zákona č. 322/2016 Sb., zákona č. 183/2017 Sb., zákona č. 222/2017 Sb., zákona
č. 225/2017 Sb., zákona č. 365/2017 Sb., zákona č. 38/2019 Sb., zákona č. 111/2019 Sb.,
zákona č. 176/2019 Sb., zákona č. 77/2021 Sb., zákona č. 218/2021 Sb., zákona č. 284/2021
Sb., zákona č. 152/2023 Sb., zákona č. 173/2023 Sb., zákona č. 349/2023 Sb., zákona č. 89/2024
Sb., zákona č. 268/2024 Sb., zákona č. 448/2024 Sb., zákona č. 77/2025 Sb., zákona č. 152/2025
Sb., zákona č. 269/2025 Sb. a zákona č. 314/2025 Sb., se mění takto:
1.
V § 7 odst. 4 se za slovo „věcech“ vkládají slova „podle části šesté stavebního zákona“
a slova „nebo měl rozhodnout v prvním stupni Dopravní a energetický stavební úřad“ se
nahrazují slovy „Úřad rozvoje území České republiky“.
2.
V § 42 se na konci textu odstavce 2 doplňují slova „ ; to neplatí pro výzvu k zaplacení
soudního poplatku, výzvu k vyjádření k věci nebo předvolání k jednání, které se doručují
pouze zástupci“.
3.
V § 68 se na konci textu písmene a) doplňují slova „ ; za opravný prostředek proti
závaznému stanovisku se nepovažuje jeho přezkum v řízení o odvolání proti rozhodnutí“.
4.
V § 101a odst. 1 se slova „ ; jsou-li“ nahrazují slovy „ . Jsou-li“, slova „rozhodl, že se
takové opatření obecné povahy nebo jeho část v této věci nepoužijí, pokud by jinak byly
dány důvody pro jejich zrušení“ se nahrazují slovy „přezkoumal zákonnost takového
opatření obecné povahy jako závazného podkladu rozhodnutí nebo jiného úkonu
správního orgánu napadeného žalobou nebo jiným návrhem“, za slovo „Soud“ se vkládají
slova „v takovém případě“ a slovo „nepoužití“ se nahrazuje slovy „přezkum zákonnosti“.
5.
V § 101d se za odstavec 2 vkládá nový odstavec 3, který zní:
„(3) Je-li žaloba nebo jiný návrh ve věci, ve které bylo opatření obecné povahy užito, podán
po uplynutí lhůty podle § 101b odst. 1, soud se s návrhem na přezkum zákonnosti opatření
obecné povahy nebo jeho části vypořádá pouze v odůvodnění rozsudku; je-li takový návrh
důvodný, soud v odůvodnění uvede, že se napadené opatření obecné povahy nebo jeho část
v této věci nepoužijí. Právním názorem soudu je v dalším řízení správní orgán vázán.“.
Dosavadní odstavce 3 až 5 se označují jako odstavce 4 až 6.
ČÁST TŘICÁTÁ PÁTÁ
Změna zákona o dani z přidané hodnoty
Čl. LIV
V § 55a odst. 2 písm. a) zákona č. 235/2004 Sb., o dani z přidané hodnoty, ve znění zákona
č. 461/2024 Sb., se slovo „zastavěného“ nahrazuje slovem „zastavitelného“.
ČÁST TŘICÁTÁ ŠESTÁ
Změna zákona o rostlinolékařské péči
Čl. LV
V § 52b odst. 3 úvodní části ustanovení zákona č. 326/2004 Sb., o rostlinolékařské péči
a o změně některých souvisejících zákonů, ve znění zákona č. 199/2012 Sb. a zákona
č. 299/2017 Sb., se slova „zastavěných stavebních pozemcích“ nahrazují slovy „pozemcích
zázemí stavby105)“.
Poznámka pod čarou č. 105 zní:
„105)
§ 12 písm. c) zákona č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů.“.
ČÁST TŘICÁTÁ SEDMÁ
Změna zákona o archivnictví a spisové službě
Čl. LVI
Zákon č. 499/2004 Sb., o archivnictví a spisové službě a o změně některých zákonů, ve
znění zákona č. 413/2005 Sb., zákona č. 444/2005 Sb., zákona č. 112/2006 Sb., zákona
č. 181/2007 Sb., zákona č. 296/2007 Sb., zákona č. 32/2008 Sb., zákona č. 190/2009 Sb.,
zákona č. 227/2009 Sb., zákona č. 424/2010 Sb., zákona č. 89/2012 Sb., zákona č. 167/2012
Sb., zákona č. 303/2013 Sb., zákona č. 56/2014 Sb., zákona č. 250/2014 Sb., zákona č. 298/2016
Sb., zákona č. 183/2017 Sb., zákona č. 205/2017 Sb., zákona č. 111/2019 Sb., zákona
č. 261/2021 Sb., zákona č. 284/2021 Sb., zákona č. 326/2021 Sb., zákona č. 416/2021 Sb.,
zákona č. 152/2023 Sb., zákona č. 197/2024 Sb. a zákona č. 263/2024 Sb., se mění takto:
1.
V § 63 odst. 1 písm. d) se slova „se stavebním nebo“ nahrazují slovem „s“.
2.
V § 63 odst. 1 písm. e) se slova „působnosti obce se stavebním nebo“ zrušují.
ČÁST TŘICÁTÁ OSMÁ
Změna zákona o správních poplatcích
Čl. LVII
Příloha k zákonu č. 634/2004 Sb., o správních poplatcích, ve znění zákona č. 217/2005 Sb.,
zákona č. 228/2005 Sb., zákona č. 357/2005 Sb., zákona č. 361/2005 Sb., zákona č. 444/2005
Sb., zákona č. 545/2005 Sb., zákona č. 553/2005 Sb., zákona č. 48/2006 Sb., zákona č. 56/2006
Sb., zákona č. 57/2006 Sb., zákona č. 81/2006 Sb., zákona č. 109/2006 Sb., zákona č. 112/2006
Sb., zákona č. 130/2006 Sb., zákona č. 136/2006 Sb., zákona č. 138/2006 Sb., zákona
č. 161/2006 Sb., zákona č. 179/2006 Sb., zákona č. 186/2006 Sb., zákona č. 215/2006 Sb.,
zákona č. 226/2006 Sb., zákona č. 227/2006 Sb., zákona č. 235/2006 Sb., zákona č. 312/2006
Sb., zákona č. 575/2006 Sb., zákona č. 106/2007 Sb., zákona č. 261/2007 Sb., zákona
č. 269/2007 Sb., zákona č. 374/2007 Sb., zákona č. 379/2007 Sb., zákona č. 38/2008 Sb.,
zákona č. 130/2008 Sb., zákona č. 140/2008 Sb., zákona č. 182/2008 Sb., zákona č. 189/2008
Sb., zákona č. 230/2008 Sb., zákona č. 239/2008 Sb., zákona č. 254/2008 Sb., zákona
č. 296/2008 Sb., zákona č. 297/2008 Sb., zákona č. 301/2008 Sb., zákona č. 309/2008 Sb.,
zákona č. 312/2008 Sb., zákona č. 382/2008 Sb., zákona č. 9/2009 Sb., zákona č. 141/2009 Sb.,
zákona č. 197/2009 Sb., zákona č. 206/2009 Sb., zákona č. 227/2009 Sb., zákona č. 281/2009
Sb., zákona č. 291/2009 Sb., zákona č. 301/2009 Sb., zákona č. 346/2009 Sb., zákona
č. 420/2009 Sb., zákona č. 132/2010 Sb., zákona č. 148/2010 Sb., zákona č. 153/2010 Sb.,
zákona č. 160/2010 Sb., zákona č. 343/2010 Sb., zákona č. 427/2010 Sb., zákona č. 30/2011
Sb., zákona č. 105/2011 Sb., zákona č. 133/2011 Sb., zákona č. 134/2011 Sb., zákona
č. 152/2011 Sb., zákona č. 188/2011 Sb., zákona č. 245/2011 Sb., zákona č. 249/2011 Sb.,
zákona č. 255/2011 Sb., zákona č. 262/2011 Sb., zákona č. 300/2011 Sb., zákona č. 308/2011
Sb., zákona č. 329/2011 Sb., zákona č. 344/2011 Sb., zákona č. 349/2011 Sb., zákona
č. 350/2011 Sb., zákona č. 357/2011 Sb., zákona č. 367/2011 Sb., zákona č. 375/2011 Sb.,
zákona č. 428/2011 Sb., zákona č. 457/2011 Sb., zákona č. 458/2011 Sb., zákona č. 472/2011
Sb., zákona č. 19/2012 Sb., zákona č. 37/2012 Sb., zákona č. 53/2012 Sb., zákona č. 119/2012
Sb., zákona č. 169/2012 Sb., zákona č. 172/2012 Sb., zákona č. 202/2012 Sb., zákona
č. 221/2012 Sb., zákona č. 225/2012 Sb., zákona č. 274/2012 Sb., zákona č. 350/2012 Sb.,
zákona č. 359/2012 Sb., zákona č. 399/2012 Sb., zákona č. 407/2012 Sb., zákona č. 428/2012
Sb., zákona č. 496/2012 Sb., zákona č. 502/2012 Sb., zákona č. 503/2012 Sb., zákona č. 50/2013
Sb., zákona č. 69/2013 Sb., zákona č. 102/2013 Sb., zákona č. 170/2013 Sb., zákona č. 185/2013
Sb., zákona č. 186/2013 Sb., zákona č. 232/2013 Sb., zákona č. 239/2013 Sb., zákona
č. 241/2013 Sb., zákona č. 257/2013 Sb., zákona č. 273/2013 Sb., zákona č. 279/2013 Sb.,
zákona č. 281/2013 Sb., zákona č. 306/2013 Sb., zákona č. 313/2013 Sb., zákonného opatření
č. 344/2013 Sb., zákona č. 101/2014 Sb., zákona č. 127/2014 Sb., zákona č. 187/2014 Sb.,
zákona č. 249/2014 Sb., zákona č. 257/2014 Sb., zákona č. 259/2014 Sb., zákona č. 264/2014
Sb., zákona č. 268/2014 Sb., zákona č. 331/2014 Sb., zákona č. 81/2015 Sb., zákona č. 103/2015
Sb., zákona č. 204/2015 Sb., zákona č. 206/2015 Sb., zákona č. 224/2015 Sb., zákona
č. 268/2015 Sb., zákona č. 314/2015 Sb., zákona č. 318/2015 Sb., zákona č. 113/2016 Sb.,
zákona č. 126/2016 Sb., zákona č. 137/2016 Sb., zákona č. 148/2016 Sb., zákona č. 188/2016
Sb., zákona č. 229/2016 Sb., zákona č. 243/2016 Sb., zákona č. 258/2016 Sb., zákona
č. 264/2016 Sb., zákona č. 298/2016 Sb., zákona č. 319/2016 Sb., zákona č. 324/2016 Sb.,
zákona č. 369/2016 Sb., zákona č. 63/2017 Sb., zákona č. 170/2017 Sb., zákona č. 194/2017
Sb., zákona č. 195/2017 Sb., zákona č. 199/2017 Sb., zákona č. 202/2017 Sb., zákona
č. 204/2017 Sb., zákona č. 206/2017 Sb., zákona č. 222/2017 Sb., zákona č. 225/2017 Sb.,
zákona č. 251/2017 Sb., zákona č. 261/2017 Sb., zákona č. 289/2017 Sb., zákona č. 295/2017
Sb., zákona č. 299/2017 Sb., zákona č. 302/2017 Sb., zákona č. 304/2017 Sb., zákona
č. 371/2017 Sb., zákona č. 90/2018 Sb., zákona č. 171/2018 Sb., zákona č. 193/2018 Sb.,
zákona č. 286/2018 Sb., zákona č. 307/2018 Sb., zákona č. 135/2019 Sb., zákona č. 176/2019
Sb., zákona č. 209/2019 Sb., zákona č. 255/2019 Sb., zákona č. 279/2019 Sb., zákona
č. 364/2019 Sb., zákona č. 368/2019 Sb., zákona č. 369/2019 Sb., zákona č. 12/2020 Sb.,
zákona č. 115/2020 Sb., zákona č. 117/2020 Sb., zákona č. 119/2020 Sb., zákona č. 334/2020
Sb., zákona č. 336/2020 Sb., zákona č. 337/2020 Sb., zákona č. 501/2020 Sb., zákona
č. 524/2020 Sb., zákona č. 543/2020 Sb., zákona č. 13/2021 Sb., zákona č. 14/2021 Sb., zákona
č. 90/2021 Sb., zákona č. 261/2021 Sb., zákona č. 270/2021 Sb., zákona č. 274/2021 Sb., zákona
č. 284/2021 Sb., zákona č. 300/2021 Sb., zákona č. 362/2021 Sb., zákona č. 366/2021 Sb.,
zákona č. 371/2021 Sb., zákona č. 374/2021 Sb., zákona č. 426/2021 Sb., zákona č. 91/2022
Sb., zákona č. 96/2022 Sb., zákona č. 217/2022 Sb., zákona č. 225/2022 Sb., zákona č. 246/2022
Sb., zákona č. 314/2022 Sb., zákona č. 372/2022 Sb., zákona č. 376/2022 Sb., zákona
č. 431/2022 Sb., zákona č. 432/2022 Sb., zákona č. 458/2022 Sb., zákona č. 88/2023 Sb.,
zákona č. 149/2023 Sb., zákona č. 173/2023 Sb., zákona č. 185/2023 Sb., zákona č. 271/2023
Sb., zákona č. 277/2023 Sb., zákona č. 349/2023 Sb., zákona č. 414/2023 Sb., zákona
č. 469/2023 Sb., zákona č. 1/2024 Sb., zákona č. 85/2024 Sb., zákona č. 123/2024 Sb., zákona
č. 125/2024 Sb., zákona č. 163/2024 Sb., zákona č. 196/2024 Sb., zákona č. 237/2024 Sb.,
zákona č. 278/2024 Sb., zákona č. 321/2024 Sb., zákona č. 453/2024 Sb., zákona č. 480/2024
Sb., zákona č. 23/2025 Sb., zákona č. 32/2025 Sb., zákona č. 42/2025 Sb., zákona č. 52/2025
Sb., zákona č. 70/2025 Sb., zákona č. 79/2025 Sb., zákona č. 130/2025 Sb., zákona č. 152/2025
Sb., zákona č. 220/2025 Sb., zákona č. 230/2025 Sb., zákona č. 277/2025 Sb., zákona
č. 280/2025 Sb., zákona č. 300/2025 Sb., zákona č. 314/2025 Sb., zákona č. 330/2025
Sb., zákona č. 344/2025 Sb. a zákona č. 60/2026 Sb., se mění takto:
1.
V příloze v položce 17 bod 1 se písmeno b) zrušuje.
Dosavadní písmeno c) se označuje jako písmeno b).
2.
V příloze se na konci položky 17 doplňuje poznámka, která zní:
„Poznámka
Správní poplatek podle bodu 1 písm. b) se vybere i za stanovení ochranného pásma
opatřením obecné povahy.“.
3.
V příloze v položce 18 bodu 3 se slova „prodloužení platnosti povolení“ nahrazují slovy
„změně povolení“.
4.
V příloze v položce 18 v Poznámkách bodu 2 se za text „c)“ vkládají slova „a vydání
povolení změny záměru před dokončením dle bodu 4 písm. a), b) a c)“.
5.
V příloze v položce 18 v Poznámkách se doplňuje bod 6, který zní:
„6. Za vydání povolení na změnu dokončené stavby vybere správní úřad poplatek ve výši
poloviny sazby příslušného poplatku dle bodu 1. této položky.“.
6.
V příloze v položce 18 v Osvobození v odstavci 2 se za slovo „opatření“ vkládají slova
„a staveb s nimi souvisejících“.
7.
V příloze v položce 18 v Osvobození se doplňuje odstavec, který zní:
„Od poplatku je osvobozeno vydání povolení záměru a vydání kolaudačního rozhodnutí,
pokud stavební úřad o žádosti nerozhodne ve lhůtě podle stavebního zákona.“.
8.
V příloze v položce 102 se bod 2 zrušuje a zároveň se zrušuje označení bodu 1.
Čl. LVIII
Přechodné ustanovení
Změny v položce 17 a 18 přílohy zákona č. 634/2004 Sb., ve znění účinném ode dne nabytí
účinnosti tohoto zákona, se použijí až v řízeních zahájených po dni nabytí účinnosti tohoto
zákona.
ČÁST TŘICÁTÁ DEVÁTÁ
Změna zákona o uznávání výsledků dalšího vzdělávání
Čl. LIX
V příloze k zákonu č. 179/2006 Sb., o ověřování a uznávání výsledků dalšího vzdělávání
a o změně některých zákonů (zákon o uznávání výsledků dalšího vzdělávání), ve znění zákona
č. 110/2007 Sb., zákona č. 375/2011 Sb. a zákona č. 471/2022 Sb., se text
„
Ministerstvo pro místní rozvoj
domovního a bytového fondu,
územního plánování
a stavebního řádu, investiční
politiky, cestovního ruchu,
pohřebnictví
.“.
nahrazuje textem
„
Ministerstvo pro místní rozvoj
domovního a bytového fondu,
investiční politiky, cestovního
ruchu, pohřebnictví
Úřad rozvoje území České republiky
územního
plánování, stavebního řádu a
vyvlastnění
.“.
ČÁST ČTYŘICÁTÁ
Změna zákona o vyvlastnění
Čl. LX
Zákon č. 184/2006 Sb., o odnětí nebo omezení vlastnického práva k pozemku nebo ke
stavbě (zákon o vyvlastnění), ve znění zákona č. 167/2012 Sb., zákona č. 405/2012 Sb., zákona
č. 49/2016 Sb., zákona č. 225/2017 Sb., zákona č. 169/2018 Sb., zákona č. 403/2020 Sb.,
zákona č. 261/2021 Sb., zákona č. 284/2021 Sb., zákona č. 152/2023 Sb. a zákona č. 465/2023
Sb., se mění takto:
1.
§ 15 včetně nadpisu zní:
„§ 15
Vyvlastňovací úřad
(1) Vyvlastňovacími úřady jsou Úřad rozvoje území České republiky a úřady rozvoje
území krajů.
(2) Úřad rozvoje území České republiky je nadřízeným správním orgánem úřadů rozvoje
území krajů.“.
2.
§ 16 včetně nadpisu zní:
„§ 16
Příslušnost
(1) K vyvlastňovacímu řízení je příslušný úřad rozvoje území kraje, v jehož správním
obvodu se nachází pozemek nebo stavba, jichž se vyvlastnění týká.
(2) Úřad rozvoje území České republiky je příslušný k vyvlastňovacímu řízení pro účel
vyvlastnění,
a) pro jehož dosažení je třeba povolení vyhrazené stavby podle stavebního zákona,
b) který je stanoven horním zákonem, s výjimkou vyvlastnění pro uskutečnění zvláštních
zásahů do zemské kůry, nebo
c) podle § 29d zákona o zajišťování obrany České republiky.“.
3.
V § 28 odst. 3 písm. b) se slovo „zastavěném“ nahrazuje slovem „zastavitelném“.
Čl. LXI
Přechodná ustanovení
1. Řízení a postupy zahájené a neskončené přede dnem nabytí účinnosti tohoto zákona se
dokončí podle zákona č. 184/2006 Sb., ve znění účinném ode dne nabytí účinnosti tohoto
zákona, není-li stanoveno jinak.
2. Řízení a postupy zahájené a neskončené do dne vzniku Úřadu rozvoje území České
republiky (dále jen „Úřad“), k nimž je příslušný Úřad, převezme a dokončí ode dne svého
vzniku Úřad.
3. Řízení a postupy zahájené a neskončené do dne vzniku úřadů rozvoje území krajů, k
nimž je příslušný úřad rozvoje území kraje nebo jeho územní pracoviště, ode dne vzniku úřadů
rozvoje území krajů převezme a dokončí příslušný úřad rozvoje území kraje nebo jeho příslušné
územní pracoviště. Do dne vzniku úřadů rozvoje území krajů pokračují v těchto řízeních a
postupech podle tohoto zákona stavební úřady příslušné podle dosavadních právních předpisů.
ČÁST ČTYŘICÁTÁ PRVNÍ
Změna zákona o stabilizaci veřejných rozpočtů
Čl. LXII
Zákon č. 261/2007 Sb., o stabilizaci veřejných rozpočtů, ve znění zákona č. 2/2009 Sb.,
zákona č. 206/2009 Sb., zákona č. 281/2009 Sb., zákona č. 282/2009 Sb., zákona č. 292/2009
Sb., zákona č. 199/2010 Sb., zákona č. 329/2011 Sb., zákona č. 366/2011 Sb., zákona
č. 420/2011 Sb., zákona č. 167/2012 Sb., zákona č. 463/2012 Sb., zákona č. 313/2013 Sb.,
zákonného opatření Senátu č. 340/2013 Sb., zákonného opatření Senátu č. 344/2013 Sb., zákona
č. 182/2014 Sb., zákona č. 234/2014 Sb., zákona č. 331/2014 Sb., zákona č. 131/2015 Sb.,
zákona č. 382/2015 Sb., zákona č. 298/2016 Sb., zákona č. 183/2017 Sb., zákona č. 349/2023
Sb., zákona č. 469/2023 Sb., zákona č. 265/2024 Sb., zákona č. 462/2024 Sb. a zákona
č. 87/2025 Sb., se mění takto:
1.
V části čtyřicáté sedmé čl. LXXIV § 2 odst. 1 písm. b) se za slovo „zákona“ vkládají
slova „ , osoba provozující zařízení pro ukládání elektřiny podle energetického zákona, a
to v rozsahu množství elektřiny určeného Elektroenergetickým datovým centrem jako
množství elektřiny odebrané v předávacím místě z přenosové soustavy nebo distribuční
soustavy pro ukládání elektřiny a zpětně dodané do přenosové soustavy nebo distribuční
soustavy“.
2.
V části čtyřicáté sedmé čl. LXXIV § 8 odst. 1 písm. a) bodu 2 se číslo „50“ nahrazuje
číslem „100“.
3.
V části čtyřicáté sedmé čl. LXXIV § 12 ve větě první se za slovo „elektřinou“ vkládají
slova „nebo osoba provozující zařízení pro ukládání elektřiny podle energetického zákona
v rozsahu množství elektřiny, pro které je dodavatelem“ a na konci § 12 se doplňuje věta
„Nabýt elektřinu bez daně může na daňovém území bez povolení k nabytí elektřiny bez
daně také osoba provozující zařízení pro ukládání elektřiny podle energetického zákona
o celkovém instalovaném elektrickém výkonu do 100 kW v rozsahu množství elektřiny,
pro které je dodavatelem.“.
4.
V části čtyřicáté sedmé čl. LXXIV § 13 odst. 2 se na konci textu písmene d) doplňují
slova „ , je-li navrhovatelem obchodník s elektřinou“.
5.
V části čtyřicáté sedmé čl. LXXIV § 13 se na konci odstavce 2 tečka nahrazuje čárkou a
doplňuje se písmeno e), které zní:
„e) je-li navrhovatelem osoba provozující zařízení pro ukládání elektřiny podle energetického
zákona a provádění této činnosti vyžaduje licenci podle energetického zákona, doklad
prokazující, že navrhovatel je držitelem takové licence.“.
6.
V části čtyřicáté sedmé čl. LXXIV § 15 odst. 1 písm. e) se za text „§ 13 odst. 2 písm. d)“
vkládají slova „nebo e)“.
7.
V části čtyřicáté sedmé čl. LXXIV § 16 se na konci textu odstavce 2 doplňují slova „ ; to
neplatí pro dodání elektřiny osobě provozující zařízení pro ukládání elektřiny podle
energetického zákona o celkovém instalovaném elektrickém výkonu do 100 kW v
rozsahu množství elektřiny, pro které je tato osoba dodavatelem“.
8.
V části čtyřicáté sedmé čl. LXXIV § 17 odst. 1 se za slovo „elektřinou“ vkládají slova
„nebo osobě provozující zařízení pro ukládání elektřiny podle energetického zákona“.
9.
V části čtyřicáté sedmé čl. LXXIV § 17 odst. 4 úvodní části ustanovení se za slovo
„elektřinou“ vkládají slova „nebo osobě provozující zařízení pro ukládání elektřiny podle
energetického zákona“.
10.
V části čtyřicáté sedmé čl. LXXIV § 17 odst. 4 se na konci textu písmene b) doplňují
slova „nebo osobě provozující zařízení pro ukládání elektřiny podle energetického
zákona“.
11.
V části čtyřicáté sedmé čl. LXXIV § 18 se doplňuje odstavec 3, který zní:
„(3) Evidenci podle odstavce 1 není povinna vést osoba provozující zařízení pro ukládání
elektřiny podle energetického zákona o celkovém instalovaném elektrickém výkonu do 100
kW.“.
12.
V části čtyřicáté sedmé čl. LXXIV § 27 odst. 1 se na konci textu písmene a) doplňují
slova „ ; to neplatí pro dodání elektřiny osobě provozující zařízení pro ukládání elektřiny
podle energetického zákona o celkovém instalovaném elektrickém výkonu do 100 kW
v rozsahu množství elektřiny, pro které je tato osoba dodavatelem“.
Čl. LXIII
Přechodné ustanovení
Pokud osoba provozující zařízení pro ukládání elektřiny podle energetického zákona podá
návrh na vydání povolení k nabytí elektřiny bez daně do 31. srpna 2026, považuje se taková
osoba od 1. srpna 2026 do dne předcházejícího dni pravomocného ukončení řízení o návrhu na
vydání povolení za držitele povolení k nabytí elektřiny bez daně podle zákona č. 261/2007 Sb.,
ve znění účinném ode dne nabytí účinnosti tohoto zákona, bylo-li návrhu vyhověno.
ČÁST ČTYŘICÁTÁ DRUHÁ
Změna zákona o urychlení výstavby strategicky významné infrastruktury
Čl. LXIV
Zákon č. 416/2009 Sb., o urychlení výstavby strategicky významné infrastruktury, ve znění
zákona č. 209/2011 Sb., zákona č. 405/2012 Sb., zákona č. 178/2014 Sb., zákona č. 49/2016
Sb., zákona č. 194/2017 Sb., zákona č. 225/2017 Sb., zákona č. 169/2018 Sb., zákona
č. 237/2020 Sb., zákona č. 403/2020 Sb., zákona č. 284/2021 Sb., zákona č. 126/2023 Sb.,
zákona č. 152/2023 Sb., zákona č. 202/2023 Sb., zákona č. 465/2023 Sb., zákona č. 183/2024
Sb., zákona č. 23/2025 Sb. a zákona č. 223/2025 Sb., se mění takto:
1.
Poznámka pod čarou č. 1 zní:
 „1)
§ 10 odst. 1 písm. a) zákona č. 283/2021 Sb., stavební zákon, ve znění pozdějších
předpisů.“.
2.
V § 1 se na konci odstavce 5 tečka nahrazuje čárkou a doplňují se písmena e) a f), která
znějí:
„e) stavba skladu a úložiště radioaktivního odpadu,
f)
stavba spalovny nebezpečného odpadu umožňující nakládání s odpadem vzniklým ve
spojitosti s výstavbou, uváděním do provozu, provozem, prováděním změn nebo údržbou
energetické infrastruktury včetně staveb souvisejících.“.
3.
V § 1 odst. 13 se slova „zastavitelných nebo transformačních“ zrušují a na konci textu
odstavce se doplňují slova „a stavba podle odstavce 14“.
4.
V § 1 se za odstavec 13 vkládá nový odstavec 14, který včetně poznámek pod čarou č. 30
a 31 zní:
„(14) Strategickou stavbou zdravotnické infrastruktury se pro účely tohoto zákona rozumí
stavba zdravotnického zařízení poskytovatele zdravotních služeb lůžkové péče zřizovaného
Českou republikou, krajem nebo veřejnou vysokou školou, jde-li o
a) stavbu fakultní nemocnice podle zákona o zdravotních službách30), včetně výstavby nového
areálu fakultní nemocnice, jeho podstatného rozšíření nebo komplexní obnovy, nebo
b) stavbu pro poskytování zdravotních služeb lůžkové péče poskytovatelem, jemuž byl udělen
status centra vysoce specializované zdravotní péče podle zákona o zdravotních službách31),
jejíž celkové investiční náklady přesahují 1 000 000 000 Kč.
__________________
30)
§ 111 zákona č. 372/2011 Sb., o zdravotních službách a podmínkách jejich poskytování,
ve znění pozdějších předpisů.
31)
§ 112 zákona č. 372/2011 Sb.“.
Dosavadní odstavce 14 a 15 se označují jako odstavce 15 a 16.
5.
V § 1 odst. 16 se slova „zastavitelných nebo transformačních“ zrušují.
6.
V § 2 odst. 6 větě čtvrté se za slovo „žadateli,“ vkládá slovo „vyvlastňovanému,“, ve větě
poslední se slovo „třicátý“ nahrazuje slovem „patnáctý“ a na konci odstavce se doplňuje
věta „V případě podzemní stavby, která funkčně ani svou konstrukcí nesouvisí se
stavbami na pozemku ani s provozem na něm a která ani jinak nemůže mít vliv na využití
pozemku k účelu, pro který je určen, se v řízení podle tohoto zákona nebo stavebního
zákona doručuje veřejnou vyhláškou vždy.“.
7.
V § 2b odst. 1 a § 2b odst. 2 úvodní části ustanovení se slovo „zastavěném“ nahrazuje
slovem „zastavitelném“.
8.
V § 2b odst. 1 větě první se za slovo „vedení“ vkládají slova „přenosové soustavy“ a na
konci textu věty se doplňují slova „ , nenavrhne-li stavebník jinak“.
9.
V § 2d odst. 4 se na konci textu věty první doplňují slova „ ; tuto lhůtu nelze prodloužit“
a věty druhá až poslední se zrušují.
10.
V § 2d odst. 13 větě první se slova „ , závazného stanoviska nebo jednotného
environmentálního stanoviska“ nahrazují slovy „nebo závazného stanoviska“.
11.
V § 2d se odstavec 14 zrušuje.
Dosavadní odstavce 15 až 19 se označují jako odstavce 14 až 18.
12.
V § 2d odst. 18 úvodní části ustanovení se číslo „18“ nahrazuje číslem „17“.
13.
V § 2d odst. 18 se písmeno b) zrušuje.
Dosavadní písmena c) až e) se označují jako písmena b) až d).
14.
V § 2d se doplňují odstavce 19 až 21, které znějí:
„(19) Ustanovení § 311 odst. 5 stavebního zákona se na rozhodnutí o povolení záměru
stavby pro energetickou bezpečnost nepoužije.
(20) V případě záměrů staveb pro energetickou bezpečnost podle § 1 odst. 5 písm. a) a b)
se omezení maximální doby předčasného užívání nebo zkušebního provozu podle § 238 odst.
3 stavebního zákona neuplatní.
(21) V případě záměrů staveb pro energetickou bezpečnost podle § 1 odst. 5 písm. a) nebo
b) a záměru staveb podle bodu 3 písm. a) přílohy č. 1 povolovaných podle stavebního zákona
rozhodne o povolení podle § 8 nebo § 16 nebo o výjimce podle § 23a odst. 8 vodního zákona11)
stavební úřad v rámci rozhodnutí o záměru podle stavebního zákona na základě závazného
stanoviska vodoprávního úřadu, kterým je příslušný krajský úřad. V odůvodněných případech
může vodoprávní úřad s ohledem na průběh řízení o rozhodnutí o záměru podle stavebního
zákona závazné stanovisko podle věty první změnit či nahradit novým závazným stanoviskem,
a to i pokud nedojde ke změně podmínek ve smyslu § 3 stavebního zákona; vodoprávní úřad
přitom dbá ochrany legitimního očekávání žadatele. Účastníky řízení o rozhodnutí o záměru
podle stavebního zákona jsou i ti, kteří by jinak byli účastníky vodoprávního řízení podle
vodního zákona11).“.
15.
V § 2e odst. 2 se slova „Dopravního a energetického stavebního úřadu“ nahrazují slovy
„Úřadu rozvoje území České republiky (dále jen „Úřad“)“.
16.
V § 2e se doplňují odstavce 3 až 5, které znějí:
„(3) Před realizací stavby pro energetickou bezpečnost podle § 1 odst. 5 písm. a) až c) jsou
prováděny přípravné práce. Přípravnými pracemi pro stavby pro energetickou bezpečnost (dále
jen „přípravné práce“) se rozumí zejména terénní úpravy, úprava pozemku, příprava
odstavných, manipulačních a skladových ploch, příprava staveniště, zřizování přístupových
cest, výstavba objektů pro hospodaření se srážkovými vodami včetně úpravy koryt, výstavba
skladovacích a technických zařízení a staveb, výstavba staveb a zařízení dopravní nebo
technické infrastruktury, včetně úpravy staveb a zařízení stávajících.
(4) Přípravné práce jsou záměrem podle zákona o posuzování vlivů na životní prostředí,
pokud je předmětem posuzování stavba pro energetickou bezpečnost; podléhají posouzení vlivů
na životní prostředí, pokud se tak stanoví ve zjišťovacím řízení; předmětem posuzování jsou
samostatně, pokud o samostatné posouzení přípravných prací oznamovatel záměru stavby pro
energetickou bezpečnost požádá. Příslušným úřadem pro postup podle věty první je orgán kraje.
(5) Přípravné práce lze povolit samostatně v řízení podle zvláštních právních předpisů.
K přípravným pracím se při hodnocení a posuzování stavby pro energetickou bezpečnost podle
zákona o posuzování vlivů na životní prostředí a při jejím povolování podle zvláštních právních
předpisů, v rozsahu, ve kterém byly povoleny, nepřihlíží.“.
17.
V § 2f se za větu první vkládá věta „Příprava stavby podle věty první zahrnuje
i vyhledávání vhodné lokality pro její umístění.“.
18.
V § 2h se odstavec 4 zrušuje.
Dosavadní odstavec 5 se označuje jako odstavec 4.
19.
V § 2i se odstavec 1 zrušuje.
Dosavadní odstavce 2 až 6 se označují jako odstavce 1 až 5.
20.
V § 2i odst. 5 se slova „Pokud stavba základnové stanice mobilní sítě elektronických
komunikací včetně souvisejícího elektrického a optického přípojného vedení je nutná ke
splnění povinnosti uložené na základě zvláštního právního předpisu, lze tuto stavbu“
nahrazují slovy „Stavbu základnové stanice mobilní sítě elektronických komunikací
včetně souvisejícího elektrického a optického přípojného vedení lze“.
21.
V § 2j se odstavec 3 zrušuje.
22.
V § 2l odst. 6 a § 2m odst. 1 se slova „Ministerstvo pro místní rozvoj“ nahrazuje slovem
„Úřad“.
23.
V § 2m odst. 1 se slova „Ministerstvem pro místní rozvoj“ se nahrazují slovem „Úřadem“.
24.
V § 2n se odstavec 3 zrušuje.
Dosavadní odstavec 4 se označuje jako odstavec 3.
25.
V § 2n se doplňuje odstavec 4, který zní:
„(4) Strategickou investiční stavbu lze v územně plánovací dokumentaci vymezit jako
veřejně prospěšnou stavbu podle stavebního zákona.“.
26.
V § 3 se na konci odstavce 4 doplňuje věta „Splnění podmínek přípustnosti vyvlastnění
uvedených v odstavci 2 nebo 3 se nevyžaduje, jde-li o podzemní stavbu, která funkčně
ani svou konstrukcí nesouvisí se stavbami na pozemku ani s provozem na něm a která ani
jinak nemůže mít vliv na využití pozemku k účelu, pro který je určen.“.
27.
V § 3e odst. 1 se slova „nebo po vydání souhlasného jednotného environmentálního
stanoviska podle zákona o jednotném environmentálním stanovisku26), je-li jeho součástí
závazné stanovisko k posouzení vlivů provedení záměru na životní prostředí“ zrušují.
Poznámka pod čarou č. 26 se zrušuje.
28.
Za § 3e se vkládá nový § 3f, který včetně nadpisu zní:
„§ 3f
Žaloba na odstranění stavby energetické infrastruktury a infrastruktury elektronických
komunikací
(1) Jestliže došlo k zahájení vyvlastňovacího řízení ve vztahu k předmětu vyvlastnění,
který je předmětem řízení o žalobě na odstranění stavby energetické infrastruktury, nebo stavby
infrastruktury elektronických komunikací, soud přeruší řízení o žalobě na odstranění stavby.
(2) Jestliže došlo v průběhu vyvlastňovacího řízení k zahájení řízení o žalobě na odstranění
stavby energetické infrastruktury, nebo stavby infrastruktury elektronických komunikací
k předmětu vyvlastnění, soud přeruší řízení o žalobě na odstranění stavby k předmětu
vyvlastnění.
(3) Došlo-li k přerušení řízení o žalobě na odstranění stavby podle odstavce 1 nebo 2, lze
v řízení o žalobě na odstranění stavby pokračovat až po zamítnutí nebo odmítnutí žádosti
o vyvlastnění, nebo po nabytí právních účinků výroku o vyvlastnění.
(4) Došlo-li k vyvlastnění spočívajícím v odnětí či omezení vlastnického práva, soud
žalobu o žalobě na odstranění stavby energetické infrastruktury, nebo stavby infrastruktury
elektronických komunikací zamítne.
(5) Odstavce 1 až 4 se pro žalobu na ochranu vlastnictví a žalobu na vyklizení ve vztahu k
předmětu vyvlastnění použijí pro stavby nebo zařízení energetické infrastruktury, nebo stavby
infrastruktury elektronických komunikací obdobně.“.
29.
V § 4a odst. 1 úvodní části ustanovení se za slovo „uskutečnění“ vkládá slovo
„vyhrazené“ a na konci úvodní části ustanovení se doplňují slova „podle stavebního
zákona a dále“.
30.
V § 4a odst. 1 písm. a) se čárka nahrazuje slovem „nebo“ a slova „nebo energetické“ se
zrušují.
31.
V § 4a se na konci odstavce 1 tečka nahrazuje slovem „ , nebo“ a doplňuje se písmeno c),
které zní:
„c) energetické infrastruktury, stavby těžební infrastruktury nebo stavby infrastruktury pro
ukládání oxidu uhličitého.“.
32.
§ 4b se zrušuje.
33.
V § 4d odst. 1 se slovo „vybrané“ zrušuje a na konci odstavce se doplňuje věta „Pro
omezení vlastnického práva nebo práva odpovídajícího věcnému břemenu k pozemku
nebo ke stavbě nebo jejich části potřebné k uskutečnění stavby infrastruktury
elektronických komunikací platí věta první obdobně.“.
34.
V § 5a odst. 1 se slova „Dopravní a energetický stavební úřad“ nahrazují slovem „Úřad“.
35.
V § 5f odst. 1 úvodní části ustanovení se slova „a popřípadě rovněž žádost o vydání
jednotného environmentálního stanoviska“ a slova „nebo žádost o vydání jednotného
environmentálního stanoviska“ zrušují.
36.
V § 5f odst. 2 úvodní části ustanovení se slova „vydání jednotného environmentálního
stanoviska“ nahrazují slovy „povolení záměru podle stavebního zákona“ a slova „správní
orgán příslušný k vydání jednotného environmentálního stanoviska“ se nahrazují slovy
„stavební úřad“.
37.
V § 5f odst. 2 písm. a) se slova „sdělí stavebnímu úřadu příslušnému k povolení záměru
tuto skutečnost a stavební úřad neprodleně“ zrušují.
38.
V § 5f odst. 2 písm. b) se slova „určenou žadateli sdělí stavebnímu úřadu příslušnému
k povolení záměru tuto skutečnost a uvede přitom, kterými vadami žádost trpí; stavební
úřad neprodleně“ a slova „ , a toto oznámení odůvodní závěrem správního orgánu
příslušného k vydání jednotného environmentálního stanoviska“ zrušují.
39.
V § 5f se odstavce 3 až 5 zrušují.
Dosavadní odstavce 6 a 7 se označují jako odstavce 3 a 4.
40.
V § 5f odst. 3 se slova „1 věty první,“ nahrazují slovy „1 věty první nebo“ a slova „nebo
odstavce 3 písm. b) anebo ode dne podání žádosti podle odstavce 5“ se zrušují.
41.
V § 5f odst. 4 se číslo „6“ nahrazuje číslem „3“.
42.
V § 5g odst. 1 úvodní části ustanovení se slova „Ministerstvo dopravy“ nahrazují slovem
„Úřad“.
43.
V § 5h se slova „1, 2, 3 nebo 5 nebo“ nahrazují slovy „1 nebo 2 anebo“.
44.
V § 5j odst. 1 úvodní části ustanovení se slova „zastavitelných nebo transformačních“
zrušují.
45.
V příloze č. 1 bod 3 zní:
„3. Infrastruktura pro vodní dopravu
a) plavební stupeň Děčín, včetně vodní elektrárny
b) plavební stupeň Přelouč“.
46.
V příloze č. 1 bodě 5 se za slova „vedení 400 kV Milín - Orlík“ vkládají slova „vedení
400 kV Slavětice - Prosenice“ a slova „vedení 400 kV Čechy Střed - Malešice“.
47.
V příloze č. 1 bodě 7 se za slova „nový jaderný zdroj v lokalitě Dukovany“ vkládají slova
„nový jaderný zdroj v lokalitě Tušimice“, „nový jaderný zdroj v lokalitě Dětmarovice“,
„nový plynový zdroj v lokalitě Počerady“, „nový plynový zdroj v lokalitě Mělník“, „nový
plynový zdroj v lokalitě Prunéřov“, „nový plynový zdroj v lokalitě Dětmarovice“ a „nový
plynový zdroj v lokalitě Ledvice“.
48.
V příloze č. 3 bodě 2 se za slovo „parku“ vkládají slova „Úpravna uhlí“ a slova „ , Důl
Československé armády sloužící zejména pro potřeby datového centra, k výrobě a
zpracování druhotných surovin a recyklátů, k robotické výrobě, k výrobě a zpracování
vodíku nebo pro potřeby přečerpávací vodní elektrárny“ se nahrazují slovy „sloužící
zejména pro záměry spojené s elektromobilitou, s výrobou technologických částí či celků
pro obnovitelné zdroje energie, s výrobou polovodičů, s výrobou a zpracováním
druhotných surovin a recyklátů, s výrobou a zpracováním vodíku nebo s robotickou
výrobou či datová centra“.
49.
V příloze č. 3 se na konci textu bodu 3 doplňují slova „a zpracovatelský závod pro úpravu
lithia“.
50.
V příloze č. 3 bodě 4 se slova „k výrobě a skladování baterií pro elektrická vozidla“
nahrazují slovy „pro záměry spojené s elektromobilitou, s výrobou technologických částí
či celků pro obnovitelné zdroje energie, s výrobou polovodičů, s výrobou a zpracováním
druhotných surovin a recyklátů, s výrobou a zpracováním vodíku nebo s robotickou
výrobou či datová centra“.
51.
V příloze č. 3 se bod 12 zrušuje.
Dosavadní bod 13 se označuje jako bod 12.
52.
V příloze č. 3 se doplňují body 13 až 16, které znějí:
„13. Stavby v lokalitě strategického podnikatelského parku Hrabák sloužící zejména pro
záměry spojené s elektromobilitou, s výrobou technologických částí či celků pro obnovitelné
zdroje energie, s výrobou polovodičů, s výrobou a zpracováním druhotných surovin a recyklátů,
s výrobou a zpracováním vodíku nebo s robotickou výrobou či datová centra.
14. Stavby v lokalitě strategického podnikatelského parku Ústí nad Labem - Předlice
sloužící zejména pro záměry spojené s elektromobilitou, s výrobou technologických částí či
celků pro obnovitelné zdroje energie, s výrobou polovodičů, s výrobou a zpracováním
druhotných surovin a recyklátů, s výrobou a zpracováním vodíku nebo s robotickou výrobou či
datová centra.
15. Stavby v lokalitě strategického podnikatelského parku Svitavy sloužící zejména pro
záměry spojené s elektromobilitou, s výrobou technologických částí či celků pro obnovitelné
zdroje energie, s výrobou polovodičů, s výrobou a zpracováním druhotných surovin a recyklátů,
s výrobou a zpracováním vodíku nebo s robotickou výrobou či datová centra.
16. Stavby v lokalitě strategického podnikatelského parku Olomouc - Hněvotín sloužící
zejména pro záměry spojené s vědou a výzkumem, s vysokým školstvím či s průmyslem
vyspělých technologií.“.
Čl. LXV
Přechodná ustanovení
1. Řízení a postupy zahájené a neskončené přede dnem nabytí účinnosti tohoto zákona se
dokončí podle zákona č. 416/2009 Sb., ve znění účinném ode dne nabytí účinnosti tohoto
zákona, není-li stanoveno jinak.
2. Ustanovení § 2d odst. 4 věty druhé až čtvrté, § 2d odst. 13, § 2d odst. 14, § 2n odst. 3,
§ 3e odst. 1, § 5f a § 5h zákona č. 416/2009 Sb., ve znění účinném přede dnem nabytí účinnosti
tohoto zákona, se do 31. prosince 2027 použijí v řízeních o záměrech, u nichž bude příslušným
stavebním úřadem úřad rozvoje území kraje nebo jeho územní pracoviště.
ČÁST ČTYŘICÁTÁ TŘETÍ
Změna zákona o podporovaných zdrojích energie
Čl. LXVI
Zákon č. 165/2012 Sb., podporovaných zdrojích energie a o změně některých zákonů, ve
znění zákona č. 407/2012 Sb., zákona č. 310/2013 Sb., zákona č. 90/2014 Sb., zákona č.
131/2015 Sb., zákona č. 107/2016 Sb., zákona č. 190/2016 Sb., zákona č. 103/2017 Sb., zákona
č. 183/2017 Sb., zákona č. 541/2020 Sb., zákona č. 367/2021 Sb., zákona č. 382/2021 Sb.,
zákona č. 143/2022 Sb., zákona č. 232/2022 Sb., zákona č. 19/2023 Sb., zákona č. 349/2023
Sb., zákona č. 469/2023 Sb., zákona č. 265/2024 Sb., zákona č. 87/2025 Sb., zákona č. 218/2025
Sb., zákona č. 223/2025 Sb. a zákona č. 370/2025 Sb., se mění takto:
1.
V § 22b odst. 1 se slova „nabytí účinnosti tohoto zákona“ nahrazují slovy „31. prosinci
2025“.
2.
V § 22d se za odstavec 4 vkládá nový odstavec 5, který zní:
„(5) Poplatek se snižuje o částku peněžitého plnění, které poplatník poplatku v
poplatkovém období poskytl obci na základě plánovací smlouvy nebo jiného právního jednání
v souvislosti s uskutečněním záměru, bylo-li toto plnění v tomto období splatné. Poplatek se
snižuje o výši poskytnutého peněžitého plnění, a to maximálně do částky odpovídající poplatku
určenému podle odstavce 2.“.
Dosavadní odstavec 5 se označuje jako odstavec 6.
3.
V § 22d odst. 6 se slova „které podle odstavce 4 stanovily jiné výše koeficientů poplatků,“
zrušují, slova „výše poplatku“ se nahrazují slovy „dílčí výše poplatku, a to“ a na konci
odstavce se doplňuje věta „Dílčí výše poplatku vypočtená podle věty první se snižuje o
výši peněžitého plnění poskytnutého obci poplatníkem poplatku postupem podle odstavce
5.“.
4.
V § 22g odst. 2 se slova „instalovaného výkonu výrobních zdrojů umístěných na
katastrálních územích obcí“ nahrazují slovy „dílčích výší poplatků, případně snížených
postupem podle § 22d odst. 5 a 6“.
5.
V § 26e odst. 2 se slova „dodané zákazníkům“ nahrazují slovy „vstupující ze zdrojů do
soustavy zásobování tepelnou energií“.
6.
§ 26e odstavec 3 zní:
„(3) Způsob stanovení podílu tepelné energie z obnovitelných zdrojů, odpadního tepla,
kombinované výroby elektřiny a tepla a vysokoúčinné kombinované výroby elektřiny a tepla a
množství emisí skleníkových plynů na jednotku tepelné energie vstupující ze zdrojů do
soustavy zásobování tepelnou energií pro účely posouzení účinné soustavy zásobování tepelnou
energií stanoví prováděcí právní předpis.“.
7.
V § 27be odst. 4 písm. a) se slova „je vyšší“ nahrazují slovem „vyšší“.
8.
V § 27be odstavec 5 zní:
„(5) Ministerstvo změní rozhodnutí o udělení práva na podporu z aukce neprodleně poté,
co se dozví o uvedení do provozu výrobny biometanu podle odstavce 4. Právo na podporu z
aukce vzniká v případě výrobny biometanu s energetickým výkonem, který je odlišný oproti
energetickému výkonu výrobny biometanu podle její původní identifikace v rozhodnutí o
udělení práva na podporu z aukce, v rozsahu odpovídajícím skutečné výši energetického
výkonu.“.
9.
V § 29 odst. 1 větě první se slovo „zákona“ zrušuje.
10.
V § 29 odst. 1 se věta třetí nahrazuje větou „Ministerstvo poukáže operátorovi trhu vždy
do konce daného kalendářního měsíce částku odpovídající procentnímu podílu, který je
stanoven podílem skutečně vynaložených nákladů operátora trhu na podporu elektřiny,
provozní podporu tepla, přechodnou transformační podporu tepla a podporu biometanu
podle § 28 odst. 10 za daný měsíc kalendářního roku předcházejícího kalendářnímu roku,
ve kterém vláda stanoví svým usnesením prostředky státního rozpočtu pro poskytnutí
dotace podle § 28 odst. 3 a celkové výše skutečně vynaložených nákladů operátora trhu
na podporu elektřiny, provozní podporu tepla, přechodnou transformační podporu tepla a
podporu biometanu podle § 28 odst. 10 v roce předcházejícím kalendářnímu roku, ve
kterém vláda stanoví svým usnesením prostředky státního rozpočtu pro poskytnutí dotace
podle § 28 odst. 3.“.
11.
V § 29 odst. 2 se slovo „čtvrtletních“ nahrazují slovem „měsíčních“.
12.
Nadpis § 45a zní:
„Omezení vydání záruky původu energie“.
13.
Nadpis § 45d zní:
„Nakládání se zárukami původu energie vydanými v jiném členském státě nebo
převedenými do jiného členského státu“.
14.
V § 45d odst. 2 písm. b) se za slovo „tohoto“ vkládá slovo „jiného“.
15.
V § 45d odst. 2 písm. c) se slova „žadatel o převod záruky původu energie prokazatelně
doloží, že“ zrušují a za slovo „tomto“ se vkládá slovo „jiném“.
16.
V § 47d odst. 1 písmena b) až d) znějí:
„b) 1,25 % energetických od 1. ledna 2027 do 31. prosince 2027,
c) 2 % energetických od 1. ledna 2028 do 31. prosince 2028,
d) 3,50 % energetických od 1. ledna 2029 do 31. prosince 2029,“.
17.
V § 47d odst. 3 písm. a) bodě 1 se část věty za středníkem včetně středníku zrušuje.
18.
V § 47d odst. 3 písm. b) se slova „byl nebo bylo“ nahrazuje slovem „byla“ a slova
„spotřebován nebo spotřebováno,“ se nahrazují slovem „spotřebována“.
19.
V § 47d odst. 3 písmeno c) zní:
„c) nebyla zohledněna pro
1. účely splnění povinnosti uvedené v odstavci 1 jiným dodavatelem plynných
pohonných hmot,
2. účely započtení do zbytkového energetického mixu,
3. plnění cílů podle čl. 3 a 25 směrnice o podpoře využívání energie z obnovitelných
zdrojů na území jiného státu.“.
20.
V § 47d se za odstavec 3 vkládá nový odstavec 4, který zní:
„(4) K prokázání skutečnosti uvedené v odstavci 3 předkládá dodavatel plynných
pohonných hmot v případě
a) obnovitelných paliv nebiologického původu čestné prohlášení vydané osobou, která je
oprávněna vydat doklad o splnění kritérií udržitelnosti a úspor emisí skleníkových plynů,
nebo
b) pokročilého biometanu uplatněné záruky původu biometanu; pokud se jedná o záruky
původu biometanu převedené z jiného státu, musí splňovat podmínky § 45d a biometan
musí být evidován v databázi Evropské unie, pokud tato databáze bude toto evidování
umožňovat.“.
Dosavadní odstavce 4 až 6 se označují jako odstavce 5 až 7.
21.
V § 47db odst. 1 písmena b) až d) znějí:
„b) 6,50 % od 1. ledna 2027 do 31. prosince 2027,
c) 7 % od 1. ledna 2028 do 31. prosince 2028,
d) 8 % od 1. ledna 2029 do 31. prosince 2029,“.
22.
V § 47db odst. 3 písm. f) se část věty za středníkem včetně středníku zrušuje.
23.
V § 47e se odstavec 7 zrušuje.
24.
V nadpisu § 47f se slova „nebo elektřině dodávaných pro dopravní účely“ zrušují.
25.
V § 47f odst. 1 se slova „nebo provozovatel dobíjecí stanice“, „a § 47e odst. 1 také“,
„nebo elektřiny“ a slova „či elektřinu“ zrušují.
26.
V § 47f odst. 2 se slova „nebo elektřiny“ a slova „nebo elektřinu“ zrušují.
27.
V § 47f odst. 3 se slova „a § 47e odst. 1“ zrušují.
28.
V § 47f odst. 5 se slova „a § 47e odst. 1“, „a provozovatel dobíjecí stanice“ a slova „nebo
minimálního podílu elektřiny z obnovitelných zdrojů energie v dopravě“ zrušují.
29.
V § 47f odst. 6 se slova „a provozovatel dobíjecí stanice“, „a § 47e odst. 1“ a slova „nebo
elektřiny“ zrušují.
30.
V § 47f odst. 7 se slova „nebo elektřiny“ a slova „a minimálního podílu elektřiny z
obnovitelných zdrojů energie v dopravě“ zrušují.
31.
V § 47f odst. 8 se slova „nebo elektřina“ a slova „a § 47e odst. 1“ zrušují.
32.
V § 49 odst. 20 se číslo „6“ nahrazuje číslem „7“.
33.
V § 53 odst. 1 písmeno ae) zní:
„ae) způsob stanovení podílu tepelné energie z obnovitelných zdrojů, odpadního tepla,
kombinované výroby elektřiny a tepla a vysokoúčinné kombinované výroby elektřiny a
tepla a množství emisí skleníkových plynů na jednotku tepelné energie vstupující ze zdrojů
do soustavy zásobování tepelnou energií pro účely posouzení účinné soustavy zásobování
tepelnou energií,“.
Čl. LXVII
Přechodná ustanovení
1. Ustanovení zákona č. 165/2012 Sb., ve znění účinném ode dne nabytí účinnosti tohoto
zákona, upravující snížení dílčí výše poplatku o výši peněžitého plnění poskytnutého obci
poplatníkem poplatku, se použijí pouze v případě peněžitých plnění poskytovaných obci nebo
obcím podle plánovací smlouvy nebo jiného právního jednání vzniklého před 31. prosincem
2025.
2. Prostředky dotace na úhradu nákladů na podporu elektřiny, provozní podporu tepla,
přechodnou transformační podporu tepla a podporu biometanu, pro které bylo rozhodnutí podle
§ 29 odst. 1 zákona č. 165/2012 Sb., ve znění účinném přede dnem nabytí účinnosti tohoto
zákona, vydáno přede dnem nabytí účinnosti tohoto zákona, se včetně finančního vypořádání
dokončí podle dosavadních právních předpisů.
3. Ustanovení § 29 zákona č. 165/2012 Sb., ve znění účinném ode dne nabytí účinnosti
tohoto zákona, se poprvé použijí pro vydání rozhodnutí o poskytnutí dotace operátorovi trhu na
úhradu nákladů na podporu elektřiny, provozní podporu tepla, přechodnou transformační
podporu tepla a podporu biometanu pro rok 2027.
ČÁST ČTYŘICÁTÁ ČTVRTÁ
Změna zákona o ochraně ovzduší
Čl. LXVIII
Zákon č. 201/2012 Sb., o ochraně ovzduší, ve znění zákona č. 64/2014 Sb., zákona
č. 87/2014 Sb., zákona č. 382/2015 Sb., zákona č. 369/2016 Sb., zákona č. 183/2017 Sb.,
zákona č. 225/2017 Sb., zákona č. 172/2018 Sb., zákona č. 403/2020 Sb., zákona č. 261/2021
Sb., zákona č. 284/2021 Sb., zákona č. 382/2021 Sb., zákona č. 142/2022 Sb., zákona
č. 432/2022 Sb., zákona č. 149/2023 Sb. a zákona č. 42/2025 Sb., se mění takto:
1.
V § 3 odst. 1 se za slovo „zákona“ vkládají slova „ , pro stavební úřady při výkonu
působnosti podle jiného právního předpisu“.
2.
V § 11 odst. 2 písm. b) se slova „závazné stanovisko“ nahrazují slovem „vyjádření“.
3.
V § 11 odst. 2 písm. d) se slova „závazné stanovisko“ nahrazují slovem „vyjádření“
a slovo „zastavěném“ se nahrazuje slovem „zastavitelném“.
4.
V § 11 odst. 3 se slova „závazného stanoviska“ nahrazují slovem „vyjádření“, slovo
„zastavěném“ se nahrazuje slovem „zastavitelném“ a věta poslední se zrušuje.
5.
V § 11 odst. 4 větě první se slova „souhlasné závazné stanovisko podle odstavce 2 písm.
b) nebo d)“ nahrazují slovy „povolení záměru“ a ve větě druhé se slova „Souhlasné
závazné stanovisko podle odstavce 2 písm. b) nebo d)“ nahrazují slovy „Povolení
záměru“.
6.
V § 11 odst. 6 větě první se slova „závazného stanoviska podle odstavce 2 písm. b) nebo
d)“ nahrazují slovy „povolení záměru“ a ve větě druhé se za slova „uplatní kompenzační
opatření“ vkládají slova „příslušný správní orgán v rozhodnutí o povolení záměru.
Opatření může navrhnout“ a slova „v závazném stanovisku“ se nahrazují slovy „ve
vyjádření“.
7.
V § 11 odst. 7 větě první, § 11 odst. 8 větě první a § 11 odst. 9 úvodní části ustanovení se
slova „závazného stanoviska“ nahrazují slovem „vyjádření“.
8.
V § 12 odst. 1 větě první se slova „závazného stanoviska“ nahrazují slovy „vyjádření,
povolení záměru“.
9.
V § 12 odst. 3 se slova „Závazné stanovisko“ nahrazují slovem „Vyjádření“ a slovo
„podmínky“ se nahrazuje slovy „návrh podmínek“.
10.
V § 12 odst. 5 se slovo „krajský“ nahrazuje slovem „stavební“ a slova „závazném
stanovisku“ se nahrazují slovy „povolení záměru podle stavebního zákona“.
11.
V § 12 odst. 6 se věta první zrušuje.
12.
V § 12a odst. 1 úvodní části ustanovení se slova „závazného stanoviska“ nahrazují slovy
„vyjádření, povolení záměru“.
13.
V § 12a odst. 4 se slova „závazné stanovisko“ nahrazují slovy „vyjádření, povolení
záměru“.
14.
V § 16 odst. 10 se slovo „zastavěného“ nahrazuje slovem „zastavitelného“.
15.
V § 17 odst. 1 písm. f) se slova „krajským úřadem“ nahrazují slovy „správním orgánem
příslušným k povolení záměru“.
16.
V § 19f odst. 1 písmena b) až d) znějí:
„b) 1,25 % energetických od 1. ledna 2027 do 31. prosince 2027,
c) 2 % energetických od 1. ledna 2028 do 31. prosince 2028,
d) 3,50 % energetických od 1. ledna 2029 do 31. prosince 2029,“.
17.
V § 20 odst. 1 písmena b) až d) znějí:
„b) 6,50 % od 1. ledna 2027 do 31. prosince 2027,
c) 7 % od 1. ledna 2028 do 31. prosince 2028,
d) 8 % od 1. ledna 2029 do 31. prosince 2029,“.
18.
V § 24 se na konci textu odstavce 1 doplňují slova „ , a přestupku uvedeného v § 23
odst. 1 písm. g), který projednává stavební úřad“.
19.
V § 26 odst. 1 písm. d) se text „j),“ zrušuje a na konci písmene se slovo „nebo“ zrušuje.
20.
V § 26 se na konci odstavce 1 tečka nahrazuje slovem „ , nebo“ a doplňuje se písmeno f),
které zní:
„f) stavební úřad, jde-li o přestupek podle § 25 odst. 1 písm. j).“.
21.
V § 27 odst. 1 se za písmeno e) vkládají nová písmena f) a g), která znějí:
„f) stavební úřady,
g) orgány státní báňské správy,“.
Dosavadní písmena f) až i) se označují jako písmena h) až k).
22.
V § 27 odst. 5 se za slova „krajský úřad,“ vkládají slova „stavební úřad, orgán státní
báňské správy,“.
23.
V § 30 odst. 1 písm. e) se slova „závazné stanovisko“ nahrazují slovem „vyjádření“.
24.
V § 30 odst. 1 písm. f) se slova „závazných stanoviscích“ nahrazují slovem „vyjádřeních“.
25.
V § 40 se odstavec 2 zrušuje.
Dosavadní odstavce 3 až 7 se označují jako odstavce 2 až 6.
Poznámka pod čarou č. 42 se zrušuje.
26.
V příloze č. 10 v nadpisu části B se slovo „zastavěném“ nahrazuje slovem
„zastavitelném“.
Čl. LXIX
Přechodná ustanovení
1. Řízení a postupy zahájené a neskončené přede dnem nabytí účinnosti tohoto zákona se
dokončí podle zákona č. 201/2012 Sb., ve znění účinném ode dne nabytí účinnosti tohoto
zákona, není-li stanoveno jinak.
2. Řízení a postupy zahájené a neskončené do dne vzniku Úřadu rozvoje území České
republiky (dále jen „Úřad“), k nimž je příslušný Úřad nebo jiný stavební úřad, převezme a
dokončí ode dne svého vzniku Úřad nebo jiný stavební úřad.
3. Řízení a postupy zahájené a neskončené do dne vzniku úřadů rozvoje území krajů, k
nimž je příslušný úřad rozvoje území kraje nebo jeho územní pracoviště, ode dne vzniku úřadů
rozvoje území krajů převezme a dokončí příslušný úřad rozvoje území kraje nebo jeho příslušné
územní pracoviště. Do dne vzniku úřadů rozvoje území krajů pokračují v těchto řízeních a
postupech správní orgány příslušné podle dosavadních právních předpisů podle zákona č.
201/2012 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona.
ČÁST ČTYŘICÁTÁ PÁTÁ
Změna zákona o Státním pozemkovém úřadu
Čl. LXX
Zákon č. 503/2012 Sb., o Státním pozemkovém úřadu a o změně některých souvisejících
zákonů, ve znění zákona č. 256/2013 Sb., zákona č. 280/2013 Sb., zákonného opatření Senátu
č. 340/2013 Sb., zákonného opatření Senátu č. 344/2013 Sb., zákona č. 250/2014 Sb., zákona
č. 185/2016 Sb., zákona č. 225/2017 Sb., zákona č. 295/2017 Sb., zákona č. 229/2019 Sb.,
zákona č. 481/2020 Sb., zákona č. 261/2021 Sb., zákona č. 284/2021 Sb., zákona č. 299/2021
Sb., zákona č. 325/2023 Sb., zákona č. 412/2023 Sb., zákona č. 183/2024 Sb., zákona č. 36/2025
Sb., zákona č. 231/2025 Sb. a zákona č. 287/2025 Sb., se mění takto:
1.
V § 3 odst. 4 větě první se slova „pravomocného rozhodnutí o umístění stavby“ nahrazují
slovy „pravomocného rozhodnutí o povolení záměru“ a slova „popřípadě na základě
územního souhlasu nebo veřejnoprávní smlouvy, jimiž může být rozhodnutí o umístění
stavby podle stavebního zákona nahrazeno,“ se zrušují.
2.
V § 3 odst. 5 písm. c) se slova „pravomocné rozhodnutí o umístění stavby anebo byl
vydán územní souhlas nebo byla uzavřena veřejnoprávní smlouva, jimiž může být
rozhodnutí o umístění stavby podle stavebního zákona nahrazeno, ze kterých“ nahrazují
slovy „pravomocné rozhodnutí o povolení záměru, z něhož“.
3.
V § 6 odst. 1 písm. b) úvodní části ustanovení se slova „umístění stavby“ nahrazují slovy
„povolení záměru“.
4.
V § 6 odst. 1 písm. b) bodě 4 se slova „obecní úřad obce s rozšířenou působností jako
úřad územního plánování“ nahrazují slovy „stavební úřad“.
5.
V § 7 odst. 1 písm. a), § 7 odst. 2 písm. b) a § 7 odst. 3 písm. a) se slovo „zastavěném“
nahrazuje slovem „zastavitelném“.
6.
V § 7 odst. 1 se písmeno b) zrušuje.
Dosavadní písmena c) až e) se označují jako písmena b) až d).
7.
V § 7 odst. 1 písm. b) a § 7 odst. 3 písm. c) se slova „umístění stavby“ nahrazují slovy
„povolení záměru“.
8.
V § 7 odst. 1 písm. d) a § 7 odst. 3 písm. e) se slovo „zastavěném“ nahrazuje slovem
„zastavitelném“ a slova „nebo v zastavitelné ploše8) určené“ se nahrazují slovem
„určeném“.
9.
V § 7 odst. 3 se písmeno b) zrušuje.
Dosavadní písmena c) až e) se označují jako písmena b) až d).
10.
Poznámka pod čarou č. 8 zní:
„8)
Zákon č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů.“.
11.
V § 8 odst. 1 větě první a § 8 odst. 2 větě první se slova „umístění stavby“ nahrazují slovy
„povolení záměru“.
12.
V § 8 odst. 1 větě poslední a § 8 odst. 3 se text „e)“ nahrazuje textem „d)“.
13.
V § 8 odst. 2 se slova „ , b) nebo c)“ nahrazují slovy „nebo b)“.
14.
V § 10 odst. 1 písm. a) a b) a § 10 odst. 2 se slovo „zastavěném“ nahrazuje slovem
„zastavitelném“ a slova „nebo v zastavitelné ploše“ se zrušují.
15.
V § 10 odst. 1 písm. a) se slova „umístění stavby“ nahrazují slovy „povolení záměru“.
16.
V § 21 se odstavec 4 zrušuje.
ČÁST ČTYŘICÁTÁ ŠESTÁ
Změna zákona o prevenci závažných havárií
Čl. LXXI
Zákon č. 224/2015 Sb., o prevenci závažných havárií způsobených vybranými
nebezpečnými chemickými látkami nebo chemickými směsmi a o změně zákona č. 634/2004
Sb., o správních poplatcích, ve znění pozdějších předpisů, (zákon o prevenci závažných
havárií), ve znění zákona č. 183/2017 Sb., zákona č. 225/2017 Sb., zákona č. 261/2021 Sb.,
zákona č. 284/2021 Sb., zákona č. 149/2023 Sb. a zákona č. 218/2025 Sb., se mění takto:
1.
V § 31 odst. 1 větě první se slovo „krajskému“ nahrazuje slovem „stavebnímu“ a slova
„o vydání jednotného environmentálního stanoviska30)“ se nahrazují slovy „o povolení
záměru“.
2.
V § 31 odst. 2 větě první se slovo „Krajský“ nahrazuje slovem „Stavební“, za slovo „a“
se vkládají slova „rozhodnutím o záměru“ a ve větě poslední se slovo „krajský“ nahrazuje
slovem „stavební“.
3.
V § 31 odst. 3 se slovo „Krajský“ nahrazuje slovem „Stavební“.
4.
V § 31 se doplňuje odstavec 4, který zní:
„(4) V rozhodnutí o záměru stanoví stavební úřad s ohledem na požadavky tohoto zákona
podmínky pro umístění a provedení nového objektu, jakož i jeho uvedení do zkušebního
provozu nebo užívání v případě, že se zkušební provoz neprovádí.“.
5.
V § 32 odst. 1 se slovo „krajskému“ nahrazuje slovem „stavebnímu“, slova „uvedením
do užívání podle stavebního zákona16)“ se nahrazují slovy „vydáním kolaudačního
rozhodnutí“ a na konci odstavce se doplňuje věta „Kolaudačním rozhodnutím stavební
úřad rozhodne o návrhu na schválení bezpečnostního programu nebo bezpečnostní zprávy
a toto rozhodnutí zašle po právní moci na vědomí krajskému úřadu.“.
6.
V § 32 odst. 2 se věta první zrušuje.
7.
V § 43 se za písmeno e) vkládá nové písmeno f), které zní:
„f) stavební úřady,“.
Dosavadní písmena f) až h) se označují jako písmena g) až i).
8.
V § 49 odstavce 2 a 3 znějí:
„(2) Krajský úřad je dotčeným orgánem na úseku prevence závažných havárií při
projednávání územně plánovací dokumentace.
(3) Krajský úřad zajišťuje, aby se při územním plánování braly v úvahu cíle prevence
závažných havárií a omezení jejich následků při udržování vzájemných odstupů mezi objekty
a obytnými oblastmi, budovami a oblastmi navštěvovanými veřejností, hlavními dopravními
trasami, rekreačními oblastmi a územími chráněnými podle jiných právních předpisů22).“.
9.
V § 49 se odstavce 4 a 5 zrušují.
Dosavadní odstavce 6 a 7 se označují jako odstavce 4 a 5.
10.
Za § 49 se vkládá nový § 49a, který včetně nadpisu zní:
„§ 49a
Stavební úřady
(1) Stavební úřady
a) rozhodnutím o záměru podle stavebního zákona rozhodují o zařazení objektu do skupiny
A nebo do skupiny B podle § 31 odst. 2 a o podmínkách jejich umístění, provedení, uvedení
do zkušebního provozu nebo užívání v případě, že se zkušební provoz neprovádí,
b) kolaudačním rozhodnutím rozhodují o návrhu na schválení bezpečnostního programu nebo
bezpečnostní zprávy podle § 32 odst. 1,
c) zajišťují zpracování posudku k posouzení rizik podle § 31 odst. 3,
d) zasílají ministerstvu návrhy a jiné dokumenty předkládané jim provozovatelem podle
tohoto zákona, včetně svých rozhodnutí týkajících se těchto návrhů a jiných dokumentů,
e) rozhodnutím o záměru podle stavebního zákona stanoví podmínky pro záměr, nacházející
se v dosahu havarijních projevů, které jsou specifikované v příslušném posouzení rizik
závažné havárie objektu zařazeného do skupiny A nebo do skupiny B, pokud realizace
záměru může způsobit nebo zvýšit riziko závažné havárie nebo zhoršit její následky.
(2) Stavební úřady zajišťují, aby se při povolování záměrů podle stavebního zákona braly
v úvahu cíle prevence závažných havárií a omezení jejich následků zejména při
a) udržování vzájemných odstupů mezi objekty a obytnými oblastmi, budovami a oblastmi
navštěvovanými veřejností, hlavními dopravními trasami, rekreačními oblastmi a územími
chráněnými podle jiných právních předpisů22),
b) povolování nových záměrů situovaných v dosahu havarijních projevů, které jsou
specifikované v příslušném posouzení rizik závažné havárie objektu zařazeného do skupiny
A nebo do skupiny B.“.
11.
V § 51 odst. 2 se na konci textu písmene a) doplňují slova „nebo stavebnímu úřadu“.
12.
V § 51 odst. 2 písm. d) se slovo „krajskému“ nahrazuje slovem „stavebnímu“.
13.
V § 51 odst. 3 písm. b) a § 51 odst. 4 písm. b) se za slovo „úřadu“ vkládají slova „nebo
stavebnímu úřadu“.
14.
V § 53 se odstavec 3 včetně poznámky pod čarou č. 30 zrušuje.
15.
V § 54 odst. 2 se slova „průmyslu a obchodu“ nahrazují slovem „hospodářství“.
Čl. LXXII
Přechodná ustanovení
1. Řízení a postupy zahájené a neskončené přede dnem nabytí účinnosti tohoto zákona se
dokončí podle zákona č. 224/2015 Sb., ve znění účinném ode dne nabytí účinnosti tohoto
zákona.
2. Řízení a postupy zahájené a neskončené do dne vzniku Úřadu rozvoje území České
republiky (dále jen „Úřad“), k nimž je příslušný Úřad nebo jiný stavební úřad, převezme a
dokončí ode dne svého vzniku Úřad nebo jiný stavební úřad.
3. Řízení a postupy zahájené a neskončené do dne vzniku úřadů rozvoje území krajů,
k nimž je příslušný úřad rozvoje území kraje nebo jeho územní pracoviště, ode dne vzniku
úřadů rozvoje území krajů převezme a dokončí příslušný úřad rozvoje území kraje nebo jeho
příslušné územní pracoviště. Do dne vzniku úřadů rozvoje území krajů pokračují v těchto
řízeních a postupech správní orgány příslušné podle dosavadních právních předpisů podle
zákona č. 224/2015 Sb., ve znění účinném přede dnem nabytí účinnosti tohoto zákona.
ČÁST ČTYŘICÁTÁ SEDMÁ
Změna zákona o zadávání veřejných zakázek
Čl. LXXIII
Zákon č. 134/2016 Sb., o zadávání veřejných zakázek, ve znění zákona č. 368/2016 Sb.,
zákona č. 147/2017 Sb., zákona č. 183/2017 Sb., zákona č. 287/2018 Sb., zákona č. 277/2019
Sb., zákona č. 309/2019 Sb., zákona č. 527/2020 Sb., zákona č. 543/2020 Sb., zákona
č. 174/2021 Sb., zákona č. 417/2021 Sb., zákona č. 240/2022 Sb., zákona č. 166/2023 Sb.,
zákona č. 412/2023 Sb., zákona č. 238/2024 Sb., zákona č. 469/2024 Sb. a zákona č. 69/2025
Sb., se mění takto:
1.
V § 18 odst. 2 větě první se za slovo „celek“ vkládají slova „v jedné konkrétní věci nebo
v jednom případu“.
2.
V § 19 se za odstavec 2 vkládá nový odstavec 3, který zní:
„(3) Za dodávky nebo služby stejného druhu se považují po sobě jdoucí dodávky nebo
služby zajišťované za stejným účelem stejným okruhem dodavatelů s obdobnou specializací,
na jejichž výběr zadavatel použije obdobná kvalifikační a hodnotící kritéria.“.
Dosavadní odstavec 3 se označuje jako odstavec 4.
3.
V § 30 se na konci písmene p) slovo „nebo“ zrušuje.
4.
V § 30 se na konci písmene q) tečka nahrazuje čárkou a doplňují se písmena r) až u), která
včetně poznámek pod čarou č. 58 až 60 znějí:
„r) zadanou na základě plánovací smlouvy podle stavebního zákona58),
s) jde-li o provedení nařízeného opatření k nápravě stavebním úřadem podle stavebního
zákona59),
t)
zadávanou společenství podle energetického zákona60) jeho členem za účelem souvisejícím
se zajišťováním jeho energetických potřeb, nebo
u) jejímž předmětem je sdílení elektřiny členem společenství podle energetického zákona60)
tomuto společenství, sdílení elektřiny členem společenství podle energetického zákona60)
jinému členu tohoto společenství nebo sdílení elektřiny zákazníkovi mimo společenství.
_________________
58)
§ 130 zákona č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů.
59)
§ 296 zákona č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů.
60)
Zákon č. 458/2000 Sb., o podmínkách podnikání a o výkonu státní správy v
energetických odvětvích a o změně některých zákonů (energetický zákon), ve znění
pozdějších předpisů.“.
5.
Poznámka pod čarou č. 32 zní:
 „32)
§ 166 zákona č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů.“.
ČÁST ČTYŘICÁTÁ OSMÁ
Změna atomového zákona
Čl. LXXIV
V § 108 odst. 1, § 111 odst. 2 písm. d), § 113 odst. 1, § 160 odst. 5, § 206 písm. c), § 212,
§ 234 odst. 3 a § 237 odst. 1 a 3 zákona č. 263/2016 Sb., atomový zákon, ve znění zákona
č. 183/2017 Sb., zákona č. 403/2020 Sb., zákona č. 261/2021 Sb., zákona č. 284/2021 Sb.,
zákona č. 465/2023 Sb. a zákona č. 83/2025 Sb., se slova „průmyslu a obchodu“ nahrazují
slovem „hospodářství“.
ČÁST ČTYŘICÁTÁ DEVÁTÁ
Změna zákona o odpadech
Čl. LXXV
Zákon č. 541/2020 Sb., o odpadech, ve znění zákona č. 261/2021 Sb., zákona č. 284/2021
Sb., zákona č. 149/2023 Sb., nálezu Ústavního soudu, vyhlášeného pod č. 104/2025 Sb.
a zákona č. 218/2025 Sb., se mění takto:
1.
V § 8 odst. 2, § 9 odst. 2 a 7, § 10 odst. 5 a 7, § 126 písm. b), v nadpisu § 129 a v § 129
se slova „průmyslu a obchodu“ nahrazují slovem „hospodářství“.
2.
V § 21 odst. 2 se věta poslední zrušuje.
3.
V § 30 se odstavec 5 zrušuje.
Dosavadní odstavec 6 se označuje jako odstavec 5.
4.
V § 93a odst. 1 se slova „obecnímu úřadu obce s rozšířenou působností“ nahrazují slovy
„stavebnímu úřadu“.
5.
V § 93a se odstavec 2 včetně poznámky pod čarou č. 26 zrušuje a zároveň se zrušuje
označení odstavce 1.
6.
V § 126 se za písmeno k) vkládá nové písmeno l), které zní:
„l) stavební úřady,“.
Dosavadní písmena l) až n) se označují jako písmena m) až o).
7.
V § 146 odstavec 3 zní:
„(3) Obecní úřad obce s rozšířenou působností vydává vyjádření k žádosti o zřízení zařízení
určeného pro nakládání s odpady a k žádosti o zavedení nebo rozšíření výroby oxidu titaničitého
z hlediska jejich souladu s povinnostmi vyplývajícími z tohoto zákona a prováděcích právních
předpisů.“.
8.
V § 146 se odstavce 4 a 5 zrušují.
9.
Za § 146 se vkládá nový § 146a, který včetně nadpisu zní:
„§ 146a
Stavební úřad
Stavební úřad v rozhodnutí o záměru podle stavebního zákona posuzuje splnění požadavků
tohoto zákona a jeho prováděcích právních předpisů při provedení záměru, zejména z hlediska
nakládání s odpady, vedlejšími produkty, stavebními výrobky, které přestaly být odpadem,
nebo stavebními výrobky určenými k opětovnému použití; v rozhodnutí může stanovit
podmínky, které zajistí ochranu zdraví a životního prostředí a dodržení hierarchie odpadového
hospodářství.“.
10.
V § 148 odst. 1 písm. b) se slova „až 5“ nahrazují slovy „a 3“.
11.
§ 149 se včetně nadpisu zrušuje.
12.
V § 151 se odstavec 2 zrušuje a zároveň se zrušuje označení odstavce 1.
Čl. LXXVI
Přechodná ustanovení
1. Řízení a postupy zahájené a neskončené přede dnem nabytí účinnosti tohoto zákona se
dokončí podle zákona č. 541/2020 Sb., ve znění účinném ode dne nabytí účinnosti tohoto
zákona.
2. Řízení a postupy zahájené a neskončené do dne vzniku Úřadu rozvoje území České
republiky (dále jen „Úřad“), k nimž je příslušný Úřad nebo jiný stavební úřad, převezme a
dokončí ode dne svého vzniku Úřad nebo jiný stavební úřad.
3. Řízení a postupy zahájené a neskončené do dne vzniku úřadů rozvoje území krajů,
k nimž je příslušný úřad rozvoje území kraje nebo jeho územní pracoviště, ode dne vzniku
úřadů rozvoje území krajů převezme a dokončí příslušný úřad rozvoje území kraje nebo jeho
příslušné územní pracoviště. Do dne vzniku úřadů rozvoje území krajů pokračují v těchto
řízeních a postupech správní orgány příslušné podle dosavadních právních předpisů podle
zákona č. 541/2020 Sb., ve znění účinném přede dnem nabytí účinnosti tohoto zákona.
ČÁST PADESÁTÁ
Změna zákona o zvláštních postupech v oblasti územního plánování a stavebního řádu
v souvislosti s ozbrojeným konfliktem na území Ukrajiny vyvolaným invazí vojsk Ruské
federace
Čl. LXXVII
V § 4 odst. 2 zákona č. 197/2022 Sb., o zvláštních postupech v oblasti územního plánování
a stavebního řádu v souvislosti s ozbrojeným konfliktem na území Ukrajiny vyvolaným invazí
vojsk Ruské federace, se slovo „zastavěném“ nahrazuje slovem „zastavitelném“ a slova
„ , zastavitelné ploše nebo ploše přestavby“ se zrušují.
ČÁST PADESÁTÁ PRVNÍ
Změna zákona, kterým se mění některé zákony v souvislosti s přijetím zákona o
jednotném environmentálním stanovisku
Čl. LXXVIII
Zákon č. 149/2023 Sb., kterým se mění některé zákony v souvislosti s přijetím zákona
o jednotném environmentálním stanovisku, ve znění zákona č. 465/2023 Sb., se mění takto:
1.
V části páté čl. VII bodě 2 se na konci textu písmene b) doplňují slova „ , s výjimkou
případů podle bodu 5“.
2.
V části páté se na konci čl. VII doplňuje bod 5, který zní:
„5. Příslušnost k posuzování vlivů záměru na životní prostředí se v případě, kdy po nabytí
účinnosti tohoto zákona došlo ke zrušení stanoviska k posouzení vlivů provedení záměru na
životní prostředí vydaného podle § 10 zákona č. 100/2001 Sb., ve znění účinném do 31. března
2015, nebo závazného stanoviska k posouzení vlivů provedení záměru na životní prostředí
vydaného podle § 9a zákona č. 100/2001 Sb., ve znění účinném od 1. dubna 2015 do dne nabytí
účinnosti tohoto zákona, a vrácení věci k novému projednání, řídí zákonem č. 100/2001 Sb. ve
znění účinném ode dne nabytí účinnosti tohoto zákona.“.
ČÁST PADESÁTÁ DRUHÁ
Změna zákona č. 465/2023 Sb., kterým se mění zákon č. 416/2009 Sb., o urychlení
výstavby dopravní, vodní a energetické infrastruktury a infrastruktury elektronických
komunikací (liniový zákon), ve znění pozdějších předpisů, a další související zákony
Čl. LXXIX
Zákon č. 465/2023 Sb., kterým se mění zákon č. 416/2009 Sb., o urychlení výstavby
dopravní, vodní a energetické infrastruktury a infrastruktury elektronických komunikací
(liniový zákon), ve znění pozdějších předpisů, a další související zákony, ve znění zákona č.
182/2024 Sb., se mění takto:
1.
V čl. VIII bodě 1 se za slova „regionální dráhy“ vkládají slova „ , speciální dráhy“.
2.
V čl. VIII se za bod 2 vkládá nový bod 3, který zní:
„3. Stanovisko k posouzení vlivů provedení záměru na životní prostředí podle § 10
zákona č. 100/2001 Sb., ve znění účinném do 31. března 2015, nebo závazné stanovisko
k posouzení vlivů provedení záměru na životní prostředí podle § 9a zákona č. 100/2001
Sb., ve znění účinném od 1. dubna 2015 do dne nabytí účinnosti tohoto zákona, vydané
pro záměr speciální dráhy, které je podle bodu 2 platné do 31. prosince 2026, se považuje
pro účely prodloužení jeho platnosti podle bodu 1 za stanovisko nebo závazné stanovisko,
jehož platnost trvá do 31. prosince 2026. Žádost o prodloužení platnosti stanoviska nebo
závazného stanoviska podle věty první lze podat nejpozději dne 31. prosince 2026.“.
Dosavadní bod 3 se označuje jako bod 4.
ČÁST PADESÁTÁ TŘETÍ
Změna zákona č. 182/2024 Sb., kterým se mění zákon č. 254/2001 Sb., o vodách a o
změně některých zákonů (vodní zákon)
Čl. LXXX
V čl. II bodu 5 zákona č. 182/2024 Sb., kterým se mění zákon č. 254/2001 Sb., o vodách a
o změně některých zákonů (vodní zákon), ve znění pozdějších předpisů, zákon č. 114/1992 Sb.,
o ochraně přírody a krajiny, ve znění pozdějších předpisů, a zákon č. 465/2023 Sb., kterým se
mění zákon č. 416/2009 Sb., o urychlení výstavby dopravní, vodní a energetické infrastruktury
a infrastruktury elektronických komunikací (liniový zákon), ve znění pozdějších předpisů, a
další související zákony, se slova „2 let“ nahrazují slovy „4 let“.
ČÁST PADESÁTÁ ČTVRTÁ
Změna zákona o urychlení využívání některých obnovitelných zdrojů energie
Čl. LXXXI
Zákon č. 249/2025 Sb., o urychlení využívání některých obnovitelných zdrojů energie
a o změně souvisejících zákonů (zákon o urychlení využívání obnovitelných zdrojů energie),
se mění takto:
1.
V § 12 odst. 1 se slova „na společném jednání a“ zrušují.
2.
V § 12 odst. 2 se číslo „94“ nahrazuje číslem „95“.
3.
V nadpisu § 13 se slova „orgánu příslušného podle zákona o jednotném
environmentálním stanovisku“ nahrazují slovy „stavebního úřadu k územnímu
opatření“.
4.
V § 13 odstavec 1 zní:
„(1) Stavební úřad uplatní stanovisko podle § 54 odst. 2 stavebního zákona k návrhu
územního opatření a ve vztahu ke správním úkonům uvedeným v odstavcích 2 až 4 je dotčeným
orgánem při jeho pořizování a změnách; příslušnost dotčených orgánů podle jiných právních
předpisů tímto není dotčena.“.
5.
V § 13 odst. 2 úvodní části ustanovení se slova „příslušného orgánu“ nahrazují slovy
„stavebního úřadu“.
6.
V § 13 se za odstavec 2 vkládá nový odstavec 3, který zní:
„(3) Zahrnuje-li akcelerační oblast pozemky, které jsou součástí zemědělského půdního
fondu nebo pozemků určených k plnění funkcí lesa, navrhne stavební úřad ve stanovisku podle
odstavce 1 také podmínky, při jejichž splnění lze odejmout zemědělskou půdu ze zemědělského
půdního fondu podle zákona o ochraně zemědělského půdního fondu nebo odejmout pozemky
plnění funkcí lesa nebo omezit využívání pozemků pro plnění funkcí lesa podle lesního
zákona.“.
Dosavadní odstavce 3 až 5 se označují jako odstavce 4 až 6.
7.
V § 13 odst. 4 se slova „Příslušný orgán“ nahrazují slovy „Stavební úřad“ a slova
„odstavce 2“ se nahrazují slovy „odstavců 2 a 3“.
8.
V § 13 se odstavec 5 zrušuje.
Dosavadní odstavec 6 se označuje jako odstavec 5.
9.
V § 13 odst. 5 větě první se za slovo „obvodů“ vkládají slova „stavebních úřadů“, slova
„příslušný orgán“ se nahrazují slovy „stavební úřad“, slova „příslušné orgány“ se
nahrazují slovy „stavební úřady“ a ve větě druhé se slova „Příslušný orgán“ nahrazují
slovy „Stavební úřad“ a slovo „orgány“ se nahrazuje slovy „stavebními úřady“.
10.
§ 18 včetně nadpisu zní:
„§ 18
Pravidelné vyhodnocení uplatňování akcelerační oblasti
(1) Pořizovatel nejpozději do 4 let od vymezení akcelerační oblasti v územně plánovací
dokumentaci, a poté pravidelně nejméně jednou za 4 roky vyhodnotí uplatňování akcelerační
oblasti, případně všech akceleračních oblastí vymezených ve stejné územně plánovací
dokumentaci.
(2) Ve vyhodnocení uplatňování akcelerační oblasti pořizovatel zejména vyhodnotí
potřebu pořízení změny územně plánovací dokumentace spočívající ve zrušení nebo změně
vymezené akcelerační oblasti nebo vymezení nové akcelerační oblasti a potřebu zrušení, změny
nebo stanovení nových podmínek a zmírňujících opatření v územním opatření.
(3) Stavební úřad a vodoprávní úřad vydávají k vyhodnocení uplatňování akcelerační
oblasti podle odstavce 2 vyjádření, ve kterém posoudí, zda se objevily nové skutečnosti
vyvolávající potřebu změny podmínek a zmírňujících opatření stanovených na základě
stanoviska podle § 13 a stanoviska vodoprávního úřadu podle § 14.
(4) Vyplyne-li z vyhodnocení podle odstavce 2 potřeba pořízení změny územně plánovací
dokumentace je součástí vyhodnocení návrh obsahu změny územně plánovací dokumentace.
(5) Je-li výsledkem vyhodnocení podle odstavce 2 nebo vyjádření podle odstavce 3
zjištění, že stanovené podmínky a zmírňující opatření přestaly být dostačující, je součástí
vyhodnocení podle odstavce 2 návrh na pořízení změny územního opatření nebo vydání nového
územního opatření. Ustanovení § 88 až 90 stavebního zákona se použijí obdobně i ve vztahu
k návrhu na pořízení změny územního opatření.
(6) Při pořízení změny územního opatření se dále postupuje
a) obdobně podle § 11 až 14 v případě podle § 17 odst. 1 písm. a), nebo
b) obdobně podle § 16 odst. 3 a 4 v případě podle § 17 odst. 1 písm. b).
(7) Při pořízení nového územního opatření se dále postupuje obdobně podle § 16.“.
11.
V § 19 odst. 1 se slova „Nejde-li o změnu územního opatření pořizovanou na základě
zprávy o uplatňování územně plánovací dokumentace, schvalující“ nahrazují slovem
„Schvalující“.
12.
V § 19 odst. 2 se slova „Ministerstva pro místní rozvoj“ nahrazují slovy „Úřadu rozvoje
území České republiky“.
13.
V § 23 odst. 2 se slova „příslušný orgán“ nahrazují slovy „stavební úřad“.
14.
V § 24 odstavec 2 zní:
„(2) Pořizovatel nejpozději do 4 let od vymezení akcelerační oblasti v územním plánu bez
územního opatření, a poté pravidelně nejméně jednou za 4 roky vyhodnotí uplatňování
akcelerační oblasti. Ustanovení § 18 se použije obdobně. V případech podle § 18 odst. 4 nebo
5 je součástí vyhodnocení uplatňování akcelerační oblasti
a) návrh na pořízení změny územního plánu, jsou-li splněny podmínky podle § 22 odst. 1,
b) návrh na pořízení změny územního plánu a pořízení územního opatření, nejsou-li splněny
podmínky podle § 22 odst. 1.“.
15.
V nadpisu § 26 se slova „vydání jednotného environmentálního stanoviska“ nahrazují
slovy „povolení záměru“.
16.
V § 26 odst. 1 úvodní části ustanovení se slova „vydání jednotného environmentálního
stanoviska“ nahrazují slovy „povolení záměru podle stavebního zákona“ a slova
„zákonem o jednotném environmentálním stanovisku“ se nahrazují slovy „jinými
právními předpisy“.
17.
V § 26 odst. 2 se slova „vydání jednotného environmentálního stanoviska“ nahrazují
slovy „povolení záměru podle stavebního zákona“.
18.
V nadpisu § 27 se slova „jednotné environmentální stanovisko“ nahrazují slovy
„povolení záměru“.
19.
V § 27 odst. 1 se slova „vydání jednotného environmentálního stanoviska“ nahrazují
slovy „povolení záměru podle stavebního zákona“ a slova „příslušný orgán“ se nahrazují
slovy „stavební úřad“.
20.
V § 27 odst. 2 se slova „příslušný orgán“ nahrazují slovy „stavební úřad“ a slova
„jednotné environmentální stanovisko“ se nahrazují slovy „povolení záměru podle
stavebního zákona“.
21.
V § 27 odst. 3 se slova „jednotného environmentálního stanoviska a lhůty uvedené v § 28“
nahrazují slovy „povolení záměru podle stavebního zákona“.
22.
V § 27 odst. 4 se slova „příslušný orgán“ nahrazují slovy „stavební úřad“.
23.
V § 28 odstavce 1 a 2 znějí:
„(1) Jedná-li se o záměr pro využití obnovitelného zdroje energie v akcelerační oblasti,
který podléhá posuzování vlivů podle zákona o posuzování vlivů na životní prostředí, stavební
úřad postoupí bezvadnou žádost o povolení záměru podle stavebního zákona společně
s hodnocením podle § 67 zákona o ochraně přírody a krajiny, provádí-li se, příslušnému úřadu
s žádostí o posouzení podmínek pro výjimku z posouzení vlivů záměru na životní prostředí.
(2) Příslušný úřad na žádost stavebního úřadu posoudí, zda je
a) záměr předmětem posuzování vlivů na životní prostředí přesahujících hranice České
republiky podle § 11 odst. 1 písm. a) nebo b) zákona o posuzování vlivů na životní prostředí
a
b) s ohledem na ekologickou citlivost území, v němž se nachází, vysoce pravděpodobné, že
záměr pro využití obnovitelného zdroje energie povede k významným nepříznivým vlivům
na životní prostředí nebo veřejné zdraví, které nebyly zjištěny při pořizování územního
opatření a které nelze vyloučit dodatečnými podmínkami a zmírňujícími opatřeními
navrženými žadatelem nebo postupem podle § 27 odst. 3 ve spojení s § 30 odst. 1.“.
24.
V § 28 odst. 3 větě první a poslední se slovo „orgán“ nahrazuje slovem „úřad“ a ve větě
druhé se slovo „orgánem“ nahrazuje slovem „úřadem“.
25.
V § 28 odst. 4 větě první se slovo „orgán“ nahrazuje slovem „úřad“ a ve větě druhé se
slovo „orgánem“ nahrazuje slovem „úřadem“.
26.
V § 28 odst. 5 se věta první nahrazuje větou „Je-li dána některá z okolností podle odstavce
2, příslušný úřad vydá do 45 dnů ode dne doručení žádosti stavebního úřadu podle
odstavce 1 rozhodnutí o tom, že záměr pro využití obnovitelného zdroje energie podléhá
posouzení vlivů záměru na životní prostředí.“, ve větě druhé se slovo „orgán“ nahrazuje
slovem „úřad“ a na konci odstavce se doplňuje věta „Příslušný úřad informuje o vydání
rozhodnutí bezodkladně stavební úřad.“.
27.
V § 28 odst. 6 větě první se slovo „orgán“ nahrazuje slovem „úřad“ a za větu první se
vkládá věta „Shledá-li příslušný úřad před uběhnutím lhůty podle odstavce 5, že záměr
pro využití obnovitelného zdroje nepodléhá posouzení vlivů záměru na životní prostředí,
sdělí tuto skutečnost bezodkladně stavebnímu úřadu.“.
28.
V § 29 odst. 1 větě první se slovo „orgánu“ nahrazuje slovem „úřadu“ a ve větě třetí se
slovo „orgán“ nahrazuje slovem „úřad“ a číslo „1“ se nahrazuje číslem „2“.
29.
V § 29 se odstavec 3 zrušuje.
Dosavadní odstavec 4 se označuje jako odstavec 3.
30.
V § 29 odst. 3 větě první se slova „Při postupu podle odstavce 3 je příslušný orgán povinen
vydat jednotné environmentální stanovisko“ nahrazují slovy „Příslušný úřad je povinen
vydat závazné stanovisko k posouzení vlivů provedení záměru na životní prostředí“, ve
větě druhé se slova „jednotného environmentálního“ nahrazují slovem „závazného“
a slovo „orgán“ se nahrazuje slovem „úřad“, ve větě třetí se slovo „orgán“ nahrazuje
slovem „úřad“ a na konci odstavce se doplňuje věta „Vydané závazné stanovisko zašle
příslušný úřad bezodkladně stavebnímu úřadu.“.
31.
V § 30 odstavce 2 a 3 znějí:
„(2) Součástí rozhodnutí o povolení záměru pro využití obnovitelného zdroje energie
v akcelerační oblasti je posouzení souladu tohoto záměru s podmínkami a zmírňujícími
opatřeními z oblasti ochrany životního prostředí stanovenými v územním opatření nebo
v územním plánu podle § 22.
(3) Stavební úřad může stanovit jako podmínky pro povolení záměru dodatečná opatření
navržená žadatelem podle § 26 odst. 2.“.
32.
V § 31 se dosavadní text označuje jako odstavec 1 a doplňuje se odstavec 2, který zní:
„(2) Lhůta podle odstavce 1 neběží po dobu od postoupení žádosti podle § 28 odst. 1
příslušnému úřadu do
a) doručení sdělení podle § 28 odst. 6 nebo uplynutí lhůty podle § 28 odst. 5, nevydá-li
příslušný úřad v této lhůtě rozhodnutí o tom, že záměr pro využití obnovitelného zdroje
energie podléhá posouzení vlivů záměru na životní prostředí, nebo
b) doručení závazného stanoviska podle § 29 odst. 3.“.
33.
V § 32 odst. 1 písm. a) a § 32 odst. 2 písm. a) se slova „jednotné environmentální
stanovisko nebo o společné rozhodnutí“ nahrazují slovy „povolení záměru podle
stavebního zákona nebo o společné závazné stanovisko“.
34.
V§ 32 odst. 1 se písmeno b) zrušuje.
Dosavadní písmeno c) se označuje jako písmeno b).
35.
V § 32 odst. 2 se písmeno b) zrušuje.
Dosavadní písmeno c) se označuje jako písmeno b).
36.
V § 32 odst. 3 úvodní části ustanovení se slova „Příslušný orgán“ nahrazují slovy
„Stavební úřad“ a slova „§ 6 odst. 2 písm. c) zákona o jednotném environmentálním
stanovisku“ se nahrazují slovy „stavebního zákona“.
37.
V § 32 odst. 4 se slovo „rozhodnutí“ nahrazuje slovy „závazné stanovisko“ a slovo
„rozhodnutím“ se nahrazuje slovy „závazným stanoviskem“.
38.
V § 36 odst. 1 se slova „ , stavebního zákona a zákona o jednotném environmentálním
stanovisku“ nahrazují slovy „a stavebního zákona“.
39.
V § 37 odst. 6 se slova „postupuje se“ nahrazují slovy „postupuje stavební úřad
a příslušný úřad“ a část věty za středníkem se včetně středníku zrušuje.
Čl. LXXXII
Přechodná ustanovení
1. Jde-li o záměr pro využití obnovitelného zdroje energie, který není vyhrazenou stavbou,
použijí se do 31. prosince 2027 ustanovení hlavy III a IV, § 36 odst. 1 a § 37 odst. 6 zákona č.
249/2025 Sb., ve znění účinném přede dnem nabytí účinnosti tohoto zákona.
2. Do 31. prosince 2027 uplatní stanovisko podle § 13 zákona č. 249/2025 Sb., ve znění
účinném přede dnem nabytí účinnosti tohoto zákona, a vyjádření podle § 18 odst. 3 zákona
č. 249/2025 Sb., ve znění účinném ode dne nabytí účinnosti tohoto zákona, krajský úřad podle
§ 13 zákona č. 249/2025 Sb., ve znění účinném přede dnem nabytí účinnosti tohoto zákona, a
to i v případech, kdy není příslušný vydat jednotné environmentální stanovisko k záměru pro
využití obnovitelného zdroje energie v akcelerační oblasti.
ČÁST PADESÁTÁ PÁTÁ
Změna zákona o správě informací o stavbě a vystavěném prostředí
Čl. LXXXIII
Zákon č. 330/2025 Sb., o správě informací o stavbě a vystavěném prostředí a o změně
některých dalších zákonů, se mění takto:
1.
V § 7 se za odstavec 4 vkládá nový odstavec 5, který zní:
„(5) Informační kontejner podle odstavce 2 písm. a) se vkládá do evidence elektronických
dokumentací podle stavebního zákona, a to nejpozději s podáním žádosti o povolení záměru5).
Informační kontejner podle odstavce 2 písm. c) se vkládá do evidence elektronických
dokumentací podle stavebního zákona, a to nejpozději s podáním žádosti o vydání kolaudačního
rozhodnutí7).“.
Dosavadní odstavec 5 se označuje jako odstavec 6.
2.
V § 17 odst. 1 se číslo „5“ nahrazuje číslem „6“.
3.
V § 18 větě první se slovo „bude“ nahrazuje slovem „bylo“ a text „c)“ se nahrazuje textem
„d)“ a věta druhá se zrušuje.
ČÁST PADESÁTÁ ŠESTÁ
ZRUŠOVACÍ USTANOVENÍ
Čl. LXXXIV
Zrušují se:
1.
Zákon č. 148/2023 Sb., o jednotném environmentálním stanovisku.
2.
Část šestá zákona č. 465/2023 Sb., kterým se mění zákon č. 416/2009 Sb., o urychlení
výstavby dopravní, vodní a energetické infrastruktury a infrastruktury elektronických
komunikací (liniový zákon), ve znění pozdějších předpisů, a další související zákony.
3.
Část sedmá zákona č. 223/2025 Sb., kterým se mění zákon č. 458/2000 Sb., o podmínkách
podnikání a o výkonu státní správy v energetických odvětvích a o změně některých
zákonů (energetický zákon), ve znění pozdějších předpisů, a další související zákony.
4.
Část šestá zákona č. 249/2025 Sb., o urychlení využívání některých obnovitelných zdrojů
energie a o změně souvisejících zákonů (zákon o urychlení využívání obnovitelných
zdrojů energie).
5.
Vyhláška č. 583/2020 Sb., kterou se stanoví podrobnosti obsahu dokumentace pro vydání
společného povolení u staveb dopravní infrastruktury.
6.
Vyhláška č. 130/2024 Sb., o stanovení obecních stavebních úřadů.
7.
Vyhláška č. 421/2024 Sb., kterou se mění vyhláška č. 130/2024 Sb., o stanovení obecních
stavebních úřadů.
8.
Vyhláška č. 281/2025 Sb., kterou se mění vyhláška č. 130/2024 Sb., o stanovení obecních
stavebních úřadů, ve znění vyhlášky č. 421/2024 Sb.
9.
Vyhláška č. 131/2024 Sb., o dokumentaci staveb.
10.
Vyhláška č. 146/2024 Sb., o požadavcích na výstavbu.
11.
Vyhláška č. 149/2024 Sb., o provedení některých ustanovení stavebního zákona.
12.
Vyhláška č. 157/2024 Sb., o územně analytických podkladech, územně plánovací
dokumentaci a jednotném standardu.
13.
Vyhláška č. 457/2025 Sb., kterou se mění vyhláška č. 157/2024 Sb., o územně
analytických podkladech, územně plánovací dokumentaci a jednotném standardu.
14.
Vyhláška č. 190/2024 Sb., o podrobnostech provozu některých informačních systémů
stavební správy.
15.
Vyhláška č. 227/2024 Sb., o rozsahu a obsahu projektové dokumentace staveb dopravní
infrastruktury.
16.
Vyhláška č. 114/2023 Sb., o požadavcích na bezpečnou instalaci výrobny elektřiny
využívající obnovitelné zdroje energie s instalovaným výkonem do 50 kW.
ČÁST PADESÁTÁ SEDMÁ
ÚČINNOST
Čl. LXXXV
Tento zákon nabývá účinnosti dnem 1. ledna 2027, s výjimkou ustanovení
a) čl. I bodů 12, 404, 405, 410, 411, 417, 422 až 433, 439, 446, 447, 456 až 459, 464 až 472,
474, 475, 489, 495 až 530, 559, 560, 575, 576, 583, 584, 609 až 615, 617, 621, 641 až 687,
čl. II, čl. XIV bodů 1, 23, 34 až 46 a 49 až 52, čl. XV bodů 16 a 20, čl. XVI bodů 1 až 7,
13 až 16, 18, 19 a 35, čl. XVII bodů 6 až 8, čl. XXIX, čl. XXXII bodu 1, čl. XLV bodů 17
až 20 a 35 až 89, čl. XLVI bodů 4 až 8, čl. XLVII bodů 2 až 4, 16 až 20, 56, 57 a 65, čl.
XLVIII bodu 4, čl. LIII bodů 2 až 5, čl. LXIV bodů 19 a 25 a čl. LXXX, která nabývají
účinnosti prvním dnem kalendářního měsíce následujícího po dni jeho vyhlášení,
b) čl. I bodů 84 až 86, čl. LVII bodu 8, čl. LXXXI bodů 3 až 9 a 13 a čl. LXXXIV bodů 1
až 4, která nabývají účinnosti dnem 1. ledna 2028.
