# Základ — stavební zákon 283/2021 Sb. (e-Sbírka 2026-06-11)

Aktuálně účinné znění stavebního zákona ke dni **2026-06-11** (e-Sbírka). 341 §, 2063 řádků odstavců/písmen. Bez novelizace ze senátního tisku 272/0.

---

## Zákon č. 283/2021 Sb., stavební zákon

### ČÁST PRVNÍ

#### HLAVA I

#### § 1 — Předmět úpravy

(1) Tento zákon upravuje působnost orgánů stavební správy, orgánů územního plánování a orgánů územní samosprávy v oblasti územního plánování a stavebního řádu, stanoví cíle, úkoly a nástroje územního plánování, požadavky na výstavbu a stavební řád.

(2) Tento zákon dále upravuje podmínky pro integrovanou ochranu veřejných zájmů při územním plánování, povolování staveb a výstavbě, povinnosti osob při přípravě a provádění staveb, podmínky pro projektovou činnost a provádění staveb, některé účely vyvlastnění, oprávnění autorizovaných inspektorů a výkon kontroly.

(3) Účelem stavebního zákona je zajistit integrovanou ochranu veřejných zájmů při územním plánování, povolování staveb a výstavbě a vytvářet podmínky pro udržitelný rozvoj území a zvyšování kvality vystavěného prostředí, architektury a stavební kultury.

#### § 2 — Dotčené orgány

(1) Dotčený orgán je vázán svým předchozím stanoviskem, vyjádřením nebo závazným stanoviskem, které vydal jako podklad pro úkony podle tohoto zákona.

(2) Při pořizování navazující územně plánovací dokumentace se nepřihlíží ke stanoviskům dotčených orgánů ve věcech, o nichž bylo rozhodnuto při schválení politiky územního rozvoje a vydání nadřazené územně plánovací dokumentace.

(3) Při postupech podle části šesté se nepřihlíží k vyjádření nebo závaznému stanovisku ve věcech, o kterých bylo rozhodnuto v územně plánovací dokumentaci nebo v územním opatření.

#### § 3 — Změna podmínek

(1) Nové stanovisko, vyjádření nebo závazné stanovisko může dotčený orgán v téže věci uplatňovat pouze v rozsahu nově zjištěných skutečností, které nemohly být zjištěny dříve, nebo na základě změny právních předpisů, a pokud se jimi změnily podmínky, za kterých bylo stanovisko, vyjádření nebo závazné stanovisko vydáno, a to jen v rozsahu změny podmínek.

(2) Nové stanovisko, vyjádření nebo závazné stanovisko může dotčený orgán vydat také tehdy, pokud původní bylo vydáno na základě údajů nepravdivých, neúplných nebo zkreslených.

(3) Nové stanovisko k územně plánovací dokumentaci může dotčený orgán uplatnit také na základě skutečností vyplývajících z větší podrobnosti pořizované územně plánovací dokumentace, nebo na základě výsledku řešení rozporů.

#### HLAVA II

#### § 4 — Záměr

(1) Záměrem se v tomto zákoně rozumí stavba, soubor staveb, zařízení, údržba dokončené stavby, změna využití území, dělení nebo scelování pozemků a stanovení ochranného pásma.

(2) Záměrem EIA se v tomto zákoně rozumí záměr podle odstavce 1, který podléhá posouzení vlivů na životní prostředí podle zákona o posuzování vlivů na životní prostředí.

#### § 5 — Stavba

(1) Stavbou se v tomto zákoně rozumí stavební dílo, které vzniká stavební nebo montážní činností ze stavebních výrobků, materiálů nebo konstrukcí za účelem užívání na určitém místě. Za stavbu se považuje také výrobek plnící funkci stavby.

(2) Stavby jsou

a) drobné, které jsou uvedeny v příloze č. 1 k tomuto zákonu,

b) jednoduché, které jsou uvedeny v příloze č. 2 k tomuto zákonu,

c) vyhrazené, které jsou uvedeny v příloze č. 3 k tomuto zákonu, a

d) ostatní.

(3) Souborem staveb se v tomto zákoně rozumí vzájemně související stavby, jimiž se v rámci jednoho záměru uskutečňuje výstavba na souvislém území nebo za společným účelem.

(4) Stavbou hlavní souboru staveb se v tomto zákoně rozumí stavba, která určuje účel výstavby souboru staveb. Vedlejší stavbou v souboru staveb se v tomto zákoně rozumí stavba, která se stavbou hlavní svým účelem užívání nebo umístěním souvisí a která zabezpečuje uživatelnost stavby hlavní nebo doplňuje účel užívání stavby hlavní.

(5) Dočasnou stavbou se v tomto zákoně rozumí stavba, u které stavební úřad předem omezí dobu jejího trvání.

(6) Používá-li se v tomto zákoně pojem stavba, rozumí se tím podle okolností také její část nebo změna dokončené stavby.

#### § 6 — Změna a údržba dokončené stavby

(1) Změnou dokončené stavby se v tomto zákoně rozumí

a) nástavba, kterou se stavba zvyšuje,

b) přístavba, kterou se stavba půdorysně rozšiřuje a která je vzájemně provozně propojena s dosavadní stavbou, a

c) stavební úprava, při které se zachovává vnější půdorysné i výškové ohraničení stavby.

(2) Změnou dokončené stavby se v tomto zákoně rozumí také změna v užívání stavby spočívající ve změně v

a) způsobu užívání stavby,

b) provozním zařízení stavby,

c) způsobu výroby nebo podstatném rozšíření výroby,

d) činnosti, jejíž účinky by mohly ohrozit život nebo veřejné zdraví, život a zdraví zvířat, bezpečnost nebo životní prostředí, nebo

e) době trvání dočasné stavby, anebo změně dočasné stavby na stavbu trvalou.

(3) Údržbou dokončené stavby se v tomto zákoně rozumí udržovací práce, jimiž se zabezpečuje dobrý stavebně technický stav stavby tak, aby se co nejvíce snížilo nebezpečí výskytu závady nebo havárie stavby a nedocházelo ke znehodnocení stavby.

#### § 7 — Zařízení

(1) Zařízením se v tomto zákoně rozumí technické zařízení nebo reklamní zařízení, pokud nejde o stavbu, které vzniká za účelem užívání na určitém místě.

(2) Reklamním zařízením se v tomto zákoně rozumí panel, tabule, deska nebo konstrukce, které slouží k šíření reklamy nebo jiných informací. Reklamní zařízení o celkové ploše větší než 8 m2 se považuje za stavbu.

#### § 8 — Terénní úprava

Terénní úpravou se v tomto zákoně rozumí zemní práce a změny terénu, jimiž se podstatně mění vzhled prostředí nebo odtokové poměry, těžební a jim podobné a s nimi související práce, nejde-li o hornickou činnost nebo činnost prováděnou hornickým způsobem.

#### § 9 — Staveniště

(1) Staveništěm se v tomto zákoně rozumí místo, na kterém se provádí stavba, zařízení, terénní úprava nebo udržovací práce anebo na kterém se stavba, zařízení nebo terénní úprava odstraňuje.

(2) Staveniště zahrnuje stavební pozemek nebo jeho část anebo část stavby, popřípadě, v rozsahu vymezeném stavebním úřadem, též jiný pozemek nebo jeho část anebo část jiné stavby potřebné pro provedení nebo odstranění stavby, zařízení nebo terénní úpravy.

#### § 10 — Veřejná infrastruktura

(1) Veřejnou infrastrukturou se v tomto zákoně rozumí pozemky, stavby a zařízení sloužící veřejné potřebě, a to

a) dopravní infrastruktura, kterou jsou zejména stavby pozemních komunikací, drah, vodních cest, leteckých staveb a s nimi související stavby a zařízení,

b) technická infrastruktura, kterou jsou zejména systémy a sítě technické infrastruktury a s nimi související stavby a zařízení pro zásobování vodou, odvádění a čištění odpadních vod, energetiku, včetně výroben a zdrojů energie, zařízení pro ukládání energie, dobíjecích stanic a zásobníků plynu, produktovody a elektronické komunikace, a dále stavby a zařízení ke snižování nebezpečí v území a pro zlepšování stavu povrchových a podzemních vod nebo k nakládání s odpady,

c) zelená infrastruktura, kterou je plánovaný, převážně spojitý systém ploch a jiných prvků vegetačních, vodních a pro hospodaření s vodou, přírodního a polopřírodního charakteru, které svým cílovým stavem umožňují nebo významně podporují plnění široké škály ekosystémových služeb a funkcí; součástí zelené infrastruktury je také územní systém ekologické stability krajiny,

d) občanské vybavení, kterým jsou stavby, zařízení a pozemky sloužící k zajištění základních potřeb obyvatel, zejména pro vzdělávání, výchovu a sport, sociální a zdravotní služby, kulturu, veřejnou správu a ochranu obyvatelstva,

e) veřejná prostranství1).

(2) Sítí technické infrastruktury se v tomto zákoně rozumí liniové nebo prostorové vedení inženýrské sítě, včetně armatur, zařízení a konstrukcí na vedení a jeho koncových prvků, zabezpečující napojení na jednotlivé druhy využívaných médií.

(3) Sítě technické infrastruktury jsou podle účelu zejména energetické, vodovodní a kanalizační, elektronických komunikací a produktovody.

#### § 11 — Veřejně prospěšná stavba a opatření

(1) Veřejně prospěšnou stavbou se v tomto zákoně rozumí stavba nebo zařízení pro veřejnou infrastrukturu určená k rozvoji nebo ochraně území obce, kraje nebo státu vymezená v územně plánovací dokumentaci a stavby a zařízení s ní související nebo podmiňující její realizaci.

(2) Veřejně prospěšným opatřením se v tomto zákoně rozumí opatření nestavební povahy sloužící ke snižování nebezpečí v území, vytváření prvků územního systému ekologické stability2) a k rozvoji anebo k ochraně přírodního, kulturního a archeologického dědictví, vymezené v územně plánovací dokumentaci.

#### § 12 — Základní pojmy územního plánování

V tomto zákoně se rozumí

a) změnou v území změna jeho funkčního využití nebo prostorového uspořádání, včetně umisťování staveb nebo jejich změn,

b) stavebním pozemkem pozemek, jeho část nebo soubor pozemků vymezený a určený k zastavění,

c) zastavěným stavebním pozemkem pozemek evidovaný v katastru nemovitostí jako stavební parcela a další pozemkové parcely zpravidla pod společným oplocením tvořící souvislý funkční a prostorový celek se stavbami majícími určující funkci v tomto souvislém celku,

d) plochou část území tvořená jedním nebo více pozemky nebo jejich částmi, která je vymezena v územním rozvojovém plánu, zásadách územního rozvoje nebo územním plánu, popřípadě v územně plánovacích podkladech, s ohledem na stávající nebo požadovaný způsob využití nebo její význam,

e) koridorem území vymezené pro zpravidla liniový záměr dopravní nebo technické infrastruktury nebo opatření nestavební povahy,

f) plochou nebo koridorem celostátního významu plocha nebo koridor, které svým významem, rozsahem nebo využitím ovlivní území více krajů nebo států,

g) plochou nebo koridorem nadmístního významu plocha nebo koridor, které svým významem, rozsahem nebo využitím ovlivní území více obcí; v případě hlavního města Prahy se za plochu nebo koridor nadmístního významu považují plocha nebo koridor, které svým významem, rozsahem nebo využitím ovlivní území více městských částí,

h) zastavěným územím území vymezené samostatným postupem podle tohoto zákona (dále jen „vymezení zastavěného území“) nebo územním plánem,

i) zastavitelnou plochou plocha určená k zastavění vymezená v územním rozvojovém plánu, zásadách územního rozvoje nebo územním plánu,

j) nezastavěným územím území nezahrnuté do zastavěného území nebo do zastavitelné plochy,

k) transformační plochou plocha určená k vytvoření zcela nového charakteru území nebo k obnově znehodnoceného, nebo zanedbaného území za účelem jeho opětovného využití vymezená územním rozvojovým plánem, zásadami územního rozvoje nebo v zastavěném území územním plánem,

l) plochou změny v krajině plocha určená ke změně stávajícího využití na jiné využití nezastavěného území vymezená v nezastavěném území územním plánem,

m) uliční čarou hranice mezi pozemky a veřejným prostranstvím,

n) stavební čarou rozhraní mezi stavbou a nezastavěnou částí pozemku, která určuje polohu hrany stavby ve výši rostlého nebo upraveného terénu; stavební čára může být

1. uzavřená, která stanoví rozhraní souvisle zastavěné, v celé délce stavby, nebo

2. otevřená, která stanoví rozhraní přerušované stavebními mezerami,

o) stavební prolukou nezastavěný prostor ve stávající souvislé zástavbě, včetně nezastavěného nároží, který je určen k zastavění,

p) nadřazenou územně plánovací dokumentací se pro

1. regulační plán rozumí územní plán, zásady územního rozvoje a územní rozvojový plán,

2. územní plán rozumí zásady územního rozvoje a územní rozvojový plán,

3. zásady územního rozvoje rozumí územní rozvojový plán,

q) navazující územně plánovací dokumentací se pro

1. politiku územního rozvoje rozumí územní rozvojový plán, zásady územního rozvoje, územní plán a regulační plán,

2. územní rozvojový plán rozumí zásady územního rozvoje, územní plán a regulační plán,

3. zásady územního rozvoje rozumí územní plán a regulační plán,

4. územní plán rozumí regulační plán,

r) limitem využití území omezení změn v území z důvodu ochrany veřejných zájmů, vyplývající z právních předpisů, nebo stanovené na základě jiných právních předpisů, nebo vyplývající z vlastností území,

s) schématem výkres, ve kterém se zjednodušenou formou zobrazují jevy v měřítku menším, než je stanoveno pro jednotlivé územně plánovací dokumentace,

t) vystavěným prostředím prostředí vytvořené nebo upravené člověkem zahrnující stavby a volná prostranství veřejná i neveřejná,

u) asanací soubor opatření sloužících k ozdravění území, které vykazuje závady, zejména z důvodů hospodářských změn anebo postižení živelní pohromou nebo závažnou havárií,

v) architektonickou soutěží postup hledání nejlepšího architektonického řešení stavby anebo zhotovitele projektové dokumentace, při němž jsou předkládány a hodnoceny návrhy architektonického řešení stavby,

w) urbanistickou soutěží postup hledání nejlepšího urbanistického řešení území anebo zhotovitele územní studie nebo územně plánovací dokumentace, při němž jsou předkládány a hodnoceny návrhy urbanistického řešení území.

##### Základní pojmy stavebního řádu

#### § 13

V tomto zákoně se dále rozumí

a) budovou nadzemní stavba, včetně její podzemní části, prostorově soustředěná a navenek převážně uzavřená obvodovými stěnami a střešní konstrukcí,

b) bytovým domem stavba pro bydlení, ve které více než polovina podlahové plochy slouží bydlení,

c) rodinným domem stavba pro bydlení, ve které více než polovina podlahové plochy slouží bydlení, a která má nejvýše tři samostatné byty, nejvýše dvě nadzemní a jedno podzemní podlaží a podkroví, nebo třetí nadzemní podlaží ustoupené od vnějšího líce obvodové stěny budovy orientované k uliční čáře alespoň o 2 metry,

d) přístupností vytváření podmínek pro samostatné a bezpečné využití pozemků a staveb osobami s pohybovým, zrakovým nebo sluchovým postižením, osobami pokročilého věku, těhotnými ženami a osobami doprovázejícími dítě v kočárku nebo dítě do 3 let (dále jen „osoba s omezenou schopností pohybu nebo orientace“) s cílem bezbariérového užívání,

e) stavbou ubytovacího zařízení stavba nebo její část pro poskytování ubytování a služby s tím spojené; stavbou ubytovacího zařízení není bytový dům, rodinný dům ani stavba pro rodinnou rekreaci,

f) stavbou pro obchod stavba s prodejní plochou,

g) stavbou pro výrobu a skladování stavba pro průmyslovou, řemeslnou nebo jinou výrobu, popřípadě služby mající charakter výroby, a dále pro skladování výrobků, hmot a materiálů, kromě staveb pro skladování uvedených v písmenu h),

h) stavbou pro zemědělství stavba pro hospodářská zvířata, doprovodná stavba pro hospodářská zvířata, stavba pro rostlinnou výrobu a pro posklizňovou úpravu, stavba pro zemědělské stroje, stavba pro skladování produktů rostlinné výroby, minerálních hnojiv, přípravků a prostředků na ochranu rostlin,

i) bytem soubor místností, popřípadě jedna obytná místnost, který svým stavebně technickým uspořádáním a vybavením splňuje požadavky na trvalé bydlení,

j) bytem zvláštního určení byt upravený k bydlení osob s těžkým pohybovým postižením nebo osob s těžkým zrakovým postižením,

k) místností prostorově uzavřená část stavby, vymezená podlahou, stropem nebo konstrukcí střechy a pevnými stěnami,

l) obytnou místností část bytu, která je určena k bydlení, splňuje požadavky na bydlení z hlediska velikosti, denního osvětlení, větrání, vytápění a hluku a má podlahovou plochu nejméně 8 m2; kuchyň se za obytnou místnost považuje, pokud má podlahovou plochu nejméně 12 m2; tvoří-li byt jediná obytná místnost, musí být její podlahová plocha nejméně 16 m2,

m) pobytovou místností místnost, která svou polohou, velikostí a stavebním uspořádáním splňuje požadavky na to, aby se v ní zdržovaly osoby,

n) podlahovou plochou součet ploch vymezených vnitřním lícem svislých konstrukcí jednotlivých místností a prostorů stavebně upravených k účelovému využití v budově; v podlažích se šikmými stěnami nebo šikmým stropem je vymezena vnitřním lícem konstrukcí v úrovni 1,2 m nad úrovní podlahy; u poloodkrytých popřípadě odkrytých prostorů se místo chybějících svislých konstrukcí podlahová plocha vymezí pravoúhlým průmětem obvodu vodorovné nosné konstrukce,

o) zastavěnou plochou stavby plocha ohraničená pravoúhlými průměty vnějšího líce obvodových konstrukcí všech nadzemních i podzemních podlaží do vodorovné roviny; plochy lodžií a arkýřů se započítávají; u objektů poloodkrytých (bez některých obvodových stěn) je zastavěná plocha vymezena obalovými čarami vedenými vnějšími líci svislých konstrukcí do vodorovné roviny; u zastřešených staveb nebo jejich částí bez obvodových svislých konstrukcí je zastavěná plocha vymezena pravoúhlým průmětem střešní konstrukce do vodorovné roviny,

p) zastavěnou plochou pozemku součet všech zastavěných ploch jednotlivých staveb,

q) domem pro dostupné nájemní bydlení bytový dům, k němuž je uzavřena plánovací smlouva o dostupném nájemním bydlení, nebo který je jako dům pro dostupné nájemní bydlení vymezen v regulačním plánu vydaném obcí, která je stavebníkem.

#### § 14

V tomto zákoně se dále rozumí

a) stavebníkem osoba, která pro sebe žádá vydání povolení záměru nebo odstranění stavby, zařízení nebo terénní úpravy, a dále osoba, která provádí nebo odstraňuje stavbu, zařízení nebo terénní úpravu, pokud nejde o stavebního podnikatele jednajícího v rámci své podnikatelské činnosti,

b) projektantem fyzická osoba oprávněná podle autorizačního zákona ke zpracování územně plánovací dokumentace, územní studie a projektové dokumentace,

c) hlavním projektantem projektant pověřený koordinací při zpracování dokumentace,

d) stavebním podnikatelem osoba oprávněná k provádění stavebních nebo montážních prací jako předmětu své činnosti podle živnostenského zákona,

e) zhotovitelem stavebník v případě svépomocné formy výstavby, nebo stavební podnikatel,

f) stavbyvedoucím fyzická osoba oprávněná podle autorizačního zákona k odbornému vedení provádění nebo odstraňování stavby,

g) stavebním dozorem odborný dozor nad prováděním nebo odstraňováním stavby, zařízení anebo terénní úpravy svépomocí,

h) dozorem projektanta průběžný odborný dozor nad souladem realizace dokumentace pro provádění záměru s dokumentací o povolení záměru a nad prováděním záměru v souladu s dokumentací pro provedení záměru.

### ČÁST DRUHÁ

#### HLAVA I

#### § 15 — Obecné ustanovení

Působnost podle tohoto zákona vykonávají vláda, Ministerstvo pro místní rozvoj (dále jen „ministerstvo“), orgány územního plánování, stavební úřady, obce, a kraje.

#### § 16 — Obec a kraj

Obec a kraj soustavně sledují uplatňování jimi vydané územně plánovací dokumentace a vyhodnocují je podle tohoto zákona. Dojde-li ke změně podmínek, za kterých byla územně plánovací dokumentace vydána, pořídí změnu příslušné územně plánovací dokumentace.

#### § 17 — Dopravní a energetický stavební úřad

(1) Dopravní a energetický stavební úřad je správním úřadem s celostátní působností ve věcech stavebního řádu podřízený Ministerstvu dopravy.

(2) Sídlem Dopravního a energetického stavebního úřadu je Praha.

(3) Územní pracoviště Dopravního a energetického stavebního úřadu stanoví Ministerstvo dopravy vyhláškou.

(4) V čele Dopravního a energetického stavebního úřadu stojí ředitel. Pro účely zákona o státní službě je Ministerstvo dopravy bezprostředně nadřízeným správním úřadem Dopravního a energetického stavebního úřadu.

(5) Výběr, jmenování a odvolání ředitele se řídí zákonem o státní službě.

#### § 18 — Součinnost orgánů veřejné správy

(1) Orgány územního plánování a stavební úřady postupují při výkonu své působnosti ve vzájemné součinnosti s dotčenými orgány chránícími veřejné zájmy podle jiných právních předpisů.

(2) Stavební úřad projednává s dotčenými orgány jimi vydaná vyjádření a závazná stanoviska. Za účelem projednání vyjádření a závazných stanovisek nebo odstranění rozporů může stavební úřad svolat společné jednání s dotčenými orgány. Společné jednání je neveřejné a o jeho průběhu a závěrech se sepisuje protokol. Stavební úřad oznámí dotčeným orgánům jeho konání nejméně 5 dnů předem. Je-li to účelné, přizve stavební úřad ke společnému jednání stavebníka a ostatní účastníky řízení. V takovém případě nařídí stavební úřad společné jednání jako ústní jednání.

(3) Nedojde-li postupem podle odstavce 2 k odstranění rozporu mezi stavebním úřadem a dotčenými orgány, jakož i mezi dotčenými orgány navzájem, postupuje se podle správního řádu.

(4) Stanoví-li dotčené orgány ve svém vyjádření nebo závazném stanovisku podmínky, které se staly součástí rozhodnutí stavebního úřadu, kontrolují v součinnosti se stavebním úřadem jejich dodržování.

#### HLAVA II

#### § 19 — Obecná ustanovení

(1) Působnost ve věcech územního plánování vykonávají vláda a orgány územního plánování, kterými jsou

a) ministerstvo,

b) Ministerstvo obrany,

c) úřady územního plánování a

d) obecní úřad, který získal potvrzení o zajištění splnění kvalifikačních požadavků pro výkon územně plánovací činnosti.

(2) Úřady územního plánování jsou obecní úřady obcí s rozšířenou působností a krajské úřady.

(3) Působnost ve věcech územního plánování vykonávají dále zastupitelstvo obce, zastupitelstvo kraje, rada obce a rada kraje.

#### § 20 — Vláda

Vláda

a) schvaluje politiku architektury a stavební kultury,

b) rozhoduje o pořízení politiky územního rozvoje,

c) schvaluje politiku územního rozvoje,

d) projednává a schvaluje zprávu o plnění politiky územního rozvoje a politiky architektury a stavební kultury,

e) vydává územní rozvojový plán,

f) projednává a schvaluje zprávu o uplatňování územního rozvojového plánu,

g) vydává územní opatření o stavební uzávěře, jedná-li se o změny v území celostátního významu,

h) vydává územní opatření o asanaci území, ovlivní-li svým významem, rozsahem nebo využitím území více krajů nebo států.

#### § 21 — Ministerstvo

(1) Ministerstvo je nadřízeným správním orgánem krajských úřadů jako úřadů územního plánování.

(2) Ministerstvo

a) vykonává kontrolu ve věcech územního plánování,

b) pořizuje politiku architektury a stavební kultury,

c) pořizuje politiku územního rozvoje,

d) pořizuje územní rozvojový plán,

e) pořizuje územně plánovací podklady v podrobnosti a rozsahu nezbytném pro pořizování politiky územního rozvoje a územního rozvojového plánu, popřípadě pro plnění dalších svých úkolů,

f) pořizuje územní opatření o stavební uzávěře, jedná-li se o změny v území celostátního významu,

g) pořizuje územní opatření o asanaci území, ovlivní-li svým významem, rozsahem nebo využitím území více krajů nebo států,

h) vede národní geoportál územního plánování a vkládá do něj data,

i) zajišťuje metodickou podporu uplatňování soudobých poznatků vědy a techniky a metodicky sjednocuje výkladovou a aplikační činnost krajských úřadů a obecních úřadů v oblasti územního plánování, urbanismu a architektury,

j) vykonává další činnosti podle tohoto zákona.

#### § 22 — Ministerstvo obrany

Ministerstvo obrany pro území vojenských újezdů

a) pořizuje a vydává územní plán a regulační plán,

b) pořizuje územně plánovací podklady v podrobnosti a rozsahu nezbytném pro pořizování územních plánů, regulačních plánů, popřípadě pro další územně plánovací činnost Ministerstva obrany,

c) vkládá data do národního geoportálu územního plánování.

#### § 23 — Krajský úřad

(1) Krajský úřad je nadřízeným správním orgánem obecních úřadů obcí s rozšířenou působností jako úřadů územního plánování a obecních úřadů podle § 26.

(2) Krajský úřad jako úřad územního plánování

a) vykonává kontrolu ve věcech územního plánování,

b) pořizuje zásady územního rozvoje,

c) pořizuje územně plánovací podklady v podrobnosti a rozsahu nezbytném pro pořizování zásad územního rozvoje, popřípadě pro další územně plánovací činnost kraje,

d) pořizuje územní opatření o stavební uzávěře, jedná-li se o změny v území nadmístního významu,

e) pořizuje územní opatření o asanaci území, ovlivní-li svým významem, rozsahem nebo využitím území více obcí,

f) vkládá data do národního geoportálu územního plánování,

g) vydává potvrzení o splnění kvalifikačních předpokladů pro výkon územně plánovací činnosti,

h) vykonává další činnosti podle tohoto zákona.

#### § 24 — Zastupitelstvo kraje a rada kraje

(1) Zastupitelstvo kraje

a) rozhoduje o pořízení zásad územního rozvoje,

b) schvaluje zadání zásad územního rozvoje,

c) schvaluje návrh výběru nejvhodnější varianty v návrhu zásad územního rozvoje,

d) vydává zásady územního rozvoje,

e) projednává a schvaluje zprávu o uplatňování zásad územního rozvoje.

(2) Rada kraje

a) uplatňuje připomínky k návrhu politiky územního rozvoje a územního rozvojového plánu a zásad územního rozvoje sousedního kraje,

b) uplatňuje připomínky k návrhu územního opatření, který pořizuje ministerstvo a dotýká se území kraje,

c) rozhoduje o pořízení územního opatření o stavební uzávěře a asanaci území, k jejichž pořízení je příslušný krajský úřad,

d) vydává územní opatření o stavební uzávěře a asanaci území, k jejichž pořízení je příslušný krajský úřad,

e) podává podnět k pořízení změny politiky územního rozvoje, změny územního rozvojového plánu, změny územního plánu nebo změny regulačního plánu.

#### § 25 — Obecní úřad obce s rozšířenou působností

Obecní úřad obce s rozšířenou působností jako úřad územního plánování

a) pořizuje územní plán a regulační plán,

b) pořizuje územní plán, regulační plán a územní opatření na žádost obce,

c) pořizuje územně plánovací podklady pro svůj správní obvod v podrobnosti a rozsahu nezbytném pro pořizování územních plánů, regulačních plánů, popřípadě pro další územně plánovací činnost obcí,

d) pořizuje a vydává vymezení zastavěného území,

e) pořizuje územní opatření o stavební uzávěře a územní opatření o asanaci území pro území obce,

f) vkládá data do národního geoportálu územního plánování,

g) vykonává další činnosti podle tohoto zákona.

#### § 26 — Obecní úřad

Obecní úřad, který získal potvrzení krajského úřadu o zajištění splnění kvalifikačních požadavků pro výkon územně plánovací činnosti, může vykonávat v přenesené působnosti působnost podle § 25 písm. a), e) a f) a pořizovat územní studii.

#### § 27 — Zastupitelstvo obce a rada obce

(1) Zastupitelstvo obce

a) rozhoduje o pořízení územního plánu a regulačního plánu,

b) schvaluje zadání územního plánu a regulačního plánu,

c) schvaluje návrh výběru nejvhodnější varianty v návrhu územního plánu a regulačního plánu,

d) vydává územní plán a regulační plán,

e) projednává a schvaluje zprávu o uplatňování územního plánu.

(2) Rada obce a v obcích, kde se rada nevolí, zastupitelstvo obce

a) uplatňuje připomínky k návrhu politiky územního rozvoje, územního rozvojového plánu, zásad územního rozvoje a územního plánu sousední obce,

b) uplatňuje připomínky k návrhu vymezení zastavěného území pro území obce,

c) uplatňuje připomínky k návrhu územního opatření o asanaci území a územního opatření o stavební uzávěře, které pořizuje krajský úřad jako úřad územního plánování, nebo ministerstvo, a dotýkají se území obce,

d) rozhoduje o pořízení územního opatření o stavební uzávěře a o asanaci území pro území obce,

e) vydává územní opatření o stavební uzávěře a o asanaci území pro území obce,

f) rozhoduje o podání žádosti podle § 25 písm. b) anebo rozhoduje o uzavření smlouvy s osobou splňující předpoklady pro výkon územně plánovací činnosti podle § 46 odst. 2 písm. c),

g) rozhoduje o podání žádosti podle § 48 odst. 3.

#### § 28 — Působnost na území hlavního města Prahy

(1) Pořizuje-li územní plán pro území hlavního města Prahy Magistrát hlavního města Prahy, vykonává působnost krajského úřadu ministerstvo.

(2) Pořizuje-li územní plán pro vymezenou část území hlavního města Prahy úřad městské části, vykonává působnost krajského úřadu Magistrát hlavního města Prahy.

#### § 29 — Ústav územního rozvoje

(1) Ústav územního rozvoje se sídlem v Brně je organizační složkou státu a účetní jednotkou, pro kterou plní funkci zřizovatele ministerstvo.

(2) Ústav územního rozvoje

a) provádí výzkum, publikační činnost a řeší koncepční otázky teorie a praxe v oboru územního plánování a stavebního řádu, stavební kultury a vystavěného prostředí, urbanismu a architektury,

b) zpracovává návrh politiky architektury a stavební kultury,

c) zpracovává návrh politiky územního rozvoje, jejích změn a úplné znění politiky územního rozvoje po její poslední změně,

d) zpracovává návrh územního rozvojového plánu, jeho změn a úplné znění územního rozvojového plánu po jeho změně,

e) zpracovává návrh územně plánovacích podkladů pro území státu,

f) vykonává další činnosti, kterými ho pověří ministerstvo.

#### HLAVA III

#### § 30 — Obecná ustanovení

(1) Působnost ve věcech stavebního řádu vykonávají stavební úřady, kterými jsou

a) ministerstvo,

b) Ministerstvo dopravy,

c) Ministerstvo průmyslu a obchodu,

d) Dopravní a energetický stavební úřad,

e) krajské stavební úřady,

f) obecní stavební úřady a

g) jiné stavební úřady3).

(2) Krajskými stavebními úřady jsou krajské úřady.

(3) Obecními stavebními úřady jsou

a) obecní úřady obcí s rozšířenou působností a

b) pověřené obecní úřady a obecní úřady, které stanoví ministerstvo prováděcím právním předpisem.

(4) Správní obvody obecních stavebních úřadů stanoví ministerstvo prováděcím právním předpisem. Stanovení obecního stavebního úřadu nebo jeho zrušení, popřípadě změnu jeho správního obvodu, lze provést pouze k počátku kalendářního roku.

(5) Dojde-li ke stanovení obecního stavebního úřadu nebo k jeho zrušení, popřípadě ke změně jeho správního obvodu, stanoví ministerstvo v prováděcím právním předpisu, který obecní stavební úřad dokončí neskončená správní řízení, a provede spisovou rozluku s rušeným obecním stavebním úřadem.

(6) Jinými stavebními úřady jsou Ministerstvo obrany, Ministerstvo vnitra a Ministerstvo spravedlnosti.

#### § 30a — Kvalifikační požadavky pro výkon činnosti na úseku stavebního řádu

(1) Krajské stavební úřady a obecní stavební úřady vykonávají činnost na úseku stavebního řádu prostřednictvím úředníků6) splňujících kvalifikační požadavky pro výkon činnosti na úseku stavebního řádu.

(2) Kvalifikační požadavky pro výkon činnosti na úseku stavebního řádu splňuje fyzická osoba, která

a) má osvědčení zvláštní odborné způsobilosti pro správní činnost stavební řád a vyvlastnění podle jiného právního předpisu7), nebo osvědčení o úspěšném vykonání úřednické zkoušky pro obor státní služby, jehož součástí je stavební řád a

b) splňuje kvalifikační požadavky vzdělání podle tohoto zákona.

(3) Ustanovení jiného právního předpisu o vydávání osvědčení o uznání rovnocennosti vzdělání8) se pro podmínky podle odstavce 2 nepoužije.

(4) Kvalifikační požadavky vzdělání podle odstavce 2 písm. b) splňuje

a) autorizovaný architekt, kterému byla udělena autorizace pro obor architektura nebo bez specifikace oboru podle autorizačního zákona,

b) autorizovaný inženýr nebo autorizovaný technik, kterému byla udělena autorizace pro obor pozemní stavby, dopravní stavby, stavby vodního hospodářství a krajinného inženýrství, mosty a inženýrské konstrukce, statika a dynamika staveb nebo městské inženýrství,

c) fyzická osoba, která má vysokoškolské vzdělání ve studijním programu náležejícím do oblasti vzdělávání architektura a urbanismus, stavebnictví, ekonomické obory, doprava, biologie, ekologie a životní prostředí, lesnictví a dřevařství, vědy o zemi, nebo právo,

d) fyzická osoba, která má vyšší odborné vzdělání v oboru stavebnictví, geodézie a kartografie, obecně právní činnost, veřejnosprávní činnost, nebo doprava, nebo

e) fyzická osoba, která má střední vzdělání s maturitní zkouškou v oboru stavebnictví, geodézie a katastr nemovitostí, nebo veřejnosprávní činnost.

(5) Úředník nesplňující kvalifikační požadavky může vykonávat činnost stavebního úřadu na úseku stavebního řádu, pokud je zajištěno, že bude do doby splnění uvedených požadavků vykonávat tuto činnost pod odborným vedením úředníka splňujícího kvalifikační požadavky pro výkon činnosti na úseku stavebního řádu, nejvýše však po dobu 3 let.

#### § 31 — Metodická činnost

(1) Ministerstvo metodicky sjednocuje výkon působnosti stavebních úřadů v oblasti stavebního řádu a požadavků na výstavbu.

(2) Ministerstvo dopravy metodicky sjednocuje u staveb dálnic, silnic, místních komunikací a veřejně přístupných účelových komunikací, staveb drah a civilních leteckých staveb výkon působnosti stavebních úřadů v oblasti požadavků na výstavbu.

#### § 32 — Ministerstvo

(1) Ministerstvo je nadřízeným správním orgánem krajského stavebního úřadu, není-li jeho nadřízeným správním orgánem Dopravní a energetický stavební úřad.

(2) Ministerstvo

a) vede systém stavebně technické prevence, v němž sleduje a analyzuje závažné nebo opakující se závady nebo havárie staveb, kterým je třeba ve veřejném zájmu předcházet, a navrhuje opatření k zabránění jejich opakování,

b) sleduje účinnost technických předpisů pro stavby a dbá o zlepšování jejich úrovně,

c) navrhuje úpravy požadavků na stavby, jejich části, funkce, prvky a stavební výrobky a podává podněty k úpravě českých technických norem nebo certifikace stavebních výrobků anebo k jiným stavebně technickým opatřením,

d) připravuje seznam závazných českých technických norem nebo jejich částí obsahujících podrobnější technické požadavky na stavby, které určí Úřad pro technickou normalizaci, metrologii a státní zkušebnictví jako určené technické normy ve stavebnictví a oznámí je ve Věstníku podle jiného právního předpisu s výjimkou norem stanovených prováděcím právním předpisem územního samosprávného celku,

e) zajišťuje bezplatný přístup k určeným technickým normám ve stavebnictví podle jiného právního předpisu s výjimkou norem stanovených prováděcím právním předpisem územního samosprávného celku,

f) vykonává kontrolu ve věcech stavebního řádu,

g) vykonává kontrolu nad činností autorizovaných inspektorů.

(3) Ministerstvo může

a) vyhradit si zjišťování stavebně technických příčin havárií staveb nebo účast při něm, pokud se svým rozsahem nebo opakovanými důsledky ve značné míře dotýkají veřejných zájmů,

b) pověřit vedením systému stavebně technické prevence Ústav územního rozvoje.

(4) Ministerstvo nevykonává působnost podle tohoto zákona v rozsahu, v jakém ji vykonává Ministerstvo dopravy nebo Ministerstvo průmyslu a obchodu.

#### § 32a — Ministerstvo dopravy

(1) Ministerstvo dopravy je nadřízeným správním orgánem Dopravního a energetického stavebního úřadu, není-li jeho nadřízeným správním orgánem Ministerstvo průmyslu a obchodu.

(2) Ministerstvo dopravy ve věcech staveb dálnic, silnic, místních komunikací a veřejně přístupných účelových komunikací, staveb drah a civilních leteckých staveb

a) sleduje účinnost technických předpisů pro stavby a dbá o zlepšování jejich úrovně,

b) navrhuje úpravy požadavků na stavby, jejich části, funkce, prvky a stavební výrobky a podává podněty k úpravě českých technických norem nebo certifikace stavebních výrobků anebo k jiným stavebně technickým opatřením,

c) připravuje seznam závazných českých technických norem nebo jejich částí obsahujících podrobnější technické požadavky na stavby, které určí Úřad pro technickou normalizaci, metrologii a státní zkušebnictví jako určené technické normy ve stavebnictví a oznámí je ve Věstníku podle jiného právního předpisu s výjimkou norem stanovených prováděcím právním předpisem územního samosprávného celku,

d) zajišťuje bezplatný přístup k určeným technickým normám ve stavebnictví podle jiného právního předpisu s výjimkou norem stanovených prováděcím právním předpisem územního samosprávného celku,

e) vykonává kontrolu ve věcech stavebního řádu.

#### § 32b — Ministerstvo průmyslu a obchodu

(1) Ministerstvo průmyslu a obchodu je nadřízeným správním orgánem Dopravního a energetického stavebního úřadu ve věcech

a) vyhrazených staveb uvedených v příloze č. 3 písm. d) až p) k tomuto zákonu, včetně staveb souvisejících,

b) staveb uvedených v § 34 písm. a) bodu 3,

c) staveb technické infrastruktury pro energetiku a elektronické komunikace.

(2) Ministerstvo průmyslu a obchodu u staveb podle odstavce 1

a) sleduje účinnost technických předpisů pro stavby a dbá o zlepšování jejich úrovně,

b) vykonává kontrolu ve věcech stavebního řádu.

#### § 33 — Dopravní a energetický stavební úřad

(1) Dopravní a energetický stavební úřad je nadřízeným správním orgánem krajského stavebního úřadu ve věcech staveb

a) silnic, místních komunikací a veřejně přístupných účelových komunikací,

b) uvedených v § 34 písm. a) bodu 3,

c) technické infrastruktury pro energetiku a elektronické komunikace.

(2) Dopravní a energetický stavební úřad

a) vykonává působnost stavebního úřadu ve věcech vyhrazených staveb,

b) vykonává působnost stavebního úřadu ve věcech staveb souvisejících s vyhrazenými stavbami, jež by jinak byly v působnosti krajského stavebního úřadu nebo obecního stavebního úřadu,

c) vydává rámcové povolení pro stavby jaderného zařízení a stavby související, nacházející se uvnitř i vně areálu jaderného zařízení, a

d) vykonává kontrolu ve věcech stavebního řádu.

(3) K přechodu související stavby do působnosti krajského úřadu nebo obecního stavebního úřadu se vyžaduje změna účelu užívání.

#### § 34 — Krajský stavební úřad

Krajský stavební úřad

a) vykonává působnost stavebního úřadu ve věcech

1. záměrů EIA,

2. silnic I. třídy,

3. výroben z obnovitelných zdrojů energie neuvedených v příloze č. 3 k tomuto zákonu,

4. vodních děl na hraničních vodách,

5. čistíren odpadních vod sloužících k vypouštění odpadních vod do vod povrchových ze zdrojů znečištění o velikosti 10 000 ekvivalentních obyvatel nebo více,

6. vodních nádrží s celkovým objemem nad 1 000 000 m3 nebo s výškou vzdutí nad 10 m ode dna základové výpusti,

7. vodních děl sloužících k vypouštění odpadních vod z těžby a zpracování uranových rud a jaderných elektráren a odpadních vod s obsahem zvlášť nebezpečných závadných nebo nebezpečných závadných látek do vod povrchových a k vypouštění odpadních vod s obsahem zvlášť nebezpečné závadné látky nebo prioritní nebezpečné látky do kanalizace s výjimkou případů, kdy je instalováno zařízení s dostatečnou účinností podle jiného právního předpisu,

8. vodních děl sloužících k čerpání znečištěných podzemních vod za účelem snížení jejich znečištění a jejich následné vypouštění do těchto vod, popřípadě do vod povrchových,

9. staveb a zařízení distribuční soustavy o napětí 110 kV včetně transformovny 110 kV a staveb a zařízení pro ukládání energie připojených do distribuční soustavy s napětím 110 kV,

10. staveb a zařízení distribuční soustavy plynu o tlakové hladině 4 až 40 barů včetně souvisejících technologických objektů,

u kterých nevykonává působnost Dopravní a energetický stavební úřad nebo jiný stavební úřad,

b) vydává rámcové povolení pro stavby v působnosti jiného stavebního úřadu, včetně staveb souvisejících, a

c) vykonává kontrolu ve věcech stavebního řádu.

#### § 34a — Obecní stavební úřad

(1) Obecní stavební úřad

a) vykonává působnost stavebního úřadu ve věcech záměrů, u kterých nevykonává působnost Dopravní a energetický stavební úřad, krajský stavební úřad nebo jiný stavební úřad,

b) vykonává kontrolu ve věcech stavebního řádu.

(2) Působnost stavebního úřadu ve věcech záměru bytového domu, silnice II. a III. třídy, místní komunikace, veřejně přístupné účelové komunikace, technické infrastruktury, která je součástí distribuční soustavy v elektroenergetice nebo plynárenství, sítí elektronických komunikací, staveb a zařízení pro ukládání energie, vodního díla, u něhož nevykonává působnost stavebního úřadu krajský stavební úřad, a souboru staveb, jehož jsou tyto záměry součástí, vykonává obecní stavební úřad obce s rozšířenou působností; § 37 odst. 3 se pro určení příslušnosti stavebního úřadu nepoužije.

#### § 35 — Jiné stavební úřady

(1) Ministerstvo obrany vykonává působnost stavebního úřadu pro území vojenských újezdů a u záměrů, které slouží nebo mají sloužit k zajišťování obrany státu5), realizovaných Ministerstvem obrany, jím zřízenou nebo založenou právnickou osobou nebo, u staveb a záměrů, které slouží nebo mají sloužit k plnění úkolů Národního úřadu pro kybernetickou a informační bezpečnost, s výjimkou vydání rámcového povolení.

(2) Ministerstvo vnitra vykonává působnost stavebního úřadu u záměrů pro bezpečnost státu, kterými se rozumí stavby sloužící k plnění úkolů Ministerstva vnitra nebo jím zřízené organizační složky státu, Policie České republiky, Policejní akademie České republiky, Hasičského záchranného sboru České republiky, Úřadu pro zahraniční styky a informace, Bezpečnostní informační služby a Národního bezpečnostního úřadu, s výjimkou staveb nebo jejich částí převážně užívaných pro účely bytové nebo rekreační. Do výkonu působnosti podle věty první nenáleží vydání rámcového povolení.

(3) Ministerstvo spravedlnosti vykonává působnost stavebního úřadu u záměrů staveb pro účely Vězeňské služby České republiky a jejích organizačních jednotek, s výjimkou vydání rámcového povolení.

(4) K přechodu stavby podle odstavců 1 až 3 do působnosti krajského úřadu nebo obecního stavebního úřadu se vyžaduje změna účelu užívání.

#### HLAVA IV

#### § 36

(1) Ministerstvo obrany a Ministerstvo vnitra vymezí opatřením obecné povahy území, v němž v zájmu zajišťování obrany a bezpečnosti státu

a) vydává závazné stanovisko pro účely povolení záměru,

b) vydává vyjádření k návrhu zadání územně plánovací dokumentace a stanovisko k návrhu územně plánovací dokumentace nebo její změny, dotýká-li se vymezeného území, a

c) může se vyjádřit k nezbytným úpravám u již zřízených staveb nebo uplatnit požadavky na nezbytné úpravy.

(2) Opatření obecné povahy podle odstavce 1 se vydává bez řízení o jeho návrhu a nabývá účinnosti dnem vyvěšení veřejné vyhlášky.

(3) Náklady spojené s požadavky na nezbytné úpravy podle odstavce 1 písm. c) nese ministerstvo, které je uplatnilo.

#### HLAVA V

#### § 37

(1) Působnost stanovená tímto zákonem krajskému úřadu, obecnímu úřadu obce s rozšířenou působností a obecnímu úřadu je přenesenou působností.

(2) V pochybnostech, který stavební úřad je příslušný ve věcech týkajících se záměru, určí příslušný stavební úřad nadřízený stavební úřad.

(3) U souboru staveb se příslušnost stavebního úřadu k vydání povolení záměru řídí příslušností k povolení záměru stavby hlavní souboru staveb. Stavební úřad je příslušný k provedení všech úkonů, postupů a vydání rozhodnutí podle tohoto zákona pro všechny stavby souboru staveb.

### ČÁST TŘETÍ

#### HLAVA I

#### § 38 — Cíle územního plánování

(1) Cílem územního plánování je soustavně a komplexně řešit funkční využití území, stanovovat zásady jeho funkčního a prostorového uspořádání a vytvářet předpoklady pro udržitelný rozvoj území spočívající ve vyváženém vztahu podmínek pro příznivé životní prostředí, pro hospodářský rozvoj a pro soudržnost společenství obyvatel území, který uspokojuje potřeby současné generace, aniž by ohrožoval podmínky života generací budoucích.

(2) Územní plánování zajišťuje předpoklady pro udržitelný rozvoj území a za tímto účelem vyhodnocuje potenciál rozvoje území a prognózy jeho dalšího vývoje.

(3) Cílem územního plánování je také zvyšovat kvalitu vystavěného prostředí sídel, rozvíjet jejich identitu a vytvářet funkční a harmonické prostředí pro každodenní život jejich obyvatel.

(4) Územní plánování chrání a rozvíjí přírodní, kulturní a civilizační hodnoty území, včetně urbanistického, architektonického a archeologického dědictví, a přitom chrání krajinu jako podstatnou složku prostředí života obyvatel a základ jejich totožnosti. S ohledem na to určuje podmínky pro hospodárné využívání zastavěného území a zajišťuje ochranu nezastavěného území a ochranu a rozvoj zelené infrastruktury. Zastavitelné plochy se vymezují s ohledem na možnosti rozvoje území a míru využití zastavěného území.

(5) Orgány územního plánování postupem podle tohoto zákona koordinují veřejné zájmy v území a podněty na provedení změn v území, výstavbu a jiné činnosti ovlivňující rozvoj území a konkretizují ochranu veřejných zájmů vyplývajících z tohoto zákona a jiných právních předpisů.

#### § 39 — Úkoly územního plánování

Úkolem územního plánování je ve veřejném zájmu zejména

a) zjišťovat a posuzovat stav území, jeho přírodní, kulturní a civilizační hodnoty,

b) stanovovat s ohledem na podmínky a hodnoty území koncepci využití a rozvoje území, včetně dlouhodobé urbanistické koncepce sídel, rozvoje veřejné infrastruktury a ochrany volné krajiny a stanovení podmínek prostupnosti území,

c) prověřovat a posuzovat potřebu změn v území, jejich přínosy, problémy a rizika s ohledem na ochranu veřejných zájmů a hospodárné využívání území,

d) stanovovat urbanistické, architektonické, estetické a funkční požadavky na využívání a prostorové uspořádání území a na jeho změny, zejména na míru využití území, umístění, uspořádání a řešení staveb a kvalitu veřejných prostranství,

e) vytvářet předpoklady pro hospodárné využívání území, zejména důsledným využíváním zastavěného území sídel prostřednictvím cílené revitalizace znehodnocených nebo zanedbaných ploch,

f) s ohledem na charakter území a kvalitu vystavěného prostředí vyhodnocovat a, je-li to účelné, vymezovat vhodné plochy pro výrobu; plochy pro výrobu elektřiny, plynu a tepla včetně ploch pro jejich výrobu z obnovitelných zdrojů vymezovat rovněž s ohledem na cíle energetické koncepce67) a klimatické cíle státu,

g) stanovovat podmínky pro obnovu a rozvoj sídelní struktury, pro kvalitní bydlení a pro rozvoj rekreace a cestovního ruchu,

h) prověřovat a posuzovat potřebu změn v území, zejména pak pro umístění a uspořádání staveb s ohledem na stávající charakter a hodnoty v území a na využitelnost navazujícího území, tyto změny navrhovat a stanovovat podmínky pro jejich provedení,

i) stanovovat pořadí provádění změn v území,

j) koordinovat veřejné zájmy a podněty na provedení změn v území,

k) vymezovat veřejně prospěšné stavby a veřejně prospěšná opatření,

l) vytvářet a stanovovat podmínky pro snižování nebezpečí v území, zejména před účinky povodní, sucha, erozních jevů a extrémních teplot,

m) uplatňovat požadavky na adaptaci sídel a uspořádání krajiny vyplývající ze změny klimatu,

n) prověřovat a vytvářet v území podmínky pro hospodárné vynakládání prostředků z veřejných rozpočtů na změny v území,

o) vytvářet v území podmínky pro zajištění obrany a bezpečnosti státu a civilní ochrany,

p) vytvářet v území podmínky pro odstraňování následků náhlých hospodářských změn zejména prověřováním a případným vymezováním zastavitelných ploch nebo transformačních ploch,

q) určovat nutné asanační a rekultivační zásahy do území,

r) regulovat rozsah ploch pro využívání přírodních a nerostných zdrojů, vytvářet a stanovovat podmínky pro jejich využití,

s) vytvářet podmínky pro ochranu území podle jiných právních předpisů před významnými negativními vlivy záměrů na území a navrhovat kompenzační opatření, pokud tak stanoví jiný právní předpis.

#### § 40 — Vyhodnocení vlivů na udržitelný rozvoj území

(1) Úkolem územního plánování je také posoudit vlivy politiky územního rozvoje, územního rozvojového plánu, zásad územního rozvoje nebo územního plánu na udržitelný rozvoj území. Za tímto účelem se zpracovává vyhodnocení vlivů na udržitelný rozvoj území (dále jen „vyhodnocení vlivů“).

(2) Vyhodnocení vlivů se zpracovává k návrhu politiky územního rozvoje, územního rozvojového plánu, zásad územního rozvoje nebo územního plánu, je-li vyžadováno posouzení z hlediska vlivů na životní prostředí.

(3) Součástí vyhodnocení vlivů je vyhodnocení vlivů na

a) hospodářský rozvoj,

b) soudržnost společenství obyvatel území a

c) životní prostředí.

(4) Součástí vyhodnocení vlivů na životní prostředí je i posouzení vlivů na předmět ochrany a celistvost evropsky významné lokality nebo ptačí oblasti, je-li to vyžadováno podle jiného právního předpisu.

(5) Ve vyhodnocení vlivů se určí, popíší a posoudí možné významné vlivy podle odstavce 3 vyplývající z politiky územního rozvoje, územního rozvojového plánu, zásad územního rozvoje nebo územního plánu a rozumná náhradní řešení s přihlédnutím k cílům posuzovaných dokumentů. Vyhodnocení vlivů politiky územního rozvoje, nadřazené územně plánovací dokumentace nesmí obsahovat podrobnosti, které náleží vyhodnocení vlivů navazující územně plánovací dokumentace.

(6) Obsah a struktura vyhodnocení vlivů a vyhodnocení vlivů na životní prostředí jsou stanoveny v příloze č. 4 k tomuto zákonu. Náležitosti vyhodnocení vlivů na předmět ochrany nebo celistvost evropsky významné lokality nebo ptačí oblasti jsou stanoveny jiným právním předpisem.

#### § 41 — Charakter území

Charakter území se určuje zejména podle funkčního využití, struktury a typu zástavby, uspořádání veřejných prostranství, dalších prvků prostorového uspořádání a urbanistických, architektonických, estetických, kulturních a přírodních hodnot území, včetně jejich vzájemných vztahů a vazeb, a to především vymezením v územně plánovací dokumentaci.

#### HLAVA II

##### Díl 1

#### § 42 — Oprávněný investor

(1) Oprávněným investorem se v tomto zákoně rozumí vlastník, správce nebo provozovatel veřejné dopravní nebo veřejné technické infrastruktury.

(2) Oprávněný investor může požadovat, aby byl o úkonech orgánu územního plánování při projednání návrhů územně plánovací dokumentace a územních opatření vyrozuměn jednotlivě. Za tímto účelem se zřizuje seznam oprávněných investorů, který vede a spravuje ministerstvo.

(3) Ministerstvo zaznamená oprávněného investora do seznamu oprávněných investorů na základě žádosti. V žádosti oprávněný investor kromě obecných náležitostí podle správního řádu uvede

a) seznam obcí, popřípadě krajů, kterých se vyrozumění týká, a

b) doklad prokazující skutečnost, že je oprávněným investorem s územní působností na území uvedených obcí, popřípadě krajů.

(4) Je-li žádost podle odstavce 3 úplná, zaznamená ministerstvo oprávněného investora do 14 dnů ode dne obdržení žádosti do seznamu oprávněných investorů. Seznam oprávněných investorů zveřejňuje ministerstvo způsobem umožňujícím dálkový přístup na národním geoportálu územního plánování.

(5) Záznam v seznamu oprávněných investorů je veden po dobu 5 let ode dne jeho zveřejnění. Žádost podle odstavce 3 lze podávat opakovaně. Změní-li se údaje poskytnuté oprávněným investorem podle odstavce 3, je oprávněný investor povinen o této skutečnosti neprodleně vyrozumět ministerstvo, které údaje v seznamu oprávněných investorů upraví.

#### § 43 — Zveřejňování a ukládání dokumentů

(1) Pořizovatel musí veřejnosti a dotčeným orgánům zajistit možnost seznámit se s návrhy zadání územně plánovací dokumentace, územně plánovací dokumentace nebo zprávy o jejím uplatňování, územních opatření a vymezení zastavěného území ode dne vyvěšení návrhu veřejnou vyhláškou.

(2) Příslušný pořizovatel zveřejňuje zadání územně plánovací dokumentace, zprávu o uplatňování územně plánovací dokumentace, územně plánovací dokumentaci, zastavěné území, územní studii a územní opatření a jejich návrhy v národním geoportálu územního plánování.

(3) Politiku územního rozvoje, včetně dokladů o jejím pořizování, územní rozvojový plán a územní opatření, které vydala vláda, včetně spisu k územnímu rozvojovému plánu a územnímu opatření o stavební uzávěře, ukládá ministerstvo.

(4) Zásady územního rozvoje, územní plán, regulační plán a územní opatření, včetně spisu, ukládá pořizovatel u kraje nebo obce, pro něž byly pořízeny.

(5) Vymezení zastavěného území, včetně spisu, a územně plánovací podklady, včetně dokladů o jejich pořizování, ukládá příslušný pořizovatel.

##### Díl 2

#### § 44 — Kvalifikační požadavky

(1) Úřady územního plánování vykonávají územně plánovací činnost podle § 23 a 25 prostřednictvím úředníků6) splňujících kvalifikační požadavky pro výkon územně plánovací činnosti.

(2) Kvalifikační požadavky pro výkon územně plánovací činnosti splňuje fyzická osoba, která

a) má osvědčení zvláštní odborné způsobilosti pro správní činnost územní plánování podle jiného právního předpisu7), nebo osvědčení o úspěšném vykonání úřednické zkoušky pro obor státní služby, jehož součástí je územní plánování,

b) splňuje kvalifikační požadavky vzdělání podle tohoto zákona a

c) splňuje kvalifikační požadavky praxe podle tohoto zákona.

(3) Ustanovení jiného právního předpisu o vydávání osvědčení o uznání rovnocennosti vzdělání8) se pro podmínky podle odstavce 2 nepoužije.

(4) Kvalifikační požadavky vzdělání a praxe podle odstavce 2 písm. b) a c) splňuje

a) autorizovaný architekt, kterému byla udělena autorizace pro obor územní plánování nebo bez specifikace oboru podle autorizačního zákona, nebo autorizovaný inženýr pro obor městské inženýrství,

b) fyzická osoba, která má vysokoškolské vzdělání uznané pro autorizaci v oboru územní plánování a nejméně 18 měsíců praxe při výkonu územně plánovací činnosti ve veřejné správě, nebo

c) fyzická osoba, která má vysokoškolské vzdělání ve studijním programu náležejícím do oblasti vzdělávání architektura a urbanismus, stavebnictví nebo geografie a nejméně 24 měsíců praxe při výkonu územně plánovací činnosti ve veřejné správě.

(5) Úředník nesplňující kvalifikační požadavky může vykonávat územně plánovací činnost úřadu územního plánování, pokud je zajištěno, že bude do doby splnění uvedených požadavků vykonávat tuto činnost pod odborným vedením úředníka splňujícího kvalifikační požadavky pro výkon územně plánovací činnosti, nejvýše však po dobu 3 let.

#### § 45 — Výjimka z kvalifikačních požadavků

(1) Výjimku z kvalifikačního požadavku vzdělání ministerstvo udělí na základě žádosti úředníka územního samosprávného celku, který vykonává územně plánovací činnost v souladu s právními předpisy, splňuje kvalifikační požadavky praxe a má osvědčení zvláštní odborné způsobilosti podle jiného právního předpisu7).

(2) Při posuzování žádosti ministerstvo vychází z kvality úkonů žadatele při pořizování územně plánovací dokumentace a územně plánovacích podkladů, na nichž se prokazatelně osobně podílel, a z příloh žádosti uvedených v odstavci 3 písm. b) a c).

(3) Součástí žádosti o udělení výjimky z kvalifikačního požadavku vzdělání je

a) doklad o praxi ve veřejné správě při pořizování územně plánovací dokumentace nebo územně plánovacích podkladů v délce nejméně 18 měsíců, včetně výčtu územně plánovacích dokumentací nebo územně plánovacích podkladů, na jejichž pořízení se žadatel osobně podílel, s uvedením rozsahu svého podílu,

b) kopie návrhu zadání nebo zprávy o uplatňování územně plánovací dokumentace a úkonů pořizovatele při pořizování návrhu územně plánovací dokumentace nebo její změny, anebo stanoviska krajského úřadu k návrhu územního plánu, na kterých se žadatel osobně podílel,

c) posudek o pracovní činnosti9) nebo jiný doklad prokazující kvalitu práce žadatele,

d) kopie osvědčení zvláštní odborné způsobilosti pro správní činnost územní plánování, nebo osvědčení o úspěšném vykonání úřednické zkoušky pro obor státní služby, jehož součástí je územní plánování.

##### Díl 3

##### Oddíl 1

#### § 46 — Pořizovatel

(1) Pořizovatelem se v tomto zákoně rozumí

a) ministerstvo,

b) Ministerstvo obrany,

c) úřad územního plánování a

d) obecní úřad na základě potvrzení krajského úřadu o zajištění splnění kvalifikačních požadavků pro výkon územně plánovací činnosti.

(2) Pořizovatel vykonává územně plánovací činnost prostřednictvím

a) státního zaměstnance, který byl přijat do služebního poměru a zařazen na služební místo nebo jmenován na služební místo představeného k výkonu v oboru státní služby, jehož součástí je územní plánování,

b) úředníka územního samosprávného celku splňujícího kvalifikační požadavky pro výkon územně plánovací činnosti, nebyla-li mu z nich udělena výjimka, nebo

c) osoby splňující kvalifikační požadavky pro výkon územně plánovací činnosti, které bylo uděleno oprávnění k výkonu územně plánovací činnosti ministerstvem (dále jen „zástupce pořizovatele“), jde-li o pořizovatele podle odstavce 1 písm. d).

(3) Výkon územně plánovací činnosti osobami podle odstavce 2 a činnost projektanta jsou vzájemně neslučitelné.

#### § 47 — Územně plánovací činnost vykonávaná obecním úřadem

(1) Obecní úřad může vykonávat územně plánovací činnost podle § 26 pouze na základě potvrzení vydaného krajským úřadem o tom, že zajistil výkon územně plánovací činnosti prostřednictvím osoby, která splňuje kvalifikační požadavky pro výkon územně plánovací činnosti.

(2) V žádosti o vydání potvrzení obecní úřad uvede

a) své identifikační údaje,

b) informaci o tom, jakou územně plánovací dokumentaci, popřípadě územní studii hodlá pořizovat,

c) doklad, že bude vykonávat územně plánovací činnost prostřednictvím osoby splňující požadavky pro výkon územně plánovací činnosti.

(3) Krajský úřad do 30 dnů od obdržení žádosti podle odstavce 2 přezkoumá, zda obecní úřad bude územně plánovací činnost vykonávat prostřednictvím osoby splňující požadavky pro výkon územně plánovací činnosti, a vydá obecnímu úřadu potvrzení nebo mu sdělí, že potvrzení nelze vydat. Součástí potvrzení je stanovení rozsahu výkonu územně plánovací činnosti obecním úřadem. Potvrzení zašle krajský úřad současně ministerstvu a úřadu územního plánování.

(4) Ministerstvo zajistí obecnímu úřadu přístup do národního geoportálu územního plánování v rozsahu potvrzení podle odstavce 3.

#### § 48 — Překážky výkonu územně plánovací činnosti

(1) Nemůže-li obecní úřad v průběhu pořizování územně plánovací dokumentace nebo územní studie zajistit výkon územně plánovací činnosti prostřednictvím osoby splňující kvalifikační požadavky pro výkon územně plánovací činnosti, pořizování neprodleně přeruší a sdělí tuto skutečnost ministerstvu a krajskému úřadu. Krajský úřad na základě oznámení podle věty první zruší obecnímu úřadu potvrzení podle § 47 odst. 3.

(2) Ve sdělení podle odstavce 1 obecní úřad uvede, zda

a) předloží zastupitelstvu návrh na ukončení pořizování,

b) požaduje, aby pořizování dokončil úřad územního plánování obce s rozšířenou působností, nebo

c) učiní kroky, aby zajistil výkon územně plánovací činnosti prostřednictvím osoby, která splňuje kvalifikační požadavky pro výkon územně plánovací činnosti.

(3) Požaduje-li obec, aby pořizování dokončil úřad územního plánování obce s rozšířenou působností, předá krajský úřad tuto žádost příslušnému úřadu územního plánování. Požadavek podle věty první se považuje za žádost obce podle § 25 písm. b).

(4) Je-li obsahem sdělení údaj podle odstavce 2 písm. c), postupuje se podle § 47 obdobně.

#### § 49 — Určený zastupitel

(1) Zastupitelstvo obce a zastupitelstvo kraje určí člena zastupitelstva, který při pořizování územně plánovací dokumentace obce nebo kraje spolupracuje s pořizovatelem (dále jen „určený zastupitel“).

(2) Pořizovatel při pořizování územně plánovací dokumentace postupuje v součinnosti s určeným zastupitelem.

(3) Nedojde-li mezi pořizovatelem a určeným zastupitelem ke shodě, je pro pokračování v pořizování územně plánovací dokumentace z hlediska souladu návrhu s nadřazenou územně plánovací dokumentací, s právními předpisy a se stanovisky nadřízeného orgánu územního plánování a dotčených orgánů rozhodující řešení navržené pořizovatelem, v ostatních případech řešení navržené určeným zastupitelem.

(4) Je-li pro obec pořizována úřadem územního plánování územní studie, která je podmínkou pro rozhodování v území podle § 81 odst. 4, může zastupitelstvo určit zastupitele, který při jejím pořizování spolupracuje s pořizovatelem; ustanovení o určeném zastupiteli se použijí přiměřeně.

##### Oddíl 2

#### § 50 — Obecná ustanovení

(1) Ministerstvo udělí oprávnění k výkonu územně plánovací činnosti osobě, která

a) je plně svéprávná,

b) má osvědčení zvláštní odborné způsobilosti pro správní činnost v územním plánování, nebo osvědčení o úspěšném vykonání úřednické zkoušky pro obor státní služby, jehož součástí je územní plánování,

c) splňuje kvalifikační požadavky vzdělání a praxe podle § 44 odst. 4,

d) je bezúhonná,

e) vykonávala územně plánovací činnost v souladu s právními předpisy; při posuzování ministerstvo vychází z kvality úkonů žadatele při pořizování územně plánovací dokumentace, na níž se osobně podílel.

(2) Seznam zástupců pořizovatele vede ministerstvo a zveřejňuje jej způsobem umožňujícím dálkový přístup v národním geoportálu územního plánování.

#### § 51 — Bezúhonnost

(1) Za bezúhonnou se pro účely udělení oprávnění k výkonu územně plánovací činnosti nepovažuje osoba,

a) která byla pravomocně odsouzena za trestný čin spáchaný úmyslně, jestliže byl tento trestný čin spáchán v souvislosti s výkonem územně plánovací činnosti, nehledí-li se na ni, jako by nebyla odsouzena, nebo

b) které bylo Českou komorou architektů pravomocně uloženo disciplinární opatření ve formě pozastavení nebo odnětí autorizace.

(2) Osoba, která není státním občanem České republiky a nemá na území České republiky povolen trvalý pobyt, dokládá bezúhonnost výpisem z evidence obdobné Rejstříku trestů vydaným státem, jehož je občanem, nebo státem posledního pobytu. Osoba, která je nebo byla státním občanem jiného členského státu Evropské unie nebo má nebo měla adresu bydliště v jiném členském státě Evropské unie, může místo výpisu z evidence obdobné Rejstříku trestů doložit bezúhonnost výpisem z Rejstříku trestů s přílohou obsahující informace, které jsou zapsané v evidenci trestů jiného členského státu Evropské unie.

(3) Pro ověření bezúhonnosti si ministerstvo vyžádá výpis z Rejstříku trestů, včetně přílohy obsahující cizozemská odsouzení. Žádost o vydání výpisu z Rejstříku trestů a výpis z Rejstříku trestů se předávají v elektronické podobě, a to způsobem umožňujícím dálkový přístup.

(4) Česká komora architektů bezodkladně uvědomí ministerstvo o pravomocném uložení disciplinárního opatření spočívajícího v pozastavení nebo odnětí autorizace zástupce pořizovatele.

#### § 52 — Žádost o udělení oprávnění

(1) Součástí žádosti o udělení oprávnění k výkonu územně plánovací činnosti je

a) doklad o dosaženém vzdělání podle § 44 odst. 3, nebo doklad o udělení výjimky podle § 45 odst. 1,

b) doklad o praxi ve veřejné správě při pořizování územně plánovací dokumentace,

c) kopie osvědčení zvláštní odborné způsobilosti v územním plánování, nebo kopie osvědčení o úspěšném vykonání úřednické zkoušky podle zákona o státní službě,

d) výčet žadatelem pořizované územně plánovací dokumentace, na níž se osobně podílel, s uvedením rozsahu jeho podílu.

(2) Ministerstvo může požádat krajský úřad o vyjádření, zda v posledních 3 letech před podáním žádosti u územně plánovací dokumentace, u které vykonával žadatel činnost pořizovatele, neučinil opatření při kontrole ve věcech územního plánování.

#### § 53 — Udělení a zánik oprávnění

(1) Oprávnění k výkonu územně plánovací činnosti se uděluje na dobu 5 let. Tato doba se na žádost zástupce pořizovatele prodlouží o 5 let, a to i opakovaně, splňuje-li podmínky § 50 odst. 1.

(2) Oprávnění k výkonu územně plánovací činnosti zaniká

a) dnem doručení písemného prohlášení zástupce pořizovatele o ukončení činnosti ministrovi pro místní rozvoj,

b) uplynutím doby, na kterou bylo uděleno,

c) dnem nabytí právní moci rozhodnutí soudu, kterým byla omezena svéprávnost zástupce pořizovatele,

d) ztrátou bezúhonnosti, nebo

e) zrušením oprávnění podle odstavce 3.

(3) Ministerstvo zruší oprávnění k výkonu územně plánovací činnosti, pokud zástupce pořizovatele

a) poruší opakovaně nebo hrubým způsobem právní předpisy při výkonu územně plánovací činnosti, nebo

b) přestal splňovat podmínky pro výkon funkce.

(4) Osoba, které zaniklo oprávnění k výkonu územně plánovací činnosti, o této skutečnosti bezodkladně informuje obecní úřad, pro který tuto činnost vykonává, a předloží mu návrh dalšího postupu pořizování územně plánovací dokumentace nebo územní studie.

##### Díl 4

#### § 54 — Stanoviska a vyjádření dotčených orgánů

(1) Dotčené orgány uplatňují stanoviska, která nejsou rozhodnutím ve správním řízení a jejichž obsah je závazný pro pořizování územně plánovací dokumentace, územních opatření nebo vymezení zastavěného území, není-li při řešení rozporů stanoveno jinak. Ustanovení § 149 odst. 2 správního řádu se použije pro obsah stanovisek obdobně.

(2) Dotčené orgány uplatňují vyjádření k návrhu zadání územně plánovací dokumentace, vyhodnocení vlivů, návrhu zprávy o uplatňování územně plánovací dokumentace a návrhu zadání změny územně plánovací dokumentace.

(3) Obsahuje-li posuzovaný návrh varianty řešení, dotčený orgán posuzuje každou variantu samostatně.

(4) Jsou-li v rámci procesu pořizování nástrojů územního plánování stanoveny lhůty pro uplatnění stanovisek nebo vyjádření a dotčený orgán v této lhůtě stanovisko nebo vyjádření neuplatní, k později uplatněnému stanovisku nebo vyjádření se nepřihlíží.

#### § 55 — Řešení rozporů

Orgány územního plánování projednávají protichůdná stanoviska dotčených orgánů. Dojde-li k rozporu mezi pořizovatelem a dotčenými orgány, jakož i mezi dotčenými orgány navzájem, postupuje se podle správního řádu.

##### Díl 5

#### § 56 — Územní rezerva

(1) Územní rezervou se v tomto zákoně rozumí plocha nebo koridor, které jsou vymezené v územně plánovací dokumentaci pro využití, jehož potřebu a plošné nároky je třeba následně prověřit.

(2) Při vymezení územní rezervy se v územně plánovací dokumentaci stanoví její uvažované budoucí využití, popřípadě podmínky pro jeho prověření.

(3) Změnit územní rezervu na plochu nebo koridor umožňující stanovené využití lze jen změnou územně plánovací dokumentace.

(4) Územní rezerva se neposuzuje z hlediska vlivů na udržitelný rozvoj území, na životní prostředí, na předmět ochrany nebo celistvost evropsky významné lokality nebo ptačí oblasti ani z hlediska předpokládaných důsledků navrhovaného řešení na zemědělský půdní fond a pozemky určené k plnění funkce lesa; uvedené vlivy se posuzují až při změně územně plánovací dokumentace, která má umožnit stanovené využití.

(5) V územní rezervě jsou zakázány změny v území, které by mohly stanovené využití podstatně ztížit nebo znemožnit.

(6) Účelnost dalšího trvání vymezení územní rezervy pořizovatel vždy vyhodnotí podle § 107 odst. 2 písm. a).

##### Úplné znění a koordinační výkres

#### § 57

(1) Úplným zněním územně plánovací dokumentace nebo vymezení zastavěného území (dále jen „úplné znění“) se rozumí účinné znění územně plánovací dokumentace nebo vymezení zastavěného území se zapracovanými pozdějšími změnami. Úplné znění obsahuje textovou a grafickou část.

(2) Zpracování úplného znění zajistí pořizovatel změny územně plánovací dokumentace nebo vymezení zastavěného území.

(3) Koordinačním výkresem se rozumí výkres zahrnující navržené řešení, neměněný současný stav a důležitá omezení v území, zejména limity využití území.

(4) Úplné znění se po vydání změny územně plánovací dokumentace opatří záznamem o účinnosti, který obsahuje

a) označení správního orgánu, který poslední změnu vydal,

b) pořadové číslo poslední změny,

c) datum nabytí účinnosti poslední změny,

d) jméno, příjmení, funkci a podpis oprávněné úřední osoby pořizovatele a otisk úředního razítka.

#### § 58

(1) Dojde-li při vyhotovení úplného znění k pochybení, pořizovatel chybu bezodkladně odstraní nebo zajistí její odstranění; případné vady při vyhotovení úplného znění nemají vliv na účinnost změny územně plánovací dokumentace.

(2) Za padělání nebo pozměňování úplného znění se nepovažuje změna způsobu grafického vyjádření.

#### § 59 — Jednotný standard

(1) Územně plánovací dokumentace, její změna a úplné znění, územní studie, vymezení zastavěného území, jeho změna a úplné znění a územní opatření se vyhotovují v elektronické verzi ve strojově čitelném formátu10), včetně prostorových dat11), rovněž ve vektorové formě.

(2) Vybrané části územně plánovací dokumentace, její změny a úplné znění, vymezení zastavěného území, jeho změna a úplné znění a územní opatření se zpracovávají v jednotném standardu.

(3) Jednotný standard územně plánovací dokumentace, vymezení zastavěného území a územního opatření stanoví jejich standardizované části a požadavky na

a) geodetický referenční systém,

b) strukturu standardizovaných částí,

c) grafické vyjádření standardizovaných částí,

d) výměnný formát dat a

e) metadata.

(4) Podrobný obsah jednotného standardu včetně stanovení vybraných částí územně plánovací dokumentace, vymezení zastavěného území a územního opatření, které se zpracovávají v jednotném standardu, a požadavky na strojově čitelný formát stanoví prováděcí právní předpis.

#### § 60 — Mapové a další podklady pro územně plánovací činnost

(1) Mapovými podklady pro územně plánovací činnost (dále jen „mapové podklady“) jsou katastrální mapa a základní státní mapová díla; mapovým podkladem pro pořízení regulačního plánu může být též polohopisné a výškopisné zaměření řešeného území.

(2) Mapovým podkladem jsou dále základní báze geografických dat a tematická státní mapová díla.

(3) Pro účely územního plánování je možné mapový podklad doplnit na základě skutečností zjištěných vlastním průzkumem území; záznam o provedeném doplnění se ukládá u pořizovatele.

(4) Při územně plánovací činnosti se jako další podklad používají digitální technická mapa kraje, digitální technická mapa obce, je-li k dispozici, a digitální mapa veřejné správy podle jiného právního předpisu14).

#### HLAVA III

##### Díl 1

#### § 61 — Druhy nástrojů územního plánování

Nástroji územního plánování jsou

a) územně plánovací podklady, kterými jsou územně analytické podklady a územní studie,

b) politika územního rozvoje,

c) územně plánovací dokumentace, kterými jsou územní rozvojový plán, zásady územního rozvoje, územní plán a regulační plán,

d) vymezení zastavěného území,

e) územní opatření, kterými jsou územní opatření o stavební uzávěře, územní opatření o asanaci území a územní opatření o podmínkách a zmírňujících opatřeních podle zákona o urychlení využívání obnovitelných zdrojů energie.

##### Díl 2

##### Oddíl 1

#### § 62

(1) Územně analytické podklady slouží zejména jako odborný podklad pro pořizování politiky územního rozvoje, územně plánovacích dokumentací, územních studií, územních opatření, vymezení zastavěného území a pro rozhodování v území.

(2) Územně analytické podklady obsahují zjištění a vyhodnocení stavu a vývoje území, jeho hodnot, limitů využití území, záměrů na provedení změn v území, zjišťování a vyhodnocování podmínek udržitelného rozvoje území a určení problémů k řešení v územně plánovací dokumentaci.

(3) Náležitosti obsahu územně analytických podkladů stanoví prováděcí právní předpis.

#### § 63 — Údaje o území

(1) Údaji o území jsou informace nebo data o stavu území a omezeních, která se váží k určité části území, například ploše, pozemku, přírodnímu útvaru nebo stavbě, a která vznikla nebo byla zjištěna zejména na základě právních předpisů, a dále informace nebo data o záměrech na provedení změny v území; součástí údaje o území jsou také metadata.

(2) Údaje o území poskytuje pořizovateli poskytovatel údajů o území, kterým je

a) orgán veřejné správy, s jehož působností údaje o území souvisejí, nebo právnická osoba, jejímž zřizovatelem je stát nebo územní samosprávný celek,

b) vlastník dopravní nebo technické infrastruktury,

c) provozovatel staveb a zařízení, z jejichž provozu vznikají omezení v území podle jiného právního předpisu15).

#### § 64 — Poskytování údajů o území

(1) Poskytovatel údajů o území poskytuje údaje v digitální formě bezodkladně po jejich vzniku nebo po jejich zjištění, přitom odpovídá za jejich správnost, úplnost a aktuálnost, a to v rozsahu charakteristik přesnosti uvedených v rámci metadat. Údaje o území se poskytují ve formátech a za podmínek stanovených prováděcím právním předpisem. Povinnost poskytnutí údajů o území je splněna jejich vložením do digitální technické mapy kraje16), do národního geoportálu územního plánování nebo do registru územní identifikace, adres a nemovitostí17).

(2) Údaje o území mohou být použity pouze pro činnost orgánů veřejné správy a pro činnost projektanta územně plánovací dokumentace a územní studie.

(3) Vlastník dopravní nebo technické infrastruktury má nárok na úhradu účelně vynaložených nákladů spojených s poskytnutím údajů o území podle tohoto zákona, nejvýše však do výše nákladů na pořízení jejich kopií, nosičů dat a nákladů na doručení pořizovateli. Náklady hradí pořizovatel na základě žádosti vlastníka dopravní nebo technické infrastruktury.

(4) Poskytovatel údajů o území, který nesplní povinnost podle odstavce 1, je povinen uhradit z toho vyplývající náklady na změny územně plánovací dokumentace, územní studie a na aktualizaci územně analytických podkladů a odpovídá za škodu vzniklou v důsledku toho, že údaje o území neposkytl nebo je poskytl nesprávné.

#### § 65 — Pořizování a aktualizace územně analytických podkladů

(1) Územně analytické podklady a jejich aktualizace pořizuje pořizovatel na základě průzkumů území, údajů o území a dalších dostupných informací. Pořizovatel zohledňuje také prognózy dalšího vývoje území, aby získal představu o jeho budoucím stavu a vývoji.

(2) Podkladem pro pořízení územně analytických podkladů je i digitální technická mapa kraje nebo obce, je-li k dispozici.

(3) Pořizovatel průběžně aktualizuje územně analytické podklady a nejpozději do 4 let od jejich poslední úplné aktualizace pořídí návrh nové úplné aktualizace.

#### § 66 — Projednání územně analytických podkladů

(1) Územně analytické podklady pro správní obvod obce s rozšířenou působností a jejich úplnou aktualizaci projedná pořizovatel v rozsahu určení problémů k řešení v územně plánovacích dokumentacích do 30 dnů po jejich vyhotovení s obcemi ve svém správním obvodu.

(2) Pořizovatel upraví územně analytické podklady pro správní obvod obce s rozšířenou působností podle výsledku projednání a bezodkladně je vloží do národního geoportálu územního plánování.

(3) Územně analytické podklady pro území kraje a jejich úplnou aktualizaci předkládá pořizovatel k projednání radě kraje v rozsahu a formě stanovené prováděcím právním předpisem.

(4) Krajský úřad vloží územně analytické podklady pro území kraje do národního geoportálu územního plánování do 10 dnů od jejich projednání podle odstavce 3.

##### Oddíl 2

#### § 67 — Účel

(1) Územní studie navrhuje, prověřuje a posuzuje možná řešení vybraných problémů v území, které by mohly významně ovlivňovat nebo podmiňovat jeho využití a uspořádání.

(2) Územní studie slouží jako odborný podklad pro

a) rozhodování v území, a to pouze v těch částech, v nichž je v souladu s územně plánovací dokumentací,

b) pořizování územně plánovací dokumentace, a to pouze v těch částech, v nichž není v rozporu s politikou územního rozvoje a nadřazenou územně plánovací dokumentací,

c) pořizování politiky územního rozvoje.

#### § 68 — Pořízení

(1) Pořizovatel pořizuje územní studii

a) v případech, kdy je to požadováno územně plánovací dokumentací,

b) z vlastního podnětu, nebo

c) z jiného podnětu.

(2) Náklady na zpracování územní studie požadované územně plánovací dokumentací hradí orgán, který územně plánovací dokumentaci vydal. Pořízení územní studie z jiného podnětu může pořizovatel podmínit úhradou nákladů na zpracování územní studie od toho, kdo tento podnět podal.

(3) V zadání územní studie určí pořizovatel její obsah, rozsah, cíle a účel. Pořizovatel může stanovit, že ten, kdo hodlá změnu v území realizovat, zajistí zpracování územní studie na své náklady.

(4) Jedná-li se o územní studii, jejíž pořízení je uloženo územním plánem jako podmínka pro rozhodování v území, předloží pořizovatel její návrh k projednání zastupitelstvu obce, které územní plán schválilo. Neprojedná-li zastupitelstvo obce návrh územní studie ve lhůtě 90 dnů ode dne jeho předložení zastupitelstvu obce pořizovatelem, platí, že s návrhem souhlasí.

(5) Je-li to nezbytné, zajistí pořizovatel úpravu územní studie a vloží ji do 7 dnů ode dne, kdy schválil možnost jejího využití do národního geoportálu územního plánování; toto vložení je podmínkou využití územní studie.

#### § 69 — Prověření územní studie

(1) Pořizovatel nejpozději do 8 let od vložení územní studie do národního geoportálu územního plánování a následně vždy do 8 let prověří její aktuálnost a v případě kladného výsledku prověření zajistí vložení dat o této skutečnosti do národního geoportálu územního plánování, jinak územní studii z národního geoportálu územního plánování vypustí.

(2) Nedojde-li ke vložení dat o prověření aktuálnosti územní studie ani k vypuštění územní studie z národního geoportálu územního plánování pořizovatelem ve lhůtě podle odstavce 1, vypustí ministerstvo, nebo jím pověřená organizační složka státu, do 30 dnů ode dne uplynutí lhůty podle odstavce 1 územní studii z národního geoportálu územního plánování.

##### Díl 3

#### § 70 — Politika územního rozvoje

(1) Politika územního rozvoje je strategickým dokumentem, který určuje ve stanoveném období požadavky na konkretizaci úkolů územního plánování v celostátních, přeshraničních a mezinárodních souvislostech a určuje strategii a základní podmínky pro naplňování těchto úkolů. Politika územního rozvoje se zpracovává pro celé území státu.

(2) Politika územního rozvoje s ohledem na možnosti území koordinuje tvorbu a změny územního rozvojového plánu a zásad územního rozvoje, tvorbu koncepcí schvalovaných ministerstvy a jinými ústředními správními úřady a záměry na změny v území celostátního významu a stanoví úkoly zajišťující tuto koordinaci.

(3) Ministerstvo zajistí, aby ve Sbírce zákonů a mezinárodních smluv bylo uveřejněno sdělení o schválení politiky územního rozvoje, a její zveřejnění v národním geoportálu územního plánování. Politika územního rozvoje je závazná pro pořizování a vydávání územně plánovací dokumentace dnem následujícím po dni uveřejnění sdělení podle věty první.

#### § 71 — Obsah

(1) Politika územního rozvoje

a) stanoví celostátní priority územního plánování pro zajištění udržitelného rozvoje území České republiky,

b) stanoví koncepci sídelní struktury České republiky,

c) vymezí oblasti ovlivněné rozvojovou dynamikou jednoho nebo více center osídlení se zvýšenými požadavky na změny v území, které jsou mezinárodního nebo celostátního významu nebo oblasti ovlivněné rozvojovou dynamikou jednoho nebo více center osídlení se zvýšenými požadavky na změny v území, které svým významem přesahují území jednoho kraje (dále jen „rozvojové oblasti“), a území s vazbou na kapacitní dopravní infrastrukturu propojující rozvojové oblasti a významná centra osídlení (dále jen „rozvojové osy“),

d) vymezí oblasti se specifickými hodnotami a se specifickými problémy mezinárodního nebo celostátního významu nebo oblasti se specifickými hodnotami a se specifickými problémy, které svým významem přesahují území jednoho kraje (dále jen „specifické oblasti“),

e) vymezí záměry dopravní a technické infrastruktury mezinárodního a celostátního významu nebo záměry dopravní a technické infrastruktury, které svým významem přesahují území jednoho kraje, a

f) stanoví úkoly podle § 70 odst. 2.

(2) K návrhu politiky územního rozvoje ministerstvo zajistí vyhodnocení vlivů, je-li to vyžadováno podle § 40.

(3) Obsah a struktura politiky územního rozvoje jsou stanoveny v příloze č. 5 k tomuto zákonu.

#### § 71a — Návrh

(1) Ministerstvo pořizuje návrh politiky územního rozvoje ve spolupráci s ministerstvy, jinými ústředními správními úřady a kraji.

(2) Ministerstvo životního prostředí na žádost ministerstva ve lhůtě 30 dnů ode dne obdržení návrhu obsahu politiky územního rozvoje stanoví požadavky na vyhodnocení vlivů na životní prostředí. Příslušný orgán ochrany přírody doručí stanovisko podle § 45i odst. 1 zákona o ochraně přírody a krajiny ministerstvu a Ministerstvu životního prostředí nejpozději 10 dní před uplynutím lhůty podle věty první.

(3) Návrh politiky územního rozvoje pořizuje ministerstvo na základě

a) územně plánovacích podkladů,

b) dokumentů určených k podpoře regionálního rozvoje,

c) podkladů a dokumentů veřejné správy, které mají v mezinárodních a celostátních souvislostech vliv na využívání území státu,

d) zprávy o stavu životního prostředí a

e) mezinárodních závazků České republiky vztahujících se k územnímu rozvoji.

#### § 71b — Projednání návrhu

(1) Ministerstvo zveřejní návrh politiky územního rozvoje spolu s vyhodnocením vlivů v národním geoportálu územního plánování a současně návrh politiky územního rozvoje spolu s vyhodnocením vlivů zašle

a) ministerstvům,

b) jiným ústředním správním úřadům a

c) krajům.

(2) Ministerstva, jiné ústřední správní úřady, kraje, obce a veřejnost mohou písemně uplatnit své připomínky do 60 dnů od zveřejnění návrhu politiky územního rozvoje. K později uplatněným připomínkám se nepřihlíží.

(3) Ministerstvo ve spolupráci s Ministerstvem zahraničních věcí a Ministerstvem životního prostředí zašle návrh politiky územního rozvoje spolu s vyhodnocením vlivů sousedním státům, jejichž území může být uplatňováním politiky územního rozvoje významně ovlivněno a nabídne jim konzultace. Projeví-li sousední stát o konzultace zájem, ministerstvo se ve spolupráci s Ministerstvem zahraničních věcí a Ministerstvem životního prostředí konzultací účastní.

(4) Ministerstvo v návrhu politiky územního rozvoje zohlední připomínky, výsledky vyhodnocení vlivů a případná vyjádření sousedních států a výsledky konzultací.

#### § 71c — Stanovisko k návrhu koncepce

(1) Ministerstvo zašle návrh vyhodnocení uplatněných připomínek, případných vyjádření sousedních států a výsledků konzultací Ministerstvu životního prostředí jako podklad pro vydání stanoviska k návrhu koncepce podle § 10g zákona o posuzování vlivů na životní prostředí.

(2) Ministerstvo životního prostředí stanovisko uplatní do 30 dnů od obdržení podkladů podle odstavce 1. Nejedná-li se o změnu politiky územního rozvoje, lze lhůtu pro uplatnění stanoviska ze závažných důvodů, které Ministerstvo životního prostředí sdělí ministerstvu nejpozději do 30 dnů od obdržení podkladů, prodloužit, nejdéle však o 30 dnů.

(3) Neuplatní-li Ministerstvo životního prostředí stanovisko ve lhůtě podle odstavce 2, je možné politiku územního rozvoje schválit i bez tohoto stanoviska; v takovém případě ministerstvo zohlední závěry vyhodnocení vlivů, připomínky a výsledky konzultací.

(4) Vyplyne-li z posouzení vlivu na evropsky významnou lokalitu nebo ptačí oblast, že politika územního rozvoje má významný negativní vliv na předmět ochrany nebo celistvost evropsky významné lokality nebo ptačí oblasti, postupuje se podle § 45i zákona o ochraně přírody a krajiny. Kompenzační opatření uvede Ministerstvo životního prostředí ve stanovisku podle § 54 odst. 1.

#### § 71d — Schválení a uplatňování

(1) Ministerstvo předkládá návrh politiky územního rozvoje ke schválení vládě.

(2) Ministerstvo nejpozději do 4 let od schválení politiky územního rozvoje a poté nejméně jednou za 4 roky vyhodnotí uplatňování politiky územního rozvoje.

(3) Za účelem vyhodnocení uplatňování politiky územního rozvoje zpracuje ministerstvo ve spolupráci s ministerstvy, jinými ústředními správními úřady a kraji zprávu o plnění politiky územního rozvoje (dále jen „zpráva o plnění“), která obsahuje zejména

a) vyhodnocení plnění úkolů politiky územního rozvoje,

b) problémy k řešení v politice územního rozvoje vyplývající z územně analytických podkladů,

c) posouzení vlivu územního rozvojového plánu, zásad územního rozvoje, podkladů a dokumentů veřejné správy s celostátním zaměřením na uplatňování politiky územního rozvoje,

d) vyhodnocení vlivů na udržitelný rozvoj území vyplývajících z uplatňování politiky územního rozvoje z hlediska možných nepředvídaných dopadů, včetně potřeby opatření na jejich odvrácení, zmírnění nebo kompenzaci,

e) vyhodnocení potřeby pořízení změny politiky územního rozvoje nebo nové politiky územního rozvoje.

(4) Vyplyne-li z vyhodnocení podle odstavce 3 písm. e) potřeba pořízení změny politiky územního rozvoje nebo nové politiky územního rozvoje, obsahuje zpráva o plnění dále zejména

a) návrhy na změnu politiky územního rozvoje včetně jejich zdůvodnění, popřípadě návrh a důvody na pořízení nového návrhu politiky územního rozvoje,

b) stanovisko podle § 45i odst. 1 zákona o ochraně přírody a krajiny,

c) stanovisko Ministerstva životního prostředí zpracované na základě kritérií podle přílohy č. 8 k zákonu o posuzování vlivů na životní prostředí s uvedením, má-li být změna politiky územního rozvoje posouzena z hlediska vlivů na životní prostředí,

d) návrh opatření, která je nutné provést v územně plánovací činnosti krajů a obcí a v činnosti ministerstev a dalších ústředních správních úřadů.

(5) Ministerstvo zveřejní návrh zprávy o plnění v národním geoportálu územního plánování a stanoví lhůtu pro podání písemných připomínek obcí a veřejnosti, která nesmí být kratší než 30 dnů ode dne zveřejnění návrhu. Připomínky se podávají ministerstvu. K později uplatněným připomínkám se nepřihlíží.

(6) Návrh zprávy o plnění předloží ministerstvo vládě, která

a) vezme zprávu o plnění na vědomí, není-li vyžadována změna nebo pořízení nové politiky územního rozvoje, nebo

b) schválí zprávu o plnění a rozhodne o změně politiky územního rozvoje nebo o pořízení návrhu nové politiky územního rozvoje.

#### § 71e — Změna

(1) Změna politiky územního rozvoje se zpracovává, projednává a vydává v rozsahu měněných částí. Pro zpracování a projednání změny politiky územního rozvoje se § 71a až 71c použijí obdobně.

(2) Vyhodnocení vlivů změny politiky územního rozvoje se zpracovává pouze v případě, stanoví-li tak Ministerstvo životního prostředí ve svém stanovisku podle § 71d odst. 4 písm. c).

(3) Ministerstvo zajistí vyhotovení úplného znění politiky územního rozvoje po její změně. Změnu politiky územního rozvoje a úplné znění politiky územního rozvoje po její změně ministerstvo zveřejní v národním geoportálu územního plánování.

(4) Z důvodu naléhavého veřejného zájmu může vláda na návrh rozhodnout o změně politiky územního rozvoje a jejím obsahu bez předložení zprávy o plnění. V takovém případě vláda může rozhodnout o zkrácení lhůt uvedených v § 71b odst. 2 a § 71c odst. 2.

(5) Návrh na změnu politiky územního rozvoje z důvodu naléhavého veřejného zájmu může podat ústřední orgán státní správy nebo rada kraje a obsahuje

a) údaje umožňující identifikaci navrhovatele,

b) obsah změny politiky územního rozvoje,

c) důvody pro pořízení změny, včetně uvedení naléhavého veřejného zájmu,

d) stanovisko podle § 45i odst. 1 zákona o ochraně přírody a krajiny a

e) stanovisko Ministerstva životního prostředí s uvedením, má-li být změna politiky územního rozvoje posouzena z hlediska vlivů na životní prostředí.

(6) Vláda může v odůvodněných případech rozhodnout o souběžném pořízení změny politiky územního rozvoje a územního rozvojového plánu nebo jeho změny.

##### Díl 4

##### Oddíl 1

#### § 72 — Společná ustanovení

(1) Územně plánovací dokumentace nesmí obsahovat podrobnosti, které náležejí svým obsahem navazující územně plánovací dokumentaci nebo rozhodnutí.

(2) Územně plánovací dokumentace a její odůvodnění obsahuje textovou část a grafickou část. Obsah a struktura územně plánovací dokumentace a obsah odůvodnění územně plánovací dokumentace jsou stanoveny v přílohách č. 6 až 9 k tomuto zákonu.

(3) Územně plánovací dokumentací se rozumí i změna územně plánovací dokumentace.

(4) Pro obsah územně plánovací dokumentace vojenského újezdu se ustanovení tohoto zákona použijí přiměřeně. Návrh územně plánovací dokumentace vojenského újezdu se podle tohoto zákona projednává jen v rozsahu vlivů přesahujících hranice vojenského újezdu.

#### § 73 — Forma a závaznost územně plánovací dokumentace

(1) Územně plánovací dokumentace se vydává formou opatření obecné povahy.

(2) Územně plánovací dokumentace je závazná pro rozhodování v území a další změny v území. Drobné stavby lze realizovat pouze v souladu s územně plánovací dokumentací.

(3) Nadřazená územně plánovací dokumentace je závazná pro obsah navazující územně plánovací dokumentace. K části navazující územně plánovací dokumentace, která je v rozporu s nadřazenou územně plánovací dokumentací, se nepřihlíží.

(4) Je-li to účelné, navazující územně plánovací dokumentace zpřesňuje vymezení ploch a koridorů vymezených v nadřazené územně plánovací dokumentaci.

(5) Zpřesněním podle odstavce 4 se rozumí vymezení ploch a koridorů v území zahrnutém do plochy nebo koridoru vymezeného v nadřazené územně plánovací dokumentaci. Zpřesněním plochy nebo koridoru se upřesňuje také území, k němuž se vztahují podmínky stanovené v nadřazené územně plánovací dokumentaci pro zpřesňovanou plochu nebo koridor.

##### Územní rozvojový plán

#### § 74

(1) Územní rozvojový plán zpřesňuje záměry vymezené v politice územního rozvoje v souladu s cíli a úkoly územního plánování, vymezuje další záměry, zohledňuje požadavky vyplývající ze strategických koncepcí České republiky a mezinárodních závazků a přispívá k jejich naplňování.

(2) Územní rozvojový plán vymezuje

a) zastavitelné plochy, transformační plochy a koridory určené pro umístění záměrů dopravní a technické infrastruktury mezinárodního nebo celostátního významu, nebo přesahující svým významem území jednoho kraje, vymezené politikou územního rozvoje a stanovuje účel jejich vymezení, popřípadě podmínky pro rozhodování v území,

b) zastavitelné plochy, transformační plochy, plochy a koridory pro další záměry mezinárodního nebo celostátního významu, nebo přesahující svým významem území jednoho kraje, které nejsou vymezeny v politice územního rozvoje a o kterých tak rozhodne vláda, a stanovuje účel jejich vymezení, popřípadě podmínky pro rozhodování v území,

c) akcelerační oblasti celostátního významu a stanovuje druh primární energie zdrojů, pro něž se oblast vymezuje,

d) územní systém ekologické stability nadregionálního významu a

e) veřejně prospěšné stavby, veřejně prospěšná opatření, stavby a opatření k zajišťování obrany a bezpečnosti státu a plochy pro asanaci, pro které lze práva k pozemkům a stavbám vyvlastnit.

#### § 75

(1) Územní rozvojový plán může vymezit plochu nebo koridor územní rezervy.

(2) Územní rozvojový plán může stanovit pořadí provádění změn v území.

(3) K podrobnějšímu prověření navrženého řešení může územní rozvojový plán ve vybraných plochách nebo koridorech uložit pořízení územní studie.

#### § 76

(1) Územní rozvojový plán se pořizuje a vydává pro celé území státu.

(2) K návrhu územního rozvojového plánu ministerstvo zajistí vyhodnocení vlivů, je-li to vyžadováno podle § 40.

##### Zásady územního rozvoje

#### § 77

(1) Zásady územního rozvoje jsou základním koncepčním dokumentem kraje k usměrňování jeho územního rozvoje a ochrany hodnot jeho území.

(2) Zásady územního rozvoje

a) stanoví koncepci rozvoje území kraje a rozvoje a ochrany jeho hodnot, včetně koncepce sídelní struktury kraje, se zohledněním koncepce sídelní struktury státu obsažené v politice územního rozvoje,

b) zpřesňují vymezení rozvojových oblastí a rozvojových os obsažených v politice územního rozvoje a, je-li to účelné, vymezí rozvojové oblasti a rozvojové osy nadmístního významu,

c) zpřesňují vymezení specifických oblastí obsažených v politice územního rozvoje a, je-li to účelné, vymezí specifické oblasti nadmístního významu,

d) přebírají a, je-li to účelné, zpřesňují věcná řešení obsažená v územním rozvojovém plánu, zejména zastavitelné plochy, transformační plochy a koridory, akcelerační oblasti a územní systém ekologické stability nadregionálního významu,

e) vymezují zastavitelné plochy, transformační plochy a koridory nadmístního významu, včetně ploch a koridorů veřejné infrastruktury, ploch pro těžbu nerostů, územního systému ekologické stability regionálního významu, stanoví účel, pro který jsou vymezeny, a požadavky na jejich využití,

f) vymezují akcelerační oblasti nadmístního významu a stanovují druh primární energie zdrojů, pro něž se oblast vymezuje,

g) vymezují krajiny a stanoví jejich cílové kvality podle Evropské úmluvy o krajině18), včetně územních podmínek pro jejich zachování nebo dosažení,

h) přebírají a, je-li to účelné, zpřesňují veřejně prospěšné stavby, veřejně prospěšná opatření, stavby a opatření k zajišťování obrany a bezpečnosti státu a plochy pro asanaci, pro které lze práva k pozemkům a stavbám vyvlastnit, obsažené v územním rozvojovém plánu,

i) vymezují veřejně prospěšné stavby, veřejně prospěšná opatření, stavby a opatření k zajišťování obrany a bezpečnosti státu a plochy pro asanaci, pro které lze práva k pozemkům a stavbám vyvlastnit,

j) stanovují požadavky na koordinaci územně plánovací činnosti obcí a na řešení v územně plánovacích dokumentacích obcí, a to i s přihlédnutím ke stanovené sídelní struktuře a obnovitelným a druhotným zdrojům energie.

#### § 78

(1) Zásady územního rozvoje v nadmístních souvislostech zpřesňují a rozvíjejí cíle a úkoly územního plánování v souladu s politikou územního rozvoje a územním rozvojovým plánem a určují strategii pro jejich naplňování.

(2) Je-li to účelné, zásady územního rozvoje stanoví podrobnější řešení obsažené v politice územního rozvoje nebo územním rozvojovém plánu a řeší další záležitosti, které přesahují svým významem nebo rozsahem území obce; přitom mohou obsahovat řešení vybraného území, koridoru, plochy nebo akcelerační oblasti, v podrobnějším měřítku.

(3) Zásady územního rozvoje mohou vymezit plochu nebo koridor územní rezervy.

(4) Zásady územního rozvoje mohou stanovit pořadí provádění změn v území.

(5) K podrobnějšímu prověření navrženého řešení mohou zásady územního rozvoje ve vybraných územích nebo koridorech uložit pořízení územní studie.

#### § 79

(1) Zásady územního rozvoje se pořizují a vydávají pro celé území kraje.

(2) Záležitosti celostátního významu, které nejsou obsaženy v politice územního rozvoje nebo územním rozvojovém plánu, mohou být součástí zásad územního rozvoje, nevyloučí-li to nadřízený orgán ve stanovisku podle § 101 z důvodů potřeby jejich nadregionální koordinace.

(3) K návrhu zásad územního rozvoje pořizovatel zajistí vyhodnocení vlivů, je-li to vyžadováno podle § 40.

(4) Zásady územního rozvoje hlavního města Prahy řeší záležitosti celoměstského významu; přitom se ustanovení stanovící obsah zásad územního rozvoje týkající se rozvojových oblastí, rozvojových os, specifických oblastí a sídelní struktury použijí přiměřeně.

##### Územní plán

#### § 80

(1) Územní plán je základním koncepčním dokumentem obce k usměrňování územního rozvoje a ochrany hodnot jejího území.

(2) Územní plán

a) vymezí zastavěné území a stanoví datum, k němuž je vymezeno,

b) stanoví základní koncepci rozvoje území obce, vyjádřenou zejména v cílech zlepšování jeho dosavadního stavu a požadavcích na rozvoj a ochranu jeho hodnot,

c) stanoví urbanistickou koncepci, jejíž součástí je i urbanistická kompozice, vymezení ploch podle stávajícího nebo nově požadovaného způsobu využití (dále jen „plocha s rozdílným způsobem využití“), vymezení zastavitelných ploch, transformačních ploch, systému veřejných prostranství a systému sídelní zeleně,

d) stanoví koncepci veřejné infrastruktury, jejíž součástí je i stanovení podmínek pro její umisťování, vymezení ploch a koridorů pro veřejnou infrastrukturu, včetně stanovení podmínek pro jejich využití a vymezení akceleračních oblastí, včetně stanovení druhu primární energie zdrojů, pro něž se oblast vymezuje,

e) stanoví koncepci uspořádání krajiny, jejíž součástí je i vymezení ploch s rozdílným způsobem využití, ploch změn v krajině a stanovení podmínek pro jejich využití, vymezení a stanovení podmínek pro zelenou infrastrukturu včetně územního systému ekologické stability, prostupnost krajiny, protierozní opatření, ochranu před povodněmi a suchem, rekreaci a dobývání ložisek nerostných surovin,

f) stanoví podmínky pro využití ploch s rozdílným způsobem využití s určením hlavního využití, pokud je možné jej stanovit, přípustného využití, nepřípustného využití, popřípadě stanovení podmíněně přípustného využití těchto ploch a podmínky prostorového uspořádání, včetně základních podmínek ochrany krajinného rázu a charakteru území,

g) vymezí veřejně prospěšné stavby, veřejně prospěšná opatření, stavby a opatření k zajišťování obrany a bezpečnosti státu a plochy pro asanaci, pro které lze práva k pozemkům a stavbám vyvlastnit.

(3) Územní plán přebírá věcná řešení zásad územního rozvoje, zejména plochy, koridory a akcelerační oblasti a, je-li to účelné, zpřesňuje je. Nezohlednily-li zásady územního rozvoje dosud věcná řešení obsažená v politice územního rozvoje nebo územním rozvojovém plánu, územní plán tato řešení přebírá a, je-li to účelné, zpřesňuje je.

#### § 81

(1) Územní plán může vymezit plochy a koridory územních rezerv a členit území podle převažujícího charakteru na lokality.

(2) Územní plán může vymezit zastavitelné území. Do zastavitelného území se zahrne zastavěné území, zastavitelné plochy a transformační plochy.

(3) V územním plánu lze vymezit plochu nebo koridor, v němž je rozhodování v území podmíněno uzavřením plánovací smlouvy. V takovém případě územní plán stanoví základní obsah plánovací smlouvy, podmínky a lhůtu pro její uzavření, která nesmí být delší než 6 let od nabytí účinnosti územního plánu. Marným uplynutím stanovené lhůty pozbývá uvedená podmínka platnosti.

(4) Územní plán může ve vybraných plochách nebo koridorech uložit pořízení územní studie nebo vydání regulačního plánu jako podmínku pro rozhodování v území a stanoví základní podmínky pro pořízení územní studie a základní podmínky pro pořízení regulačního plánu nebo zadání regulačního plánu a lhůtu pro vložení územní studie do národního geoportálu územního plánování nebo pro nabytí účinnosti regulačního plánu, která nesmí být v obou případech delší než 6 let od nabytí účinnosti územního plánu. Marným uplynutím stanovené lhůty pozbývá uvedená podmínka platnosti.

(5) Územní plán může vymezit plochu nebo koridor, v nichž je rozhodování v území podmíněno architektonickou nebo urbanistickou soutěží. Architektonickou nebo urbanistickou soutěž zajistí na požádání stavebníka na své náklady obec, jejíž zastupitelstvo územní plán vydalo. Architektonickou nebo urbanistickou soutěž může namísto obce zajistit na své náklady ten, kdo hodlá v této ploše nebo koridoru záměr realizovat.

(6) Územní plán může stanovit pořadí provádění změn v území.

#### § 82

(1) Územní plán se pořizuje a vydává, rozhodne-li tak zastupitelstvo obce, a to pro celé území obce, není-li v tomto zákoně stanoveno jinak.

(2) Územní plán může být pořízen a vydán i pro část území hlavního města Prahy. V takovém případě obsahuje územní plán vymezení řešeného území. Územní plán hlavního města Prahy se považuje za nadřazenou územně plánovací dokumentaci.

(3) Územní plán může pro celé území obce nebo pro jeho část obsahovat prvky regulačního plánu, stanoví-li tak zastupitelstvo obce v zadání územního plánu nebo v zadání změny územního plánu.

#### § 83

(1) K návrhu územního plánu pořizovatel zajistí vyhodnocení vlivů, je-li to vyžadováno podle § 40.

(2) Územní plán může vymezit architektonicky nebo urbanisticky významné stavby19).

(3) Poskytování veřejných prostředků podle jiných právních předpisů na provedení změn v území nesmí být v rozporu s vydaným územním plánem.

#### § 84

Záležitosti nadmístního významu, které nejsou obsaženy v zásadách územního rozvoje, mohou být součástí územního plánu, nevyloučí-li to nadřízený orgán ve stanovisku podle § 101 z důvodů potřeby jejich nadmístní koordinace.

##### Regulační plán

#### § 85

(1) Regulační plán v řešeném území stanoví podrobné podmínky pro

a) vymezení a využití pozemků,

b) umístění a prostorové uspořádání staveb, včetně jejich napojení na veřejnou dopravní a technickou infrastrukturu, a urbanistických a architektonických podmínek,

c) umístění a prostorové uspořádání staveb veřejné infrastruktury,

d) ochranu hodnot, charakteru území a krajinného rázu.

(2) Regulační plán dále zpravidla stanoví

a) uliční a stavební čáry,

b) vzájemné odstupy staveb a odstupy staveb od hranice pozemku,

c) půdorysnou velikost stavby, výšku, objem a tvar stavby,

d) základní údaje o kapacitě stavby,

e) určení částí pozemku, které mohou být zastavěny, nebo zastavitelnost pozemku dalšími stavbami,

f) základní podmínky pro požární ochranu,

g) podmínky pro příznivé životní prostředí a zelenou infrastrukturu, včetně vymezení a využití pozemků územního systému ekologické stability.

#### § 86

(1) Regulační plán se pořizuje a vydává pro řešené území, rozhodne-li tak zastupitelstvo obce.

(2) Regulační plán může vymezit veřejně prospěšné stavby nebo veřejně prospěšná opatření, stavby a opatření k zajišťování obrany a bezpečnosti státu a pozemky pro asanaci, pro která lze práva k pozemkům a stavbám vyvlastnit.

(3) V regulačním plánu lze vymezit záměr, pro který je uzavření plánovací smlouvy podmínkou pro rozhodování v území. V takovém případě obsahuje základní podmínky pro uzavření plánovací smlouvy a lhůtu pro uzavření plánovací smlouvy, která nesmí být delší než 4 roky. Marným uplynutím stanovené lhůty pozbývá uvedená podmínka platnosti.

(4) Regulační plán může vymezit záměr, pro který je provedení architektonické nebo urbanistické soutěže podmínkou pro rozhodování v území. Architektonickou nebo urbanistickou soutěž zajistí na požádání stavebníka na své náklady obec, jejíž zastupitelstvo regulační plán vydalo, není-li dohodnuto jinak. Architektonickou nebo urbanistickou soutěž může namísto obce zajistit na své náklady ten, kdo hodlá tento záměr realizovat.

(5) Regulační plán může vymezit stavbu domu pro dostupné nájemní bydlení, včetně stanovení podílu bytů určených pro dostupné nájemní bydlení.

(6) Regulační plán může stanovit pořadí provádění změn v území nebo architektonicky nebo urbanisticky významné stavby19).

##### Oddíl 2

#### § 87 — Rozhodnutí o pořízení a návrh zadání

(1) O pořízení územně plánovací dokumentace rozhoduje orgán příslušný k jejímu vydání (dále jen „schvalující orgán“) z

a) vlastního podnětu, nebo

b) podnětu podle § 109 odst. 1, jedná-li se o regulační plán nebo změnu územně plánovací dokumentace.

(2) Pořizovatel v součinnosti s určeným zastupitelem zpracuje návrh zadání územně plánovací dokumentace (dále jen „návrh zadání“) na základě rozhodnutí podle odstavce 1, a územně plánovacích podkladů. Jako podklad pro zpracování návrhu zadání lze využít i doplňující průzkumy a rozbory.

(3) V návrhu zadání se stanoví hlavní cíle a požadavky na zpracování návrhu územně plánovací dokumentace, v případě regulačního plánu a územního plánu pro vymezenou část území hlavního města Prahy se vymezí řešené území.

(4) Náležitosti obsahu a strukturu zadání zásad územního rozvoje, zadání územního plánu a zadání regulačního plánu stanoví prováděcí právní předpis.

##### Projednání a schválení návrhu zadání

#### § 88

(1) Pořizovatel bezodkladně zveřejní návrh zadání v národním geoportálu územního plánování a toto zveřejnění oznámí veřejnou vyhláškou. Pořizovatel oznámí zveřejnění jednotlivě dotčeným orgánům a

a) ministerstvu, územním samosprávným celkům v řešeném území a s řešeným územím přímo sousedícím v případě zásad územního rozvoje,

b) nadřízenému orgánu územního plánování a územním samosprávným celkům s řešeným územím přímo sousedícím v případě územního plánu.

(2) Územní samosprávný celek, pro který má být územně plánovací dokumentace pořizována, zveřejní návrh zadání na své úřední desce. Návrh zadání územního rozvojového plánu zveřejní na své úřední desce ministerstvo.

#### § 89

(1) Pořizovatel zašle bezodkladně návrh zadání územního rozvojového plánu, zpracovává-li se, zásad územního rozvoje a územního plánu příslušnému úřadu20) a současně orgánu ochrany přírody.

(2) Orgán ochrany přírody doručí pořizovateli a příslušnému úřadu do 20 dnů od obdržení návrhu zadání stanovisko podle § 45i zákona o ochraně přírody a krajiny, ve kterém uvede, zda je možné vyloučit významný vliv na předmět ochrany a celistvost evropsky významné lokality nebo ptačí oblasti.

(3) Příslušný úřad uplatní u pořizovatele do 30 dnů od obdržení návrhu zadání stanovisko, ve kterém i s přihlédnutím ke stanovisku orgánu ochrany přírody podle odstavce 2 uvede v případě

a) územního rozvojového plánu a zásad územního rozvoje podrobnější požadavky podle jiného právního předpisu21),

b) změny územního rozvojového plánu, změny zásad územního rozvoje a územního plánu a jeho změny, zda má být jejich návrh posuzován z hlediska vlivů na životní prostředí, popřípadě stanoví podrobnější požadavky podle jiného právního předpisu21).

(4) Požadavky podle odstavce 3 nesmí vyžadovat podrobnosti náležející svým obsahem navazující územně plánovací dokumentaci nebo rozhodnutí.

(5) Do 30 dnů od doručení oznámení podle § 88 odst. 1 může pořizovateli písemně doručit

a) dotčený orgán a nadřízený orgán vyjádření,

b) každý podněty.

(6) Vyplyne-li ze stanoviska orgánu uvedeného v odstavci 3, že návrh územního rozvojového plánu, zásad územního rozvoje nebo územního plánu má být posuzován z hlediska vlivů na životní prostředí, doplní pořizovatel v souladu s § 40 do návrhu zadání požadavek na vyhodnocení vlivů.

#### § 90

(1) Pořizovatel v součinnosti s určeným zastupitelem upraví návrh zadání na základě výsledků projednání a předloží jej ke schválení schvalujícímu orgánu.

(2) Schvalující orgán v odůvodněných případech nebo z podnětu dotčeného orgánu uloží v zadání zpracování variantního řešení návrhu územně plánovací dokumentace. Nesouhlasí-li schvalující orgán s předloženým návrhem zadání, vrátí předložený návrh pořizovateli se svými pokyny k úpravě a k novému projednání, nebo návrh zamítne.

(3) Schválené zadání pořizovatel do 7 dnů od jeho obdržení od schvalujícího orgánu zveřejní v národním geoportálu územního plánování.

##### Úhrada nákladů při pořizování územně plánovací dokumentace

#### § 91

(1) Náklady na mapové podklady, na zpracování územně plánovací dokumentace nebo její změny projektantem, na vyhodnocení vlivů, zpracovává-li se, na vyhotovení úplného znění územně plánovací dokumentace po její změně, na změnu navazující územně plánovací dokumentace a náklady na náhradu za změnu v území hradí u

a) územního rozvojového plánu ministerstvo,

b) zásad územního rozvoje kraj,

c) územního plánu a u regulačního plánu obec,

d) územně plánovací dokumentace pro území vojenského újezdu Ministerstvo obrany.

(2) Náklady spojené s pořizováním územně plánovací dokumentace neuvedené v odstavci 1 hradí pořizovatel.

#### § 92

(1) Vyplývá-li pořízení změny územně plánovací dokumentace ze změny politiky územního rozvoje nebo nadřazené územně plánovací dokumentace, uhradí náklady uvedené v § 91 odst. 1 na žádost ministerstvo, jedná-li se o politiku územního rozvoje nebo územní rozvojový plán, nebo územní samosprávný celek, který vydal nadřazenou územně plánovací dokumentaci.

(2) Odstavec 1 se nepoužije, byla-li příslušná část politiky územního rozvoje nebo nadřazené územně plánovací dokumentace, která změnu vyvolala, vydána na základě výhradní potřeby obce nebo kraje, nebo je-li ve prospěch rozvoje obce nebo kraje příslušných ke schválení navazující územně plánovací dokumentace.

(3) Je-li pořízení změny územně plánovací dokumentace nebo pořízení regulačního plánu vyvoláno výhradní potřebou toho, kdo dal ke změně podnět, může schvalující orgán podmínit jejich pořízení částečnou nebo úplnou úhradou nákladů uvedených v odstavci 1 a v § 91 odst. 1 tím, kdo podnět dal.

#### § 93 — Návrh územně plánovací dokumentace

(1) Schválené zadání předá pořizovatel bezodkladně projektantovi územně plánovací dokumentace, který zajistí zpracování návrhu územně plánovací dokumentace. Je-li vyžadováno zpracování vyhodnocení vlivů, zajistí jeho zpracování pořizovatel.

(2) Po obdržení návrhu územně plánovací dokumentace a vyhodnocení vlivů, zpracovává-li se, pořizovatel v součinnosti s určeným zastupitelem bez zbytečného odkladu vyhodnotí zejména jejich úplnost, soulad s požadavky tohoto zákona a jeho prováděcích právních předpisů, soulad se zadáním a soulad s nadřazenou územně plánovací dokumentací.

(3) Nesplňuje-li návrh územně plánovací dokumentace požadavky uvedené v odstavci 2, zpracuje pořizovatel v součinnosti s určeným zastupitelem pokyny k jeho dopracování. Pořizovatel pokyny předá projektantovi do 7 dnů od jejich zpracování a stanoví mu přiměřenou lhůtu k jejich zapracování. Po obdržení dopracovaného návrhu se postup podle odstavce 2 a tohoto odstavce použije přiměřeně.

(4) Pro vyhodnocení vlivů, zpracovává-li se, se postup podle odstavce 3 použije obdobně.

(5) Pořizovatel do 7 dnů po kladném vyhodnocení podle odstavce 2

a) zveřejní návrh územně plánovací dokumentace a vyhodnocení vlivů, zpracovává-li se, v národním geoportálu územního plánování a vystaví je k nahlédnutí,

b) oznámí místo a dobu konání společného jednání a

c) veřejnou vyhláškou oznámí místo a dobu konání veřejného projednání a místa, kde je možné do návrhu územně plánovací dokumentace a vyhodnocení vlivů, zpracovává-li se, nahlédnout.

#### § 94 — Společné jednání

(1) Pořizovatel oznámí místo, dobu konání společného jednání a adresu uložení návrhu územně plánovací dokumentace v národním geoportálu územního plánování jednotlivě dotčeným orgánům a dále v případě

a) územního rozvojového plánu krajům,

b) zásad územního rozvoje ministerstvu, sousedním krajům, a obcím v řešeném území a s řešeným územím sousedícím,

c) územního plánu obci, pro kterou je územní plán pořizován, krajskému úřadu, Ministerstvu obrany, je-li územní plán zpracováván pro obec sousedící s vojenským újezdem a sousedním obcím,

d) regulačního plánu obci, pro kterou je regulační plán pořizován.

(2) Společné jednání se koná nejdříve 15 dnů, nejpozději však 30 dnů od oznámení podle § 93 odst. 5.

(3) Dotčené orgány uplatní do 15 dnů ode dne konání společného jednání svá stanoviska k návrhu územně plánovací dokumentace a vyjádření k vyhodnocení vlivů. Ve stejné lhůtě mohou orgány a osoby uvedené v odstavci 1 uplatnit připomínky. Ke stanoviskům a připomínkám uplatněným po uvedené lhůtě nebo uplatněným ve věcech, o nichž bylo rozhodnuto v nadřazené územně plánovací dokumentaci, se nepřihlíží.

#### § 95 — Přeshraniční konzultace

(1) Je-li ve vyhodnocení vlivů zjištěn významný negativní vliv na území sousedního státu, pořizovatel prostřednictvím Ministerstva životního prostředí a Ministerstva zahraničních věcí zašle návrh územně plánovací dokumentace a vyhodnocení vlivů příslušnému orgánu sousedního státu22), jehož území může být uplatňováním územně plánovací dokumentace významně ovlivněno, a nabídne mu konzultace.

(2) Projeví-li příslušný orgán sousedního státu o konzultace zájem, pořizovatel přizve k účasti příslušný orgán sousedního státu, Ministerstvo zahraničních věcí, Ministerstvo životního prostředí, určeného zastupitele a ministerstvo, není-li pořizovatelem projednávané územně plánovací dokumentace.

#### § 96 — Veřejné projednání

(1) Veřejným projednáním se rozumí prezentace návrhu územně plánovací dokumentace a vyhodnocení vlivů, zpracovává-li se, veřejnosti se zajištěním odborného výkladu, který zajistí pořizovatel ve spolupráci s projektantem, a umožnění dotazů veřejnosti.

(2) Veřejné projednání nařizuje pořizovatel po dohodě s určeným zastupitelem postupem podle § 93 odst. 5 písm. c). Je-li to účelné, nařídí pořizovatel více veřejných projednání na jím určených místech nebo konání veřejného projednání formou dálkového přístupu. Pro počítání lhůt stanovených zákonem je rozhodný den konání posledního veřejného projednání.

(3) Veřejné projednání se koná nejpozději třicátý den ode dne doručení veřejné vyhlášky podle § 93 odst. 5.

(4) Z průběhu veřejného projednání pořizovatel pořídí písemný záznam.

#### § 97 — Připomínky

(1) Do 15 dnů ode dne veřejného projednání může každý uplatnit písemně své připomínky k návrhu územně plánovací dokumentace a vyhodnocení vlivů, zpracovává-li se. K připomínkám uplatněným po stanovené lhůtě nebo uplatněným ve věcech, o kterých bylo rozhodnuto v nadřazené územně plánovací dokumentaci, se nepřihlíží.

(2) Připomínka musí kromě obecných náležitostí podání podle správního řádu obsahovat odůvodnění a vymezení území dotčeného připomínkou.

(3) Obsahuje-li návrh územně plánovací dokumentace varianty řešení, uplatňují se připomínky ke každé variantě samostatně.

(4) Proti návrhu územně plánovací dokumentace nelze podat námitky podle části šesté správního řádu.

#### § 98 — Vyhodnocení výsledků projednání

(1) Pořizovatel v součinnosti s určeným zastupitelem vyhodnotí uplatněná stanoviska a zajistí řešení případných rozporů.

(2) S ohledem na cíle a úkoly územního plánování zpracuje pořizovatel v součinnosti s určeným zastupitelem návrh vyhodnocení připomínek uplatněných k návrhu územně plánovací dokumentace, včetně jeho odůvodnění, je-li navrženo připomínce nevyhovět nebo vyhovět pouze částečně. Věcně související připomínky lze vyhodnotit společně.

(3) Návrh vyhodnocení připomínek nesmí být v rozporu s právními předpisy, se stanovisky dotčených orgánů nebo s výsledkem řešení rozporů a s politikou územního rozvoje a nadřazenou územně plánovací dokumentací.

(4) Obsahuje-li návrh územně plánovací dokumentace varianty řešení, pořizovatel v součinnosti s projektantem a určeným zastupitelem na základě uplatněných připomínek a stanovisek, vyhodnocení vlivů, zpracovává-li se, popřípadě na základě výsledků řešení rozporů, navrhne s ohledem na cíle a úkoly územního plánování výběr nejvhodnější varianty.

(5) Pořizovatel zašle bezodkladně návrh vyhodnocení připomínek a návrh výběru nejvhodnější varianty dotčeným orgánům a vyzve je, aby k nim ve lhůtě 30 dnů od obdržení uplatnily stanoviska. Neuplatní-li dotčený orgán stanovisko v uvedené lhůtě, má se za to, že s návrhy pořizovatele souhlasí.

(6) Pořizovatel v součinnosti s určeným zastupitelem vyhodnotí uplatněná stanoviska podle odstavce 5 a, je-li to nezbytné, zajistí řešení případných rozporů.

#### § 99 — Informování zastupitelstva

(1) Určený zastupitel může předložit zastupitelstvu návrh výběru nejvhodnější varianty a návrh vyhodnocení připomínek uplatněných k návrhu územně plánovací dokumentace k projednání.

(2) Předloží-li určený zastupitel návrhy podle odstavce 1 na jednání zastupitelstva, zastupitelstvo je projedná ve lhůtě 60 dnů. Neprojedná-li zastupitelstvo návrhy ve lhůtě podle věty první, platí, že s nimi souhlasí.

(3) Nesouhlasí-li zastupitelstvo s návrhy podle odstavce 1, vrátí je určenému zastupiteli se svými pokyny k úpravě, v opačném případě je vezme na vědomí.

(4) Pokyny zastupitelstva nesmí být v rozporu s právními předpisy, se stanovisky dotčených orgánů nebo s výsledkem řešení rozporů a s nadřazenou územně plánovací dokumentací.

(5) Určený zastupitel předá pokyny k úpravě návrhů podle odstavce 1 bezodkladně pořizovateli. Pořizovatel v součinnosti s určeným zastupitelem zajistí úpravu návrhů podle pokynů zastupitelstva.

#### § 100 — Stanovisko k návrhu koncepce

(1) Zpracovává-li se vyhodnocení vlivů, pořizovatel bezodkladně zašle návrh vyhodnocení připomínek, výsledky konzultací a návrh vyhodnocení uplatněných stanovisek, popřípadě výsledky řešení rozporů a návrh výběru nejvhodnější varianty příslušnému úřadu jako podklad pro vydání stanoviska k návrhu koncepce podle § 10g zákona o posuzování vlivů na životní prostředí.

(2) Příslušný úřad uplatní stanovisko k návrhu územního rozvojového plánu, zásad územního rozvoje nebo územního plánu, je-li předmětem posuzování, do 30 dnů od obdržení podkladů podle odstavce 1. Stanovisko podle věty první není stanoviskem podle § 54 odst. 1. Nejde-li o změnu územního plánu, lze lhůtu pro uplatnění stanoviska ze závažných důvodů usnesením, které se pouze poznamenává do spisu, prodloužit, nejdéle však o 30 dnů. Příslušný úřad vyrozumí bezodkladně pořizovatele o prodloužení lhůty.

(3) Neuplatní-li příslušný úřad stanovisko ve lhůtě podle odstavce 2, je možné územní rozvojový plán, zásady územního rozvoje nebo územní plán vydat i bez jeho stanoviska; v takovém případě pořizovatel zohlední závěry vyhodnocení vlivů, připomínky a výsledky konzultací.

(4) Vyplyne-li z posouzení vlivu na evropsky významnou lokalitu nebo ptačí oblast, že územní rozvojový plán, zásady územního rozvoje nebo územní plán mají významný negativní vliv na předmět ochrany nebo celistvost některé evropsky významné lokality nebo ptačí oblasti, který nebyl předmětem posouzení nadřazené územně plánovací dokumentace z hlediska těchto vlivů, postupuje se podle § 45i zákona o ochraně přírody a krajiny. Kompenzační opatření uvede příslušný orgán ochrany přírody ve svém stanovisku.

#### § 101 — Stanovisko nadřízeného orgánu

(1) Pořizovatel zásad územního rozvoje a územního plánu zašle návrh vyhodnocení připomínek, výsledky konzultací a návrh vyhodnocení stanovisek, popřípadě výsledky řešení rozporů a návrh výběru nejvhodnější varianty nadřízenému orgánu.

(2) Nadřízený orgán zašle pořizovateli stanovisko k návrhu zásad územního rozvoje nebo územního plánu z hledisek zajištění koordinace využívání území s ohledem na širší územní vztahy a souladu s politikou územního rozvoje a nadřazenou územně plánovací dokumentací ve lhůtě 30 dnů od obdržení podkladů podle odstavce 1. Nejde-li o změnu územního plánu, lhůtu podle věty první lze ze závažných důvodů usnesením, které se pouze poznamenává do spisu, prodloužit, nejdéle však o 30 dnů. Nadřízený orgán vyrozumí bezodkladně pořizovatele o prodloužení lhůty.

(3) Neuplatní-li nadřízený orgán stanovisko ve lhůtě podle odstavce 2 věty první, nebo ve lhůtě prodloužené, je možné zásady územního rozvoje nebo územní plán vydat i bez jeho stanoviska.

(4) Upozorní-li nadřízený orgán ve svém stanovisku pořizovatele na nedostatky z hledisek uvedených v odstavci 2, lze návrh předložit schvalujícímu orgánu ke schválení až na základě potvrzení nadřízeného orgánu o odstranění nedostatků.

##### Úprava návrhu a opakované projednání

#### § 102

(1) Pořizovatel v součinnosti s určeným zastupitelem vypracuje pokyny pro úpravu návrhu územně plánovací dokumentace v souladu s vyhodnocením výsledků projednání, stanoviskem k návrhu koncepce a se stanoviskem nadřízeného orgánu a předá je projektantovi. Obsahoval-li návrh varianty řešení, je součástí pokynů výběr nejvhodnější varianty.

(2) Projektant na základě pokynů podle odstavce 1 upraví návrh územně plánovací dokumentace. Obsahoval-li návrh varianty řešení, doplní odůvodnění o schéma variant a zdůvodnění výběru nejvhodnější varianty.

#### § 103

(1) Dojde-li na základě projednání k upravení návrhu územně plánovací dokumentace, při němž jsou nově negativně dotčeny veřejné zájmy nebo v případě územního plánu nebo regulačního plánu negativně dotčeno vlastnictví pozemků a staveb a dotčený orgán ani vlastník neměli možnost k upravené dokumentaci uplatnit stanovisko nebo připomínku (dále jen „podstatná úprava“), nařídí pořizovatel bez zbytečného odkladu nové projednání v rozsahu podstatné úpravy. Za podstatnou úpravu se nepovažuje zúžení návrhu na nejvhodnější variantu ani jiný způsob grafického vyjádření nebo vnitřního uspořádání prostorových dat.

(2) Pořizovatel si k podstatné úpravě návrhu územního rozvojového plánu, zásad územního rozvoje a územního plánu vyžádá stanovisko orgánu ochrany přírody podle § 45i zákona o ochraně přírody a krajiny a stanovisko příslušného úřadu, ve kterém bude stanoveno, zda je nutné vyhodnocení vlivů upravit nebo zda vyžaduje podstatná úprava doplnit posouzení vlivů na životní prostředí. Stanovisko příslušný úřad vydá do 20 dnů od doručení žádosti pořizovatele. Příslušný orgán ochrany přírody doručí stanovisko pořizovateli a příslušnému úřadu nejpozději 7 dní před uplynutím lhůty podle věty druhé.

(3) Podstatná úprava se projednává v rozsahu měněných částí postupem podle § 93 odst. 5, § 94 až 99 a podle odstavců 1 a 2; společné jednání a veřejné projednání lze při splnění požadavků kladených na obě jednání spojit. Stanoviska, připomínky a vyjádření je možné uplatnit jen k podstatné úpravě, jinak se k nim nepřihlíží.

(4) Vyhodnocení vlivů, které sloužilo jako podklad pro projednání návrhu územně plánovací dokumentace, se s výjimkou případu, kdy tak stanoví příslušný úřad podle odstavce 2, neupravuje.

(5) Do 15 dnů ode dne konání opakovaného veřejného projednání uplatní stanovisko

a) příslušný úřad k podstatné úpravě návrhu územního rozvojového plánu, zásad územního rozvoje a územního plánu; pro jeho obsah, postup při jeho nevydání ve stanovené lhůtě a pro stanovení kompenzačních opatření se postupuje podle § 100 odst. 2 až 4 obdobně, a

b) nadřízený orgán k podstatné úpravě návrhu zásad územního rozvoje a územního plánu; pro jeho obsah, postup při jeho nevydání ve stanovené lhůtě a pro případ upozornění na nedostatky se postupuje podle § 101 odst. 2 až 4 obdobně.

(6) Vyžaduje-li návrh územně plánovací dokumentace na základě výsledku projednání podstatné úpravy další úpravy, postupuje se přiměřeně podle § 102, a je-li to nezbytné, obdobně podle odstavců 1 až 5.

##### Vydání územně plánovací dokumentace

#### § 104

(1) Pořizovatel v součinnosti s určeným zastupitelem bezodkladně předloží schvalujícímu orgánu návrh územně plánovací dokumentace s odůvodněním. Obsahoval-li návrh územně plánovací dokumentace varianty řešení, je součástí předkládaného návrhu také návrh výběru nejvhodnější varianty podle § 98 odst. 4. Návrh územně plánovací dokumentace musí být v souladu

a) s požadavky tohoto zákona a jeho prováděcích právních předpisů,

b) se stanovisky dotčených orgánů, popřípadě s výsledkem řešení rozporů a

c) s politikou územního rozvoje a nadřazenou územně plánovací dokumentací.

(2) Schvalující orgán schválí výběr nejvhodnější varianty, obsahuje-li ji předložený návrh, a vydá územně plánovací dokumentaci po ověření, že není v rozporu s požadavky uvedenými v odstavci 1 písm. a) a b) a nadřazenou územně plánovací dokumentací. Nesouhlasí-li schvalující orgán s předloženým návrhem, schválí pokyny k úpravě územně plánovací dokumentace, které předá pořizovateli, nebo návrh zamítne a ukončí tím její pořizování.

(3) Nevyvolají-li pokyny k úpravě podstatnou úpravu, pořizovatel zajistí úpravu návrhu územně plánovací dokumentace a poté jej předloží schvalujícímu orgánu k vydání. Vyvolají-li pokyny k úpravě podstatnou úpravu, postupuje pořizovatel obdobně podle § 103.

#### § 105

(1) Pořizovatel po vydání územně plánovací dokumentace zajistí její vložení do národního geoportálu územního plánování.

(2) Územně plánovací dokumentaci a adresu jejího uložení v národním geoportálu územního plánování oznámí pořizovatel veřejnou vyhláškou; dnem doručení veřejné vyhlášky nabývá územně plánovací dokumentace účinnosti.

(3) Územně plánovací dokumentace se opatří záznamem o účinnosti, který obsahuje

a) označení orgánu, který územně plánovací dokumentaci vydal,

b) datum nabytí účinnosti územně plánovací dokumentace,

c) jméno, příjmení, funkci a podpis oprávněné úřední osoby pořizovatele a otisk úředního razítka.

##### Oddíl 3

#### § 106 — Vyhodnocování uplatňování územně plánovací dokumentace

(1) Pořizovatel nejpozději do 4 let od vydání územně plánovací dokumentace, s výjimkou regulačního plánu, a poté pravidelně nejméně jednou za 4 roky vyhodnotí uplatňování územně plánovací dokumentace.

(2) Za účelem vyhodnocení uplatňování zásad územního rozvoje a územního plánu zastupitelstvo na žádost pořizovatele určí určeného zastupitele, není-li určen na celé volební období.

#### § 107 — Zpráva o uplatňování

(1) Pořizovatel v součinnosti s určeným zastupitelem zpracuje návrh zprávy o uplatňování územně plánovací dokumentace, s výjimkou regulačního plánu, (dále jen „zpráva o uplatňování“).

(2) Zpráva o uplatňování obsahuje zejména

a) vyhodnocení uplatňování územně plánovací dokumentace,

b) problémy k řešení v územně plánovací dokumentaci vyplývající z územně analytických podkladů,

c) vyhodnocení souladu územně plánovací dokumentace s politikou územního rozvoje a nadřazenou územně plánovací dokumentací,

d) vyhodnocení vlivů uplatňování územně plánovací dokumentace na udržitelný rozvoj území z hlediska jejich možných nepředvídaných dopadů, včetně potřeby opatření na jejich odvrácení, zmírnění nebo kompenzaci,

e) vyhodnocení potřeby pořízení změny územně plánovací dokumentace nebo nové územně plánovací dokumentace,

f) vyhodnocení podnětů na změnu územně plánovací dokumentace,

g) podnět na změnu nadřazené územně plánovací dokumentace nebo politiky územního rozvoje.

(3) Vyplyne-li z vyhodnocení podle odstavce 2 písm. e) potřeba pořízení změny územně plánovací dokumentace nebo nové územně plánovací dokumentace, je součástí zprávy o uplatňování návrh zadání změny územně plánovací dokumentace (dále jen „zadání změny“) nebo návrh zadání. Na projednání a schválení návrhu zprávy o uplatňování, návrhu zadání změny nebo návrhu zadání, jsou-li jejím obsahem, se použijí § 88 až 90 obdobně.

(4) Při pořizování nové územně plánovací dokumentace navazující na schválené zadání podle odstavce 3 se dále postupuje podle § 91 až 105.

(5) Při pořizování změny územně plánovací dokumentace navazující na schválené zadání změny podle odstavce 3 se postupuje podle § 111 odst. 5 obdobně.

##### Oddíl 4

#### § 108 — Obecná ustanovení

(1) Změna územně plánovací dokumentace se zpracovává, projednává a vydává v rozsahu měněných částí.

(2) Pořizovatel po vydání změny územně plánovací dokumentace zajistí zpracování úplného znění a změnu územně plánovací dokumentace i její úplné znění vloží do národního geoportálu územního plánování.

(3) Změnu územně plánovací dokumentace, úplné znění územně plánovací dokumentace po této změně a adresy jejich uložení v národním geoportálu územního plánování oznámí pořizovatel veřejnou vyhláškou; dnem doručení veřejné vyhlášky nabývá změna účinnosti.

(4) Jedná-li se o změnu územního plánu, lze další zastavitelné plochy touto změnou vymezit pouze na základě prokázání potřeby vymezení nových zastavitelných ploch.

#### § 109 — Rozhodnutí o změně

(1) Nejde-li o změnu územního rozvojového plánu pořizovanou na základě změny politiky územního rozvoje nebo nejde-li o změnu pořizovanou na základě zprávy o uplatňování, schvalující orgán rozhoduje o pořízení změny z vlastního podnětu nebo z podnětu

a) oprávněného investora,

b) ministerstva, jiného ústředního správního úřadu nebo rady kraje v případě územního rozvojového plánu, není-li změna podmíněna změnou politiky územního rozvoje,

c) orgánu veřejné správy v případě zásad územního rozvoje, územního plánu nebo regulačního plánu,

d) organizace podle horního zákona, v případě zásad územního rozvoje,

e) občana obce nebo osoby, která má vlastnická nebo jiná věcná práva k pozemku nebo stavbě na území obce v případě územního plánu nebo regulačního plánu.

(2) Podnět na pořízení změny podle odstavce 1 se podává v případě územního rozvojového plánu u ministerstva, v ostatních případech u příslušného schvalujícího orgánu a obsahuje

a) údaje umožňující identifikaci navrhovatele podnětu, včetně uvedení skutečnosti prokazující, že je oprávněn podat podnět na pořízení změny územně plánovací dokumentace,

b) název územně plánovací dokumentace, kterou navrhuje změnit,

c) předmět změny a důvody pro její pořízení,

d) návrh úhrady nákladů uvedených v § 91 odst. 1 a § 92.

(3) Podnět může dále obsahovat návrh zadání změny a nejde-li o změnu regulačního plánu také

a) stanovisko příslušného orgánu ochrany přírody podle zákona o ochraně přírody a krajiny k navrhovanému obsahu změny územně plánovací dokumentace, ve kterém uvede, zda je možné vyloučit významný vliv na evropsky významnou lokalitu nebo ptačí oblast,

b) stanovisko příslušného úřadu k navrhovanému obsahu změny územně plánovací dokumentace, ve kterém i s přihlédnutím ke stanovisku orgánu ochrany přírody podle písmene a) uvede, zda má být návrh změny posuzován z hlediska vlivů na životní prostředí, popřípadě stanoví podrobnější požadavky podle § 10i zákona o posuzování vlivů na životní prostředí.

(4) Obsahové náležitosti zadání změny územně plánovací dokumentace stanoví prováděcí právní předpis.

(5) Obsahuje-li podnět na pořízení změny náležitosti podle odstavce 3, předá jej schvalující orgán bezodkladně pořizovateli, v ostatních případech se podnět vyhodnotí postupem podle § 107 odst. 2 písm. f).

#### § 110 — Posouzení podnětu

(1) Pořizovatel posoudí nejpozději do 30 dnů od jeho obdržení podnět podle § 109 z hlediska jeho úplnosti a souladu návrhu zadání změny

a) s tímto zákonem a jeho prováděcími právními předpisy,

b) se stanovisky podle § 109 odst. 3, a

c) s politikou územního rozvoje a nadřazenou územně plánovací dokumentací.

(2) Není-li podnět úplný nebo vykazuje-li nedostatky z hledisek uvedených v odstavci 1 a ten, kdo podnět dal, ani na výzvu pořizovatele nedostatky neodstraní ve stanovené lhůtě, pořizovatel podnět odloží a informuje o tom toho, kdo podnět dal, a schvalující orgán.

#### § 111 — Zpracování a projednání změny

(1) Je-li změna pořizována z vlastního podnětu a neobsahoval-li tento podnět návrh zadání změny, zpracuje návrh zadání změny pořizovatel v součinnosti s určeným zastupitelem obdobně podle § 87 odst. 2 a 3 a dále postupuje obdobně podle § 89 odst. 1 až 4 a 6.

(2) Pořizovatel bez zbytečného odkladu předloží návrh zadání změny se svým vyjádřením k projednání schvalujícímu orgánu.

(3) Souhlasí-li schvalující orgán s návrhem zadání změny, rozhodne o pořízení změny územně plánovací dokumentace a schválí její zadání. Nesouhlasí-li schvalující orgán s návrhem, vrátí jej pořizovateli se svými pokyny k úpravě, nebo jej zamítne.

(4) Schvalující orgán může podmínit pořízení změny územně plánovací dokumentace úhradou nákladů podle § 91 odst. 1 a § 92 tím, kdo dal ke změně podnět. Schvalující orgán může rozhodnout o sloučení společného jednání a veřejného projednání. Veřejné projednání musí v takovém případě splňovat také požadavky tohoto zákona na společné jednání.

(5) Při pořizování změny územně plánovací dokumentace se dále postupuje podle § 90 odst. 3, § 93 až 104, § 105 odst. 3 a § 108 obdobně.

##### Oddíl 5

#### § 112 — Zvláštní postupy

(1) Kraj a obec jsou povinny bez zbytečného odkladu územně plánovací dokumentaci, kterou vydaly, uvést do souladu s nadřazenou územně plánovací dokumentací. Do té doby nelze rozhodovat podle částí územně plánovací dokumentace, které jsou v rozporu s nadřazenou územně plánovací dokumentací. Vyhodnocení vlivů navazuje na vyhodnocení vlivů nadřazené územně plánovací dokumentace. Vlivy, které byly posouzeny v nadřazené územně plánovací dokumentaci, se v rozsahu a podrobnosti, v jaké byly v této dokumentaci posouzeny, znovu neposuzují.

(2) Znemožňuje-li územně plánovací dokumentace kraje nebo obce nebo její část realizaci záměru obsaženého v nadřazené územně plánovací dokumentaci, tato část navazující územně plánovací dokumentace se pro rozhodování v území ani pro pořizování navazující územně plánovací dokumentace nepoužije a rozhoduje se podle nadřazené územně plánovací dokumentace.

#### § 113 — Zrušení územně plánovací dokumentace schvalujícím orgánem

(1) Územní rozvojový plán, zásady územního rozvoje a územní plán může schvalující orgán zrušit pouze současně s vydáním nového územního rozvojového plánu, zásad územního rozvoje nebo územního plánu.

(2) Zastupitelstvo může zrušit regulační plán v případě, že se změnily podstatně podmínky, za kterých byl pořízen a vydán a není-li řešení v něm obsažené již aktuální.

(3) Návrh na zrušení regulačního plánu se projednává obdobně podle § 94, 96, 97 a § 98 odst. 1 až 3; ustanovení o vyhodnocení vlivů a variant řešení se nepoužijí.

(4) Zastupitelstvo obce může zrušit regulační plán, je-li to v souladu se stanovisky dotčených orgánů nebo s výsledkem řešení rozporů. Odůvodnění opatření obecné povahy vždy obsahuje prokázání podmínky uvedené ve větě první a vyhodnocení připomínek.

(5) Zrušení regulačního plánu pořizovatel oznámí veřejnou vyhláškou; dnem jejího doručení nabývá zrušení regulačního plánu účinnosti.

(6) Do 7 dnů po nabytí účinnosti zrušení regulačního plánu pořizovatel v národním geoportálu územního plánování

a) oznámí zrušení regulačního plánu,

b) vypustí zrušený regulační plán.

#### § 114 — Následky zrušení územně plánovací dokumentace

(1) Dojde-li ke zrušení územně plánovací dokumentace nebo její části nadřízeným orgánem územního plánování v přezkumném řízení nebo soudem, schvalující orgán bezodkladně rozhodne o

a) pokračování v pořizování územně plánovací dokumentace, přičemž pořizovatel naváže na poslední úkon, který nebyl zrušením dotčen,

b) pořízení nové územně plánovací dokumentace nebo její změny, nebo

c) zastavení pořizování v případě regulačního plánu nebo změny územně plánovací dokumentace.

(2) Při zrušení změny územně plánovací dokumentace platí územně plánovací dokumentace ve znění před touto změnou. Je-li to nezbytné, zajistí pořizovatel úpravu úplného znění.

(3) Obec nebo kraj zašlou ministerstvu rozhodnutí soudu o tom, že byla zrušena jimi vydaná územně plánovací dokumentace nebo její část. Ministerstvo bezodkladně zajistí zveřejnění rozhodnutí soudu v národním geoportálu územního plánování.

(4) Ministerstvo a krajský úřad bezodkladně zajistí zveřejnění rozhodnutí o zrušení územně plánovací dokumentace nebo její části v přezkumném řízení v národním geoportálu územního plánování.

(5) Dojde-li ke zrušení územního plánu, považuje se zastavěné území vymezené tímto územním plánem za zastavěné území vymezené podle tohoto zákona do doby vydání nového územního plánu nebo vymezení zastavěného území, nejdéle však po dobu 5 let. To neplatí, byla-li důvodem zrušení územního plánu také nezákonnost vymezení zastavěného území. Úřad územního plánování ve lhůtě 3 měsíců vyhodnotí aktuálnost vymezení zastavěného území postupem podle § 121 a zajistí jeho vydání postupem podle § 120.

#### § 115 — Souběžné pořizování územně plánovací dokumentace

(1) Je-li k vydání různých územně plánovacích dokumentací příslušný tentýž schvalující orgán, může rozhodnout o souběžném pořízení navazující územně plánovací dokumentace a změny nadřazené územně plánovací dokumentace. Umožňuje-li to povaha projednávané územně plánovací dokumentace, může se projednání obou územně plánovacích dokumentací konat souběžně v jednom projednání.

(2) Při souběžném pořizování územně plánovacích dokumentací nemusí být navazující územně plánovací dokumentace v souladu s částmi nadřazené územně plánovací dokumentace, které mají být změněny souběžně pořizovanou změnou; vydání nadřazené územně plánovací dokumentace je podmínkou pro vydání navazující územně plánovací dokumentace.

(3) Je-li vyžadováno posouzení vlivů na životní prostředí, zpracovává se při postupu podle odstavců 1 a 2 vyhodnocení vlivů jen pro navazující územně plánovací dokumentaci a v podrobnosti, která této navazující dokumentaci odpovídá, je-li řešené území vyžadující posouzení shodné a byl-li stanoviskem orgánu ochrany přírody vyloučen vliv nadřazené a navazující územně plánovací dokumentace nebo její změny na předmět ochrany nebo celistvost evropsky významné lokality nebo ptačí oblasti.

(4) Ustanovení odstavce 3 se nepoužije, je-li navazující územně plánovací dokumentací regulační plán nebo jeho změna.

##### Díl 5

##### Oddíl 1

#### § 116

(1) Na území obce se vymezuje jedno, popřípadě více zastavěných území. Hranici jednoho zastavěného území tvoří čára vedená po hranici parcel, ve výjimečných případech ji tvoří spojnice lomových bodů stávajících hranic nebo bodů na těchto hranicích.

(2) Při vymezení zastavěného území se vychází z posledního účinného územního plánu. Nemá-li obec územní plán, je podkladem pro vymezení zastavěného území vymezení pozemků v zastavěné části obce vymezené k 1. září 1966 vyznačené v mapách evidence nemovitostí (dále jen „intravilán“), ze kterého se vyjmou

a) vinice,

b) chmelnice,

c) lesní pozemky a

d) zemědělské pozemky přiléhající k hranici intravilánu netvořící stavební proluku.

(3) Do zastavěného území se dále vždy zahrnou

a) zastavěné stavební pozemky,

b) stavební proluky,

c) další oplocené proluky mezi zastavěnými stavebními pozemky,

d) veřejná prostranství,

e) pozemní komunikace nebo jejich části, ze kterých jsou vjezdy na ostatní pozemky zastavěného území a dráhy v části procházející intravilánem a ostatními pozemky zastavěného území,

f) další pozemky, které jsou obklopeny ostatními pozemky zastavěného území, s výjimkou pozemků vinic a chmelnic.

(3) Zastavěné území se vymezuje v územním plánu a aktualizuje se jeho změnou.

##### Oddíl 2

#### § 117 — Obecná ustanovení

(1) Není-li vydán územní plán, pořizovatel zajistí bezodkladně v souladu s § 116 odst. 1 až 3 zpracování návrhu vymezení zastavěného území.

(2) Při vymezení zastavěného území se v něm vyznačí pozemky, které jsou nezastavitelné do doby vydání územního plánu (dále jen „nezastavitelný pozemek“), a to

a) pozemek veřejné zeleně a parku tvořící veřejné prostranství1),

b) v intravilánu lesní pozemek nebo soubor sousedících lesních pozemků o výměře větší než 0,5 ha,

c) pozemek zbořeniště, není-li obklopen zastavěnými stavebními pozemky.

(3) Na nezastavitelných pozemcích lze do doby vydání územního plánu povolit jen nezbytnou dopravní a technickou infrastrukturu neznemožňující jejich dosavadní využití.

(4) Vymezení zastavěného území vydává formou opatření obecné povahy úřad územního plánování pro celé území obce.

(5) Vymezení zastavěného území pozbývá platnosti vydáním územního plánu.

#### § 118 — Obsah

(1) Vymezení zastavěného území obsahuje textovou část a grafickou část.

(2) Textová část obsahuje zejména datum, k němuž je zastavěné území vymezeno.

(3) Grafická část obsahuje výkres vymezení zastavěného území, který se zpracovává nad mapovým podkladem v měřítku katastrální mapy a vydává se v měřítku katastrální mapy nebo 1 : 5 000, a který obsahuje vyznačení hranic

a) zastavěného území a

b) nezastavitelných pozemků.

(4) Odůvodnění vymezení zastavěného území obsahuje zejména

a) stručný popis postupu pořízení vymezení zastavěného území,

b) vyhodnocení souladu s § 116 odst. 2 a 3 a vyhodnocení souladu se stanovisky dotčených orgánů nebo s výsledkem řešení rozporů,

c) vyhodnocení připomínek a

d) posouzení souladu vymezení zastavěného území s jednotným standardem.

#### § 119 — Pořízení

(1) Pořizovatel zajistí zpracování návrhu vymezení zastavěného území, který zveřejní v národním geoportálu územního plánování a vystaví jej u obce k nahlédnutí. Místa, kde je možné do návrhu vymezení zastavěného území nahlédnout, pořizovatel oznámí veřejnou vyhláškou.

(2) Do 15 dnů ode dne doručení veřejné vyhlášky může každý uplatnit k návrhu vymezení zastavěného území u pořizovatele písemně své připomínky. K připomínkám, kterými je požadována úprava zastavěného území na základě skutečností, které nastaly po datu, k němuž je zastavěné území vymezeno, se nepřihlíží. Proti návrhu vymezení zastavěného území nelze podat námitky podle části šesté správního řádu.

(3) Pořizovatel svolá místní šetření za účasti obce a dotčených orgánů hájících veřejné zájmy na úseku

a) ochrany přírody,

b) ochrany zemědělského půdního fondu,

c) ochrany lesa,

d) státní památkové péče, a

e) pozemních komunikací.

(4) Místo a dobu konání místního šetření oznámí pořizovatel nejméně 15 dnů předem. Dotčené orgány uplatní svá stanoviska a příslušná obec své připomínky nejpozději do 15 dnů ode dne místního šetření.

(5) Pořizovatel bezodkladně vyhodnotí výsledky projednání návrhu vymezení zastavěného území, zpracuje návrh vyhodnocení připomínek a zajistí řešení případných rozporů. Je-li to nezbytné, zajistí pořizovatel úpravu návrhu vymezení zastavěného území v souladu s výsledky projednání.

(6) Dojde-li na základě projednání k podstatné úpravě návrhu vymezení zastavěného území, pořizovatel zajistí zveřejnění, vystavení a oznámení upraveného návrhu obdobně podle odstavce 1; v rozsahu upravených částí se postupuje podle odstavců 2 až 5.

#### § 120 — Vydání

(1) Vymezení zastavěného území lze vydat jen tehdy, je-li v souladu s výsledky projednání. Pořizovatel zajistí vložení vymezení zastavěného území do národního geoportálu územního plánování do 7 dnů po jeho vydání.

(2) Vymezení zastavěného území a adresu jeho uložení v národním geoportálu územního plánování pořizovatel bezodkladně oznámí veřejnou vyhláškou; dnem doručení veřejné vyhlášky nabývá vymezení zastavěného území účinnosti.

(3) Vymezení zastavěného území se opatří záznamem o účinnosti, který obsahuje

a) označení správního orgánu, který vymezení zastavěného území vydal,

b) datum nabytí účinnosti vymezení zastavěného území,

c) jméno, příjmení, funkci a podpis oprávněné úřední osoby pořizovatele a otisk úředního razítka.

(4) Dojde-li ke zrušení vymezení zastavěného území nebo jeho části soudem, zveřejní pořizovatel rozsudek v národním geoportálu územního plánování.

#### § 121 — Změna

(1) Pořizovatel nejpozději do 8 let od vydání vymezení zastavěného území a poté pravidelně nejméně jednou za 8 let vyhodnotí aktuálnost vymezení zastavěného území.

(2) Vymezení zastavěného území se aktualizuje jeho změnou. Je-li na území obce vymezeno více zastavěných území, aktualizují se jen ta, která aktualizaci vyžadují.

(3) Změnu vymezení zastavěného území lze pořídit také na základě podnětu dotčené obce.

(4) Pro pořízení změny vymezení zastavěného území se použijí § 117 až 120 v rozsahu měněných částí obdobně. Ke stanoviskům a připomínkám uplatněným k neměněným částem se nepřihlíží.

(5) Změnu vymezení zastavěného území, úplné znění vymezení zastavěného území a adresy jejich uložení v národním geoportálu územního plánování pořizovatel oznámí veřejnou vyhláškou. Dnem doručení veřejné vyhlášky nabývá změna vymezení zastavěného území účinnosti.

##### Oddíl 3

#### § 122

(1) V nezastavěném území lze v souladu s jeho charakterem povolovat záměry pro

a) veřejnou dopravní a technickou infrastrukturu, přípojky a účelové komunikace,

b) vodní hospodářství,

c) vyhledávání, průzkum a těžbu nerostů a zvláštní zásahy do zemské kůry,

d) snižování nebezpečí havárií, ekologických a přírodních katastrof a pro odstraňování jejich důsledků,

e) zemědělství a lesnictví,

f) ochranu přírody a krajiny a

g) zlepšení podmínek jeho využití pro rekreaci a cestovní ruch, například cyklistické stezky, hygienická zařízení, ekologická a informační centra,

h) zázemí lesních mateřských škol a výdejen lesních mateřských škol, jedná-li se o drobnou stavbu.

(2) U staveb a zařízení podle odstavce 1 není doplňková funkce bydlení nebo pobytové rekreace přípustná.

(3) Stavby a zařízení podle odstavce 1 lze v nezastavěném území povolit pouze v případě, že je územně plánovací dokumentace výslovně nevylučuje z důvodu veřejného zájmu.

##### Díl 6

##### Oddíl 1

#### § 123 — Podmínky vydání

(1) Územním opatřením o stavební uzávěře se omezuje nebo zakazuje v nezbytném rozsahu stavební činnost ve vymezeném území, pokud by mohla ztížit nebo znemožnit jeho budoucí využití podle připravované územně plánovací dokumentace, jestliže bylo rozhodnuto o jejím pořízení nebo o pořízení její změny, nebo podle jiného rozhodnutí nebo opatření v území, jímž se upravuje využití území.

(2) Územní opatření o stavební uzávěře lze vydat také v případech, kdy je zrušena územně plánovací dokumentace nebo její část.

(3) Územní opatření o stavební uzávěře, kterým se omezuje nebo zakazuje stavební činnost, která by mohla ztížit nebo znemožnit budoucí využití území podle připravované územně plánovací dokumentace, se vydává na nezbytně nutnou dobu, která však nesmí být delší než 6 let.

(4) Územní opatření o stavební uzávěře dále pozbývá účinnosti jeho zrušením.

(5) Územním opatřením o stavební uzávěře nelze omezit nebo zakázat udržovací práce. Územním opatřením o stavební uzávěře dále nelze omezit nebo zakázat realizaci veřejně prospěšné stavby dopravní nebo technické infrastruktury a stanovení dobývacího prostoru vymezené v územním rozvojovém plánu nebo v zásadách územního rozvoje.

#### § 124 — Obsah

(1) Územní opatření o stavební uzávěře obsahuje

a) vymezení území s uvedením katastrálního území a parcelních čísel pozemků podle katastru nemovitostí, pro které platí omezení nebo zákaz stavební činnosti,

b) rozsah a obsah omezení nebo zákazu stavební činnosti,

c) popřípadě další podmínky vyplývající ze stanovisek dotčených orgánů,

d) dobu trvání omezení nebo zákazu stavební činnosti,

e) stanovení podmínek pro povolování výjimek.

(2) Součástí územního opatření o stavební uzávěře je výkres na podkladu katastrální mapy s vyznačením území, pro které platí stavební uzávěra.

(3) Týká-li se územní opatření o stavební uzávěře zvlášť rozsáhlého území, nahradí se údaj podle odstavce 1 písm. a) popisem hranice dotčeného území, pro které platí omezení nebo zákaz stavební činnosti.

##### Oddíl 2

#### § 125 — Podmínky vydání

(1) Územní opatření o asanaci území se vydává na území postiženém živelní pohromou nebo závažnou havárií, v jejichž důsledku došlo k podstatnému zásahu do využití území, je-li nezbytné pro postižené území stanovit podmínky pro odstranění jejich dopadů a pro další využití území.

(2) Územní opatření o asanaci území lze vydat i pro území, ve kterém jsou závadné stavby, kontaminovaná místa nebo staré ekologické zátěže, a to z důvodů hygienických, bezpečnostních, požárních, provozních a ochrany životního prostředí, a u nichž je ve veřejném zájmu nebo z důvodu ohrožení života nebo zdraví osob nebo hrozby značné újmy nutné nařídit úpravy, odstranění staveb, sanaci, rekultivaci kontaminovaných míst nebo starých ekologických zátěží.

(3) Dnem nabytí účinnosti územního opatření o asanaci území pozbývá v dotčeném území účinnosti vydaná územně plánovací dokumentace v rozsahu podle § 126 odst. 2.

(4) Územní opatření o asanaci území pozbývá účinnosti dnem vydání nové územně plánovací dokumentace nebo její změny pro dotčené území.

(5) Územní opatření o asanaci území dále pozbývá účinnosti jeho zrušením.

#### § 126 — Obsah

(1) Územní opatření o asanaci území obsahuje

a) vymezení území s uvedením katastrálního území a parcelních čísel pozemků a staveb na nich podle katastru nemovitostí, pro které platí územní opatření o asanaci území,

b) seznam pozemků, které musí být upraveny nebo zabezpečeny s uvedením způsobu provedení,

c) seznam staveb a zařízení, které musí být odstraněny, zabezpečeny nebo upraveny s uvedením způsobu provedení,

d) stanovení územních, stavebně technických a bezpečnostních podmínek pro provádění asanace, sanace nebo rekultivace území,

e) stanovení územních, architektonických a urbanistických podmínek pro budoucí využití území,

f) případné další podmínky vyplývající ze stanovisek dotčených orgánů.

(2) V územním opatření o asanaci území se označí územně plánovací dokumentace, která v dotčeném území pozbývá účinnosti, a vymezí území, ve kterém pozbývá účinnosti.

(3) Součástí územního opatření o asanaci území je výkres na kopii katastrální mapy nebo na kopii jiného státního mapového díla vhodného měřítka s vyznačením území, kterého se územní opatření o asanaci týká.

(4) Týká-li se územní opatření o asanaci území zvlášť rozsáhlého území, nahradí se údaj podle odstavce 1 písm. a) popisem hranice dotčeného území, kterého se opatření o asanaci území týká.

##### Oddíl 3

#### § 127 — Pořízení

(1) O pořízení územního opatření rozhodne vláda, rada kraje nebo rada obce z

a) vlastního podnětu,

b) podnětu oprávněného investora,

c) podnětu orgánu veřejné správy,

d) podnětu rady kraje, je-li příslušná k jeho vydání vláda, nebo

e) podnětu rady obce, je-li příslušná k jeho vydání rada kraje.

(2) Návrh územního opatření připraví pořizovatel na základě průzkumu a vyhodnocení dotčeného území, nástrojů územního plánování a v případě územního opatření o stavební uzávěře v souladu s cíli a úkoly územního plánování.

(3) V případě územního opatření o asanaci území postupuje pořizovatel bezodkladně a při přípravě návrhu zohlední rovněž vyhodnocení stavu staveb a pozemků z hlediska ohrožení života nebo zdraví osob nebo z hlediska požadavků na využití území v důsledku odstraňování živelní pohromy nebo havárie.

(4) Návrh územního opatření pořizovatel zveřejní v národním geoportálu územního plánování, zveřejnění oznámí veřejnou vyhláškou a návrh písemně projedná s dotčenými orgány, které mohou uplatnit svá stanoviska.

(5) Každý může k návrhu územního opatření uplatnit připomínky. Stanoviska a připomínky se uplatňují u pořizovatele písemně do 30 dnů ode dne zveřejnění návrhu. Na vyhodnocení připomínek uplatněných k návrhu se použije § 98 odst. 2 obdobně s tím, že návrh vyhodnocení připomínek zpracuje pořizovatel samostatně. Proti návrhu územního opatření nelze podat námitky podle části šesté správního řádu.

(6) Lhůtu podle odstavce 5 může pořizovatel v případě územního opatření o asanaci území z důležitých důvodů zkrátit.

#### § 128 — Vydání

(1) Územní opatření se vydává formou opatření obecné povahy.

(2) Pořizovatel zajistí vložení územního opatření do národního geoportálu územního plánování do 7 dnů po jeho vydání. Územní opatření a adresu jeho uložení v národním geoportálu územního plánování oznámí pořizovatel veřejnou vyhláškou; dnem doručení veřejné vyhlášky nabývá územní opatření účinnosti.

(3) Územní opatření se opatří záznamem o účinnosti, který obsahuje

a) označení správního orgánu, který územní opatření vydal,

b) datum nabytí účinnosti územního opatření,

c) jméno, příjmení, funkci a podpis oprávněné úřední osoby pořizovatele a otisk úředního razítka.

(4) Obec nebo kraj zašlou bezodkladně ministerstvu rozhodnutí soudu o tom, že bylo zrušeno jimi vydané územní opatření nebo jeho část. Ministerstvo bezodkladně zajistí zveřejnění rozhodnutí soudu podle věty první v národním geoportálu územního plánování.

(5) Ministerstvo a krajský úřad bezodkladně zajistí zveřejnění rozhodnutí, kterým bylo rozhodnuto o zrušení územního opatření nebo jeho části v přezkumném řízení, v národním geoportálu územního plánování.

#### § 129 — Výjimky

Ministerstvo, rada obce a v obcích, kde se rada nevolí, zastupitelstvo obce, nebo rada kraje, které územní opatření o stavební uzávěře vydaly, mohou na žádost povolit výjimku z podmínek, omezení nebo zákazu stavební činnosti podle územního opatření o stavební uzávěře, jestliže povolení výjimky neohrožuje sledovaný účel stavební uzávěry. Proti rozhodnutí o žádosti o výjimku se nelze odvolat.

##### Díl 7

##### Oddíl 1

#### § 130 — Úvodní ustanovení

(1) Plánovací smlouvou je veřejnoprávní smlouva uzavřená mezi stavebníkem a obcí, městskou částí hlavního města Prahy nebo krajem nebo vlastníkem veřejné infrastruktury, jejímž obsahem je vzájemná povinnost stran poskytnout si součinnost při uskutečnění ve smlouvě uvedeného záměru a postupovat při jeho uskutečňování ujednaným způsobem.

(2) Plánovací smlouva může obsahovat i úpravu práv a povinností osob v oblasti soukromého práva. Se souhlasem všech stran může být plánovací smlouva postoupena; ustanovení občanského zákoníku o postoupení smlouvy se použijí přiměřeně.

(3) Obec, městská část hlavního města Prahy nebo kraj zašlou bezodkladně uzavřenou plánovací smlouvu příslušnému úřadu územního plánování, který zajistí její vložení do národního geoportálu územního plánování. Dojde-li k zániku plánovací smlouvy, sdělí obec, městská část hlavního města Prahy nebo kraj tuto skutečnost úřadu územního plánování, který zajistí její vypuštění z národního geoportálu územního plánování.

#### § 131 — Obsah plánovací smlouvy

(1) V plánovací smlouvě se obec, městská část hlavního města Prahy, kraj nebo vlastník veřejné infrastruktury může zavázat k tomu, že

a) poskytne stavebníkovi součinnost k uskutečnění záměru,

b) obec nebo kraj učiní kroky k vydání územně plánovací dokumentace, v případě, že záměr nelze uskutečnit bez předchozího vydání územně plánovací dokumentace,

c) po sjednanou dobu nevydá nebo nezmění územně plánovací dokumentaci nebo neučiní jiný úkon, který by ztížil nebo vyloučil uskutečnění záměru,

d) po dobu trvání plánovací smlouvy nebude ve správních nebo soudních řízeních týkajících se povolení záměru uplatňovat návrhy, vyjádření a opravné prostředky, které by byly v rozporu s obsahem uzavřené plánovací smlouvy.

(2) V plánovací smlouvě se obec, městská část hlavního města Prahy, kraj nebo vlastník veřejné infrastruktury může dále zavázat k tomu, že

a) pozemky nebo stavby potřebné k realizaci záměru, k nimž vykonávají práva, ať již přímo, nebo prostřednictvím dalších osob, po sjednanou dobu nezatíží nebo nezcizí,

b) se bude podílet na přípravě, výstavbě nebo financování veřejné infrastruktury nebo veřejně prospěšných staveb nebo jiných opatření potřebných k uskutečnění záměru,

c) od stavebníka převezme jím zhotovenou stavbu do svého vlastnictví,

d) učiní jiné právní jednání v oblasti soukromého práva.

(3) Stavebník se může v plánovací smlouvě zavázat zejména k

a) účasti na výstavbě veřejné infrastruktury nebo jiných staveb nebo opatření vyvolaných záměrem,

b) převzetí nákladů na výstavbu veřejné infrastruktury nebo veřejně prospěšných staveb nebo opatření vyvolaných záměrem,

c) účasti na asanaci území dotčeného záměrem,

d) účasti na narovnání majetkových vztahů v území dotčeném záměrem,

e) poskytnutí peněžního nebo věcného plnění za zhodnocení pozemku vydáním územně plánovací dokumentace; v plánovací smlouvě lze sjednat i jeho účel.

#### § 132 — Uzavírání a přezkum plánovací smlouvy

(1) Plánovací smlouvu uzavíranou obcí, krajem nebo hlavním městem Prahou schvaluje zastupitelstvo obce, zastupitelstvo kraje nebo zastupitelstvo hlavního města Prahy. Plánovací smlouvu uzavíranou městskou částí hlavního města Prahy schvaluje zastupitelstvo městské části.

(2) K přezkumu souladu plánovací smlouvy uzavřené obcí s právními předpisy a k rozhodování sporů z ní je příslušný krajský úřad. K přezkumu souladu plánovací smlouvy uzavřené městskou částí hlavního města Prahy s právními předpisy a k rozhodování sporů z ní je příslušný Magistrát hlavního města Prahy.

(3) K přezkumu souladu plánovací smlouvy uzavřené krajem nebo hlavním městem Prahou s právními předpisy a k rozhodování sporů z ní je příslušné ministerstvo.

##### Oddíl 2

#### § 133 — Oprávněné osoby

(1) Vlastníkovi pozemku nebo stavby a osobě, která má jiné věcné právo k pozemku nebo stavbě (dále jen „oprávněná osoba“) a které vznikla škoda v důsledku zrušení nebo významného omezení zastavitelnosti pozemku na základě změny územně plánovací dokumentace nebo vydáním nové územně plánovací dokumentace, náleží náhrada škody spočívající v nákladech vynaložených na přípravu výstavby v obvyklé výši, zejména na koupi pozemku, na projektovou přípravu výstavby nebo za snížení hodnoty pozemku, který slouží k zajištění dluhu.

(2) Oprávněné osobě náleží dále náhrada, byla-li její práva k pozemku nebo stavbě významně omezena územním opatřením o stavební uzávěře a byla-li jí tím způsobena škoda.

(3) Náhrada oprávněné osobě nenáleží, došlo-li ke zrušení nebo významnému omezení zastavitelnosti pozemku na základě jejího návrhu nebo po uplynutí doby 5 let od nabytí účinnosti územně plánovací dokumentace, která zastavění dotčeného pozemku ke stanovenému účelu umožnila. Do této doby se nezapočítává doba, po kterou bylo zastavění pozemku znemožněno v důsledku stavební uzávěry nebo jiného dočasného omezení zastavitelnosti pozemku stanoveného územně plánovací dokumentací.

(4) Náhrada oprávněné osobě dále nenáleží, nabylo-li právní moci povolení záměru, pro který bylo zastavění příslušnou územně plánovací dokumentací určeno, a toto povolení je platné nebo pozbylo platnosti.

#### § 134 — Povinné osoby

(1) Povinnost poskytnout náhradu za změnu v území má obec, kraj nebo stát, jejichž orgány vydaly územně plánovací dokumentaci nebo její změnu nebo územní opatření o stavební uzávěře.

(2) Náhrada se poskytne na základě písemné žádosti oprávněné osoby obsahující prokázání škody.

#### § 135 — Způsob náhrady

(1) Náhrada se poskytuje v penězích. Místo peněžité náhrady lze na základě dohody poskytnout oprávněné osobě jiný pozemek nebo stavbu; právo na vyrovnání rozdílu mezi výší peněžité náhrady a hodnotou náhradního pozemku nebo stavby tím není dotčeno.

(2) Dojde-li k následné změně územního plánu anebo změně nebo zrušení regulačního plánu a pozemek, za který byla vyplacena náhrada, se vrátí do původního nebo jiného režimu umožňujícího zastavění, je ten, komu byla náhrada vyplacena, povinen vyplacenou náhradu v plné výši vrátit tomu, kdo ji poskytl, do 3 měsíců od vyrozumění o vzniku této povinnosti. Byl-li místo peněžité náhrady poskytnut oprávněné osobě jiný pozemek nebo stavba, je povinna vrátit náhradu v té výši, která by jí jinak náležela.

(3) Povinnost vrátit náhradu zaniká po 5 letech od nabytí účinnosti změny územního plánu anebo změny nebo zrušení regulačního plánu, na jejichž základě nárok na náhradu vznikl.

#### § 136 — Regresní náhrada

(1) Uhradí-li obec nebo kraj náhradu za změnu v důsledku územně plánovací činnosti, může požadovat regresní náhradu od správního orgánu, na základě jehož požadavku došlo k omezení vlastnického práva vlastníka, popřípadě od kraje nebo státu, pokud došlo ke změně územně plánovací dokumentace obce nebo kraje v důsledku jejího uvedení do souladu s nadřazenou územně plánovací dokumentací.

(2) Obec nebo kraj uplatní požadavek na regresní náhradu do 3 měsíců od uhrazení náhrady, jinak jejich právo zaniká. Regresní náhrada musí být uhrazena do 3 měsíců od doručení požadavku obce nebo kraje, který tuto náhradu uhradil.

#### HLAVA IV

#### § 136a

(1) Politika architektury a stavební kultury je strategickým dokumentem s celostátní působností, který určuje vizi, cíle a opatření k dosažení kvality vystavěného prostředí.

(2) Politika architektury a stavební kultury rozvíjí cíle a úkoly územního plánování a je podkladem pro zpracování politiky územního rozvoje, který není závazný.

(3) Ministerstvo zajistí zveřejnění usnesení vlády, kterým byla schválena politika architektury a stavební kultury, ve Věstníku vlády pro orgány krajů a orgány obcí a v téže lhůtě zveřejní politiku architektury a stavební kultury způsobem umožňujícím dálkový přístup.

(4) Ministerstvo nejpozději do 6 let od schválení politiky architektury a stavební kultury a poté nejméně jednou za 6 let předloží vládě zprávu o plnění politiky architektury a stavební kultury. Vláda může na jejím základě uložit ministerstvu pořídit aktualizaci nebo novou politiku architektury a stavební kultury.

### ČÁST ČTVRTÁ

#### HLAVA I

##### Díl 1

#### § 137

(1) Požadavky na výstavbu se rozumí

a) požadavky na vymezování pozemků,

b) požadavky na umisťování staveb,

c) technické požadavky na stavby.

(2) Při územně plánovací a projektové činnosti, při povolování, provádění, užívání a odstraňování staveb je každý povinen dodržovat cíle a úkoly územního plánování a dodržovat požadavky na výstavbu stanovené tímto zákonem, prováděcím právním předpisem nebo jinými právními předpisy.

(3) Požadavky na výstavbu se považují za splněné splněním požadavků, které stanoví tento zákon, jeho prováděcí právní předpisy a další právní předpisy.

(4) V rozsahu, v jakém to závažné územně technické nebo stavebně technické důvody nebo jiný veřejný zájem nevylučují, uplatní se požadavky na výstavbu rovněž u

a) změny dokončené stavby,

b) údržby dokončené stavby,

c) změny v užívání stavby,

d) dočasné stavby,

e) zařízení staveniště,

f) pozemku nebo stavby, které jsou kulturní památkou nebo se nacházejí v památkové rezervaci nebo památkové zóně.

#### § 138 — Výjimky z požadavků na výstavbu a odchylné řešení

(1) Výjimku z požadavků na výstavbu lze povolit pouze z těch ustanovení prováděcího právního předpisu, ze kterých tento předpis povolení výjimky výslovně umožňuje, a jen pokud se tím neohrozí bezpečnost, ochrana zdraví nebo života osob nebo zvířat, životní prostředí, sousední pozemky nebo stavby. Řešením podle povolené výjimky musí být dosaženo účelu sledovaného požadavky na výstavbu stanovenými tímto zákonem.

(2) V regulačním plánu nebo v územním plánu, který obsahuje prvky regulačního plánu, lze stanovit požadavky na vymezování pozemků a požadavky na umisťování staveb odchylně od těch ustanovení prováděcího právního předpisu, která to umožňují, a to i pro část území; podmínky podle odstavce 1 se použijí přiměřeně.

##### Díl 2

#### § 139 — Obecné požadavky

(1) Pozemky se vymezují a podmínky pro jejich využití se stanovují v souladu s územně plánovací dokumentací, a nebyla-li vydána, s cíli a úkoly územního plánování, s ohledem na charakter území, urbanistickou, architektonickou, kulturně historickou, přírodní a archeologickou hodnotu území a kvalitu vystavěného prostředí. Pozemky se vždy vymezují tak, aby svými vlastnostmi, zejména velikostí, polohou, plošným a prostorovým uspořádáním umožňovaly využití pro navrhovaný účel.

(2) V zastavěném území obce, která nemá územní plán, lze vymezovat pozemky a povolovat stavby pro bydlení, pro rodinnou rekreaci, stavby občanského vybavení souvisejícího a slučitelného s bydlením nebo rekreací, stavby pro dopravní a technickou infrastrukturu a pozemky veřejných prostranství. Vymezování jiných pozemků a umisťování dalších staveb na nich je možné, jen pokud jsou tyto stavby v souladu s charakterem území a nesnižují kvalitu životního prostředí stanovenou jinými právními předpisy.

(3) Při vymezování pozemků se dbá na vymezení veřejných prostranství odpovídajících charakteru území, zejména uličního prostranství.

#### § 140 — Požadavky na vymezování stavebních pozemků

(1) Pozemky nesmí být děleny tak, aby bylo vyloučeno jejich účelné využití. Pozemky, jejichž součástí je stavba, nesmí být děleny tak, aby tím došlo k oddělení části stavby, kterou nelze samostatně užívat; obdobně se postupuje při dělení pozemků, které jsou zatíženy právem stavby.

(2) Stavební pozemek se vždy vymezuje tak, aby svými vlastnostmi, zejména velikostí, polohou, plošným a prostorovým uspořádáním, umožňoval umístění, realizaci a užívání stavby pro navrhovaný účel a aby byl dopravně napojen na kapacitně vyhovující veřejně přístupnou pozemní komunikaci23).

(3) Stavební pozemek se vždy vymezuje tak, aby na něm bylo vyřešeno

a) umístění odstavných a parkovacích stání pro účel využití pozemku a užívání staveb na něm umístěných,

b) nakládání s odpady a zneškodňování odpadních vod podle jiných právních předpisů24), které na pozemku vznikají jeho užíváním nebo užíváním staveb na něm umístěných,

c) hospodaření se srážkovými vodami jejich

1. akumulací a následným využitím, vsakováním nebo výparem, pokud to hydrogeologické poměry, velikost pozemku a jeho výhledové využití umožňují a pokud nejsou vsakováním ohroženy okolní stavby nebo pozemky,

2. odváděním do vod povrchových prostřednictvím dešťové kanalizace, pokud jejich vsakování ani akumulace s následným využitím není možná, nebo

3. regulovaným odváděním do jednotné kanalizace, není-li možné odvádění do vod povrchových.

(4) Při vymezování stavebního pozemku nebo při změně využití zastavěného stavebního pozemku lze prokázat splnění požadavků odstavců 2 a 3 regulačním plánem nebo dokumentací pro vydání povolení záměru též s využitím dalších pozemků.

#### § 141 — Veřejné prostranství

(1) Pozemky tvořící veřejné prostranství se vymezují tak, aby vytvářely prostupný spojitý systém odpovídající charakteru území a potřebám života lidí, přispívaly obytné kvalitě a významu místa a omezovaly dopady oteplování a sucha, zejména možností vsakování vody a výsadby stromů a další veřejné zeleně.

(2) Uspořádání veřejných prostranství musí zajistit dostupnost a obsluhu území a jeho prostupnost pro užití chodci a podle možností též bezmotorovou dopravou.

(3) Chodníky, nástupiště veřejné dopravy, úrovňové i mimoúrovňové přechody, chodníky v sadech i parcích a ostatní pochozí plochy jako součást veřejných prostranství musí splňovat požadavky na přístupnost.

#### § 142 — Uliční prostranství

(1) Uliční prostranství tvoří část veřejného prostranství a vytváří základní síť obsluhy a prostupnosti území; je vymezeno zejména uličními čarami.

(2) Pozemky tvořící uliční prostranství se vymezují tak, aby svými vlastnostmi, zejména svou šířkou, umožňovaly předpokládané využití v souladu s charakterem území.

(3) Je-li to technicky možné a není-li to v rozporu s charakterem území, vymezují se v nově zakládaných uličních prostranstvích a při celkových stavebních úpravách stávajících uličních prostranství pozemky tvořící výsadbový pás pro stromy nebo jinou veřejnou zeleň.

##### Díl 3

#### § 143 — Obecné požadavky

(1) Stavby se umisťují v souladu s územně plánovací dokumentací, a nebyla-li vydána, s cíli územního plánování. Stavby se umisťují též s ohledem na charakter území, urbanistickou, architektonickou, kulturně historickou, přírodní a archeologickou hodnotu území a kvalitu vystavěného prostředí.

(2) Stavby se podle druhu a potřeby umisťují tak, aby bylo umožněno jejich napojení na sítě technické infrastruktury a pozemní komunikace a aby jejich umístění na pozemku umožňovalo přístup požární techniky a provedení jejího zásahu mimo ochranná pásma rozvodu energetických vedení. Připojení staveb na pozemní komunikace musí svými parametry, provedením a způsobem připojení vyhovovat požadavkům bezpečného užívání staveb a bezpečného a plynulého provozu na přilehlých pozemních komunikacích25). Podle druhu a charakteru stavby musí připojení splňovat též požadavky na dopravní obslužnost a parkování.

(3) Změnou stavby nesmí být narušeny kulturně historické, přírodní, urbanistické a architektonické hodnoty daného místa nebo nesmí dojít k narušení architektonické jednoty celku.

(4) Mimo stavební pozemek lze umístit jen stavby zařízení staveniště a připojení staveb na sítě technické infrastruktury a pozemní komunikace.

#### § 144 — Odstupy staveb

(1) Vzájemné odstupy staveb musí splňovat požadavky urbanistické, architektonické a požadavky stanovené prováděcím právním předpisem a jinými právními předpisy.

(2) Vzájemné odstupy staveb musí umožňovat údržbu staveb.

#### § 144a — Zvláštní požadavky

(1) Zastavěná plocha stavby výrobny elektřiny využívající energii slunečního záření se nezahrnuje do celkové plochy určené k zastavění a do celkové plochy minimálního podílu zeleně, jsou-li územním plánem stanoveny, umisťuje-li se stavba pro výrobu elektřiny využívající energii slunečního záření

a) v plochách s rozdílným způsobem využití plochy výroby a skladování nebo plochy smíšené výrobní a

b) pod stavbou je zachována zeleň.

(2) Stavbu výrobny elektřiny využívající energii slunečního záření lze umístit na stávající stavby, nevylučuje-li to regulační plán.

##### Díl 4

#### § 145 — Základní požadavky na stavby

(1) Stavba musí být navržena a provedena tak, aby byla vhodná pro určené využití a po celou dobu trvání plnila při běžné údržbě a působení běžně předvídatelných vlivů základní požadavky na stavby, kterými jsou

a) mechanická odolnost a stabilita,

b) požární bezpečnost26),

c) ochrana zdraví27),

d) ochrana životního prostředí28),

e) bezpečnost a přístupnost při užívání, provozu a údržbě,

f) úspora energie29),

g) udržitelné využívání přírodních zdrojů30).

(2) Při projektové činnosti, při povolování, provádění a užívání staveb v působnosti jiných stavebních úřadů nebo u staveb jaderného zařízení a staveb v areálu jaderného zařízení, které jsou jaderným zařízením31), se technické požadavky na stavbu stanovené tímto zákonem nebo jinými právními předpisy použijí přiměřeně tak, aby nedošlo k ohrožení bezpečnosti, ochrany zdraví a života osob nebo zvířat a životního prostředí.

#### § 146 — Požadavky na mechanickou odolnost a stabilitu stavby

(1) Stavba musí být navržena a provedena tak, aby účinky zatížení a nepříznivé vlivy prostředí, kterým je vystavena během výstavby a užívání, neměly za následek

a) náhlé nebo postupné zřícení stavby nebo její části,

b) nepřípustné deformace, které mohou narušit stabilitu stavby, mechanickou odolnost a funkční způsobilost stavby nebo její části,

c) poškození částí stavby nebo technických zařízení anebo instalovaného vybavení v důsledku deformace nosné konstrukce,

d) poškození stavby v míře nepřiměřené původní příčině,

e) ohrožení provozuschopnosti dopravní a technické infrastruktury v dosahu stavby nebo staveniště,

f) poškození stavby vlivem nepříznivých účinků podzemních vod nebo dynamickými účinky povodňových průtoků, popřípadě hydrostatickým vztlakem při zaplavení,

g) ohrožení průtočnosti koryt vodních toků, popřípadě údolních profilů mostů a propustků.

(2) Stavby umístěné v dosahu účinků hlubinného dobývání nebo v dosahu seizmických účinků se navrhují též s ohledem na předpokládané deformace základové půdy, způsobené projevy důlní nebo seizmické činnosti na povrchu.

#### § 147 — Požadavky na požární bezpečnost

Stavba musí být navržena a provedena takovým způsobem, aby v případě požáru

a) byla po určenou dobu zachována nosnost konstrukcí,

b) byl uvnitř stavby omezen vznik a šíření ohně a kouře,

c) bylo omezeno šíření požáru na sousední stavby,

d) uživatelé mohli stavbu opustit nebo aby mohli být jinými prostředky zachráněni,

e) byla brána v úvahu bezpečnost záchranných jednotek.

#### § 148 — Požadavky na ochranu zdraví a životního prostředí

(1) Stavba musí být navržena a provedena takovým způsobem, aby neohrožovala bezpečnost, život nebo zdraví osob nebo zvířat, aby byl hluk v chráněném prostoru stavby udržován na úrovni, která neohrozí zdraví jejích uživatelů, zaručí noční klid a je vyhovující pro prostředí s pobytem osob nebo zvířat, a to i na sousedních pozemcích a stavbách, ani neměla nepřípustný negativní vliv na kvalitu životního prostředí nebo na klima, a to během výstavby, užívání i odstraňování, zejména následkem

a) nedostatečných tepelně izolačních, zvukoizolačních nebo světelně technických vlastností,

b) uvolňování toxických plynů, nebezpečných látek, těkavých organických sloučenin, skleníkových plynů nebo nebezpečných částic do vnitřního nebo venkovního prostředí,

c) výskytu vlhkosti ve stavebních konstrukcích nebo na povrchu stavebních konstrukcí uvnitř staveb,

d) emisí nebezpečného záření a světla,

e) uvolňování nebezpečných látek do vody nebo půdy,

f) vypouštění odpadních vod, emisí odpadních plynů, nebo

g) narušení podloží s následkem trvalé změny proudění podzemních vod nebo jiným nepřípustným dopadem na úroveň hladiny podzemní vody.

(2) Stavba musí být navržena a provedena takovým způsobem, aby nezpůsobila

a) nadměrný úhyn rostlin a zranění nebo úhyn živočichů nebo ničení jejich biotopů, nebo

b) zhoršení prostupnosti krajiny pro volně žijící živočichy.

#### § 149 — Požadavky na bezpečnost a přístupnost při užívání, provozu a údržbě

Stavba musí být navržena a provedena takovým způsobem, aby při jejím užívání, údržbě nebo provozu

a) nevznikalo nebezpečí nehod nebo poškození zdraví osob nebo zvířat,

b) byla zohledněna přístupnost pro osoby s omezenou schopností pohybu nebo orientace, zejména u

1. staveb pozemních komunikací a veřejných prostranství32),

2. staveb občanského vybavení v částech určených pro užívání veřejností,

3. společných prostor a domovního vybavení bytového domu,

4. bytu zvláštního určení,

5. staveb pro výkon práce více než 25 osob, pokud charakter provozu v těchto stavbách umožňuje zaměstnávat osoby se zdravotním postižením.

#### § 150 — Požadavky na úsporu energie

Stavba a její technické zařízení pro vytápění, chlazení, osvětlení a větrání musí být navrženy a provedeny takovým způsobem, aby při jejich užívání, údržbě nebo provozu byla spotřeba energie co nejnižší s ohledem na účel užívání a na místní klimatické podmínky. Stavba musí být rovněž energeticky účinná.

#### § 151 — Požadavky na udržitelné využití přírodních zdrojů

(1) Stavba musí být navržena, provedena a odstraněna takovým způsobem, aby bylo zajištěno udržitelné využití přírodních zdrojů zejména opětovným využitím nebo recyklovatelností materiálů a konstrukcí z odstraněné stavby nebo použitím surovin nebo druhotných materiálů šetrných k životnímu prostředí při stavbě.

(2) Udržitelné využití přírodních zdrojů může být zajištěno opětovným použitím materiálů a konstrukcí nebo stavebních výrobků, které vznikly při realizaci nebo odstraňování záměru, nebo využitím vedlejších produktů nebo stavebních výrobků, které přestaly být odpadem.

##### Díl 5

#### § 152 — Podrobné vymezení požadavků na výstavbu

(1) Prováděcí právní předpis stanoví podrobné požadavky na výstavbu.

(2) Územní samosprávné celky, které jsou k tomu tímto zákonem zmocněny, mohou stanovit prováděcím právním předpisem podrobné požadavky na výstavbu odchylně od prováděcího právního předpisu podle odstavce 1 s výjimkou požadavků na výstavbu staveb dálnic, silnic, drah a civilních leteckých staveb a technických požadavků na stavby technické infrastruktury.

(3) Prováděcí právní předpis podle odstavce 1 nebo jeho jednotlivá ustanovení se použijí, nestanoví-li prováděcí právní předpis podle odstavce 2 jinak.

(4) Určí-li prováděcí právní předpis územního samosprávného celku podle odstavce 2 závazné technické normy ve stavebnictví odchylně od prováděcího právního předpisu podle odstavce 1, zajistí územní samosprávný celek bezplatný přístup k těmto určeným technickým normám a vede jejich seznam.

#### HLAVA II

#### § 153

(1) Pro stavby mohou být navrženy a použity jen takové výrobky, materiály a konstrukce, jejichž vlastnosti z hlediska způsobilosti stavby pro navržený účel zaručují, že stavba při správném provedení a běžné údržbě po dobu předpokládané existence splní základní požadavky na stavby33).

(2) Výrobky pro stavby, které mají rozhodující význam pro výslednou kvalitu stavby a které by mohly ve zvýšené míře ohrozit život nebo zdraví osob nebo zvířat, bezpečnost anebo životní prostředí, popřípadě jiný veřejný zájem, jsou stanoveny a posuzovány podle jiných právních předpisů34).

#### HLAVA III

#### § 154

(1) V systému stavebně technické prevence se evidují závažné nebo opakující se vady nebo havárie staveb, a výsledky šetření jejich příčin, došlo-li při nich ke ztrátám na životech osob nebo zvířat, k ohrožení života a zdraví osob nebo zvířat, k ohrožení bezpečnosti stavby nebo ke značným škodám.

(2) Rozsah a obsah systému stavebně technické prevence stanoví prováděcí právní předpis.

(3) Veřejnoprávní smlouva může upravit spolupráci při předávání informací o skutečnostech, které mají vliv na stavebně technickou prevenci, majících souvislost s havárií nebo mimořádnou událostí, při nichž došlo ke ztrátám na životech, k ohrožení života osob nebo zvířat nebo ke značným škodám. Veřejnoprávní smlouvu může uzavřít ministerstvo s jiným ústředním orgánem státní správy, veřejnoprávní korporací nebo právnickou osobou zřízenou zákonem. Ve veřejnoprávní smlouvě se určí rozsah předávaných informací a četnost jejich poskytování a doba jejího trvání.

#### HLAVA IV

#### § 155 — Vybrané činnosti

Vybrané činnosti, jejichž výsledek ovlivňuje ochranu veřejných zájmů ve výstavbě, může vykonávat pouze fyzická osoba, která získala oprávnění k jejich výkonu podle jiného právního předpisu35). Vybranými činnostmi jsou

a) zpracování územně plánovací dokumentace, územní studie a projektové dokumentace,

b) odborné vedení provádění stavby nebo její změny anebo odstraňování stavby,

c) ověřování výsledků zeměměřických činností ve výstavbě36),

d) výkon dozoru projektanta.

#### § 156 — Projektová činnost

(1) Územně plánovací dokumentace, územní studie a projektová dokumentace musí být zpracovány projektantem.

(2) Dokumentaci jednoduchých staveb, s výjimkou jednoduchých staveb pro bydlení a rodinnou rekreaci nebo vodních děl, a dokumentaci stávajícího stavu stavby (dále jen „pasport stavby“) může zpracovat též osoba, která má vysokoškolské vzdělání stavebního nebo architektonického směru anebo střední vzdělání stavebního směru s maturitní zkouškou a alespoň 3 roky praxe v projektování staveb.

(3) Projektantovi se poskytují údaje z neveřejné části digitální technické mapy kraje v rozsahu nezbytném pro projektovou činnost.

#### § 157 — Projektová dokumentace a dokumentace pro povolení záměru

(1) Projektovou dokumentací se rozumí dokumentace pro

a) povolení stavby, zařízení nebo udržovacích prací (dále jen „dokumentace pro povolení stavby“) jednoduchých staveb pro bydlení a rodinnou rekreaci, vodních děl, vyhrazených a ostatních staveb,

b) rámcové povolení,

c) povolení změny využití území,

d) provádění stavby jednoduchých staveb pro bydlení a rodinnou rekreaci, vyhrazených a ostatních staveb,

e) odstranění stavby jednoduchých staveb pro bydlení a rodinnou rekreaci, jednoduchých staveb, v nichž je obsažen azbest, vodních děl, vyhrazených a ostatních staveb.

(2) Dokumentací pro povolení záměru se rozumí dokumentace pro

a) povolení stavby,

b) rámcové povolení,

c) povolení změny využití území.

#### § 158 — Obsah dokumentace

(1) Dokumentace pro povolení stavby obsahuje průvodní list, souhrnnou technickou zprávu, situační výkresy a dokumentaci objektů. Dokumentace pro povolení změny využití území obsahuje průvodní list, souhrnnou technickou zprávu, situační výkresy a výkresovou dokumentaci. Dokumentace pro rámcové povolení obsahuje průvodní list, souhrnnou technickou zprávu a situační výkresy. Dokumentace pro povolení záměru stanovená prováděcím právním předpisem musí obsahovat urbanistické a základní architektonické a technické řešení záměru umožňující posouzení jeho mechanické odolnosti a stability, požární bezpečnosti a vlivů na území a životní prostředí.

(2) Dokumentace pro provádění stavby a dokumentace pro odstranění stavby obsahuje průvodní list, souhrnnou technickou zprávu, situační výkresy, dokumentaci objektů a technických a technologických zařízení.

(3) Pasport stavby obsahuje průvodní list, souhrnnou technickou zprávu, situační výkresy a zjednodušenou výkresovou dokumentaci. V případě výrobku, který plní funkci stavby, lze příslušné části dokumentace nahradit dokladem podle jiného právního předpisu34) prokazujícím shodu vlastností výrobku plnícího funkci stavby s požadavky podle § 153, dokumentací výrobce nebo dovozce, popřípadě dalšími doklady, ze kterých je možné ověřit dodržení požadavků na stavby.

(4) K projektové dokumentaci a dokumentaci, která nemusí být zpracována projektantem, se přikládá dokladová část, která obsahuje doklady o splnění požadavků podle jiných právních předpisů, dokumentaci zpracovanou osobami oprávněnými podle jiných právních předpisů a závěry provedených průzkumů.

(5) Podrobnosti obsahu projektové dokumentace, dokumentace, která nemusí být zpracována projektantem, pasportu stavby a obsahové náležitosti průzkumů stanoví prováděcí právní předpis.

(6) Obsah jednotlivých částí dokumentace musí odpovídat druhu a významu stavby, charakteru navrhované změny v území, charakteru navrhované změny vlivu užívání stavby na území, podmínkám v území, umístění stavby, stavebně technickému provedení, účelu využití, vlivu na životní prostředí a době trvání stavby. Části dokumentace, které nejsou předmětem navrhovaného záměru, se neuvádějí.

#### § 159 — Provádění a odstraňování staveb, zařízení a terénních úprav

(1) Stavby, zařízení a terénní úpravy musí být prováděny a odstraňovány stavebním podnikatelem, který zabezpečí odborné vedení provádění nebo odstraňování stavby stavbyvedoucím, pokud v odstavcích 2 a 3 není stanoveno jinak.

(2) Svépomocí může stavebník provádět

a) drobné stavby uvedené v příloze č. 1 k tomuto zákonu, s výjimkou staveb uvedených v odstavci 1 písm. a) bodu 11, 12 a 25 a v odstavci 1 písm. f) této přílohy,

b) jednoduché stavby uvedené v příloze č. 2 k tomuto zákonu, s výjimkou staveb uvedených v odstavci 1 písm. m), r) a s) této přílohy,

pokud zajistí stavební dozor, není-li pro takovou činnost sám odborně způsobilý. Jde-li však o stavbu pro bydlení nebo změnu stavby, která je kulturní památkou, je stavebník povinen zajistit odborné vedení provádění stavby stavbyvedoucím.

(3) Svépomocí může stavebník odstraňovat drobné stavby, s výjimkou drobných staveb uvedených v odstavci 1 písm. a) bodu 11, 12 a 25 a v odstavci 1 písm. f) přílohy č. 1 k tomuto zákonu, a jednoduché stavby uvedené v příloze č. 2 k tomuto zákonu, s výjimkou jednoduchých staveb uvedených v odstavci 1 písm. m), r) a s) této přílohy. U staveb, v nichž je obsažen azbest, zajistí odborné vedení odstraňování stavby stavbyvedoucím.

#### HLAVA V

##### Stavebník

#### § 160

(1) Stavebník je povinen pro účely projednání záměru podle tohoto zákona opatřit stanovenou dokumentaci. Vyžaduje-li zákon zpracování projektové dokumentace osobou k tomu oprávněnou, je stavebník povinen zajistit zpracování projektové dokumentace takovou osobou, pokud nemá potřebné oprávnění sám.

(2) Stavebník je v případě stavby, zařízení nebo terénní úpravy podléhající povolení podle tohoto zákona povinen

a) před zahájením stavby zajistit vypracování dokumentace pro provádění stavby jednoduché stavby pro bydlení a rodinnou rekreaci, vyhrazené a ostatní stavby,

b) před zahájením stavby opatřit souhlas orgánu státního požárního dozoru k dokumentaci pro provádění stavby, je-li vyžadován jiným právním předpisem26),

c) oznámit stavebnímu úřadu předem termín zahájení provádění nebo odstraňování stavby, zařízení nebo terénní úpravy, název a sídlo stavebního podnikatele, který je bude provádět nebo odstraňovat, u stavby prováděné nebo odstraňované svépomocí jméno a příjmení stavbyvedoucího, nebo osoby, která bude vykonávat stavební dozor, a změny v těchto skutečnostech oznámit neprodleně stavebnímu úřadu,

d) před zahájením provádění nebo odstraňování stavby umístit na viditelném místě u vstupu na staveniště štítek obsahující identifikační údaje o stavbě a ponechat jej tam až do dokončení stavby, popřípadě do vydání kolaudačního rozhodnutí, nebo do jejího odstranění; rozsáhlé stavby se mohou označit jiným vhodným způsobem s uvedením údajů ze štítku,

e) zajistit, aby na stavbě nebo na staveništi byla k dispozici ověřená dokumentace pro povolení stavby a dokumentace pro provádění stavby, je-li povinná, popřípadě ověřená dokumentace pro odstranění stavby, a všechny doklady týkající se prováděné nebo odstraňované stavby, popřípadě jejich kopie,

f) ohlašovat stavebnímu úřadu fáze výstavby stanovené v podmínkách povolení za účelem provedení kontrolních prohlídek stavby, umožnit provedení kontrolní prohlídky, a pokud tomu nebrání vážné důvody, této prohlídky se zúčastnit,

g) oznámit stavebnímu úřadu předem zahájení zkušebního provozu,

h) při výstavbě, nejpozději k žádosti o vydání kolaudačního rozhodnutí, pokud jiný právní předpis37) nestanoví jinak, opatřit průkaz energetické náročnosti budovy, je-li vyžadován jiným právním předpisem37).

#### § 161

(1) Od zahájení stavby do jejího dokončení je stavebník povinen zabezpečit uchování všech povinných dokladů a dokumentací uvedených v § 167 písm. c) a d), a není-li současně vlastníkem stavby, je povinen je předat vlastníku stavby nejpozději po dokončení nebo kolaudaci stavby.

(2) U stavby financované z veřejných prostředků, kterou provádí stavební podnikatel jako zhotovitel, je stavebník povinen zajistit technický dozor stavebníka nad prováděním stavby fyzickou osobou oprávněnou podle autorizačního zákona. Zpracoval-li projektovou dokumentaci pro tuto stavbu projektant, zajistí stavebník dozor projektanta; to neplatí pro stavby sítí technické infrastruktury.

(3) Při provádění vyhrazených staveb je stavebník povinen vždy zajistit dozor projektanta.

(4) Obsahové náležitosti štítku stanoví prováděcí právní předpis.

#### § 162 — Projektant

(1) Projektant je při projektové činnosti povinen respektovat veřejné zájmy chráněné na základě tohoto nebo jiného právního předpisu, požadavky vyplývající z cílů a úkolů územního plánování a požadavky na výstavbu a jednat v součinnosti s dotčenými orgány. Při zpracování územně plánovací dokumentace a územní studie je dále povinen jednat v součinnosti s orgánem územního plánování a při zpracování projektové dokumentace se stavebním úřadem.

(2) Projektant je povinen zpracovat

a) územně plánovací dokumentaci a územní studii v souladu s právními předpisy,

b) projektovou dokumentaci v souladu s právními předpisy; statické a jiné výpočty musí být vypracovány tak, aby byly přezkoumatelné.

(3) Není-li projektant způsobilý některou část projektové dokumentace zpracovat sám, je povinen k jejímu zpracování přizvat osobu s oprávněním pro příslušný obor nebo specializaci, která odpovídá za jí zpracovaný návrh.

(4) Projektant neodpovídá za odchylky od projektové dokumentace, ke kterým došlo při provádění stavby a které neschválil.

(5) Na zpracovatele dokumentace jednoduchých staveb, která nemusí být zpracována projektantem, se vztahují odstavce 1 až 4 obdobně.

(6) Projektant je povinen zajistit zpracování příslušných částí územně plánovací dokumentace nebo územní studie a podkladů pro zpracování projektové dokumentace prostřednictvím osob, které jsou k tomu oprávněny podle jiných právních předpisů38). Projektant územně plánovací dokumentaci zpracovává a pořizovateli ji předává v jednotném standardu.

#### § 163 — Zhotovitel

(1) Zhotovitel je povinen

a) dbát na řádnou přípravu a provádění stavby, zařízení nebo terénní úpravy; přitom musí mít na zřeteli zejména ochranu života a zdraví osob nebo zvířat, ochranu životního prostředí a majetku i šetrnost k sousedství,

b) zajistit vytyčení prostorové polohy stavby v souladu s ověřenou dokumentací pro povolení záměru a dokumentací pro provádění stavby,

c) zajistit při provádění nebo odstraňování stavby, zařízení nebo terénní úpravy stavbyvedoucího nebo stavební dozor,

d) zajistit při provádění nebo odstraňování stavby, zařízení nebo terénní úpravy dodržení požadavků na výstavbu, popřípadě technických předpisů a technických norem, které souvisí s vlastním prováděním nebo odstraňováním stavby, zařízení nebo terénní úpravy,

e) ohlásit stavebnímu úřadu neprodleně po jejich zjištění závady na stavbě, zařízení nebo terénní úpravě, které ohrožují životy a zdraví osob nebo zvířat anebo bezpečnost stavby, zařízení nebo terénní úpravy,

f) zajistit při provádění nebo odstraňování stavby, zařízení nebo terénní úpravy provedení a vyhodnocení zkoušek a měření stanovených jinými právními předpisy.

(2) Zhotovitel je při provádění nebo odstraňování stavby, zařízení nebo terénní úpravy podléhajícím povolení podle tohoto zákona dále povinen

a) provádět nebo odstraňovat stavbu, zařízení nebo terénní úpravu v souladu s rozhodnutím stavebního úřadu, ověřenou dokumentací pro povolení záměru a dokumentací pro provádění stavby nebo dokumentací pro odstranění stavby,

b) zajistit dodržování povinností k ochraně života, zdraví, životního prostředí a bezpečnosti práce vyplývajících z jiných právních předpisů,

c) zajistit, aby práce na stavbě, jejím odstranění nebo terénní úpravě, k jejichž provádění je předepsáno zvláštní oprávnění39), vykonávaly pouze osoby, které jsou držiteli takového oprávnění,

d) vést stavební deník nebo jednoduchý záznam o stavbě.

#### § 164 — Stavbyvedoucí

(1) Stavbyvedoucí je povinen

a) odborně vést provádění nebo odstraňování stavby, zařízení nebo terénní úpravy,

b) řídit provádění nebo odstraňování stavby, zařízení nebo terénní úpravy v souladu s rozhodnutím stavebního úřadu a s ověřenou dokumentací pro povolení záměru a dokumentací pro provádění stavby nebo dokumentací pro odstranění stavby,

c) zajistit řádné uspořádání staveniště a provozu na něm,

d) zajistit dodržování povinností k ochraně života, zdraví, životního prostředí a bezpečnosti práce vyplývajících z jiných právních předpisů,

e) zajistit dodržení požadavků na výstavbu, popřípadě technických předpisů a technických norem, které souvisí s vlastním prováděním nebo odstraňováním stavby, zařízení nebo terénní úpravy,

f) zajistit vytyčení tras technické infrastruktury na staveništi.

(2) Stavbyvedoucí je dále povinen působit k odstranění závad vzniklých při provádění nebo odstraňování stavby nebo terénní úpravy a neprodleně oznámit stavebnímu úřadu závady, které se nepodařilo odstranit při vedení stavby, vytvářet podmínky pro kontrolní prohlídku stavby, spolupracovat s osobou vykonávající technický dozor stavebníka nebo dozor projektanta, pokud jsou určeny, a s koordinátorem bezpečnosti a ochrany zdraví při práci40), působí-li na staveništi.

#### § 165 — Stavební dozor

(1) Stavební dozor může vykonávat pouze fyzická osoba, která má vysokoškolské vzdělání stavebního nebo architektonického směru nebo střední vzdělání stavebního směru s maturitní zkouškou a alespoň 3 roky praxe při provádění staveb.

(2) Osoba vykonávající stavební dozor zajistí spolu se stavebníkem

a) provádění nebo odstraňování stavby, zařízení nebo terénní úpravy v souladu s rozhodnutím stavebního úřadu a s ověřenou dokumentací pro povolení záměru a dokumentací pro provádění stavby nebo dokumentací pro odstranění stavby,

b) dodržení požadavků na výstavbu, popřípadě jiných technických předpisů a technických norem, které souvisí s vlastním prováděním nebo odstraňováním stavby, zařízení nebo terénní úpravy.

(3) Osoba vykonávající stavební dozor sleduje způsob a postup provádění nebo odstraňování stavby, zejména bezpečnost provádění a provozu technických zařízení na staveništi, vhodnost použití a správnost ukládání stavebních výrobků, materiálů a konstrukcí na staveništi a způsob vedení stavebního deníku nebo jednoduchého záznamu o stavbě; působí k odstranění závad vzniklých při provádění stavby, a pokud se jí nepodaří takové závady v rámci vykonávání dozoru odstranit, oznámí je neprodleně stavebnímu úřadu.

#### § 166 — Stavební deník

(1) Při provádění nebo odstraňování stavby, zařízení nebo terénní úpravy, která vyžaduje povolení podle tohoto zákona, musí být veden stavební deník v českém jazyce. Do stavebního deníku se pravidelně zaznamenávají údaje týkající se provádění nebo odstraňování stavby, zařízení nebo terénní úpravy. Při provádění nebo odstraňování jednoduchých staveb, s výjimkou jednoduchých staveb pro bydlení a rodinnou rekreaci, postačí vedení jednoduchého záznamu o stavbě.

(2) Záznamy do stavebního deníku nebo jednoduchého záznamu o stavbě jsou oprávněni provádět stavebník, stavbyvedoucí, osoba vykonávající stavební dozor, osoba provádějící kontrolní prohlídku stavby a osoba odpovídající za provádění vybraných zeměměřických činností. Záznamy jsou dále oprávněny provádět osoby vykonávající technický dozor stavebníka nebo dozor projektanta, jsou-li takové dozory vykonávány, koordinátor bezpečnosti a ochrany zdraví při práci, působí-li na staveništi, a další osoby, které mohou vykonávat kontrolu podle jiných právních předpisů.

(3) Po dokončení nebo odstranění stavby předá zhotovitel originál stavebního deníku nebo jednoduchého záznamu o stavbě stavebníkovi; v případě jejich vedení v elektronické formě je zhotovitel předá ve strojově čitelném formátu nebo je uchová a zajistí k nim stavebníkovi a jím určeným osobám přístup po dobu 10 let od právní moci kolaudačního rozhodnutí, popřípadě od dokončení stavby, pokud se kolaudační rozhodnutí nevyžaduje.

(4) Obsahové náležitosti stavebního deníku a jednoduchého záznamu o stavbě a způsob jejich vedení stanoví prováděcí právní předpis.

(5) U stavby, která je předmětem veřejné zakázky v nadlimitním režimu, musí být stavební deník veden v elektronické formě.

#### § 167 — Vlastník stavby a zařízení

Vlastník stavby a zařízení je povinen

a) provádět údržbu stavby nebo zařízení po celou dobu jejich existence,

b) neprodleně ohlásit stavebnímu úřadu závady na stavbě nebo zařízení, které ohrožují životy, zdraví osob nebo zvířat,

c) uchovávat stavební deník nebo jednoduchý záznam o stavbě nebo zařízení po dobu 10 let ode dne právní moci kolaudačního rozhodnutí, popřípadě od dokončení stavby nebo zařízení, pokud se kolaudační rozhodnutí nevyžaduje,

d) uchovávat po celou dobu trvání stavby ověřenou projektovou dokumentaci, dokumentaci pro provádění stavby, dokumentaci stavby, došlo-li k odchylce od dokumentace pro povolení stavby, popřípadě dokumentaci skutečného provedení stavby, včetně její geodetické části, nebo pasport stavby, rozhodnutí, osvědčení, souhlasy a jiné důležité doklady týkající se stavby nebo zařízení; dokumentaci lze uchovávat i v elektronické formě,

e) pokud je to technicky proveditelné, zajistit do 1. ledna 2027 za podmínek stanovených prováděcím právním předpisem instalaci alespoň 1 dobíjecího bodu na každých 10 parkovacích stání pro automobily nebo alespoň 50 % kabelovodů parkovacích stání pro automobily, pro jiné než obytné budovy, v nichž se používá energie k úpravě vnitřního prostředí za účelem vytápění nebo chlazení s více než 20 parkovacími stáními, tuto povinnost lze odložit do 1. ledna 2029, pokud vlastník instaloval alespoň 1 dobíjecí bod mezi 28. květnem 2022 a 28. květnem 2024,

f) zajistit do 1. ledna 2033 za podmínek stanovených prováděcím právním předpisem instalaci kabeláže pro alespoň 50 % stání pro automobily v jiné než obytné budově, v níž se používá energie k úpravě vnitřního prostředí za účelem vytápění nebo chlazení, a to pokud je vlastníkem nebo uživatelem této budovy veřejný subjekt,

g) pokud je to technicky proveditelné, zajistit do 1. ledna 2025 instalaci automatizačního a řídícího systému budovy, za podmínek stanovených jiným právním předpisem67), pokud je vlastníkem jiné než obytné budovy se systémem

1. vytápění nebo kombinovaným systémem pro vytápění a větrání o jmenovitém výkonu vyšším než 290 kW nebo

2. klimatizace nebo kombinovaným systémem klimatizace a větrání o jmenovitém výkonu vyšším než 290 kW.

h) pokud je to technicky proveditelné, zajistit do 1. ledna 2030 instalaci automatizačního a řídícího systému budovy, za podmínek stanovených jiným právním předpisem67), pokud je vlastníkem jiné než obytné budovy, v níž se používá energie k úpravě vnitřního prostředí za účelem vytápění nebo chlazení, se systémem

1. vytápění nebo kombinovaným systémem pro vytápění a větrání o jmenovitém výkonu vyšším než 70 kW nebo

2. klimatizace nebo kombinovaným systémem klimatizace a větrání o jmenovitém výkonu vyšším než 70 kW,

i) pokud je to technicky a ekonomicky proveditelné, vybavit budovu, v níž se používá energie k úpravě vnitřního prostředí za účelem vytápění nebo chlazení, automatickými ovladači osvětlení, je-li vlastníkem jiné než obytné budovy se systémem vytápění nebo systémem klimatizace, nebo kombinovaným systémem vytápění a větrání nebo kombinovaným systémem klimatizace a větrání o jmenovitém výkonu vyšším než

1. 290 kW do 1. ledna 2028,

2. 70 kW do 1. ledna 2030,

j) za podmínek stanovených prováděcím právním předpisem zajistit instalaci dobíjecí infrastruktury u nových jiných než obytných budov, v nichž se používá energie k úpravě vnitřního prostředí za účelem vytápění nebo chlazení, nebo u změn jiných než obytných dokončených budov na více než 25 % celkové plochy obálky budovy, v nichž se používá energie k úpravě vnitřního prostředí za účelem vytápění nebo chlazení; povinnost se nevztahuje na změnu dokončené budovy, pokud náklady na instalaci dobíjecí infrastruktury překročí alespoň 10 % celkových nákladů na danou změnu dokončené budovy,

k) za podmínek stanovených prováděcím právním předpisem zajistit instalaci dobíjecí infrastruktury u nových bytových domů nebo u změn dokončených staveb bytových domů na více než 25 % celkové plochy obálky budovy; povinnost se nevztahuje na změnu dokončené budovy, pokud náklady na instalaci dobíjecí infrastruktury překročí alespoň 10 % celkových nákladů na danou změnu dokončené budovy.

#### § 168 — Vlastník technické infrastruktury

Vlastník technické infrastruktury je povinen

a) vést evidenci technické infrastruktury, která musí obsahovat polohové umístění a ochranu, a v odůvodněných případech, s ohledem na charakter technické infrastruktury, i výškové umístění,

b) sdělit bezplatně každému na žádost údaje o podmínkách napojení, o ochranných a bezpečnostních pásmech a o základních podmínkách provádění činnosti v nich, pokud nejde o technickou infrastrukturu, s níž je příslušné hospodařit Ministerstvo obrany nebo Ministerstvo vnitra.

#### § 169 — Oznámení závad a havárií staveb

(1) Stavebník, zhotovitel, stavbyvedoucí, osoba vykonávající stavební dozor, dozor projektanta, technický dozor stavebníka, autorizovaný inspektor a vlastník stavby jsou povinni bezodkladně oznamovat stavebnímu úřadu prostřednictvím systému stavebně technické prevence výskyt závažné a opakující se závady nebo havárie stavby a výsledky šetření jejich příčin, došlo-li při nich ke ztrátám na životech, k ohrožení života osob nebo zvířat nebo ke značným škodám. Oznámení musí obsahovat místo, čas, popis oznamované události a jejích důsledků, povahu stavby, popřípadě další okolnosti důležité pro správné posouzení příčin.

(2) Obsahové náležitosti oznámení výskytu závady nebo havárie a výsledku šetření jejich příčin stanoví prováděcí právní předpis.

### ČÁST PÁTÁ

#### § 170 — Účely vyvlastnění

(1) Práva k pozemkům a stavbám lze odejmout nebo omezit, jsou-li vymezeny v územně plánovací dokumentaci a jde-li o

a) uskutečnění veřejně prospěšné stavby,

b) uskutečnění veřejně prospěšného opatření,

c) realizaci stavby a opatření k zajišťování bezpečnosti státu, nebo

d) asanaci území.

(2) Právo k pozemku nebo stavbě lze odejmout nebo omezit též k vytvoření podmínek pro nezbytný přístup k pozemku nebo stavbě, a pro řádné užívání veřejně prospěšné stavby nebo veřejně prospěšného opatření.

(3) Odejmutí nebo omezení práva podle odstavce 1 se vztahuje také na plochy nezbytné k zajištění výstavby nebo k uskutečnění veřejně prospěšného opatření a vytvoření ochranného pásma, jde-li o ochranné pásmo podle zákona.

### ČÁST ŠESTÁ

#### HLAVA I

#### § 171

Záměr vyžaduje povolení s výjimkou drobných staveb a změn využití území, u kterých tak stanoví tento zákon.

#### § 172 — Způsob a forma podání a žádosti

(1) Podání podle této části je možné učinit také prostřednictvím portálu stavebníka.

(2) Žádost nebo návrh podle této části se podává na stanoveném formuláři elektronicky prostřednictvím portálu stavebníka nebo v listinné podobě. Formulář žádosti a formulář návrhu stanoví prováděcí právní předpis.

(3) Na elektronický dokument vedený v evidenci elektronických dokumentací nebo v evidenci řízení a jiných postupů stavebních úřadů a dotčených orgánů (dále jen „evidence stavebních postupů“) může žadatel v žádosti odkázat namísto jeho přiložení k žádosti jako její součást.

(4) Nejpozději s podáním žádosti vloží stavebník projektovou dokumentaci nebo dokumentaci pro povolení záměru do evidence elektronických dokumentací. Dokumentaci pro povolení záměru, která nemusí být zpracovaná projektantem, vloží do evidence elektronických dokumentací stavební úřad, neučiní-li tak spolu s podáním žádosti stavebník.

#### § 173 — Evidence a doručování

(1) Stavební úřad eviduje veškeré úkony a vkládá veškeré písemnosti do evidence stavebních postupů.

(2) Stavební úřad a dotčený orgán si doručují písemnosti navzájem prostřednictvím evidence stavebních postupů. Písemnost je doručena dnem, kdy ji stavební úřad nebo dotčený orgán vloží do evidence stavebních postupů.

(3) Je-li žádost o vyjádření nebo závazné stanovisko podána žadatelem před zahájením řízení podle této části, vloží dotčený orgán vyjádření nebo závazné stanovisko do evidence stavebních postupů a doručí jej žadateli.

#### HLAVA II

##### Díl 1

#### § 174

(1) Stavební úřad poskytne tomu, kdo požádá, v rámci své působnosti do 30 dnů od požádání předběžnou informaci

a) o podmínkách využívání území a změn jeho využití, zejména na základě územně plánovacích podkladů a územně plánovací dokumentace,

b) o nezbytnosti povolení záměru a jeho kolaudace,

c) o tom, podle jakých hledisek bude posuzovat žádost o vydání rozhodnutí o povolení záměru a za jakých předpokladů lze žádosti vyhovět,

d) o dotčených orgánech ve vztahu k záměru.

(2) Dotčený orgán poskytne tomu, kdo požádá, v rámci své působnosti do 30 dnů od požádání předběžnou informaci

a) o nezbytnosti vyjádření nebo závazného stanoviska dotčeného orgánu,

b) o tom, podle jakých hledisek bude posuzovat žádost o vydání vyjádření nebo závazného stanoviska a za jakých předpokladů lze žádosti vyhovět.

(3) Ten, kdo o předběžnou informaci žádá, kromě obecných náležitostí podle správního řádu uvede konkrétní požadavky na předběžnou informaci a konkrétní údaje o záměru, zejména jeho umístění, účel a technické provedení záměru.

##### Díl 2

#### § 175 — Vyjádření

(1) Vyjádření dotčeného orgánu obsahuje závěr a odůvodnění. V závěru dotčený orgán uvede, zda je záměr z hlediska jím chráněných veřejných zájmů přípustný. V odůvodnění dotčený orgán stručně uvede důvody, o které opírá svůj závěr, podklady pro jeho vydání a úvahy, kterými se řídil při jejich hodnocení a při výkladu právních předpisů, na kterých je závěr založen.

(2) Je-li to nezbytné pro ochranu jím chráněných veřejných zájmů, dotčený orgán uvede v závěru též podmínky přípustnosti záměru. Dotčený orgán je povinen dbát, aby podmínky byly ve vzájemném souladu.

#### § 176 — Koordinované vyjádření a koordinované závazné stanovisko

(1) Je-li dotčeným orgánem podle jiného právního předpisu tentýž orgán veřejné správy, vydá namísto jednotlivých vyjádření koordinované vyjádření a namísto jednotlivých závazných stanovisek koordinované závazné stanovisko. Ustanovení správního řádu o společném řízení a ustanovení o řešení rozporů se použijí přiměřeně.

(2) Koordinované vyjádření nebo koordinované závazné stanovisko zahrnuje požadavky na ochranu všech dotčených veřejných zájmů, které orgán veřejné správy hájí podle jiných právních předpisů.

(3) Koordinované závazné stanovisko nezahrnuje

a) závazné stanovisko k posouzení vlivů provedení záměru na životní prostředí podle zákona o posuzování vlivů na životní prostředí a

b) jednotné environmentální stanovisko podle zákona o jednotném environmentálním stanovisku, vydává-li se současně jako závazné stanovisko k posouzení vlivů provedení záměru na životní prostředí podle zákona o posuzování vlivů na životní prostředí.

(4) V závěru koordinovaného vyjádření nebo koordinovaného závazného stanoviska orgán veřejné správy souhrnně uvede, zda je záměr z hlediska všech jím chráněných veřejných zájmů přípustný. Ustanovení § 175 odst. 2 se použije obdobně.

(5) Koordinované závazné stanovisko je platné 5 let ode dne jeho vydání. Zahrnuje-li koordinované závazné stanovisko jednotné environmentální závazné stanovisko, použijí se ustanovení o platnosti jednotného environmentálního závazného stanoviska podle zákona o jednotném environmentálním stanovisku pro koordinované závazné stanovisko obdobně.

#### § 177 — Žádost

(1) Žádost o vyjádření nebo závazné stanovisko obsahuje kromě obecných náležitostí podle správního řádu dokumentaci, identifikační údaje o záměru a popřípadě další náležitosti podle jiných právních předpisů.

(2) Nemá-li žádost o vyjádření nebo závazné stanovisko stanovené náležitosti nebo trpí-li jinými vadami, vyzve dotčený orgán žadatele k jejich odstranění nejpozději do 10 dnů od jejího podání, poskytne mu k tomu přiměřenou lhůtu a poučí jej o následcích neodstranění nedostatků žádosti.

(3) Neodstraní-li žadatel vady žádosti, dotčený orgán písemně sdělí žadateli, že vyjádření nebo závazné stanovisko nemůže být vydáno. Po dobu odstraňování vad žádosti lhůta pro vydání vyjádření nebo závazného stanoviska neběží. Ode dne odstranění vad žádosti počne běžet nová lhůta pro jejich vydání.

#### § 178 — Lhůta pro vydání

(1) Dotčený orgán vydá do 30 dnů ode dne doručení žádosti nebo vyžádání stavebním úřadem vyjádření nebo závazné stanovisko k záměru z hlediska jím chráněných veřejných zájmů.

(2) Lhůtu podle odstavce 1 může dotčený orgán prodloužit až o 30 dnů, jestliže je zapotřebí nařídit ohledání na místě nebo jde-li o zvlášť složitý případ. Lhůtu podle odstavce 1 může dotčený orgán prodloužit také z důvodu, pro který lze prodloužit lhůtu pro vydání jednotného environmentálního stanoviska podle zákona o jednotném environmentálním stanovisku, jde-li o koordinované závazné stanovisko, které zahrnuje jednotné environmentální stanovisko. O prodloužení lhůty vydá dotčený orgán usnesení, které se pouze poznamená do spisu.

(3) Nevydá-li dotčený orgán vyjádření nebo závazné stanovisko ve lhůtě pro jeho vydání, považuje se za souhlasné a bez podmínek.

(4) Ustanovení odstavce 3 se nepoužije na

a) závazné stanovisko k posouzení vlivů provedení záměru na životní prostředí podle zákona o posuzování vlivů na životní prostředí,

b) jednotné environmentální stanovisko vydané podle zákona o jednotném environmentálním stanovisku namísto závazného stanoviska k posouzení vlivů provedení záměru na životní prostředí podle zákona o posuzování vlivů na životní prostředí nebo správního úkonu orgánu ochrany přírody podle zákona o ochraně přírody a krajiny, kterým se

1. posuzuje splnění podmínek pro stanovení odchylného postupu při ochraně ptáků,

2. vyslovuje souhlas k zásahům, které by mohly vést k závažnému nebo nevratnému poškození nebo ke zničení evropského stanoviště nebo stanoviště evropsky významných druhů,

3. uděluje souhlas k činnostem v ptačích oblastech,

4. posuzuje splnění podmínek pro povolení výjimky ze zákazů u zvláště chráněných druhů rostlin a živočichů, které jsou předmětem ochrany podle práva Evropské unie,

5. uděluje souhlas k činnostem vymezeným v bližších ochranných podmínkách zvláště chráněných území, která byla vyhlášena k zajištění udržení příznivého stavu evropských stanovišť nebo stanovišť evropsky významných druhů, které jsou předmětem ochrany evropsky významných lokalit.

#### § 179 — Nové vyjádření a závazné stanovisko dotčeného orgánu

(1) Nebyly-li v případě uvedeném v § 178 odst. 3 splněny předpoklady pro vydání souhlasného vyjádření nebo závazného stanoviska bez podmínek, vydá nadřízený správní orgán nové vyjádření nebo závazné stanovisko, kterým se vyjádření nebo závazné stanovisko ruší.

(2) Nové vyjádření nebo závazné stanovisko lze vydat do 6 měsíců ode dne právní moci rozhodnutí, pro které bylo vyjádření nebo závazné stanovisko podkladem.

#### § 179a — Přezkum závazného stanoviska v přezkumném řízení

Zahájit přezkumné řízení, jehož předmětem je závazné stanovisko sloužící jako podklad pro řízení podle tohoto zákona, lze do 6 měsíců od právní moci rozhodnutí, jehož bylo závazné stanovisko podkladem. Závazné stanovisko nelze v přezkumném řízení zrušit nebo změnit po uplynutí 9 měsíců od právní moci rozhodnutí, jehož bylo závazné stanovisko podkladem.

##### Díl 3

#### § 180 — Žádost

(1) Žádost o vyjádření vlastníka veřejné dopravní nebo technické infrastruktury z hlediska možnosti a způsobu napojení záměru nebo k podmínkám dotčených ochranných a bezpečnostních pásem musí obsahovat identifikační údaje žadatele a identifikační údaje o záměru.

(2) Žádost o vyjádření lze podat prostřednictvím portálu stavebníka, pokud má vlastník veřejné dopravní nebo technické infrastruktury zřízenu datovou schránku nebo přístup k datovému rozhraní portálu stavebníka.

(3) Součástí žádosti je vždy dokumentace pro povolení záměru.

#### § 181 — Lhůta a způsob doručení

(1) Vlastník veřejné dopravní nebo technické infrastruktury vydá vyjádření k záměru do 30 dnů, ve zvlášť složitých případech do 60 dnů ode dne doručení úplné žádosti.

(2) Má se za to, že žádost podaná prostřednictvím portálu stavebníka je vlastníkovi veřejné dopravní nebo technické infrastruktury, který má zřízen přístup k datovému rozhraní portálu stavebníka, doručena okamžikem jejího odeslání.

(3) Vlastník veřejné dopravní nebo technické infrastruktury, který má zřízen přístup k datovému rozhraní portálu stavebníka, doručí své vyjádření jeho vložením do evidence stavebních postupů. Vyjádření je doručeno okamžikem jeho vložení do evidence stavebních postupů.

(4) Za vlastníka veřejné dopravní nebo technické infrastruktury činí úkony její správce nebo provozovatel v rozsahu, v jakém plní editační povinnost správce technické infrastruktury podle seznamu editorů digitálních technických map krajů vedeného na základě zákona o zeměměřictví.

#### HLAVA III

##### Díl 1

#### § 182 — Účastníci řízení

Účastníky řízení jsou

a) stavebník,

b) obec, na jejímž území má být záměr uskutečněn,

c) vlastník pozemku nebo stavby, na kterých má být záměr uskutečněn, nebo ten, kdo má jiné věcné právo k tomuto pozemku nebo stavbě,

d) osoby, jejichž vlastnické nebo jiné věcné právo k sousedním stavbám nebo sousedním pozemkům může být rozhodnutím o povolení záměru přímo dotčeno,

e) osoby, o kterých tak stanoví jiný zákon.

#### § 183 — Společenství vlastníků jednotek

Je-li stavebníkem společenství vlastníků jednotek41), je zástupcem vlastníků jednotek, kteří jsou účastníky řízení. Oznámí-li zastoupený vlastník jednotky stavebnímu úřadu, že nadále nechce být zastupován společenstvím vlastníků jednotek, jeho zastoupení zaniká okamžikem, kdy toto oznámení dojde stavebnímu úřadu.

#### § 184 — Žádost

(1) Žádost o povolení záměru obsahuje kromě obecných náležitostí podle správního řádu

a) základní údaje o záměru, jeho rozsahu a účelu, způsobu a době provádění,

b) identifikační údaje o pozemku nebo stavbě, na nichž se má záměr uskutečnit,

c) dobu trvání u dočasné stavby a návrh úpravy pozemku po jejím odstranění.

(2) Součástí žádosti je

a) dokumentace pro povolení záměru,

b) plánovací smlouva, je-li uzavřena,

c) souhlas vlastníka,

d) souhlas účastníků řízení se záměrem, pokud stavebník žádá o vydání povolení ve zrychleném řízení,

e) vyjádření, závazné stanovisko nebo rozhodnutí dotčeného orgánu, je-li vyžadováno tímto zákonem nebo jiným právním předpisem, nebo náležitosti žádosti podle § 177, není-li vyjádření nebo závazné stanovisko součástí žádosti,

f) vyjádření vlastníků veřejné dopravní nebo technické infrastruktury uvedených v digitální technické mapě,

g) závěr zjišťovacího řízení, že záměr nepodléhá posouzení vlivů na životní prostředí podle zákona o posuzování vlivů na životní prostředí, byl-li vydán,

h) specifikace výjimky z obecných požadavků na výstavbu požadované k realizaci záměru a její odůvodnění a vyjádření nebo závazné stanovisko dotčeného orgánu, který hájí zájmy podle jiných právních předpisů, kterých se výjimka z obecných požadavků týká,

i) další podklad vyžadovaný jinými právními předpisy.

(3) Není-li součástí žádosti vyjádření nebo závazné stanovisko vyžadované tímto zákonem nebo jiným právním předpisem, stavební úřad si je vyžádá u dotčeného orgánu; to neplatí pro závazné stanovisko k ověření změn záměru podle § 9a odst. 6 zákona o posuzování vlivů na životní prostředí.

(4) Vyžádáním podle odstavce 3 se běh lhůty pro vydání rozhodnutí staví do doby vydání vyjádření nebo závazného stanoviska, nejpozději však do dne, kdy nastane skutečnost podle § 178 odst. 3.

#### § 185 — Vady žádosti

(1) Při výzvě k odstranění vad žádosti postupuje stavební úřad tak, aby mohly být všechny vady odstraněny najednou, je-li to možné.

(2) Stavební úřad vyzve stavebníka k doplnění žádosti a odstranění vad žádosti nejpozději do 10 dnů od zahájení řízení a řízení usnesením přeruší; usnesení se doručuje pouze stavebníkovi a nelze se proti němu odvolat.

(3) Stavební úřad žádost neprojedná a usnesením ji odloží,

a) není-li součástí žádosti dokumentace pro povolení záměru,

b) není-li projektová dokumentace nebo její část zpracována projektantem, nebo

c) nevloží-li stavebník projektovou dokumentaci nebo dokumentaci pro povolení záměru do evidence elektronických dokumentací.

(4) Usnesení o odložení žádosti se oznamuje pouze stavebníkovi.

#### § 186 — Závěr zjišťovacího řízení

(1) V případě záměru, pro který byl vydán závěr zjišťovacího řízení podle jiného právního předpisu42), že záměr nepodléhá posouzení vlivů na životní prostředí, stavební úřad ověří, zda nedošlo ke změnám záměru, které by mohly mít významný negativní vliv na životní prostředí. Stavební úřad zejména ověří, zda nedošlo ke zvýšení kapacity a rozsahu záměru nebo ke změně jeho technologie, řízení provozu nebo způsobu užívání43).

(2) Dojde-li stavební úřad na základě ověření podle odstavce 1 k závěru, že došlo ke změnám záměru, které by mohly mít významný negativní vliv na životní prostředí, vyzve stavebníka k předložení závěru zjišťovacího řízení podle odstavce 1 k takto změněnému záměru. V takovém případě stavební úřad řízení přeruší a postupuje podle ustanovení jiného právního předpisu.

#### § 187 — Souhlas vlastníka

(1) Je-li stavebník vlastníkem pozemku nebo stavby, na nichž má být záměr uskutečněn, nebo je-li oprávněn k realizaci záměru z práva stavby nebo ze služebnosti, ověří stavební úřad tuto skutečnost v katastru nemovitostí. Vlastnické právo ke stavbě, která není předmětem evidence v katastru nemovitostí, doloží stavebník čestným prohlášením.

(2) Není-li stavebník vlastníkem pozemku, na němž má být záměr uskutečněn, a není-li ani oprávněn k realizaci záměru z práva stavby nebo ze služebnosti, dokládá stavebník souhlas vlastníka pozemku, který je zapsán v katastru nemovitostí ke dni podání žádosti. To platí obdobně i v případě, že stavebník není vlastníkem stavby, která není součástí pozemku. Souhlas vlastníka pozemku nebo stavby nelze vzít zpět po podání žádosti o povolení záměru. Dojde-li po podání žádosti k podstatné změně záměru, lze záměr povolit, jen doloží-li stavebník souhlas vlastníka pozemku nebo stavby s upraveným záměrem.

(3) Souhlas musí být vyznačen na situačním výkresu dokumentace a musí obsahovat identifikační údaje a podpis vlastníka pozemku nebo stavby, na nichž má být záměr povolen, nebo oprávněného k realizaci záměru z práva stavby nebo ze služebnosti. Identifikačními údaji jsou u

a) fyzické osoby jméno, příjmení, datum narození, adresa místa trvalého pobytu, a nemá-li ji, adresa bydliště,

b) právnické osoby název, sídlo a identifikační číslo osoby, bylo-li přiděleno.

(4) K souhlasu vlastníka pozemku nebo stavby, které jsou v podílovém spoluvlastnictví, je třeba souhlas dvoutřetinové většiny spoluvlastníků podle výše jejich podílů; v případě bytového spoluvlastnictví postačí pouze souhlas společenství vlastníků jednotek, nebo správce, pokud společenství vlastníků jednotek nevzniklo.

(5) Souhlas není potřeba, je-li pro získání potřebných práv k pozemku nebo stavbě pro záměr stanoven zákonem účel vyvlastnění.

#### § 188 — Vyrozumění o zahájení řízení

(1) Bezodkladně, nejpozději do 7 dnů od zahájení řízení doručením bezvadné žádosti nebo od odstranění vad žádosti vyrozumí stavební úřad účastníky řízení, dotčené orgány a hlavního projektanta o zahájení řízení. Ve vyrozumění uvede, jakým způsobem se mohou účastníci řízení se záměrem seznámit a zda, popřípadě kdy bude ve věci nařízeno ústní jednání anebo veřejné ústní jednání, a zda bude ústní jednání spojeno s ohledáním na místě.

(2) Vyrozumění o zahájení řízení obsahuje také poučení o podmínkách pro uplatňování námitek účastníků řízení, popřípadě připomínek veřejnosti.

(3) Účastníci řízení podle § 182 písm. d) se ve vyrozumění o zahájení řízení s velkým počtem účastníků a v dalších písemnostech v řízení identifikují označením pozemků a staveb evidovaných v katastru nemovitostí.

(4) V řízení s velkým počtem účastníků se vyrozumění o zahájení řízení doručuje účastníkům řízení podle § 182 písm. a), b) a c) jednotlivě. Ostatní písemnosti se doručují jednotlivě pouze žadateli, obci, na jejímž území má být záměr uskutečněn, a dotčeným orgánům; ostatním účastníkům řízení se doručují veřejnou vyhláškou, o čemž se tito účastníci poučí ve vyrozumění o zahájení řízení. Při doručování do ciziny se písemnost doručuje na adresu uvedenou v katastru nemovitostí a za den doručení se považuje třicátý den od předání písemnosti k poštovní přepravě.

(5) U záměru zasahujícího do území několika obcí se vyrozumění o zahájení řízení a další úkony v řízení oznamují rovněž vyvěšením na úředních deskách všech těchto obcí.

#### § 189 — Ústní jednání

(1) Nařídí-li stavební úřad ústní jednání, vyrozumí účastníky řízení a dotčené orgány o termínu jeho konání nejméně 15 dnů předem. Nebude-li nařízeno ústní jednání, stavební úřad ve vyrozumění o zahájení řízení určí lhůtu, která nesmí být kratší než 15 dnů, do kdy mohou účastníci řízení podat námitky.

(2) V případě záměru v území, ve kterém nebyl vydán územní plán, nařídí stavební úřad vždy veřejné ústní jednání. V případech záměrů EIA v území, ve kterém byl vydán územní plán, může stavební úřad nařídit veřejné ústní jednání. Konání veřejného ústního jednání se veřejnosti oznamuje veřejnou vyhláškou a může být stanoveno nejdříve po uplynutí 30 dnů ode dne doručení veřejnou vyhláškou; po tuto dobu stavební úřad umožní každému nahlédnout do podkladů pro vydání rozhodnutí.

#### § 190 — Námitky účastníků řízení

(1) Námitky účastníků řízení musí být uplatněny nejpozději při ústním jednání, popřípadě při veřejném ústním jednání, a nebylo-li nařízeno, ve lhůtě stanovené ve vyrozumění o zahájení řízení. K později uplatněným námitkám stavební úřad přihlédne a vypořádá je pouze tehdy, týkají-li se nově doplněných podkladů pro rozhodnutí, k nimž nebylo možné uplatnit námitku dříve. K námitkám o věcech, o kterých bylo rozhodnuto při vydání územně plánovací dokumentace, se nepřihlíží.

(2) Účastníci řízení mohou uplatňovat námitky směřující k hájení jejich procesních práv; další námitky pouze v rozsahu uvedeném v odstavci 3. K námitkám, které přesahují rozsah odstavce 3, stavební úřad nepřihlíží. Stavební úřad dále nepřihlíží k námitkám účastníka řízení, které jsou v rozporu s uzavřenou plánovací smlouvou, jejíž smluvní stranou je tento účastník řízení.

(3) Obec jako účastník řízení může uplatňovat námitky pouze v rozsahu své samostatné působnosti. Účastník řízení podle § 182 písm. c) a d) může uplatňovat námitky pouze v rozsahu možného přímého dotčení svých práv. Účastník řízení podle § 182 písm. e) může uplatňovat námitky pouze v rozsahu, v jakém se projednávaný záměr dotýká zájmů chráněných jiným právním předpisem, který zakládá jeho účastenství v řízení podle tohoto zákona. Účastník řízení je povinen v námitce uvést důvody podání námitky.

(4) Shledá-li stavební úřad námitku důvodnou, umožní stavebníkovi se k ní vyjádřit, k čemuž mu poskytne přiměřenou lhůtu. Výzvu k vyjádření stavebníka může stavební úřad spojit s jiným úkonem v řízení.

#### § 191 — Námitky o existenci nebo rozsahu věcných práv

(1) Námitky týkající se existence nebo rozsahu vlastnických nebo jiných věcných práv posoudí stavební úřad podle údajů v katastru nemovitostí. Svědčí-li vlastnické nebo jiné věcné právo stavebníkovi, stavební úřad k námitce nepřihlíží.

(2) Zakládají-li údaje v katastru nemovitostí pochybnosti o existenci nebo rozsahu vlastnického nebo jiného věcného práva, stavební úřad řízení přeruší a vyzve účastníka řízení, který takovou námitku uplatnil, aby ji uplatnil ve stanovené lhůtě u soudu.

(3) Nebylo-li ve stanovené lhůtě zahájeno soudní řízení, návrh byl soudem odmítnut nebo bylo řízení zastaveno, stavební úřad k námitce nepřihlíží.

#### § 192 — Připomínky veřejnosti

(1) Je-li nařízeno veřejné ústní jednání, může každý uplatnit připomínky, a to nejpozději na tomto jednání. K připomínkám o věcech, o kterých bylo rozhodnuto při vydání územně plánovací dokumentace, se nepřihlíží.

(2) K později uplatněným připomínkám stavební úřad přihlédne a vyhodnotí je pouze tehdy, týkají-li se nově doplněných podkladů pro rozhodnutí, k nimž nebylo možné uplatnit připomínku dříve.

(3) Vyhodnocení připomínek veřejnosti se uvede jako součást odůvodnění rozhodnutí o povolení záměru.

#### § 193 — Posuzování záměru

(1) Stavební úřad posuzuje, zda je záměr v souladu s

a) územně plánovací dokumentací, územními opatřeními a vymezením zastavěného území,

b) cíli a úkoly územního plánování, zejména s charakterem území a s požadavky na ochranu kulturně historických, architektonických a urbanistických hodnot v území, nemá-li obec vydán územní plán,

c) požadavky tohoto zákona a jeho prováděcích právních předpisů,

d) požadavky jiných právních předpisů chránících dotčené veřejné zájmy,

e) požadavky na veřejnou dopravní nebo technickou infrastrukturu,

f) ochranou práv a právem chráněných zájmů účastníků řízení,

které hodnotí a poměřuje ve vzájemných souvislostech.

(2) Při posuzování souladu záměru s požadavky jiných právních předpisů vychází stavební úřad z vyjádření nebo závazného stanoviska dotčeného orgánu nebo z výsledků řešení rozporů. Na vyžádání stavebního úřadu vydá dotčený orgán do 5 dnů sdělení k návrhům, námitkám, vyjádřením nebo návrhům důkazů účastníků řízení, které se týkají jím chráněného veřejného zájmu.

#### § 195 — Rozhodnutí o záměru

Jsou-li splněny podmínky podle § 193 nebo lze-li jejich splnění zajistit stanovením podmínek v rozhodnutí o povolení záměru, stavební úřad vydá povolení záměru; v opačném případě žádost o povolení záměru zamítne.

#### § 196 — Lhůta pro vydání rozhodnutí

(1) Stavební úřad rozhodne o žádosti nejpozději do

a) 30 dnů ode dne zahájení řízení v případě jednoduché stavby,

b) 60 dnů ode dne zahájení řízení v ostatních případech.

(2) Lhůty podle odstavce 1 může stavební úřad před jejich uplynutím usnesením prodloužit

a) až o 30 dnů ve zvlášť složitých případech nebo je-li nařízeno ústní jednání, nebo

b) až o 60 dnů v řízení s velkým počtem účastníků, nebo je-li třeba doručovat veřejnou vyhláškou osobám, jimž se prokazatelně nedaří doručovat, nebo je-li třeba doručovat do ciziny.

(3) V usnesení o prodloužení lhůty stavební úřad uvede, z jakých důvodů nelze rozhodnout ve lhůtách podle odstavce 1 nebo 2; toto usnesení stavební úřad pouze poznamená do spisu a vyrozumí o prodloužení lhůty pouze stavebníka.

(4) Lhůta pro vydání rozhodnutí se v případě přerušení řízení z důvodu vad žádosti přerušuje a začne znovu běžet od počátku po jejich odstranění.

#### § 197 — Povolení

(1) Ve výrokové části povolení záměru stavební úřad

a) povolí záměr,

b) vymezí pozemky pro realizaci záměru, popřípadě stanoví podmínky pro dělení nebo scelování pozemků, a stanoví podmínky pro jeho umístění a provedení, a pokud je to třeba, i pro jeho užívání,

c) stanoví podmínky, kterými bude zabezpečeno dodržování požadavků podle § 193 odst. 1, zejména podmínky k zabezpečení ochrany veřejných zájmů, dodržení obecných požadavků na výstavbu, popřípadě technických norem, a požadavky na veřejnou dopravní nebo technickou infrastrukturu.

(2) V případě záměru na kulturní památce nebo záměru na nemovité věci, která není kulturní památkou, ale nachází se v památkové rezervaci nebo památkové zóně, může stavební úřad ve výrokové části povolení záměru stanovit okruh dílčích prací, jejichž provedení bude podmíněno rozhodnutím orgánu státní památkové péče.

(3) Po nabytí právní moci povolení stavební úřad zašle stavebníkovi oznámení o ověření projektové dokumentace spolu se štítkem obsahujícím identifikační údaje o povolené stavbě. Oznámení o ověření projektové dokumentace zašle stavební úřad také vlastníkovi stavby, pokud není stavebníkem. Současně o vydání povolení vyrozumí hlavního projektanta.

#### § 198 — Platnost povolení

(1) Povolení platí 2 roky ode dne nabytí právní moci, nestanoví-li stavební úřad v odůvodněných případech dobu delší, nejdéle však 5 let. Bylo-li provádění záměru zahájeno v době jeho platnosti, prodlužuje se doba platnosti na 10 let ode dne právní moci povolení nebo rozhodnutí o prodloužení platnosti povolení.

(2) Povolení pozbývá platnosti také dnem, kdy stavební úřad obdrží oznámení stavebníka o tom, že od provedení svého záměru upouští. Jde-li o vyhrazené stavby, včetně staveb souvisejících, povolení nepozbývá platnosti, bylo-li provádění stavby zahájeno v době jeho platnosti.

(3) Dobu platnosti povolení může stavební úřad prodloužit na základě žádosti stavebníka podané před jejím uplynutím, a to i opakovaně, nejdéle však vždy o další 2 roky. Platnost povolení nezanikne, dokud o žádosti není pravomocně rozhodnuto.

(4) Stavební úřad v řízení o prodloužení platnosti povolení zkoumá, zda nedošlo ke změně podmínek, za kterých bylo povolení vydáno. Doplnění podkladů si stavební úřad vyžádá od stavebníka pouze v rozsahu změněných podmínek. Dojde-li stavební úřad k závěru, že od vydání povolení nedošlo k takové změně podmínek, která by vyžadovala doplnění podkladů, může prodloužit dobu platnosti povolení rozhodnutím jako prvním úkonem stavebního úřadu v řízení.

(5) Na řízení o prodloužení platnosti povolení se použijí ustanovení o řízení o povolení záměru přiměřeně.

#### § 199 — Přechod povolení

(1) O přechodu práv a povinností z povolení vyrozumí právní nástupce stavebníka stavební úřad.

(2) Na žádost právního nástupce stavebníka vydá stavební úřad nový štítek obsahující identifikační údaje o stavbě.

#### § 200 — Změna a zrušení povolení

(1) Povolení lze změnit na základě žádosti stavebníka nebo vlastníka stavby. Platnost povolení není dotčena, pokud není současně na žádost stavebníka rozhodnuto o změně doby jeho platnosti.

(2) Povolení lze změnit nebo zrušit na žádost stavebníka nebo z moci úřední v řízení o povolení veřejně prospěšné stavby nebo veřejně prospěšného opatření. Povolení nelze změnit nebo zrušit, pokud bylo se stavbou započato.

(3) Na řízení o změně nebo zrušení povolení se přiměřeně použijí ustanovení o řízení o povolení záměru. Změnu povolení projedná stavební úřad v rozsahu této změny.

##### Díl 2

#### § 201 — Žádost o povolení záměru domu pro dostupné nájemní bydlení

(1) Není-li stavebníkem obec, je součástí žádosti o povolení záměru domu pro dostupné nájemní bydlení také plánovací smlouva o dostupném nájemním bydlení, jejíž stranou je obec, na jejímž území má být záměr uskutečněn, a která obsahuje

a) závazek stavebníka poskytovat od právní moci kolaudačního rozhodnutí, kterým se povoluje užívání domu pro dostupné nájemní bydlení, nejméně 20 let alespoň 80 % podlahové plochy sloužící bydlení pro dostupné nájemní bydlení podle zákona o Státním fondu podpory investic,

b) závazek stavebníka, že po dobu trvání plánovací smlouvy o dostupném nájemním bydlení bez souhlasu obce bytový dům nezatíží ani nezcizí,

c) sjednání výše dostupného nájemného a způsob jeho navyšování v souladu se zákonem o Státním fondu podpory investic,

d) ujednání o době trvání plánovací smlouvy, která nesmí skončit před uplynutím 20 let od právní moci kolaudačního rozhodnutí, kterým se povoluje užívání domu pro dostupné nájemní bydlení,

e) závazek stavebníka umožnit kontrolu povinností vyplývajících z plánovací smlouvy o dostupném nájemním bydlení,

f) závazek stavebníka uhradit smluvní pokutu ve výši dvanáctinásobku maximálního měsíčního dostupného nájemného za 1 m2 vynásobeného počtem m2 podlahové plochy domu pro dostupné nájemní bydlení, za porušení jakéhokoli závazku vyplývajícího z plánovací smlouvy ve vztahu k poskytování dostupného nájemního bydlení, a to za každé jednotlivé porušení, nesjednají-li si smluvní strany smluvní pokutu vyšší.

(2) Stavební úřad při povolení záměru domu pro dostupné nájemní bydlení ověří, zda plánovací smlouva obsahuje ujednání podle odstavce 1 písm. a), b) a d).

#### § 202 — Posuzování záměru domu pro dostupné nájemní bydlení

Pro záměr domu pro dostupné nájemní bydlení není potřeba souhlas vlastníka podle § 187.

##### Díl 3

#### § 211 — Povolení stavby nebo zařízení

(1) Povolení stavby nebo zařízení obsahuje ve výrokové části kromě obecných náležitostí podle správního řádu a náležitostí podle § 197 odst. 1 a 2 také

a) druh a účel povolované stavby nebo zařízení,

b) katastrální území, parcelní čísla a druh pozemků podle katastru nemovitostí, na nichž se stavba nebo zařízení umisťuje,

c) umístění stavby nebo zařízení na pozemku, zejména minimální vzdálenosti od hranic pozemku a sousedních staveb,

d) určení prostorového řešení stavby nebo zařízení, zejména půdorysnou velikost, maximální výšku a tvar a základní údaje o kapacitě,

e) podmínky pro provedení stavby nebo zařízení,

f) vymezení území dotčeného vlivem stavby nebo zařízení.

(2) Stavební úřad v povolení stanoví podle okolností také

a) u dočasné stavby dobu trvání, lhůtu pro její odstranění a způsob jejího odstranění a následné úpravy území,

b) u jednoduché stavby účel užívání a případné další podmínky užívání,

c) opatření na sousedním pozemku z důvodů realizace stavby nebo zařízení,

d) fáze výstavby za účelem provedení kontrolních prohlídek stavby,

e) další požadavky podle jiných právních předpisů.

(3) K ověření funkčnosti stavby nebo zařízení může stavební úřad zároveň s povolením uložit provedení zkušebního provozu na dobu nejvýše 1 roku.

#### § 212 — Zrychlené řízení

(1) Povolení stavby nebo zařízení je vydáno jako první úkon stavebního úřadu v řízení, pokud stavebník o vydání rozhodnutí ve zrychleném řízení požádal a

a) obec, na jejímž území má být stavba nebo zařízení uskutečněna, má vydán územní plán,

b) nejde o záměr EIA,

c) nejde o záměr vyžadující povolení výjimky nebo stanovení odchylného postupu podle zákona o ochraně přírody a krajiny,

d) stavba splňuje požadavky uvedené v § 193 a

e) stavebník doložil souhlasy všech účastníků řízení se záměrem, vyznačené na situačním výkresu dokumentace.

(2) Povolení stavby nebo zařízení vydané ve zrychleném řízení se vedle oznámení účastníkům řízení zveřejňuje také na úřední desce stavebního úřadu po dobu 15 dnů ode dne vydání.

(3) Nejsou-li splněny podmínky pro vydání povolení ve zrychleném řízení, stavební úřad postupuje podle obecných ustanovení o řízení o povolení záměru.

##### Díl 4

##### Oddíl 1

#### § 213 — Změny vyžadující povolení

Povolení změny využití území vyžadují

a) terénní úprava,

b) stanovení prostoru pro dobývání ložisek nerostů, pro která se nestanoví dobývací prostor podle horního zákona,

c) odstavná, manipulační, prodejní, skladová nebo výstavní plocha,

d) pohřebiště,

e) změna druhu pozemku48), nebo způsobu využití pozemku49), pokud podmínky nejsou stanoveny schválenými pozemkovými úpravami,

f) úprava pozemku, která má vliv na schopnost vsakování vody.

#### § 214 — Změny nevyžadující povolení

(1) Povolení změny využití území nevyžadují

a) terénní úprava do 1,5 m výšky nebo hloubky o výměře do 300 m2 na pozemku, který nemá společnou hranici s veřejnou pozemní komunikací nebo veřejným prostranstvím,

b) odstavná, manipulační, prodejní, skladová nebo výstavní plocha do 300 m2, která neslouží pro skladování hořlavých látek nebo manipulaci s hořlavými látkami nebo látkami, které mohou způsobit znečištění životního prostředí, nebo se zvláště nebezpečnými a nebezpečnými látkami podle vodního zákona,

c) změna druhu pozemku48) nebo způsobu využití pozemků49) o výměře do 300 m2,

d) terénní úprava v přirozeném korytu vodního toku a na pozemcích sousedících s ním, kterou se podstatně nemění přirozené koryto vodního toku, pokud se neprovádí ve stanoveném záplavovém území,

e) úprava pozemku, která má vliv na schopnost vsakování vody, provedená na pozemku stavby pro bydlení nebo rodinnou rekreaci, která souvisí nebo podmiňuje bydlení nebo rodinnou rekreaci, neslouží ke skladování hořlavých látek nebo výbušnin, není v rozporu s územně plánovací dokumentací a plocha části pozemku schopného vsakovat dešťové vody po jejím provedení bude nejméně 50 % z celkové plochy pozemku stavby pro bydlení nebo rodinnou rekreaci,

f) plocha určená k ničení výbušnin, pokud není stavbou.

(2) Ustanovení odstavce 1 se nepoužije, pokud jde o

a) území, pro které je vydán plán území s archeologickými nálezy,

b) záměry EIA,

c) záměr ve zvláště chráněném území, evropsky významné lokalitě nebo ptačí oblasti,

d) záměr v chráněném ložiskovém území.

#### § 215 — Povolení změny využití území

(1) V povolení změny využití území stavební úřad určí nový způsob užívání pozemku a stanoví podmínky jeho využití.

(2) Povolení změny využití území obsahuje ve výrokové části kromě obecných náležitostí podle správního řádu a náležitostí podle § 197 odst. 1 a 2 také

a) katastrální území, parcelní čísla a druh pozemku podle katastru nemovitostí, kterého se změna využití týká,

b) plošné vymezení a určení nového využití území.

(3) Povolení změny využití území lze vydat jako první úkon stavebního úřadu v řízení. Ustanovení § 212 se použije obdobně.

##### Oddíl 2

#### § 216 — Podmínky

(1) Povolení dělení nebo scelení pozemků může stavební úřad vydat pouze na základě žádosti podané vlastníky všech dotčených pozemků, které mají být předmětem povolení nebo alespoň jedním z vlastníků s doložením souhlasu ostatních vlastníků dotčených pozemků. Ustanovení § 187 se na souhlas vlastníků dotčených pozemků použije obdobně. V případě veřejně prospěšné stavby nebo veřejně prospěšného opatření lze povolení dělení nebo scelení pozemků vydat i na základě žádosti stavebníka; v takovém případě se vždy nařídí veřejné ústní jednání.

(2) K žádosti o povolení dělení nebo scelení pozemků se namísto projektové dokumentace přikládá celková situace v měřítku katastrální mapy, včetně parcelních čísel, se zakreslením požadovaného dělení nebo scelení pozemků s vyznačením přímého přístupu z veřejné komunikace ke všem pozemkům, nebo přes pozemek nebo stavbu stejného vlastníka, anebo na základě jiného věcného práva k cizímu pozemku nebo stavbě.

(3) Vydání povolení dělení nebo scelení pozemků je prvním úkonem stavebního úřadu v řízení, pokud jsou podmínky pro dělení nebo scelení pozemků dány územním plánem, regulačním plánem nebo rozhodnutím podle jiného právního předpisu. Povolení dělení nebo scelování pozemků se nevydává, pokud je dělení nebo scelování schváleno pozemkovými úpravami.

(4) K žádosti o dělení nebo scelení pozemků pro stavby dálnic, silnic I. třídy, drah, leteckých staveb a staveb s nimi souvisejících se nedokládá dopravní napojení na veřejně přístupnou komunikaci. V rozhodnutí o dělení nebo scelování pozemků pro stavby dálnic, silnic I. třídy, drah, leteckých staveb a staveb s nimi souvisejících stanoví stavební úřad podmínku zřízení napojení nově vzniklých pozemků na veřejně přístupnou komunikaci.

#### § 217 — Povolení dělení nebo scelování pozemků

(1) V povolení dělení nebo scelování pozemků stavební úřad stanoví podmínky pro dělení nebo scelení pozemků.

(2) Není-li třeba stanovit podmínky pro dělení nebo scelení pozemků, je vydání povolení dělení nebo scelení pozemků prvním úkonem stavebního úřadu v řízení.

(3) Povolení dělení nebo scelení pozemků obsahuje ve výrokové části kromě obecných náležitostí podle správního řádu také

a) katastrální území, parcelní čísla a druh pozemků podle katastru nemovitostí, jichž se dělení nebo scelení týká,

b) určení nových hranic pozemků s vyznačením přístupu z veřejně přístupné pozemní komunikace ke každému pozemku.

(4) Povolení dělení nebo scelení pozemků platí na dobu neurčitou. Povolení pozbývá platnosti dnem, kdy stavební úřad obdrží oznámení stavebníka o tom, že od provedení svého záměru upouští.

##### Oddíl 3

#### § 218 — Podmínky

(1) K ochraně stavby nebo zařízení před negativními účinky okolí nebo k ochraně okolí stavby nebo zařízení před negativními účinky stavby nebo zařízení může stavební úřad stanovit ochranné pásmo rozhodnutím nebo opatřením obecné povahy, týká-li se ochranné pásmo blíže neurčeného okruhu osob.

(2) Stavební úřad ochranné pásmo nestanoví, jestliže podmínky ochrany jsou stanoveny jiným právním předpisem nebo na jeho základě. Vznik ochranného pásma podle jiného právního předpisu tím není dotčen.

(3) Stavební úřad na návrh stavebníka nebo vlastníka stavby v zájmu ochrany povolované nebo dokončené stavby nebo zařízení stanoví ochranné pásmo stavby nebo zařízení.

(4) Stavební úřad z moci úřední stanoví ochranné pásmo dokončené nebo povolované stavby nebo zařízení, pokud je to nezbytné k ochraně okolí před negativními účinky stavby nebo zařízení.

(5) V ochranném pásmu stavební úřad zakáže nebo omezí podle charakteru nebo negativních účinků chráněné stavby nebo zařízení povolování a provádění některých staveb nebo některé činnosti. Zakázat nebo omezit povolování a provádění některých staveb nebo některé činnosti lze z důvodů ochrany života a zdraví osob nebo zvířat nebo ochrany životního prostředí před negativními účinky staveb nebo zařízení na okolí nebo z důvodu ochrany staveb nebo zařízení před negativními vlivy okolí.

#### § 219 — Návrh opatření obecné povahy o stanovení ochranného pásma

(1) K návrhu opatření obecné povahy o stanovení ochranného pásma uplatňují dotčené orgány, které hájí veřejné zájmy podle jiných právních předpisů, kterých se ochrana stavby nebo zařízení nebo jejich okolí dotýká, vyjádření do 30 dnů ode dne doručení návrhu. K později uplatněným vyjádřením se nepřihlíží.

(2) Připomínky a námitky k návrhu opatření obecné povahy o stanovení ochranného pásma lze uplatnit ve lhůtě 30 dnů od jeho zveřejnění, koná-li se veřejné projednání, lze uplatnit připomínky a námitky nejpozději na tomto veřejném projednání.

(3) Námitky proti návrhu opatření obecné povahy mohou podat, kromě osob uvedených v § 172 odst. 5 správního řádu, také osoby, kterým jsou v návrhu opatření obecné povahy o stanovení ochranného pásma stanoveny povinnosti.

(4) Stavební úřad vydá opatření obecné povahy o stanovení ochranného pásma ve lhůtě 90 dnů ode dne zveřejnění návrhu ochranného pásma.

#### § 220 — Opatření obecné povahy nebo rozhodnutí o stanovení ochranného pásma

(1) Opatření obecné povahy nebo výroková část rozhodnutí o stanovení ochranného pásma obsahuje kromě obecných náležitostí podle správního řádu také

a) označení chráněné stavby nebo zařízení, anebo označení stavby nebo zařízení, před jejichž negativními účinky ochranné pásmo chrání okolí,

b) katastrální území, parcelní čísla a druh pozemků podle katastru nemovitostí, na nichž se ochranné pásmo zřizuje,

c) stanovení zákazů nebo omezení povolování a provádění staveb nebo činností,

d) dobu platnosti opatření obecné povahy nebo rozhodnutí, pokud je možno ji předem stanovit,

e) grafickou přílohu obsahující celkovou situaci v měřítku katastrální mapy s vyznačením hranic ochranného pásma a chráněných staveb, zařízení a pozemků; u ochranných pásem liniových staveb delších než 1 000 m a staveb zvlášť rozsáhlých se doplní uvedené údaje na mapovém podkladě v měřítku 1 : 10 000 až 1 : 50 000.

(2) Opatření obecné povahy o stanovení ochranného pásma nabývá účinnosti nejdříve dnem právní moci kolaudačního rozhodnutí, jde-li o stavbu, která jej vyžaduje. U stavby, která nevyžaduje kolaudační rozhodnutí, nebo v případě zařízení stanoví den nabytí účinnosti opatření obecné povahy o stanovení ochranného pásma stavební úřad.

(3) Zřizuje-li se ochranné pásmo k povolované stavbě nebo zařízení, je povolení vykonatelné nejdříve dnem vydání opatření obecné povahy o ochranném pásmu této stavby.

(4) Nestanoví-li stavební úřad dobu platnosti opatření obecné povahy o stanovení ochranného pásma, platí po dobu trvání stavby nebo zařízení.

(5) Ustanovení odstavců 2 až 4 se na rozhodnutí o stanovení ochranného pásma použijí obdobně.

(6) Opatření obecné povahy o stanovení ochranného pásma lze změnit nebo zrušit na podnět toho, komu z něj vyplývá ochrana nebo povinnost, nebo vyžaduje-li to veřejný zájem; rozhodnutí o stanovení ochranného pásma lze změnit nebo zrušit na žádost toho, komu z něj vyplývá ochrana nebo povinnost, nebo z moci úřední, vyžaduje-li to veřejný zájem. Z opatření obecné povahy nebo rozhodnutí o stanovení ochranného pásma může stavební úřad na žádost toho, komu z něj vyplývá povinnost, povolit časově omezenou výjimku za účelem uskutečnění jednorázové činnosti, pokud tato činnost není v rozporu s účelem ochranného pásma.

##### Díl 5

#### § 221 — Obecná ustanovení

(1) Stavební úřad vydá na žádost stavebníka rámcové povolení

a) v případě staveb jaderného zařízení a staveb souvisejících, nacházejících se uvnitř i vně areálu jaderného zařízení, nebo

b) u záměrů v působnosti jiného stavebního úřadu.

(2) Není-li stanoveno jinak, použijí se pro řízení o vydání rámcového povolení ustanovení této hlavy s výjimkou ustanovení dílů 3, 6 a 8 a ustanovení hlav I, II, IV a V této části. Při posuzování záměru se ochrana veřejných zájmů uplatní pouze v rozsahu rámcového povolení.

(3) Rámcové povolení neumožňuje provedení záměru. Požadavky tohoto zákona související s provedením a provozem záměru se pro rámcové povolení nepoužijí. Provedení záměru se povolí povolením záměru, které lze vydat jen za podmínek a v souladu s rámcovým povolením stavebního úřadu. Jiný stavební úřad může povolit stavbu pouze na základě rámcového povolení vydaného krajským úřadem. Stavby podle odstavce 1 písm. a) může Dopravní a energetický stavební úřad povolit i bez předchozího rámcového povolení. Rámcové povolení pro záměry na území vojenských újezdů se nevydává.

(4) Účastníky řízení o povolení záměru, pro který bylo vydáno rámcové povolení, a který slouží nebo má sloužit k zajišťování obrany a bezpečnosti státu nebo pro účely Vězeňské služby České republiky a jejích organizačních složek, jsou osoby uvedené v § 182 odst. 1 písm. a), c) a d).

(5) Záměry, které se nacházejí v areálech dokončených staveb a nepřekračují stávající prostorové parametry, zejména výškovou hladinu stávajících staveb nebo odstupové vzdálenosti od hranic pozemků a sousedních staveb, lze povolit i bez předchozího rámcového povolení. Účastníky řízení o povolení záměru pro záměry podle věty první jsou osoby uvedené v § 182 odst. 1 písm. a), c) a d).

(6) Na stanovení doby platnosti rámcového povolení se použije přiměřeně § 198. Platnost rámcového povolení nezaniká, pokud je v době jeho platnosti vydáno povolení záměru.

#### § 222 — Rozsah povolení

(1) Rámcovým povolením stavební úřad pouze vymezí stavební pozemek a v jeho rámci stanoví skladbu, druh a účel staveb a rámcové podmínky pro jejich umístění v maximálních nebo minimálních prostorových parametrech, zejména vnější půdorysné a výškové ohraničení, odstupové vzdálenosti staveb od hranic pozemků a sousedních staveb a napojení na dopravní a technickou infrastrukturu a limitní hodnoty pro vstupy a výstupy.

(2) Rámcovým povolením pro záměry v působnosti jiného stavebního úřadu, které slouží nebo mají sloužit k zajišťování obrany a bezpečnosti státu a nenachází se v areálech dokončených staveb, stavební úřad pouze vymezí stavební pozemek a stanoví účel staveb.

#### § 223 — Obsah rámcového povolení

(1) Rámcové povolení pro stavby jaderného zařízení a stavby související, nacházející se uvnitř i vně areálu jaderného zařízení, a pro záměry v působnosti jiného stavebního úřadu ve výrokové části obsahuje kromě obecných náležitostí podle správního řádu

a) vymezení areálu jako stavebního pozemku,

b) katastrální území, parcelní čísla a druh pozemků podle katastru nemovitostí, na nichž se soubor staveb umisťuje,

c) stanovení skladby, druhu a účelu staveb,

d) stanovení minimálních odstupových vzdáleností staveb umisťovaných od hranice areálu, popřípadě od sousedních staveb mimo areál,

e) vymezení maximální výměry zastavěných ploch pro umístění staveb v areálu jaderného zařízení a maximálního výškového omezení staveb uvnitř areálu jaderného zařízení,

f) stanovení rámcových podmínek napojení stavby na dopravní a technickou infrastrukturu, zejména míst napojení a kapacit, limitních požadavků na vstupy a výstupy nezbytné pro realizaci a provoz areálu, a to kapacitních a časových maxim povolených vstupů, například vody, energie a skladovaného paliva, a kapacitních a časových maxim povolených výstupů, například odpadních vod, odpadů, emisí a imisí,

g) vymezení území dotčeného vlivy stavby,

h) podle potřeby stanovení dalších podmínek pro projektovou přípravu stavby,

i) u dočasných staveb stanovení lhůty pro jejich odstranění.

(2) U záměrů v působnosti jiného stavebního úřadu, které slouží nebo mají sloužit k zajišťování obrany a bezpečnosti státu, obsahuje rámcové povolení ve výrokové části kromě obecných náležitostí podle správního řádu

a) vymezení stavebního pozemku,

b) katastrální území, parcelní čísla a druh pozemků podle katastru nemovitostí,

c) stanovení účelu staveb.

##### Díl 6

#### § 224

(1) Změna záměru před jeho dokončením je změna v záměru oproti jeho povolení nebo oproti dokumentaci pro povolení stavby ověřené stavebním úřadem.

(2) Změnu záměru před dokončením lze realizovat jen na základě povolení. O žádosti stavebníka o změnu záměru před dokončením rozhodne stavební úřad, který záměr povolil.

(3) Nepodstatné odchylky od ověřené projektové dokumentace podle § 157 písm. a), c) a d), při kterých se nemění půdorysný ani výškový rozsah stavby, nezasahuje do nosných konstrukcí stavby, nemění se způsob užívání stavby a nedochází k ovlivnění požární bezpečnosti, se nepovažují za změnu stavby a projednávají se v kolaudačním řízení.

(4) V žádosti o změnu záměru před dokončením stavebník kromě obecných náležitostí podle správního řádu uvede popis změn a připojí dokumentaci pro povolení záměru s vyznačením zamýšlených změn a připojí vyjádření, závazná stanoviska a rozhodnutí dotčených orgánů v rozsahu, v jakém se změna záměru dotýká zájmů chráněných jiným právním předpisem.

(5) Nedotýká-li se změna záměru práv účastníků řízení, s výjimkou stavebníka, ani chráněných veřejných zájmů a nepodléhá-li posouzení vlivu na životní prostředí, může stavební úřad vydat povolení jako první úkon stavebního úřadu v řízení.

##### Díl 7

#### § 225

(1) Dojde-li odvolací správní orgán k závěru, že napadené rozhodnutí vydané v řízení o žádosti je v rozporu s právními předpisy nebo že je nesprávné, napadené rozhodnutí nebo jeho část změní.

(2) Rozhodnutí v odvolacím řízení vydá odvolací správní orgán ve lhůtě podle § 196.

(3) Není-li v tomto díle stanoveno jinak, na řízení o odvolání se použijí ustanovení dílu 1 s výjimkou ustanovení o zrychleném řízení.

#### § 226 — Postup odvolacího orgánu

(1) Je-li odvolání podáno účastníkem řízení, který udělil souhlas s povolením záměru, odvolací správní orgán nepřihlíží k části obsahu odvolání, která směřuje proti tomu, s čím účastník řízení souhlasil.

(2) Odvolací správní orgán nepřihlíží k odvolacím námitkám, které mohl odvolatel uplatnit dříve. Odvolací správní orgán dále nepřihlíží k části obsahu odvolání, které bylo podáno odvolatelem, který je stranou plánovací smlouvy, pokud je obsah odvolání v rozporu s tím, k čemu se odvolatel v plánovací smlouvě zavázal. Odvolací správní orgán dále nepřihlíží k části obsahu odvolání, které bylo podáno odvolatelem, který je účastníkem řízení podle § 182 písm. e), v rozsahu, v jakém se projednávaný záměr nedotýká zájmů chráněných jiným právním předpisem, který zakládá jeho účastenství v řízení podle tohoto zákona.

(3) Podkladem pro vydání rozhodnutí o odvolání proti rozhodnutí Dopravního a energetického stavebního úřadu je také vyjádření Ministerstva zdravotnictví a v případě vyhrazených staveb uvedených v písmenech m) a n) přílohy č. 3 k tomuto zákonu i Českého báňského úřadu, ve kterém posoudí splnění podmínek pro ochranu veřejných zájmů v jejich působnosti v rozhodnutí Dopravního a energetického stavebního úřadu.

##### Díl 8

#### § 227

(1) Stavební úřad může v povolení záměru, povolení odstranění stavby, rozhodnutí o nařízení odstranění stavby, v zakazujícím opatření nebo v opatření k nápravě stanovit povinnost strpět provedení kontrolních prohlídek, pokud je to nezbytné pro zjištění, zda stavebník při výstavbě nebo odstraňování postupuje v souladu s povolením nebo rozhodnutím.

(2) Na výzvu stavebního úřadu jsou povinny se kontrolní prohlídky zúčastnit též další osoby uvedené v § 292 odst. 3; ustanovení § 292 odst. 4 a 5 se použije obdobně.

(3) O průběhu kontrolní prohlídky pořídí stavební úřad protokol, který kromě obecných náležitostí podle správního řádu obsahuje též skutková zjištění. Protokol obdrží všichni účastníci kontrolní prohlídky.

(4) Ustanovení § 62 správního řádu platí obdobně. Při kontrolní prohlídce se nepostupuje podle kontrolního řádu, pro vstup na pozemek a do stavby při kontrolní prohlídce platí ustanovení § 293 obdobně.

(5) Podrobnosti rozsahu kontrolní prohlídky stanoví prováděcí právní předpis.

#### HLAVA IV

#### § 228 — Rozhodování o výjimce a žádost

(1) Je-li k povolení záměru nezbytná výjimka z požadavků na výstavbu, rozhoduje o výjimce stavební úřad v řízení o povolení záměru.

(2) Žádost o výjimku z požadavků na výstavbu je součástí žádosti o povolení záměru a obsahuje uvedení, o jakou výjimku se žádá, a její odůvodnění.

#### HLAVA V

#### § 229

(1) Vlastníkovi pozemku, stavby nebo zařízení, jehož práva k pozemku, stavbě nebo zařízení byla stanovením ochranného pásma omezena a byla mu tím způsobena škoda, náleží náhrada.

(2) Náhradu za omezení práv k pozemku, stavbě nebo zařízení stanovením ochranného pásma je povinen poskytnout vlastník stavby nebo zařízení, pro kterou bylo ochranné pásmo stanoveno.

(3) Vlastníkovi pozemku, stavby nebo zařízení, kterému vznikla škoda v důsledku zrušení nebo změny rozhodnutí o povolení záměru stavebním úřadem z moci úřední v řízení o povolení veřejně prospěšné stavby nebo veřejně prospěšného opatření, náleží náhrada vynaložených nákladů na přípravu záměru v obvyklé výši, zejména na koupi pozemku, na projektovou přípravu výstavby nebo v souvislosti se snížením hodnoty pozemku, který slouží k zajištění dluhu.

(4) Povinnost poskytnout náhradu podle odstavce 3 má obec, kraj nebo stát, jejichž orgány daly podnět ke zrušení nebo změně rozhodnutí o povolení záměru z moci úřední postupem podle § 200 odst. 2 a 3.

(5) Náhrada se poskytuje v penězích. Místo peněžité náhrady lze na základě dohody poskytnout vlastníkovi jiný pozemek nebo stavbu; právo na vyrovnání rozdílu mezi výší peněžité náhrady a hodnotou náhradního pozemku nebo stavby tím není dotčeno.

#### HLAVA VI

##### Díl 1

#### § 230 — Kolaudace

(1) Stavbu, která vyžaduje povolení, lze užívat jen na základě kolaudačního rozhodnutí a jen k účelu vymezenému v tomto rozhodnutí.

(2) Kolaudační rozhodnutí nevyžadují jednoduché stavby s výjimkou jednoduchých staveb pro bydlení a rodinnou rekreaci.

(3) Stavbu, která nevyžaduje kolaudační rozhodnutí, lze užívat ihned po dokončení, a to pouze v souladu s účelem vymezeným v povolení stavby. Dokončení stavby je stavebník povinen neprodleně oznámit stavebnímu úřadu. V oznámení stavebník uvede

a) číslo geometrického plánu, pokud je stavba předmětem evidence v katastru nemovitostí nebo její výstavbou dochází k rozdělení pozemku,

b) identifikátor záznamu, ve kterém byly zapsány změny týkající se obsahu digitální technické mapy kraje nebo předány podklady pro jejich zápis, pokud jsou údaje o stavbě obsahem digitální technické mapy kraje50).

(4) Drobnou stavbu lze užívat jen k účelu, ke kterému je určena svým charakterem.

(5) Vznikla-li stavba, která nevyžaduje kolaudační rozhodnutí a která musí být podle jiného právního předpisu označena číslem, stavební úřad po oznámení dokončení stavby podle odstavce 3 vyzve příslušnou obec k přidělení čísla.

#### § 231 — Účastníci řízení

Účastníky kolaudačního řízení jsou stavebník a vlastník stavby.

#### § 232 — Žádost

(1) Žádost o vydání kolaudačního rozhodnutí obsahuje kromě obecných náležitostí podle správního řádu identifikační číslo stavby, předpokládaný termín dokončení stavby a popis odchylek od dokumentace pro povolení stavby.

(2) Součástí žádosti je

a) dokumentace pro povolení stavby s vyznačením odchylek, došlo-li k nepodstatné odchylce oproti ověřené projektové dokumentaci,

b) údaj o poloze definičního bodu stavby, a jde-li o budovu51), údaj o adresním místě17),

c) číslo geometrického plánu, pokud je stavba předmětem evidence v katastru nemovitostí nebo její výstavbou dochází k rozdělení nebo scelení pozemku,

d) vyjádření, závazné stanovisko nebo rozhodnutí dotčeného orgánu, je-li vyžadováno tímto zákonem nebo jiným právním předpisem,

e) vyhodnocení zkoušek a měření stanovených jinými právními předpisy,

f) vyhodnocení zkušebního provozu, pokud byl nařízen nebo povolen,

g) identifikátor záznamu, ve kterém byly zapsány změny týkající se obsahu digitální technické mapy kraje, nebo předány podklady způsobilé pro jejich zápis, pokud jsou údaje o stavbě obsahem digitální technické mapy kraje,

h) průkaz energetické náročnosti budovy, je-li vyžadován jiným právním předpisem29).

#### § 233 — Posuzování žádosti

(1) V kolaudačním řízení stavební úřad posoudí, zda skutečné provedení stavby, popřípadě její části, kterou lze užívat samostatně, je v souladu s povolením.

(2) Stavební úřad posoudí nepodstatné odchylky od ověřené projektové dokumentace pro povolení stavby. Nemění-li se jimi půdorysný ani výškový rozsah stavby, nezasahuje-li se do nosných konstrukcí stavby, nemění-li se způsob užívání stavby a nedochází-li k negativnímu ovlivnění požární bezpečnosti, stavební úřad k těmto odchylkám nepřihlíží.

(3) Dojde-li během provádění stavby ke změně technických norem nebo jiných technických předpisů, posuzuje se stavba podle technických norem nebo jiných technických předpisů, které platily v době, kdy byla dokumentace pro povolení stavby ověřena stavebním úřadem.

#### § 234 — Závěrečná kontrolní prohlídka

(1) V kolaudačním řízení stavební úřad provede závěrečnou kontrolní prohlídku dokončené stavby, je-li to nezbytné pro ověření skutečného provedení stavby. Závěrečná kontrolní prohlídka se neprovádí u podzemní stavby energetických sítí technické infrastruktury s výjimkou kolektorů a rozvodného tepelného zařízení podle energetického zákona52). Závěrečná kontrolní prohlídka musí být provedena do 30 dnů od podání úplné žádosti nebo ode dne doplnění nebo odstranění vad žádosti, neobsahovala-li žádost všechny povinné náležitosti nebo trpěla-li vadami. O termínu závěrečné kontrolní prohlídky musí být účastníci řízení vyrozuměni nejméně 10 dnů přede dnem jejího konání. O konání závěrečné kontrolní prohlídky vyrozumí stavební úřad i hlavního projektanta.

(2) Je-li k žádosti o vydání kolaudačního rozhodnutí přiložen odborný posudek autorizovaného inspektora o ověření souladu skutečného provedení stavby s jejím povolením a její způsobilosti k užívání, stavební úřad může upustit od závěrečné kontrolní prohlídky.

(3) Vznikla-li realizací stavba, která musí být podle jiného zákona54) označena číslem, stavební úřad po provedení závěrečné kontrolní prohlídky vyzve příslušnou obec k přidělení čísla.

#### § 235 — Kolaudační rozhodnutí

(1) Jsou-li splněny podmínky podle § 233, stavební úřad ve lhůtě 15 dnů ode dne provedení závěrečné kontrolní prohlídky vydá kolaudační rozhodnutí, kterým povolí užívání stavby k určenému účelu.

(2) Kolaudační rozhodnutí obsahuje ve výrokové části kromě obecných náležitostí podle správního řádu a náležitostí podle § 197 odst. 1 a 2

a) druh, účel stavby, číslo popisné nebo evidenční,

b) místo stavby s uvedením parcelního čísla pozemku a katastrálního území podle katastru nemovitostí,

c) datum a číslo jednací povolení stavby, na základě kterého byla stavba provedena,

d) údaje o zkušebním provozu, pokud byl prováděn, popřípadě o předčasném užívání stavby,

e) datum konání a výsledek závěrečné kontrolní prohlídky,

f) vymezení účelu užívání stavby.

(3) Je-li to nezbytné, kolaudační rozhodnutí ve výrokové části dále obsahuje

a) podmínky pro užívání stavby,

b) podmínky pro odstranění drobných nedostatků zjištěných při kolaudačním řízení, včetně určení přiměřené lhůty k jejich odstranění, nebo

c) podmínky k zajištění ochrany veřejných zájmů.

(4) Neprovádí-li stavební úřad závěrečnou kontrolní prohlídku, vydá kolaudační rozhodnutí jako první úkon stavebního úřadu v řízení do 15 dnů od podání žádosti. Kolaudační rozhodnutí se doručuje účastníkům řízení a dotčeným orgánům.

(5) Kolaudační rozhodnutí lze vydat i pro část stavby, lze-li ji užívat samostatně, pokud to neohrozí bezpečnost a zdraví osob nebo zvířat anebo životní prostředí.

##### Díl 2

#### § 236 — Předčasné užívání

(1) Před dokončením stavby může stavební úřad povolit předčasné užívání stavby nejdéle na dobu 1 roku, lze-li ji užívat a pokud to neohrozí bezpečnost a zdraví osob nebo zvířat anebo životní prostředí.

(2) O předčasném užívání stavby rozhoduje stavební úřad na žádost stavebníka, ve které stavebník doloží, že nedokončená stavba je předčasně uživatelná.

(3) Žádost o povolení předčasného užívání stavby obsahuje kromě obecných náležitostí podle správního řádu identifikační údaje stavby a odůvodnění žádosti. Součástí žádosti jsou podklady podle § 232 odst. 2 v rozsahu podle charakteru stavby. U stavby prováděné dodavatelsky stavebník k žádosti připojí dohodu se zhotovitelem stavby, obsahující jeho souhlas, popřípadě sjednané podmínky předčasného užívání stavby; u ostatních staveb navrhne stavebník podmínky předčasného užívání stavby v žádosti.

(4) Účastníkem řízení o povolení předčasného užívání stavby je stavebník a vlastník stavby.

(5) Po dokončení stavby se postupuje podle § 230 až 235 a 237 obdobně.

#### § 237 — Zkušební provoz

(1) Zkušebním provozem se ověřuje funkčnost dokončené stavby.

(2) Zkušební provoz stavební úřad povolí na žádost stavebníka nebo nařídí z moci úřední.

(3) Žádost o povolení zkušebního provozu obsahuje kromě obecných náležitostí podle správního řádu identifikační údaje stavby a odůvodnění. Součástí žádosti je vyjádření, závazné stanovisko nebo rozhodnutí dotčeného orgánu, je-li vyžadováno tímto zákonem nebo jiným právním předpisem.

(4) Stavební úřad nařídí zkušební provoz, pokud byla tato podmínka stanovena v povolení. Stavebník je povinen písemně oznámit stavebnímu úřadu dokončení stavby; součástí oznámení je vyjádření, závazné stanovisko nebo rozhodnutí dotčeného orgánu, je-li vyžadováno tímto zákonem nebo jiným právním předpisem.

(5) Účastníkem řízení o povolení nebo nařízení zkušebního provozu je stavebník a vlastník stavby.

(6) Po ukončení zkušebního provozu podá stavebník žádost o vydání kolaudačního rozhodnutí.

#### § 238 — Povolení předčasného užívání a zkušebního provozu

(1) Rozhodnutí o povolení předčasného užívání a zkušebního provozu obsahuje ve výrokové části kromě obecných náležitostí podle správního řádu a náležitostí podle § 197 odst. 1 a 2

a) druh, účel stavby, číslo popisné nebo evidenční,

b) místo stavby s uvedením parcelního čísla pozemku a katastrálního území podle katastru nemovitostí,

c) datum a číslo jednací povolení stavby, na základě kterého byla stavba provedena,

d) dobu trvání předčasného užívání nebo zkušebního provozu,

e) podmínky pro předčasné užívání stavby, nebo podmínky pro plynulý přechod zkušebního provozu do běžného užívání,

f) další podmínky podle zvláštních právních předpisů.

(2) V rozhodnutí o zkušebním provozu stavební úřad určí dobu trvání zkušebního provozu, nejdéle na dobu 1 roku.

(3) Stavební úřad, který předčasné užívání nebo zkušební provoz povolil, může na žádost stavebníka, v případě zkušebního provozu i z moci úřední, rozhodnutím, které je prvním úkonem stavebního úřadu v řízení, stanovenou dobu předčasného užívání, nebo dobu trvání zkušebního provozu, prodloužit před jejím uplynutím i opakovaně, v takovém případě nesmí doba předčasného užívání nebo zkušebního provozu přesáhnout 3 roky. V případě vyhrazených staveb nesmí doba předčasného užívání nebo zkušebního provozu přesáhnout 10 let.

##### Díl 3

#### § 239 — Změna v užívání stavby

(1) Změnu v užívání stavby nebo její části lze na žádost vlastníka stavby povolit povolením změny v užívání stavby, pokud taková změna není podmíněna úpravou stavby vyžadující povolení.

(2) Žádost o povolení změny v užívání stavby obsahuje kromě obecných náležitostí podle správního řádu identifikační údaje stavby a odůvodnění zamýšlené změny, její rozsah a důsledky.

(3) Součástí žádosti je

a) dokumentace stavby s vyznačením změn vyvolaných změnou v užívání a

b) vyjádření, závazné stanovisko nebo rozhodnutí dotčeného orgánu, je-li vyžadováno tímto zákonem nebo jiným právním předpisem.

(4) Účastníky řízení jsou vlastník stavby, vlastník pozemku, na němž se nachází stavba, u které bude prováděna změna v užívání, osoby, jejichž jiné věcné právo ke stavbě může být přímo dotčeno, a osoby, jejichž vlastnické nebo jiné věcné právo k sousedním stavbám nebo sousedním pozemkům může být povolením změny užívání přímo dotčeno.

#### § 240 — Povolení změny v užívání stavby

Povolení změny v užívání stavby obsahuje ve výrokové části kromě náležitosti kolaudačního rozhodnutí také

a) dosavadní účel užívání stavby,

b) nový účel užívání stavby.

#### § 241 — Zrychlené řízení o změně v užívání stavby

(1) Stavební úřad může vydat povolení změny v užívání stavby jako první úkon stavebního úřadu v řízení, jde-li o změnu v užívání stavby, která

a) se nedotýká práv třetích osob,

b) nevyžaduje vydání integrovaného povolení,

c) nevyžaduje podrobnější posouzení účinků na okolí,

d) nevyžaduje zkušební provoz,

e) nevyžaduje stanovení podmínek pro užívání nebo podmínek k zajištění ochrany veřejných zájmů, nebo

f) nezpůsobí změnu kategorie stavby z hlediska požární bezpečnosti a ochrany obyvatelstva stavby podle jiného právního předpisu.

(2) Součástí žádosti je dokumentace stavby s vyznačením změn vyvolaných změnou v užívání a vyjádření, závazné stanovisko nebo rozhodnutí dotčeného orgánu, je-li vyžadováno tímto zákonem nebo jiným právním předpisem.

(3) Účastníkem řízení je vlastník stavby.

#### § 242

(1) Dnem nabytí právní moci povolení o změně v užívání stavby se kolaudační rozhodnutí v rozsahu povolené změny ruší.

(2) Je-li změna v užívání stavby podmíněna stavební úpravou vyžadující povolení, postupuje se podle § 172 až 181, 189 až 193, 196, 225 a 226 obdobně a podle § 185, 188 a 194 přiměřeně.

#### § 243 — Změna v užívání drobné a jednoduché stavby

(1) Změnit užívání jednoduché stavby nebo její části s výjimkou jednoduchých staveb pro bydlení a rodinnou rekreaci nebo jejich části lze jen na žádost vlastníka stavby povolením o změně v užívání jednoduché stavby, pokud taková změna není podmíněna stavební úpravou záměru vyžadující povolení. To platí také pro drobné stavby, pokud změnou v užívání pozbývají charakteru drobné stavby.

(2) Při povolení změny v užívání drobné a jednoduché stavby se použije § 239 a 241 obdobně.

#### § 244 — Povolení změny v užívání drobné a jednoduché stavby

Povolení změny v užívání drobné a jednoduché stavby obsahuje ve výrokové části kromě obecných náležitostí podle správního řádu a náležitostí podle § 197 odst. 1 a 2

a) druh, účel stavby, číslo popisné nebo evidenční,

b) místo stavby s uvedením parcelního čísla pozemku a katastrálního území podle katastru nemovitostí,

c) dosavadní účel užívání stavby,

d) nový účel užívání stavby,

e) podmínky pro užívání stavby.

#### § 245 — Pasport stavby

(1) Vlastník stavby je povinen uchovávat po celou dobu trvání stavby ověřenou dokumentaci odpovídající jejímu skutečnému provedení podle vydaných povolení. V případech, kdy se dokumentace nedochovala nebo není v náležitém stavu a stavba byla povolena, je vlastník stavby povinen pořídit pasport stavby.

(2) Nejsou-li zachovány doklady, z nichž by bylo možné zjistit účel, pro který byla stavba povolena, platí, že stavba je určena k účelu, pro který je svým stavebně technickým uspořádáním určena.

(3) Neplní-li vlastník stavby povinnost podle odstavce 1, stavební úřad mu nařídí, aby pořídil pasport stavby. Rozhodnutí o nařízení pořízení pasportu stavby se vydává jako první úkon stavebního úřadu v řízení. Není-li třeba pasport stavby doplnit, změnit nebo jinak přepracovat, stavební úřad jej ověří.

##### Díl 4

#### § 246

Není-li v této hlavě stanoveno jinak, postupuje se při vydání kolaudačního rozhodnutí podle § 172 až 181, 225 a 226 obdobně a podle § 185, 188, 190 a 194 přiměřeně, při vydání povolení změny v užívání stavby nebo povolení změny v užívání drobné a jednoduché stavby podle § 172 až 181, 189 až 193, 196, 225 a 226 obdobně a podle § 185, 188 a 194 přiměřeně.

#### HLAVA VII

##### Díl 1

#### § 247 — Podmínky odstraňování staveb

(1) Stavbu, která podléhá povolení nebo obsahuje azbest, je možné odstranit pouze na základě povolení odstranění stavby.

(2) Účastníkem řízení o povolení odstranění je vlastník pozemku, na němž se odstraňovaná stavba nachází, vlastník stavby a další osoby, jejichž vlastnická nebo jiná věcná práva k sousednímu pozemku nebo stavbě mohou být odstraňováním stavby přímo dotčena.

(3) Nejde-li o stavbu v památkové rezervaci, památkové zóně nebo o stavbu, v níž je obsažen azbest, a zároveň se žádost nedotýká vlastnických nebo jiných věcných práv k pozemku, na němž se nachází stavba, která má být odstraněna, nebo stavbám na něm, a vlastnických nebo jiných věcných práv k sousedním pozemkům nebo sousedním stavbám, které by mohly být odstraňováním nebo odstraněním stavby přímo dotčeny a není třeba stanovit podmínky pro odstranění stavby nebo podmínky k zajištění ochrany veřejných zájmů, stavební úřad na základě úplné žádosti vydá povolení odstranění jako první úkon stavebního úřadu v řízení.

#### § 248 — Žádost o povolení odstranění stavby

(1) Žádost o povolení odstranění stavby kromě obecných náležitostí podle správního řádu obsahuje

a) předpokládaný termín započetí a ukončení bouracích prací a způsob jejich provádění,

b) identifikaci sousedních pozemků a staveb nezbytných k provedení bouracích prací a

c) informaci o tom, zda jde o stavbu, v níž je obsažen azbest nebo lze přítomnost azbestu očekávat.

(2) Součástí žádosti je dokumentace pro odstranění stavby a vyjádření, závazné stanovisko nebo rozhodnutí dotčeného orgánu, je-li vyžadováno tímto zákonem nebo jiným právním předpisem.

#### § 249 — Povolení odstranění stavby

(1) Povolení odstranění stavby obsahuje ve výrokové části kromě obecných náležitostí podle správního řádu

a) druh, účel stavby, parcelní číslo a katastrální území, ve kterém se stavba nachází, číslo popisné nebo evidenční, pokud bylo přiděleno,

b) lhůtu pro odstranění stavby,

c) postup a způsob provedení bouracích prací, zejména zajištění stability a bezpečného užívání sousedních staveb, včetně staveb technické infrastruktury, a provozu na přilehlých komunikacích,

d) podmínky, kterými se podle potřeby zajistí dodržení technických předpisů a ochrana veřejných zájmů,

e) povinnost oznámit před zahájením bouracích prací název a sídlo stavebního podnikatele, který bude práce provádět, nebo jméno, příjmení, datum narození a adresu místa trvalého pobytu, a nemá-li ji, adresu bydliště osoby, která bude vykonávat stavební dozor při svépomocném provádění bouracích prací u stavby, která nevyžaduje povolení,

f) povinnost oznámit určité stadium bouracích prací stavebnímu úřadu pro provedení kontrolní prohlídky,

g) úpravu pozemku po odstranění stavby, nezávadné odvádění povrchových vod a vysázení zeleně.

(2) Rozhodnutí o povolení odstranění stavby může být součástí rozhodnutí o povolení záměru.

##### Díl 2

##### Oddíl 1

#### § 250 — Obecné ustanovení

(1) Stavební úřad nařídí stavebníkovi nebo vlastníkovi stavby odstranit stavbu, pokud

a) svým závadným stavem ohrožuje život nebo zdraví osob nebo zvířat, bezpečnost, životní prostředí anebo majetek třetích osob a její vlastník přes rozhodnutí stavebního úřadu ve stanovené lhůtě neodstranil závadný stav, nejde-li o kulturní památku,

b) je prováděna nebo byla provedena bez povolení podle tohoto zákona anebo v rozporu s ním,

c) je prováděna nebo byla provedena na základě povolení podle tohoto zákona, které bylo zrušeno,

d) nevyžaduje povolení, ale je prováděna nebo byla provedena v rozporu s právními předpisy,

e) jde o stavbu, u které uplynula stanovená doba trvání, aniž byla do skončení této doby podána žádost o prodloužení doby trvání stavby,

f) jde o stavbu, která nebyla dokončena v době platnosti povolení,

g) jde o stavbu, která nebyla obnovena do 10 let ode dne oznámení stavebnímu úřadu nebo do 10 let ode dne nabytí právní moci povolení obnovy stavby,

h) je prováděna nebo byla provedena v rozporu s platnou územně plánovací dokumentací nebo s platným územním opatřením.

(2) Účastníkem řízení o nařízení odstranění je vlastník stavby a stavebník (dále jen „povinný“), vlastník pozemku, na němž se nachází stavba, která má být odstraněna, osoba, která má jiná věcná práva k pozemku, na němž se nachází stavba, která má být odstraněna, nebo ke stavbám na něm, obec, na jejímž území se stavba, která má být odstraňována, nachází, a další osoby, jejichž vlastnická nebo jiná věcná práva k sousednímu pozemku nebo stavbě mohou být odstraňováním nebo odstraněním stavby přímo dotčena.

#### § 251 — Oznámení o zahájení řízení

(1) Stavební úřad oznámí zahájení řízení o odstranění stavby a vyzve povinného k předložení dokumentace pro odstranění stavby a vyjádření, závazného stanoviska nebo rozhodnutí dotčeného orgánu, jsou-li vyžadována tímto zákonem nebo jiným právním předpisem, a stanoví mu k tomu přiměřenou lhůtu, nejde-li o opakované řízení a nové povolení stavby.

(2) Nepředloží-li povinný ve stanovené lhůtě dokumentaci pro odstranění stavby, stavební úřad ji opatří na jeho náklady; o tom musí být povinný poučen. Po předložení dokumentace pro odstranění stavby, včetně vyjádření, závazného stanoviska a rozhodnutí dotčeného orgánu, nebo po jejím opatření stavebním úřadem, stavební úřad oznámí zahájení řízení o nařízení odstranění stavby ostatním účastníkům řízení a stanoví lhůtu pro podání námitek.

#### § 252 — Rozhodnutí o nařízení odstranění stavby

(1) Rozhodnutí o nařízení odstranění stavby ve výrokové části kromě obecných náležitostí podle správního řádu a náležitostí podle § 197 odst. 1 a 2 obsahuje

a) druh, účel stavby, číslo popisné nebo evidenční,

b) místo stavby s uvedením parcelního čísla pozemku a katastrálního území podle katastru nemovitostí,

c) postup a způsob provedení bouracích prací, zejména zajištění stability a bezpečného užívání sousedních staveb, včetně staveb technické infrastruktury, a provozu na přilehlých komunikacích,

d) podmínky, kterými se podle potřeby zajistí dodržení technických předpisů a ochrana veřejných zájmů,

e) povinnost oznámit před zahájením bouracích prací název a sídlo stavebního podnikatele, který bude práce provádět,

f) povinnost oznámit určité stadium bouracích prací stavebnímu úřadu pro provedení kontrolní prohlídky,

g) povinnost zajistit úpravu pozemku po odstranění stavby podle jeho původního účelového určení, nezávadné odvádění povrchových vod a vysázení zeleně,

h) lhůtu pro odstranění stavby.

(2) V rozhodnutí může stavební úřad též uložit povinnému předložit návrh technologického postupu prací při odstraňování stavby, včetně nutných opatření k vyloučení, omezení nebo ke kompenzaci případných negativních důsledků na zájmy chráněné podle zákona nebo jiných právních předpisů. Nepředloží-li povinný ve stanovené lhůtě návrh technologického postupu prací při odstraňování stavby, stavební úřad jej opatří na náklady povinného; o tom musí být povinný poučen.

(3) O nařízení odstranění stavební úřad vyrozumí nájemce bytů a nebytových prostor informací umístěnou na místě stavby před provedením odstranění.

#### § 253 — Obnovení předcházejícího stavu stavby a odstranění stavby na základě rozhodnutí soudu

(1) Je-li třeba nařídit obnovení předcházejícího stavu stavby, u které byly bez povolení anebo v rozporu s ním provedeny stavební úpravy, postupuje stavební úřad podle tohoto dílu přiměřeně.

(2) Rozhodl-li o odstranění stavby soud, může stavební úřad z moci úřední nebo na žádost toho, komu soud odstranění stavby uložil, stanovit podmínky pro odstranění stavby; rozhodnutí, kterým se podmínky stanoví, je prvním úkonem stavebního úřadu v řízení.

(3) Náklady na odstranění nese povinný nebo ten, komu soud odstranění stavby uložil.

##### Oddíl 2

#### § 254 — Obecné ustanovení

(1) Stavbu provedenou bez povolení nebo v rozporu s ním může stavební úřad dodatečně povolit v případě, že povinný o dodatečné povolení požádal a splnil podmínky pro jeho vydání.

(2) Stavbu provedenou na základě povolení podle tohoto zákona, které bylo zrušeno, stavební úřad povolí novým rozhodnutím v opakovaném řízení v případě, že povinný splní podmínky pro jeho vydání.

(3) Stavbu nevyžadující povolení, ale prováděnou nebo provedenou v rozporu s právními předpisy stavební úřad nenařídí odstranit, pokud povinný uvedl stavbu do souladu s právními předpisy.

(4) U stavby, u které uplynula stanovená doba trvání, může stavební úřad prodloužit dobu trvání stavby, pokud do skončení doby trvání stavby nebo do 30 dnů od zahájení řízení o odstranění stavby byla podána žádost o prodloužení doby trvání stavby a povinný splní podmínky pro vydání povolení prodloužení doby trvání stavby.

(5) Účastníkem řízení podle odstavců 1, 2 a 4 je povinný, osoba, která má vlastnické nebo jiné věcné právo k pozemku, na němž se nachází stavba, která má být odstraněna, nebo stavbám na něm, a další osoby, jejichž vlastnická nebo jiná věcná práva k sousednímu pozemku nebo stavbě mohou být rozhodnutím přímo dotčena.

##### Dodatečné povolení

#### § 255

(1) V oznámení o zahájení řízení o odstranění stavby stavební úřad poučí povinného o možnosti podat ve lhůtě 30 dnů od zahájení řízení žádost o dodatečné povolení stavby. V případě, že ve stanovené lhůtě nebude žádost podána, nelze stavbu dodatečně povolit. Byla-li žádost o dodatečné povolení podána před zahájením řízení o odstranění stavby, platí, že byla podána v okamžiku zahájení řízení o odstranění stavby. Byla-li žádost o dodatečné povolení zamítnuta, nelze podat žádost o vydání nového rozhodnutí.

(2) Žádost o dodatečné povolení stavby obsahuje kromě obecných náležitostí podle správního řádu náležitosti stanovené v § 184 odst. 1 a 2 v rozsahu jako k povolení stavby.

(3) V řízení o dodatečném povolení se ustanovení § 172 až 181, 183 až 220 a 225 až 227 použijí obdobně.

(4) Řízení o dodatečném povolení stavby je součástí řízení o nařízení odstranění stavby.

#### § 256

(1) Stavbu lze dodatečně povolit, pokud povinný prokáže splnění podmínek podle § 193 a

a) stavba nevyžaduje rozhodnutí o povolení výjimky ze zákazů podle jiného právního předpisu,

b) stavba nevyžaduje povolení výjimky z požadavků na výstavbu a

c) povinný uhradil ve stanovené lhůtě pokutu za přestupek podle tohoto zákona spočívající v tom, že provedl stavbu bez povolení nebo v rozporu s ním, byla-li uložena.

(2) Vyžaduje-li stavba pouze výjimku z požadavků na umisťování staveb a stavebník doloží stavebnímu úřadu souhlas účastníků řízení, jejichž vlastnické nebo jiné věcné právo k sousedním stavbám nebo sousedním pozemkům může být povolením výjimky přímo dotčeno, považuje se podmínka podle odstavce 1 písm. b) za splněnou. Ustanovení § 187 odst. 2 až 4 se použije obdobně.

(3) Dodatečné povolení obsahuje náležitosti povolení stavby nebo zařízení. Je-li předmětem dodatečného povolení rozestavěná stavba, stavební úřad stanoví v povolení podmínky pro její dokončení.

(4) Je-li předmětem dodatečného povolení dokončená stavba, může stavební úřad po ověření splnění podmínek podle § 232 a 233 na žádost povinného podanou společně se žádostí o dodatečné povolení současně vydat kolaudační rozhodnutí, pokud stavba takové rozhodnutí vyžaduje. Stavební úřad vydá dodatečné povolení a kolaudační rozhodnutí jako společné rozhodnutí.

#### § 257

Nelze-li stavbu dodatečně povolit, stavební úřad žádost o dodatečné povolení zamítne a nařídí odstranění stavby.

##### Opakované řízení a nové povolení

#### § 258

(1) Za žádost o nové povolení stavby se považuje žádost, na základě které bylo vydáno následně zrušené povolení; doplnění podkladů stavební úřad požaduje pouze v rozsahu nezbytném pro opakované projednání stavby.

(2) V opakovaném řízení se ustanovení § 172 až 181, 183 až 220 a 225 až 227 použijí obdobně.

(3) Lhůta pro vydání rozhodnutí v opakovaném řízení začíná běžet dnem následujícím po nabytí právní moci zrušujícího rozhodnutí. Stavební úřad, který rozhodl v posledním stupni, uvědomí stavební úřad, který rozhodl v prvním stupni, o zrušení rozhodnutí o povolení stavby.

(4) Nebude-li v opakovaném stavebním řízení stavba povolena, stavební úřad žádost zamítne a nařídí odstranění stavby.

#### § 259

(1) Stavba se v opakovaném řízení povolí, pokud povinný prokáže splnění podmínek podle § 193. Nejsou-li tyto podmínky splněny, povolí se stavba, pokud povinný jednal v dobré víře a pokud by nařízením odstranění stavby vznikla třetím osobám nebo veřejnému zájmu újma, která by byla ve zjevném nepoměru k újmě vzniklé nenařízením odstranění stavby.

(2) Nové povolení obsahuje náležitosti povolení stavby.

(3) Je-li předmětem nového povolení rozestavěná stavba, stavební úřad stanoví podmínky pro její dokončení.

(4) Je-li předmětem nového povolení dokončená stavba, může stavební úřad po ověření splnění podmínek podle § 232 a 233 na žádost povinného současně vydat kolaudační rozhodnutí, pokud stavba takové rozhodnutí vyžaduje.

(5) Je-li předmětem nového povolení dokončená stavba, pro kterou bylo před zrušením povolení vydáno kolaudační rozhodnutí, vydá stavební úřad současně po ověření splnění podmínek podle § 232 a 233 na žádost povinného nové kolaudační rozhodnutí; původní kolaudační rozhodnutí pozbývá platnosti dnem nabytí právní moci nového kolaudačního rozhodnutí nebo dnem nabytí právní moci rozhodnutí o nařízení odstranění stavby v případě, že nové povolení nelze vydat.

#### § 260 — Povolení prodloužení doby trvání stavby

(1) Žádost o povolení prodloužení doby trvání stavby obsahuje kromě obecných náležitostí podle správního řádu náležitosti stanovené v § 184 odst. 1 a 2.

(2) V řízení o povolení prodloužení doby trvání stavby se ustanovení § 172 až 181, 183 až 220 a 225 až 227 použijí obdobně.

(3) Prodloužení doby trvání stavby lze povolit, pokud povinný prokáže, že splnil podmínky podle § 193.

(4) Povolení prodloužení doby trvání stavby obsahuje náležitosti povolení stavby.

(5) Nelze-li vydat povolení o prodloužení doby trvání stavby, stavební úřad žádost o povolení zamítne a nařídí odstranění stavby.

##### Díl 3

#### § 261

(1) Pro terénní úpravy a zařízení se ustanovení této hlavy použijí obdobně.

(2) Ministerstvo může na žádost stavebního úřadu uhradit účelně vynaložené náklady vzniklé při provedení náhradního výkonu rozhodnutí o nařízení odstranění stavby nebo terénní úpravy, pokud stavební úřad usnesením podle § 119 odst. 4 správního řádu uložil povinnému zaplatit předem potřebné náklady na provedení exekuce a povinný tyto náklady nezaplatil.

(3) Žádost podle odstavce 2 obsahuje

a) rozhodnutí o nařízení odstranění stavby,

b) exekuční příkaz, na jehož základě stavební úřad pověřil jinou osobu odstraněním stavby nebo terénní úpravy,

c) usnesení podle § 119 odst. 4 správního řádu, kterým stavební úřad uložil povinnému zaplatit potřebné náklady na provedení exekuce, a

d) daňový doklad o výši nákladů na odstranění stavby nebo terénní úpravy.

(4) Uhradilo-li ministerstvo účelně vynaložené náklady podle odstavce 2, uloží po provedení náhradního výkonu rozhodnutí povinnému zaplatit ministerstvu úhradu těchto nákladů.

#### § 262

Není-li v této hlavě stanoveno jinak, postupuje se v řízení o povolení odstranění stavby podle § 172, 174, 185, 188, 189, 191, 192, 194, 196, 225 a 226 obdobně a podle § 190 a 200 přiměřeně. V řízení o nařízení odstranění stavby se postupuje podle § 173, 175, 176, 178 až 181, 189, 191, 192, 225 a 226 obdobně a podle § 190 přiměřeně.

#### HLAVA VIII

#### § 263 — Mimořádné opatření

(1) Je-li při bezprostředně hrozící živelní pohromě nebo závažné havárii (dále jen „mimořádná událost“) třeba bezodkladně provést opatření k odvrácení nebo zmírnění možných dopadů mimořádné události, lze se od postupů stanovených tímto zákonem odchýlit v mezích ustanovení této hlavy.

(2) Mimořádné opatření na stavbě nebo pozemku spočívající podle okolností i v provádění staveb, terénních úprav nebo odstraňování staveb, jimiž se předchází bezprostředně hrozícím důsledkům mimořádné události, čelí jejím účinkům a zabraňuje ohrožení života nebo zdraví osob, popřípadě jiným škodám, může být zahájeno bez předchozího povolení podle tohoto zákona.

(3) Stavebník neprodleně oznámí stavebnímu úřadu, že provádí mimořádné opatření.

(4) Je-li nutné pro zmírnění následků nebo odvrácení dopadů mimořádné události provést nebo odstranit stavbu nebo terénní úpravu, může stavební úřad na základě oznámení podle odstavce 3 rozhodnout o tom, že

a) upouští od vydání povolení stavby nebo zařízení, povolení změny využití území nebo povolení odstranění,

b) omezuje obsah žádosti o povolení stavby nebo zařízení, povolení změny využití území nebo povolení odstranění a jejích příloh na nejnutnější míru nezbytnou pro povolení,

c) lze některé podklady pro vydání povolení o povolení stavby nebo zařízení, povolení změny využití území nebo povolení odstranění předložit dodatečně, a to ve lhůtě stanovené stavebním úřadem.

(5) Rozhodnutí podle odstavce 4 může stavební úřad vydat jako první úkon stavebního úřadu v řízení. Odvolání proti tomuto rozhodnutí nemá odkladný účinek.

#### § 264 — Obnova

(1) Stavbu nebo terénní úpravu zničenou nebo poškozenou mimořádnou událostí lze obnovit podle původního povolení a dokumentace, podle níž byla provedena, na základě oznámení stavebníka nebo na základě povolení obnovy stavby nebo terénní úpravy. Pokud o to stavebník nebo vlastník stavby nebo pozemku požádá, stavební úřad mu kopii původního povolení a dokumentace bezodkladně poskytne, má-li ji k dispozici.

(2) Stavebník oznámí stavebnímu úřadu obnovu stavby nebo terénní úpravy podle původního povolení a dokumentace, podle níž byla provedena, do 6 měsíců ode dne, kdy došlo ke zničení nebo poškození stavby nebo terénní úpravy. V oznámení stavebník uvede údaje o stavbě nebo terénní úpravě, která má být obnovena, jednoduchý technický popis prací a osobu, která bude činnost provádět. Po oznámení obnovy stavby nebo terénní úpravy může stavebník započít s pracemi směřujícími k obnově stavby nebo terénní úpravy.

(3) Vyžaduje-li obnovení stavby nebo terénní úpravy stanovení podmínek k ochraně veřejných zájmů, vyrozumí stavební úřad stavebníka do 15 dnů ode dne oznámení o tom, že obnova vyžaduje povolení. V takovém případě se oznámení považuje za žádost o povolení obnovy. Stavební úřad vydá povolení obnovy stavby nebo zařízení do 30 dnů od oznámení stavebníka, jinak lze obnovu provést na základě oznámení, pokud s ní bude započato do 2 let ode dne oznámení; obnova musí být provedena do 10 let ode dne oznámení stavebnímu úřadu. Odvolání proti povolení nemá odkladný účinek.

(4) Je-li obnova v rozporu s požadavky jiných právních předpisů, stavební úřad zakáže stavebníkovi obnovu provést.

(5) Povolení obnovy stavby nebo terénní úpravy platí 2 roky ode dne nabytí jeho právní moci. Bylo-li s prováděním obnovy stavby nebo terénní úpravy započato v době platnosti povolení obnovy stavby nebo terénní úpravy, prodlužuje se doba platnosti povolení na 10 let ode dne právní moci povolení nebo rozhodnutí o prodloužení platnosti povolení, byla-li doba platnosti povolení prodloužena. Ustanovení § 198 odst. 3 se na prodloužení doby platnosti povolení obnovy použije obdobně.

#### § 265 — Společná ustanovení

(1) Podle ustanovení o mimořádných postupech nelze postupovat v případě, kdy má mimořádná událost původ v zaviněném konání nebo opomenutí stavebníka nebo vlastníka pozemku nebo stavby.

(2) Dokončení staveb, terénních úprav a prací provedených podle této hlavy je stavebník povinen bezodkladně oznámit stavebnímu úřadu; ustanovení o užívání staveb tím nejsou dotčena.

#### HLAVA IX

#### § 266

(1) Nepředvídaný archeologický nebo paleontologický nález nebo nález kulturně cenného předmětu, detailu stavby nebo chráněné části přírody je stavebník povinen neprodleně oznámit stavebnímu úřadu a zároveň učinit opatření nezbytná k tomu, aby nález nebyl poškozen nebo zničen, práce v místě nálezu přerušit a zaznamenat do stavebního deníku čas a okolnosti nálezu, datum oznámení stavebnímu úřadu a popis provedených opatření.

(2) Stavební úřad do 30 dnů od oznámení nálezu a v dohodě s dotčeným orgánem rozhodnutím vydaným na místě nebo rozhodnutím vydaným jako první úkon v řízení stanoví podmínky k ochraně nálezu. Současně může stavební úřad provést ohledání na místě.

(3) Na základě oznámení nálezu může stavební úřad v součinnosti s dotčeným orgánem ve veřejném zájmu provést nové řízení a vydat nové povolení záměru.

(4) Ministerstvo kultury může z podnětu dotčeného orgánu státní památkové péče rozhodnout, že jde o nález mimořádného významu, a z moci úřední jej prohlásí za kulturní památku. Ministerstvo kultury do 30 dnů od podání podnětu informuje stavební úřad o svém postupu, a popřípadě stanoví požadavky na změnu nebo zrušení vydaného rozhodnutí o povolení stavby.

(5) Stavebník může uplatnit nárok na náhradu nákladů, které mu vznikly v důsledku postupu podle odstavce 3 u dotčeného orgánu nebo v důsledku postupu podle odstavce 4 u Ministerstva kultury, a to ve lhůtě 6 měsíců ode dne nabytí právní moci povolení, na jehož základě mu tyto náklady vznikly; jinak nárok na jejich náhradu zaniká.

### ČÁST SEDMÁ

#### § 267 — Základní ustanovení

(1) Ministerstvo je správcem informačních systémů veřejné správy55), které umožňují dálkový přístup a slouží k poskytování digitálních služeb56) podle tohoto zákona.

(2) Informačními systémy veřejné správy ve věcech územního plánování a stavebního řádu (dále jen „informační systém stavební správy“) jsou

a) portál stavebníka,

b) národní geoportál územního plánování,

c) evidence stavebních postupů,

d) evidence elektronických dokumentací,

e) informační systém identifikačního čísla stavby a

f) informační systém stavebního řízení.

(3) Informační systémy stavební správy neslouží k výkonu působnosti jiného stavebního úřadu s výjimkou působnosti Ministerstva obrany a Ministerstva vnitra jako dotčených orgánů. Dotčené orgány v případě záměrů v působnosti jiných stavebních úřadů nevyužívají k výkonu své působnosti informační systémy stavební správy. Údaje o stavbách v areálu jaderného zařízení a záměrech v působnosti jiného stavebního úřadu a řízeních s nimi souvisejících se s výjimkou národního geoportálu územního plánování v informačních systémech stavební správy neevidují.

(4) V národním geoportálu územního plánování se údaje podle odstavce 3 vedou a zobrazují v rozsahu údajů poskytnutých Ministerstvem vnitra, Ministerstvem obrany, Ministerstvem spravedlnosti, zpravodajskými službami České republiky, Policií České republiky, Hasičským záchranným sborem České republiky, Národním bezpečnostním úřadem, Národním úřadem pro kybernetickou bezpečnost a Generální inspekcí bezpečnostních sborů, s ohledem na zajištění obrany, bezpečnosti a utajení jejich činnosti.

(5) Informační systémy stavební správy zajišťují informování účastníků řízení podle části šesté a dotčených osob při vydávání opatření obecné povahy podle tohoto zákona o změně údajů v nich vedených. Způsob a podmínky informování účastníků řízení a dotčených osob při vydávání opatření obecné povahy podle tohoto zákona stanoví prováděcí právní předpis.

#### § 268 — Portál stavebníka

(1) Portál stavebníka umožňuje zejména

a) činit digitální úkony vůči stavebnímu úřadu a dotčenému orgánu, který činí úkony podle jiného právního předpisu sloužící jako podklad pro vydání rozhodnutí v řízení podle tohoto zákona,

b) podávat žádosti vlastníku veřejné dopravní nebo technické infrastruktury a poskytovat vyjádření vlastníka veřejné dopravní nebo technické infrastruktury,

c) vkládat údaje a dokumenty do národního geoportálu územního plánování, do evidence stavebních postupů, do evidence elektronických dokumentací a do digitální mapy veřejné správy57), poskytovat je a odkazovat na ně.

(2) Ministerstvo zřídí vlastníku veřejné dopravní a technické infrastruktury přístup k datovému rozhraní portálu stavebníka na základě jeho žádosti.

(3) Podrobnosti provozu a datového rozhraní portálu stavebníka stanoví prováděcí právní předpis.

#### § 269 — Národní geoportál územního plánování

(1) Národní geoportál územního plánování, který je agendovým informačním systémem, slouží pro

a) zveřejnění výstupů z územně plánovací činnosti,

b) zabezpečení přístupu k evidenci územně plánovací činnosti,

c) sledování postupu pořizování územně plánovací dokumentace,

d) poskytování prostorových dat k plánovanému využití území,

e) zpřístupňování a poskytování dalších dat, která souvisí s územním plánováním a územním rozvojem a která určí ministerstvo, a

f) další činnosti vyplývající z tohoto zákona nebo jeho prováděcích právních předpisů.

(2) Při výkonu územně plánovací činnosti lze na elektronický dokument vedený v národním geoportálu územního plánování odkázat namísto jeho přiložení.

(3) V národním geoportálu územního plánování jsou v jednotných standardech zveřejňovány vybrané části územně plánovacích dokumentací a vymezení zastavěného území, popřípadě dalších nástrojů územního plánování.

(4) Ministerstvo obrany vkládá do národního geoportálu územního plánování data vztahující se k jeho působnosti v elektronické podobě ve strojově čitelném formátu.

(5) Orgán územního plánování eviduje jednotlivé úkony v národním geoportálu územního plánování a vkládá do něj veškeré písemnosti. Data z vlastní územně plánovací činnosti vkládá v elektronické podobě i ve strojově čitelném formátu, včetně prostorových dat ve vektorové formě, a to bezodkladně po jejich vzniku.

(6) Přístup k datům zveřejněným v národním geoportálu územního plánování lze omezit nebo odepřít, pokud je to v zájmu veřejné bezpečnosti, zajištění obrany státu nebo ochrany mezinárodních vztahů nebo by jejich zpřístupněním byla porušena ochrana práv třetích osob plynoucích z jiných právních předpisů; pro omezení nebo odepření přístupu k datům zveřejněným v národním geoportálu územního plánování se použije obdobně § 11d zákona č. 123/1998 Sb., o právu na informace o životním prostředí, ve znění pozdějších předpisů.

(7) Náležitosti obsahu národního geoportálu územního plánování, podrobnosti formy a způsobu vkládání a poskytování údajů v něm vedených stanoví prováděcí právní předpis.

#### § 270 — Evidence stavebních postupů

(1) Evidence stavebních postupů slouží stavebnímu úřadu a dotčenému orgánu, který činí úkony podle jiného právního předpisu sloužící jako podklad pro vydání rozhodnutí v řízení podle tohoto zákona, k ukládání

a) podání a jiných písemností,

b) rozhodnutí a jiných úkonů stavebního úřadu nebo dotčeného orgánu,

c) informací o oprávněné úřední osobě nebo osobách.

(2) Evidence stavebních postupů dále slouží vlastníkovi dopravní nebo technické infrastruktury k doručování vyjádření z hlediska možnosti a způsobu napojení záměru nebo k podmínkám dotčených ochranných a bezpečnostních pásem.

(3) Prováděcí právní předpis stanoví

a) údaje, které se vkládají do evidence stavebních postupů,

b) způsob zaznamenávání úkonů a vkládání písemností, včetně přípustných formátů,

c) metadata náležející k úkonu nebo písemnosti a

d) dobu uchování údajů v evidenci stavebních postupů.

#### § 271 — Evidence elektronických dokumentací

(1) Do evidence elektronických dokumentací se vkládá dokumentace pro povolení záměru, projektová dokumentace s výjimkou projektové dokumentace pro provádění stavby a výsledky zeměměřických činností, včetně souvisejících informací, za účelem plnění povinností podle tohoto zákona.

(2) Žadatel vloží projektovou dokumentaci nebo dokumentaci pro povolení záměru do evidence elektronických dokumentací prostřednictvím portálu stavebníka. Není-li elektronické podání, jehož přílohou je dokumentace pro povolení záměru, která nemusí být zpracována projektantem, učiněno prostřednictvím portálu stavebníka, vloží dokumentaci pro povolení záměru do evidence elektronických dokumentací stavební úřad nebo dotčený orgán, vůči kterému bylo podání učiněno.

(3) Stavební úřad dále vkládá do evidence elektronických dokumentací projektovou dokumentaci nebo dokumentaci pro povolení záměru ověřenou stavebním úřadem po nabytí právní moci rozhodnutí.

(4) Podrobnosti formy a způsobu vkládání projektové dokumentace a dokumentace pro povolení záměru, vedení evidence elektronických dokumentací, datovou strukturu, požadované formáty projektové dokumentace, formy a podmínky poskytování údajů z evidence elektronických dokumentací, dobu uchovávání údajů v evidenci elektronických dokumentací a datové rozhraní pro přístup do ní stanoví prováděcí právní předpis.

#### § 272 — Přístup do evidencí

(1) Právo na přístup k údajům a elektronickým dokumentům v evidenci stavebních postupů a v evidenci elektronických dokumentací má ten, kdo má podle správního řádu právo nahlížet do spisu.

(2) Právo na přístup k projektové dokumentaci má dále ten, kdo se k ní má vyjádřit podle tohoto zákona nebo jiného právního předpisu, a projektant.

(3) Právo na přístup k projektové dokumentaci ve strojově čitelném formátu má ten, kdo předloží souhlas stavebníka nebo vlastníka stavby, které se tato dokumentace týká.

(4) Právo na přístup k vyjádření vlastníka veřejné dopravní nebo technické infrastruktury v evidenci stavebních postupů má rovněž ten, kdo prostřednictvím portálu stavebníka o vyjádření požádal.

(5) Osoba oprávněná k přístupu do evidencí má právo na dálkový přístup, včetně strojového vyhledávání informací, a pořizování výpisů a kopií.

#### § 273 — Informační systém identifikačního čísla stavby

(1) Informační systém identifikačního čísla stavby slouží k evidenci popisných údajů o stavbách a zařízeních a přidělování jedinečného identifikátoru stavby nebo zařízení, který umožňuje identifikovat stavbu nebo zařízení v informačních systémech stavební správy.

(2) Stavební úřad bez zbytečného odkladu po zahájení řízení přidělí stavbě nebo zařízení identifikační číslo stavby a vloží údaje o stavbě nebo zařízení do informačního systému identifikačního čísla stavby; po vydání rozhodnutí ve věci stavební úřad bez zbytečného odkladu aktualizuje údaje vedené o stavbě nebo zařízení v informačním systému identifikačního čísla stavby.

(3) Způsob členění staveb a zařízení pro účely jejich evidence v informačním systému identifikačního čísla stavby, zapisované údaje o nich a způsob přidělování identifikačního čísla stavby nebo zařízení stanoví prováděcí právní předpis.

#### § 274 — Informační systém stavebního řízení

Informační systém stavebního řízení je agendový informační systém, který slouží k výkonu působnosti

a) stavebních úřadů,

b) dotčených orgánů, činí-li úkony podle jiného právního předpisu sloužící jako podklad pro vydání rozhodnutí v řízení podle tohoto zákona,

c) ústředních správních úřadů při výkonu kontroly působnosti orgánů stavební správy.

#### § 275 — Spisová služba a nahlížení do spisu

(1) Orgány územního plánování a stavební správy vykonávají spisovou službu v elektronické podobě v elektronických systémech spisové služby. Při výkonu spisové služby mohou odkazovat na údaje a dokumenty uložené v národním geoportálu územního plánování, evidenci stavebních postupů a evidenci elektronických dokumentací.

(2) U staveb v působnosti jiného stavebního úřadu lze z důvodů ochrany zájmů podle jiných právních předpisů odepřít nahlížení do části spisu, která obsahuje projektovou dokumentaci a dokumentaci pro povolení záměru.

(3) Informační systém stavební správy je samostatnou evidencí dokumentů. Povinnost vykonávat spisovou službu se považuje ve vztahu k dokumentům uchovávaným v informačním systému stavební správy za splněnou.

### ČÁST OSMÁ

#### § 276

(1) Autorizovaný inspektor vydává odborné posudky pro účely kolaudace staveb.

(2) Autorizovaný inspektor vydává na žádost stavebníka posudek pro účely posouzení souladu projektové dokumentace pro provádění stavby s dokumentací pro povolení stavby a s jejími změnami a s požadavky na výstavbu, popřípadě s technickými předpisy a technickými normami.

#### § 277 — Podmínky výkonu činnosti

(1) Oprávnění k výkonu činnosti autorizovaného inspektora udělí ministerstvo fyzické osobě, která

a) je plně svéprávná,

b) dosáhla magisterského vzdělání architektonického nebo stavebního směru,

c) je autorizovanou osobou,

d) má nejméně 15 let praxe v projektové činnosti nebo v odborném vedení provádění staveb anebo na stavebním úřadu, má-li osvědčení o zvláštní odborné způsobilosti podle jiného právního předpisu58),

e) je bezúhonná,

f) prokázala odborné znalosti a zkušenosti potřebné pro výkon funkce při zkoušce před odbornou komisí, jejíž členy jmenuje a odvolává ministerstvo.

(2) Za splnění podmínek stanovených v odstavci 1 písm. a), b), c), e) a f) a po vyjádření České komory architektů nebo České komory autorizovaných inženýrů a techniků činných ve výstavbě (dále jen „Komora“) může být oprávnění k činnosti autorizovaného inspektora uděleno i odborníkovi z vysoké školy, výzkumného pracoviště nebo vědeckého ústavu, i když nesplňuje stanovenou praxi.

#### § 278 — Žádost o udělení oprávnění

Žádost o udělení oprávnění k výkonu činnosti autorizovaného inspektora obsahuje kromě obecných náležitostí podle správního řádu údaje a doklady osvědčující splnění podmínek pro výkon činnosti autorizovaného inspektora. Podrobnosti žádosti stanoví prováděcí právní předpis.

#### § 279 — Bezúhonnost

(1) Za bezúhonnou se pro účely udělení oprávnění k výkonu činnosti autorizovaného inspektora nepovažuje osoba,

a) která byla pravomocně odsouzena za trestný čin spáchaný úmyslně, pokud se na ni nehledí, jako by nebyla odsouzena, a

b) které bylo Komorou pravomocně uloženo disciplinární opatření ve formě pozastavení nebo odnětí autorizace, nebylo-li na návrh autorizované osoby zrušeno.

(2) Ustanovení § 51 odst. 2 a 3 se použije obdobně.

(3) Komora bezodkladně uvědomí ministerstvo o pravomocném uložení disciplinárního opatření autorizovanému inspektorovi spočívajícího v pozastavení nebo odnětí autorizace.

#### § 280 — Doba platnosti a zánik oprávnění

(1) Oprávnění k výkonu činnosti autorizovaného inspektora se uděluje s působností pro celé území České republiky na dobu 10 let. Tato doba bude na žádost prodloužena bez vykonání zkoušky nejvýše o 10 let, a to i opakovaně, jestliže autorizovaný inspektor svou činnost soustavně vykonával.

(2) Oprávnění k výkonu činnosti autorizovaného inspektora zaniká

a) dnem doručení písemného prohlášení autorizovaného inspektora o ukončení činnosti ministerstvu,

b) uplynutím doby podle odstavce 1,

c) dnem právní moci rozhodnutí soudu, kterým byla omezena jeho svéprávnost, nebo

d) ztrátou bezúhonnosti.

#### § 281 — Zrušení oprávnění

(1) Ministerstvo rozhodne o zrušení oprávnění k výkonu činnosti autorizovaného inspektora, jestliže

a) při své činnosti opakovaně nebo závažně porušil veřejné zájmy, které měl chránit, nebo

b) se dopustil jednání neslučitelného s postavením autorizovaného inspektora.

(2) Ministerstvo může rozhodnout o zrušení oprávnění k výkonu činnosti autorizovaného inspektora též pro jeho nečinnost trvající déle než 3 roky.

##### Výkon činnosti autorizovaného inspektora

#### § 282

(1) Právnická osoba může se souhlasem ministerstva vykonávat činnost autorizovaného inspektora, pokud je bezúhonná a zabezpečí výkon činnosti autorizovaným inspektorem; ustanovení § 51 odst. 2 a 3 se použije obdobně. Veřejná obchodní společnost, jejímiž společníky jsou výlučně autorizovaní inspektoři, může činnost autorizovaného inspektora vykonávat bez souhlasu ministerstva.

(2) Vykonávají-li autorizovaní inspektoři činnost ve společnosti, upraví si vzájemné vztahy písemnou smlouvou. Společníky společnosti mohou být výlučně autorizovaní inspektoři. Společníci společnosti jsou povinni vykonávat činnost ve společném sídle podnikání.

#### § 283

(1) Autorizovaný inspektor vykonává svoji činnost za úplatu, která se sjednává písemnou smlouvou.

(2) Autorizovaný inspektor odpovídá za škodu způsobenou výkonem své činnosti. Před započetím činnosti a po celou dobu jejího trvání musí být pojištěn pro případ odpovědnosti za škodu. Pojištěním musí být kryta škoda, která může být způsobena výkonem činnosti autorizovaného inspektora. Na požádání osoby, se kterou autorizovaný inspektor uzavírá smlouvu podle odstavce 1, je povinen sdělit výši částky, na kterou je pojištěn.

(3) Autorizovaný inspektor je povinen vést o svých úkonech evidenci a uchovávat ji po dobu nejméně 5 let.

(4) Autorizovaný inspektor nesmí svoji činnost vykonávat u staveb, na kterých se podílel, podílí nebo má podílet při jejich přípravě anebo provádění sám nebo osoba jemu blízká, kterou se pro účely tohoto zákona rozumí

a) příbuzný v řadě přímé, sourozenec, manžel nebo partner,

b) obchodní společnost, ve které je společníkem,

c) družstvo, jehož je členem,

d) osoba, se kterou je ve vztahu pracovním nebo služebním.

#### § 284 — Práva a povinnosti autorizovaného inspektora

(1) Autorizovaný inspektor je v rozsahu oboru, popřípadě specializace své autorizace, oprávněn vydávat odborné posudky autorizovaného inspektora. Odborný posudek autorizovaného inspektora pro účely kolaudace musí obsahovat minimálně

a) identifikační údaje stavebníka,

b) druh, účel stavby, číslo popisné nebo evidenční u změny dokončené stavby,

c) údaje o oprávnění provést stavbu,

d) údaje o zkušebním provozu, pokud byl prováděn, popřípadě o předčasném užívání stavby,

e) datum ověření splnění podmínek vydání odborného posudku,

f) výsledek ověření splnění podmínek vydání odborného posudku,

g) jméno a příjmení, podpis, otisk razítka autorizovaného inspektora a datum vystavení odborného posudku.

(2) Odborný posudek autorizovaného inspektora pro účely kolaudace dokládá, že skutečné provedení stavby nebo její části, kterou lze samostatně užívat, je v souladu s ověřenou dokumentací nebo jejími povolenými změnami, umožňuje povolený účel užívání a splňuje požadavky na výstavbu.

(3) Odborný posudek pro účely kolaudace je autorizovaný inspektor oprávněn vydat pouze tehdy, pokud ověřil splnění podmínek uvedených v odstavci 2.

(4) Odborný posudek autorizovaného inspektora k dokumentaci pro provádění stavby dokládá, že dokumentace pro provádění stavby je v souladu s ověřenou dokumentací pro povolení stavby nebo s jejími povolenými změnami a s požadavky na výstavbu, popřípadě technickými předpisy a technickými normami.

(5) Odborný posudek k dokumentaci pro provádění stavby je autorizovaný inspektor oprávněn vydat pouze tehdy, pokud ověřil splnění podmínek uvedených v odstavci 4.

(6) Odborný posudek autorizovaného inspektora nemůže být vydán pro stavby sloužící přípravě, otvírce a dobývání ložisek, jakož i úpravě a zušlechťování nerostů prováděné v souvislosti s jejich dobýváním, stavby sloužící jako sklady výbušnin a pro stavby vodních děl.

(7) Autorizovaný inspektor je povinen na výzvu stavebního úřadu a na jeho náklad poskytnout v rozsahu své odborné kvalifikace expertní součinnost.

#### § 285 — Příprava a provádění zkoušek

(1) Provádění přípravy a zkoušek uchazečů, vedení evidence autorizovaných inspektorů a další úkony s tím související organizačně zajišťuje Komora. K zabezpečení jednotného postupu podle věty první zřizují komory společný koordinační orgán schvalovaný na jejich návrh ministerstvem. Náklady spojené s přípravou na zkoušku a s jejím vykonáním nese uchazeč.

(2) Koordinační orgán na základě pověření Komory zajišťuje koordinační, organizační a administrativní záležitosti a odborné vzdělávání potřebné k jednotnému postupu při výkonu činnosti autorizovaných inspektorů.

(3) Komora shromažďuje, eviduje, aktualizuje a poskytuje informace nezbytné pro činnost autorizovaného inspektora. Na úhradě nákladů spojených s touto činností se autorizovaný inspektor každoročně podílí příspěvkem ve prospěch Komory. Výše příspěvku je shodná s příspěvkem určeným členům Komory.

(4) Postup při jmenování členů koordinačního orgánu, jeho činnost, přípravu, provádění a obsah zkoušek a náležitosti a způsob vedení evidence autorizovaných inspektorů stanoví prováděcí právní předpis.

#### § 286 — Působnost ministerstva

Ministerstvo kontroluje přípravu ke zkoušce, osnovy a postup při provádění zkoušek, spočívající v ověření odborných znalostí autorizovaného inspektora, podklady pro jmenování a odvolávání autorizovaných inspektorů, činnost Komory a výkon agendy s tím související. V součinnosti se stavebními úřady vykonává též kontrolu činnosti autorizovaných inspektorů.

### ČÁST DEVÁTÁ

#### HLAVA I

#### § 287 — Působnost

(1) Kontrolu ve věcech územního plánování vykonávají ministerstvo a krajský úřad.

(2) Ministerstvo vykonává kontrolu

a) orgánů krajů,

b) orgánů hlavního města Prahy a

c) zástupců pořizovatele.

(3) Krajský úřad vykonává kontrolu

a) orgánů obcí a

b) zástupců pořizovatele.

(4) Kontrola ve věcech územního plánování zahrnuje v případě orgánů obcí, hlavního města Prahy a krajů kontrolu nad výkonem přenesené i samostatné působnosti.

#### § 288 — Předmět kontroly

(1) Při výkonu kontroly ve věcech územního plánování ministerstvo a krajský úřad kontrolují dodržování tohoto zákona, právních předpisů vydaných k jeho provedení, opatření obecné povahy a rozhodnutí vydaných na základě tohoto zákona, jakož i dodržování usnesení vlády, směrnic ústředních správních úřadů, jakož i opatření příslušných orgánů veřejné správy přijatých při kontrole výkonu přenesené působnosti.

(2) Kontrola se vztahuje i na usnesení, rozhodnutí a jiná opatření přijatá v samostatné i přenesené působnosti.

(3) Kontrola může být vykonána i v průběhu pořizování územně plánovací dokumentace.

#### § 289 — Nápravná opatření

(1) Byly-li při kontrole zjištěny nedostatky, vyzve ministerstvo nebo krajský úřad, se zřetelem na jejich charakter a následky, nebo možné následky, ke zjednání nápravy v přiměřené lhůtě; přitom může do doby zjednání nápravy zcela nebo zčásti pozastavit výkon činnosti, při níž dochází k porušování povinností.

(2) Je-li podle odstavce 1 pozastaveno pořizování územně plánovací dokumentace, může námitky proti kontrolním zjištěním podat i kraj nebo obec, pro které je územně plánovací dokumentace pořizována.

(3) Bylo-li pozastaveno pořizování územně plánovací dokumentace, lze v jejím pořizování pokračovat až po potvrzení kontrolního orgánu o zjednání nápravy.

(4) Je-li pořizovatel nečinný, stanoví mu kontrolní orgán přiměřenou lhůtu, ve které má úkon učinit.

#### § 290 — Kontrola výkonu samostatné působnosti

Při kontrole usnesení, rozhodnutí a jiných opatření orgánů obcí, hlavního města Prahy a krajů v samostatné působnosti ve věcech územního plánování se ustanovení hlavy šesté a hlavy sedmé části první zákona o obcích, hlavy desáté a hlavy jedenácté části první zákona o hlavním městě Praze a hlav šesté a sedmé zákona o krajích použijí obdobně.

#### HLAVA II

##### Díl 1

#### § 291 — Obecné ustanovení

Stavební úřady kontrolují plnění povinností vyplývajících z tohoto zákona, jiných právních předpisů v mezích jejich působnosti a z rozhodnutí a opatření obecné povahy vydaných podle tohoto zákona.

#### § 292 — Kontrola

(1) Stavební úřad provádí kontrolu za účelem zajištění ochrany veřejných zájmů chráněných tímto zákonem. Na podnět dotčeného orgánu zahájí stavební úřad kontrolu vždy. Obsahuje-li povolení záměru podmínky k ochraně veřejných zájmů stanovené na základě vyjádření nebo závazného stanoviska dotčeného orgánu, je dotčený orgán příslušný ke kontrole jejich dodržování; stavební úřad poskytne součinnost potřebnou ke kontrole těchto podmínek.

(2) Je-li na základě kontroly zahájeno správní řízení, doručuje se stejnopis protokolu účastníkům řízení a dotčeným orgánům spolu s oznámením o zahájení řízení nebo s rozhodnutím, které je prvním úkonem stavebního úřadu v řízení.

(3) Na výzvu stavebního úřadu je povinen se kontroly zúčastnit stavebník, a je-li to nezbytné, též vlastník stavby, hlavní projektant, projektant, zhotovitel, stavbyvedoucí a osoba vykonávající stavební dozor. Výzva musí být písemná a doručuje se do vlastních rukou s nejméně pětidenním předstihem. Ve výzvě musí být uvedeno, kdo, kdy, kam, v jaké věci a z jakého důvodu se má dostavit a jaké jsou právní následky v případě, že se nedostaví.

(4) Stavební úřad může v rámci kontroly ústně vyzvat kontrolovanou osobu k odstranění zjištěných nedostatků a stanovit jí k tomu přiměřenou lhůtu, což zaznamená v protokolu. Nebudou-li nedostatky odstraněny ve stanovené lhůtě, postupuje stavební úřad podle § 294 nebo 295. Výzva obsahuje poučení o následcích spojených s neodstraněním zjištěných nedostatků.

(5) Pověření ke kontrole podle tohoto zákona lze vydat i ve formě průkazu, jehož vzor stanoví prováděcí právní předpis.

#### § 293 — Vstup na pozemek a do stavby

(1) Kontrolující může při výkonu kontroly vstupovat v nezbytné míře na pozemek, na stavbu a do stavby pouze s vědomím jejich vlastníků; uvědomění vlastníka nevyžaduje písemnou formu.

(2) Kontrolující může vstoupit na pozemek nebo do stavby i bez vědomí jejich vlastníka v případě důvodného podezření na

a) bezprostřední ohrožení života nebo zdraví osob nebo zvířat, nebo

b) porušení povinností vyplývajících ze zákona za podmínky, že se kontrolujícímu nepodařilo vlastníka pozemku nebo stavby uvědomit.

(3) O vstupu podle odstavce 2 a jeho důvodech musí kontrolující vlastníka bez zbytečného odkladu písemně informovat.

(4) Kontrolující může vstoupit do obydlí bez souhlasu vlastníka nebo uživatele, jen pokud je to nezbytné pro ochranu života, zdraví nebo bezpečnosti osob. Je-li obydlí užíváno také pro podnikání nebo provozování jiné hospodářské činnosti, může kontrolující za účelem kontroly podle tohoto zákona vstoupit do obydlí vždy. Vlastník a uživatel obydlí jsou v uvedených případech povinni kontrolujícímu vstup do obydlí umožnit. Vlastník je povinen umožnit vykonání nezbytných zkoušek a měření použitím nezbytných technických zařízení či prostředků. Pokud je to třeba, přizve kontrolující i další osoby, postup podle odstavce 3 se použije přiměřeně.

(5) Hrozí-li nebezpečí z prodlení a jde-li o některý z důvodů podle odstavce 2 nebo 4, může si stavební úřad zjednat přístup na pozemek nebo do stavby. Policie České republiky poskytne stavebnímu úřadu na jeho žádost ochranu a součinnost podle zákona o Policii České republiky.

(6) Pokud vlastník pozemku nebo stavby brání vstupu kontrolujícímu nebo jím přizvané osobě, může mu stavební úřad rozhodnutím, které je prvním úkonem stavebního úřadu v řízení, umožnění vstupu nařídit. Odvolání proti rozhodnutí nemá odkladný účinek.

#### § 294 — Zakazující opatření

(1) Stavební úřad může i bez provedené kontroly zakázat

a) stavební nebo montážní činnost, je-li prováděna v rozporu s tímto zákonem nebo jinými právními předpisy,

b) odstraňování záměru, pokud je odstraňován v rozporu s tímto zákonem nebo jinými právními předpisy,

c) užívání záměru, je-li užíván v rozporu s tímto zákonem nebo jinými právními předpisy.

(2) Stavební úřad může postupovat v řízení na místě. Vydání rozhodnutí může být prvním úkonem stavebního úřadu v řízení; odvolání proti rozhodnutí nemá odkladný účinek.

(3) V rozhodnutí o zakazujícím opatření může stavební úřad uložit další opatření, je-li to vzhledem k povaze a následkům činnosti, která se zakazuje, nezbytné, a stanovit lhůtu k jejich provedení.

#### § 295 — Opatření k nápravě

(1) Je-li to nezbytné k ochraně zákonem chráněného veřejného zájmu, stavební úřad může i bez provedené kontroly nařídit opatření k nápravě, které spočívá v povinnosti

a) provést udržovací práce, zejména v případě nedostatečné údržby stavby,

b) provést nezbytné úpravy stavby, zejména

1. při výskytu hygienických, bezpečnostních, požárních, provozních nebo jiných závad, včetně nesplnění požadavků na přístupnost,

2. v případě, že stavba nebo její užívání ohrožuje životní prostředí,

3. pro ochranu kulturně historických, archeologických, architektonických a urbanistických hodnot,

4. v zájmu bezpečnosti a plynulosti provozu na pozemních komunikacích,

5. za účelem vyhovění požadavkům obrany a bezpečnosti státu uplatněným Ministerstvem obrany nebo Ministerstvem vnitra,

6. pro připojení stavby na technickou infrastrukturu, nebo vybavení sociálním nebo jiným hygienickým zařízením,

7. pro zajištění účinného odvádění a zneškodňování odpadních vod v souladu s právními předpisy, k usnadnění průtoku přívalových vod, k zamezení vnikání povrchových vod do staveb a na přilehlé pozemky,

8. zakonzervování rozestavěné stavby, jejíž provádění bylo přerušeno,

c) provést nutné zabezpečovací práce, zejména v případě, že jsou záměrem ohroženy životy nebo zdraví osob nebo zvířat,

d) neodkladně odstranit záměr, zejména v případě, že jsou záměrem ohroženy životy nebo zdraví osob nebo zvířat, a záměr hrozí zřícením nebo sesuvem nebo

e) vyklidit stavbu v případě, že jsou závadami na stavbě ohroženy životy nebo zdraví osob nebo zvířat, anebo má být nařízeno opatření k nápravě podle písmene c) nebo d).

(2) Opatření k nápravě podle odstavce 1 se nařizuje vlastníku stavby nebo pozemku, na němž se záměr nachází. Opatření k nápravě podle odstavce 1 písm. e) se nařizuje též všem osobám, které stavbu užívají nebo se ve stavbě zdržují.

(3) V rozhodnutí o nařízení opatření k nápravě stavební úřad stanoví zejména rozsah, způsob a podmínky jeho provedení a lhůtu k jeho provedení.

(4) Vyžaduje-li provedení opatření k nápravě projektovou dokumentaci nebo jiné podklady, stavební úřad nařídí jejich obstarání vlastníku záměru nebo pozemku, na němž se záměr nachází, a stanoví lhůtu k jejich předložení. Nesplní-li vlastník nařízenou povinnost, obstará tyto podklady stavební úřad, který následně rozhodnutím uloží vlastníku povinnost uhradit náklady na jejich obstarání; na tuto povinnost stavební úřad vlastníka předem písemně upozorní.

(5) Při nařízení opatření k nápravě podle odstavce 1 písm. c), d) a e) může stavební úřad postupovat v řízení na místě. Vydání rozhodnutí může být prvním úkonem stavebního úřadu v řízení; odvolání proti rozhodnutí nemá odkladný účinek. V případě ústního vyhlášení rozhodnutí se písemné potvrzení uvede jako součást protokolu o kontrole. Písemné potvrzení obsahuje náležitosti rozhodnutí podle § 68 správního řádu; ustanovení § 67 odst. 3 správního řádu se nepoužije.

(6) Rozhodnutí o nařízení opatření k nápravě podle odstavce 1 písm. e) doručí stavební úřad vyklizovaným osobám, vlastníkovi stavby, vyklizující osobě a obci; v případě ústního vyhlášení rozhodnutí písemné potvrzení o vydání tohoto rozhodnutí doručí stavební úřad vyklizovaným osobám, vlastníkovi stavby, vyklizující osobě a obci bez zbytečného odkladu. Osoby, které se ve stavbě zdržují, ale nejsou stavebnímu úřadu známy, se o vydaném rozhodnutí vyrozumí informací umístěnou na místě stavby před provedením vyklizení.

(7) U nařízení opatření k nápravě podle odstavce 1 písm. a) až d) jsou nájemci bytů a nebytových prostor účastníky řízení, pokud jejich práva vyplývající z nájmu mohou být přímo dotčena plněním povinností nařízených stavebním úřadem.

#### § 296 — Provedení opatření k nápravě

(1) Hrozí-li u provedení opatření k nápravě podle § 295 odst. 1 písm. c), d) nebo e) nebezpečí z prodlení, zajistí provedení nařízeného opatření k nápravě stavební úřad prostřednictvím osoby, která je podle jiného právního předpisu oprávněna k provedení nařízených prací; při stanovení této osoby se zákon o zadávání veřejných zakázek nepoužije. Této osobě může stavební úřad provedení opatření k nápravě nařídit rozhodnutím, které může být vydáno jako první úkon stavebního úřadu v řízení.

(2) Náklady na provedení opatření k nápravě je povinen uhradit vlastník stavby nebo pozemku, na němž se záměr nachází. Nedošlo-li mezi osobou, prostřednictvím které stavební úřad zajišťuje provedení nařízeného opatření k nápravě, a vlastníkem k dohodě o zaplacení, stavební úřad uhradí náklady na provedení opatření k nápravě a rozhodnutím uloží vlastníkovi povinnost náklady uhradit stavebnímu úřadu.

#### § 297 — Opatření na sousedním pozemku nebo stavbě

(1) Je-li nezbytné pro provedení nařízeného opatření k nápravě, aby vlastník sousedního pozemku nebo stavby, nebo osoba, která má k sousednímu pozemku nebo stavbě jiné věcné právo, strpěli nezbytné omezení, a nedošlo-li mezi dotčenými osobami k dohodě, stavební úřad může z moci úřední nebo na žádost vlastníka stavby nebo pozemku, na němž se záměr nachází, uložit opatření na sousedním pozemku nebo stavbě přiměřené okolnostem.

(2) Stavební úřad v rozhodnutí o opatření na sousedním pozemku nebo stavbě stanoví

a) účel uloženého opatření,

b) jakého pozemku nebo stavby nebo jejich části se opatření týká,

c) vymezení prováděné činnosti na sousedním pozemku nebo stavbě a

d) podmínky omezení, zejména časové rozmezí provádění činnosti.

(3) Účastníkem řízení o opatření na sousedním pozemku nebo stavbě je ten, o jehož povinnosti je řízení vedeno, a ten, jehož právo má být opatřením na sousedním pozemku nebo stavbě založeno nebo jehož konání nebo opomenutí bylo důvodem pro zahájení řízení o uložení opatření k nápravě.

(4) Nerozhodne-li stavební úřad jinak, odvolání proti rozhodnutí o opatření na sousedním pozemku nebo stavbě nemá odkladný účinek.

(5) Při postupu podle uloženého opatření na sousedním pozemku nebo stavbě je každý povinen dbát, aby co nejméně rušil užívání sousedního pozemku nebo stavby a aby prováděnými pracemi nevznikla škoda, které je možno zabránit.

(6) Po skončení prací je povinen ten, jehož právo bylo opatřením na sousedním pozemku nebo stavbě založeno, uvést sousední pozemek nebo stavbu do předchozího stavu.

##### Díl 2

#### § 298 — Působnost

(1) Kontrolu výkonu působnosti

a) Dopravního a energetického stavebního úřadu ve věcech staveb dálnic, silnic, místních komunikací a veřejně přístupných účelových komunikací, staveb drah a civilních leteckých staveb a staveb souvisejících vykonává Ministerstvo dopravy,

b) Dopravního a energetického stavebního úřadu ve věcech vyhrazených staveb, u nichž vykonává působnost nadřízeného správního orgánu Ministerstvo průmyslu a obchodu, a ve věcech staveb technické infrastruktury pro energetiku a elektronické komunikace, výroben obnovitelných zdrojů energie a staveb souvisejících vykonává Ministerstvo průmyslu a obchodu,

c) krajských stavebních úřadů ve věcech staveb silnic, místních komunikací a veřejně přístupných účelových komunikací, staveb technické infrastruktury pro energetiku a elektronické komunikace a staveb obnovitelných zdrojů energie vykonává Dopravní a energetický stavební úřad,

d) krajských stavebních úřadů s výjimkou staveb uvedených v písmenu c) a obecních stavebních úřadů vykonává ministerstvo,

e) obecních stavebních úřadů vykonává krajský stavební úřad.

(2) Ministerstvo, Ministerstvo dopravy, Ministerstvo průmyslu a obchodu, Dopravní a energetický stavební úřad a krajský stavební úřad kontrolují dodržování tohoto zákona, právních předpisů vydaných k jeho provedení a rozhodnutí a opatření obecné povahy vydaných na základě tohoto zákona, jakož i dodržování usnesení vlády a směrnic ústředních správních úřadů.

#### § 299 — Nápravná opatření

Ministerstvo, Ministerstvo dopravy, Ministerstvo průmyslu a obchodu, Dopravní a energetický stavební úřad a krajský stavební úřad mohou při výkonu kontroly ukládat opatření k odstranění nebo prevenci zjištěných nedostatků v přiměřené lhůtě; do doby zjednání nápravy mohou pozastavit nebo omezit výkon činnosti, při níž dochází k porušování právní povinnosti.

#### HLAVA III

#### § 300

Při kontrole vydávání a obsahu prováděcího právního předpisu vydaného územním samosprávným celkem se ustanovení hlavy šesté části první zákona o obcích použijí obdobně s tím, že namísto krajského úřadu provede kontrolu ministerstvo.

### ČÁST DESÁTÁ

#### § 301 — Přestupky osob

(1) Přestupku se dopustí ten, kdo

a) provede záměr bez povolení, které je podle tohoto zákona vyžadováno,

b) provede záměr v rozporu s povolením podle tohoto zákona,

c) užívá záměr vyžadující povolení bez tohoto povolení,

d) v rozporu s § 230 odst. 1 užívá stavbu bez kolaudačního rozhodnutí,

e) v rozporu s § 230 odst. 3 užívá nedokončenou stavbu,

f) v rozporu s § 230 odst. 2 užívá jednoduchou stavbu bez kolaudačního rozhodnutí,

g) užívá stavbu v rozporu s kolaudačním rozhodnutím,

h) užívá jednoduchou stavbu v rozporu s povolením stavebního úřadu nebo užívá jednoduchou stavbu v rozporu s rozhodnutím o změně v užívání podle § 244,

i) užívá stavbu v rozporu s povolením předčasného užívání podle § 236,

j) provede zkušební provoz bez rozhodnutí podle § 237,

k) provede zkušební provoz v rozporu s rozhodnutím podle § 237,

l) v rozporu s § 247 odst. 1 odstraní stavbu, která podléhá povolení, bez povolení odstranění stavby,

m) v rozporu s § 247 odst. 1 odstraní stavbu, která obsahuje azbest, bez povolení odstranění stavby, nebo

n) odstraní stavbu v rozporu s povolením odstranění stavby nebo rozhodnutím o nařízení odstranění stavby.

(2) Přestupku se dopustí ten, kdo poruší zakazující opatření podle § 294 nebo neplní uložená opatření k nápravě podle § 295.

(3) Za přestupek lze uložit pokutu

a) do 400 000 Kč, jde-li o přestupek podle odstavce 1 písm. c) nebo d),

b) do 1 000 000 Kč, jde-li o přestupek podle odstavce 1 písm. f), g), h), i), j), k), l) nebo n), nebo odstavce 2,

c) do 2 000 000 Kč, jde-li o přestupek podle odstavce 1 písm. a), b), e) nebo m), nebo

d) do 4 000 000 Kč, jde-li o přestupek podle odstavce 1 písm. a) nebo b), jestliže se jedná o záměr ve zvláště chráněném území podle zákona o ochraně přírody a krajiny, v ochranném pásmu, na nezastavitelném pozemku, v nezastavěném území, o záměr EIA nebo o záměr vyžadující vydání integrovaného povolení.

#### § 302 — Přestupky vybraných osob

(1) Stavebník se dopustí přestupku tím, že

a) poruší některou z povinností podle § 160 odst. 1 a 2 nebo podle § 161 odst. 1 až 3,

b) poruší některou z povinností v souvislosti s nálezem podle § 266 odst. 1 nebo 2, nebo

c) nesplní oznamovací povinnost podle § 263 odst. 3.

(2) Zhotovitel se dopustí přestupku tím, že

a) provede nebo odstraní stavbu v rozporu § 163 odst. 2 písm. a),

b) poruší některou z povinností podle § 163 odst. 1 nebo § 163 odst. 2 písm. b) nebo c), nebo

c) v rozporu s § 163 odst. 2 písm. d) nevede stavební deník nebo jednoduchý záznam o stavbě.

(3) Vlastník stavby nebo zařízení se dopustí přestupku tím, že poruší některou z povinností podle § 167 písm. a) až k).

(4) Vlastník technické nebo dopravní infrastruktury nebo provozovatel staveb a zařízení, z jejichž provozu vznikají omezení v území podle jiného právního předpisu, se dopustí přestupku tím, že nesplní povinnost podle § 63 odst. 2 písm. b) nebo c).

(5) Vlastník technické infrastruktury se dopustí přestupku tím, že nesplní některou z povinností podle § 168 písm. a) nebo b) nebo § 181 odst. 1.

(6) Zhotovitel, stavbyvedoucí, osoba vykonávající stavební dozor, dozor projektanta, technický dozor stavebníka, stavebník, autorizovaný inspektor nebo vlastník stavby se dopustí přestupku tím, že poruší oznamovací povinnost podle § 169.

(7) Za přestupek lze uložit pokutu

a) do 400 000 Kč, jde-li o přestupek podle odstavce 1 písm. a) nebo c), nebo odstavce 2 písm. c) anebo odstavců 3 až 6,

b) do 1 000 000 Kč, jde-li o přestupek podle odstavce 2 písm. b),

c) do 2 000 000 Kč, jde-li o přestupek podle odstavce 1 písm. b) nebo odstavce 2 písm. a), nebo

d) do 4 000 000 Kč, jde-li o přestupek podle odstavce 2 písm. a), jestliže jde o záměr v chráněném území podle zvláštních právních předpisů, v ochranném pásmu, na nezastavitelném pozemku, v nezastavěném území, o záměr EIA nebo o záměr vyžadující vydání integrovaného povolení.

#### § 303 — Přestupky fyzických osob

(1) Fyzická osoba se dopustí přestupku tím, že v rozporu s § 155 provádí vybrané činnosti ve výstavbě bez oprávnění podle autorizačního zákona.

(2) Fyzická osoba se jako stavbyvedoucí dopustí přestupku tím, že poruší některou z povinností podle § 164.

(3) Fyzická osoba vykonávající stavební dozor se dopustí přestupku tím, že nevykonává řádně odborný dozor nad prováděním stavby svépomocí tím, že poruší některou z povinností podle § 165.

(4) Fyzická osoba se jako projektant územně plánovací dokumentace dopustí přestupku tím, že neodevzdá územně plánovací dokumentaci v jednotném standardu podle § 162 odst. 6.

(5) Za přestupek podle odstavců 1 až 4 lze uložit pokutu do 400 000 Kč.

#### § 304 — Společná ustanovení

(1) Přestupky podle tohoto zákona projednává úřad příslušný podle § 32 až 35; přestupky podle § 302 odst. 4 a § 303 odst. 4 projednává krajský úřad.

(2) Přestupkem podle tohoto zákona není porušení takových podmínek rozhodnutí, které stavební úřad převzal do svého rozhodnutí na základě jednotného environmentálního stanoviska.

(3) Stavbou se pro účely této části rozumí též terénní úprava.

### ČÁST JEDENÁCTÁ

#### § 305 — Postavení stavebníka a vlastníka stavby

Není-li stavebník nebo vlastník stavby v řízení o žalobě proti rozhodnutí stavebního úřadu žalobcem, je osobou zúčastněnou na řízení.

#### § 306 — Lhůta pro podání žaloby

(1) Žalobu proti rozhodnutí stavebního úřadu, s výjimkou rozhodnutí o přestupku, lze podat do 1 měsíce poté, kdy bylo rozhodnutí žalobci oznámeno.

(2) Rozšířit žalobu na dosud nenapadené výroky nebo ji rozšířit o další žalobní body může žalobce jen ve lhůtě 2 měsíců poté, kdy mu bylo rozhodnutí oznámeno.

#### § 307 — Nepřípustnost

(1) Žaloba proti rozhodnutí stavebního úřadu je nepřípustná, obsahuje-li pouze skutkové a právní důvody, které žalobce neuplatnil v řízení o odvolání, ač tak učinit mohl; to neplatí, jde-li o žalobu proti rozhodnutí, které bylo vydáno v řízení zahájeném z moci úřední, anebo kterým byla povolena stavba podléhající posouzení vlivů na životní prostředí.

(2) Návrh na zrušení opatření obecné povahy nebo jeho části je také nepřípustný, obsahuje-li pouze důvody, které navrhovatel neuplatnil v řízení o vydání opatření obecné povahy, ač tak učinit mohl; to neplatí, jde-li o opatření obecné povahy podléhající posouzení vlivů na životní prostředí.

#### § 308 — Odkladný účinek

Přizná-li soud žalobě odkladný účinek, projedná žalobu a rozhodne o ní přednostně s nejvyšším urychlením.

#### § 309 — Rozhodnutí o žalobě

(1) Nebrání-li tomu vady napadeného rozhodnutí nebo řízení, které předcházelo jeho vydání, přezkoumá soud všechny přípustné žalobní body.

(2) Je-li žaloba důvodná, bez dalšího dokazování je zcela zřejmé, jak by v případě jeho zrušení a vrácení stavebnímu úřadu k dalšímu řízení musel stavební úřad rozhodnout a navrhl-li takový postup žalobce nebo osoba zúčastněná na řízení, může soud rozsudkem napadené rozhodnutí změnit.

(3) Proti částem rozhodnutí stavebního úřadu, která byla změněna rozsudkem, není přípustné vést přezkumné řízení podle správního řádu. Obnova řízení podle správního řádu je přípustná pouze tehdy, bylo-li rozhodnutí stavebního úřadu dosaženo trestným činem.

#### § 310 — Přezkum územního rozvojového plánu

K řízení o zrušení územního rozvojového plánu nebo jeho části je příslušný Nejvyšší správní soud.

### ČÁST DVANÁCTÁ

#### HLAVA I

#### § 311 — Vztah ke správnímu řádu

(1) K přezkumu opatření obecné povahy podle správního řádu vydaného orgány obce je příslušný krajský úřad. K přezkumu opatření obecné povahy podle správního řádu vydaného orgány kraje je příslušné ministerstvo.

(2) Územně plánovací dokumentaci nelze změnit rozhodnutím podle § 97 odst. 3 správního řádu.

(3) Územní rozvojový plán nebo územní opatření vydané vládou nelze přezkoumat v přezkumném řízení podle správního řádu.

#### HLAVA II

##### Díl 1

#### § 312

(1) Na Dopravní a energetický stavební úřad přechází výkon práv a povinností ze služebního poměru a z pracovněprávních vztahů státních zaměstnanců a zaměstnanců v pracovním poměru, zařazených nebo jmenovaných na služební nebo pracovní místo v ministerstvech a jiných správních úřadech a zajišťujících podle dosavadních právních předpisů výkon úkolů a činností spadajících podle tohoto nebo jiného zákona do působnosti Dopravního a energetického stavebního úřadu. Přechodem státních zaměstnanců ve služebním poměru na dobu neurčitou podle tohoto odstavce platí, že úspěšně vykonali úřednickou zkoušku pro příslušný obor státní služby, v němž budou úkoly a činnosti vykonávat v Dopravním a energetickém stavebním úřadu.

(2) Podle odstavce 1 se však nepostupuje, pokud dotčení zaměstnanci zajišťují v ministerstvech a jiných správních úřadech v převažujícím rozsahu výkon úkolů a činností, které nespadají do působnosti Dopravního a energetického stavebního úřadu podle tohoto nebo jiného zákona.

(3) Práva a povinnosti z pracovního poměru zaměstnanců krajů zařazených k výkonu práce do krajských úřadů přecházejí z těchto krajů na stát v případech, kdy činnosti zajišťované těmito zaměstnanci přecházejí do působnosti Dopravního a energetického stavebního úřadu podle tohoto nebo jiného zákona. Obdobně se postupuje v případě zaměstnanců hlavního města Prahy.

(4) Podmínkou přechodu práv a povinností z pracovního poměru zaměstnanců podle odstavce 3 na stát je předchozí písemná dohoda mezi Dopravním a energetickým stavebním úřadem, zaměstnancem a územním samosprávným celkem.

(5) Dosavadní zaměstnanci krajů podle odstavce 3 se stávají zaměstnanci státu zařazenými k výkonu práce do Dopravního a energetického stavebního úřadu.

(6) Dosavadní zaměstnanci Magistrátu hlavního města Prahy podle odstavce 3 se stávají zaměstnanci státu zařazenými k výkonu práce do Dopravního a energetického stavebního úřadu.

(7) První systemizace služebních míst a první systemizace pracovních míst v Dopravním a energetickém stavebním úřadu se stanoví s účinností od 1. července 2023.

#### § 313

(1) Na služební místo ředitele sekce obsazené zaměstnancem podle § 312 odst. 5 a 6 vyhlásí služební orgán výběrové řízení nejpozději do 18 měsíců od účinnosti systemizace podle § 312 odst. 7. Na služební místo ředitele odboru a vedoucího oddělení obsazené zaměstnanci podle § 312 odst. 5 a 6 vyhlásí služební orgán výběrové řízení nejpozději do 24 měsíců od účinnosti systemizace podle § 312 odst. 7. K výběrovému řízení se mohou přihlásit státní zaměstnanci ve služebním poměru na dobu neurčitou, kteří vykonávají státní službu na služebním místě ve stejném oboru státní služby, který je stanoven pro služební místo představeného, které má být obsazeno. Osoba, která byla jmenována na služební místo představeného na dobu určitou, se po dobu 3 let od uplynutí této doby považuje za osobu splňující předpoklady pro účast ve výběrovém řízení na služební místo představeného na stejný nebo nižší stupeň řízení.

(2) Pro vznik služebního poměru zaměstnanců podle § 312 odst. 5 a 6 se použijí § 190 až 197, s výjimkou § 190 odst. 1 písm. d), § 191, 195a a 196 zákona o státní službě a dále § 200 a 201 zákona o státní službě obdobně s tím, že lhůty a doby tam stanovené se počítají ode dne nabytí účinnosti systemizace podle § 312 odst. 7. Ke dni vzniku služebního poměru rozhodne příslušný služební orgán o výši platu podle části deváté zákona o státní službě. Dnem vzniku služebního poměru těmto zaměstnancům platí, že úspěšně vykonali úřednickou zkoušku; služební orgán jim o tom vystaví osvědčení.

(3) Ztratí-li zaměstnanec podle odstavce 1 a § 312 odst. 5 a 6 přechodem funkci vedoucího zaměstnance, má po dobu 12 měsíců od vzniku služebního poměru nárok na výplatu zadostiučinění ve výši příplatku za vedení, která mu byla naposledy určena jako vedoucímu zaměstnanci, v pravidelných výplatních termínech. Pokud však byl dotčený zaměstnanec na základě výběrového řízení jmenován na služební místo představeného a začal opět pobírat příplatek za vedení ještě před uplynutím doby 12 měsíců od vzniku služebního poměru, vyplatí se mu zadostiučinění snížené o částku příplatku za vedení, který mu nově náleží.

(4) Kvalifikační požadavky pro výkon činnosti stavebního úřadu na úseku stavebního řádu podle § 30a splňuje úředník, který ke dni nabytí účinnosti tohoto zákona vykonává činnost obecného nebo speciálního stavebního úřadu a splňuje kvalifikační požadavky pro výkon činnosti na obecném nebo speciálním stavebním úřadu podle dosavadní právní úpravy.

#### § 314

Při provedení spisové rozluky v souvislosti s činnostmi, které přecházejí na orgány státní stavební správy podle tohoto nebo jiného zákona, se postupuje obdobně podle § 68a zákona č. 499/2004 Sb., o archivnictví a spisové službě a o změně některých zákonů, ve znění pozdějších předpisů. Nevyřízené dokumenty a neuzavřené spisy předají správní orgány, které vykonávaly působnost podle dosavadních předpisů, u vyhrazených staveb uvedených v příloze č. 3 k tomuto zákonu, staveb s nimi souvisejících a staveb tvořících s nimi soubor staveb do 1. února 2024, v ostatních případech do 1. srpna 2024. Ustanovení tohoto odstavce se nevztahuje na jiné stavební úřady.

#### § 315

(1) Příslušnost k hospodaření s majetkem státu užívaným organizačními složkami státu přechází ke dni nabytí účinnosti tohoto zákona na Dopravní a energetický stavební úřad, pokud byl tento majetek užíván výhradně k zajišťování úkolů a činností, které přecházejí podle tohoto nebo jiného zákona na Dopravní a energetický stavební úřad.

(2) Rozpočtované prostředky v rozpočtech organizačních složek, které souvisejí s výkonem působnosti, která ke dni nabytí účinnosti tohoto zákona přechází na Dopravní a energetický stavební úřad, se přesouvají ke dni nabytí účinnosti tohoto zákona na Dopravní a energetický stavební úřad.

(3) Nároky z nespotřebovaných výdajů vzniklé za roky předcházející roku nabytí účinnosti tohoto zákona, které souvisejí s výkonem působnosti, která ke dni nabytí účinnosti tohoto zákona přechází na Dopravní a energetický stavební úřad, se stávají ke dni nabytí účinnosti tohoto zákona nároky z nespotřebovaných výdajů Dopravního a energetického stavebního úřadu.

##### Díl 2

#### § 316 — Obecná ustanovení

(1) Ústav územního rozvoje zřízený podle zákona č. 183/2006 Sb. se považuje za Ústav územního rozvoje zřízený podle tohoto zákona.

(2) Bylo-li přede dnem nabytí účinnosti tohoto zákona rozhodnuto o pořízení územního plánu, regulačního plánu, nebo jejich změny nebo vymezení zastavěného území, nebo zahájeno zpracování územní studie a pořizovatelem je obecní úřad podle § 6 odst. 2 zákona č. 183/2006 Sb. na základě smluvního vztahu s osobou splňující kvalifikační požadavky pro výkon územně plánovací činnosti podle dosavadních právních předpisů, pohlíží se na tuto osobu do doby vydání této územně plánovací dokumentace nebo vymezení zastavěného území jako na zástupce pořizovatele. Jedná-li se o územní studii, považuje se za rozhodný moment vložení dat o ní do evidence územně plánovací činnosti.

(3) Výjimka z kvalifikačních požadavků vzdělání udělená podle dosavadních právních předpisů se považuje za výjimku z kvalifikačních požadavků vzdělání udělenou podle tohoto zákona.

(4) Kvalifikační požadavky pro výkon územně plánovací činnosti splňuje státní zaměstnanec nebo úředník, který vykonává ke dni nabytí účinnosti tohoto zákona územně plánovací činnost na ministerstvu, krajském úřadu, úřadu územního plánování nebo na obecním úřadu podle § 6 odst. 2 zákona č. 183/2006 Sb. a má osvědčení zvláštní odborné způsobilosti podle zvláštního právního předpisu vydané přede dnem 1. ledna 2007.

(5) Seznam oprávněných investorů, který vede příslušný krajský úřad podle § 23a zákona č. 183/2006 Sb., se považuje za seznam oprávněných investorů podle tohoto zákona. Ministerstvo ve spolupráci s příslušným krajským úřadem a Magistrátem hlavního města Prahy zajistí zveřejnění seznamu oprávněných investorů na národním geoportálu územního plánování do 6 měsíců ode dne nabytí účinnosti tohoto zákona.

#### § 317 — Územně plánovací podklady

(1) Územně analytické podklady pořízené přede dnem nabytí účinnosti tohoto zákona se považují za územně analytické podklady podle tohoto zákona.

(2) Území vymezená Ministerstvem obrany nebo Ministerstvem vnitra podle dřívějších právních předpisů v zájmu zajišťování obrany a bezpečnosti státu přede dnem nabytí účinnosti tohoto zákona se považují za vymezená území podle tohoto zákona do doby jejich nového vymezení postupem podle § 36.

(3) Údaje o urbanistických studiích, územních generelech a územních prognózách, které jsou ke dni nabytí účinnosti tohoto zákona uvedeny v evidenci územně plánovací činnosti, ministerstvo nebo jím pověřená organizační složka státu z této evidence vypustí do 3 měsíců po nabytí účinnosti tohoto zákona.

(4) Územní studie, o nichž byly údaje ke dni nabytí účinnosti tohoto zákona uvedeny v evidenci územně plánovací činnosti, se považují za územní studie podle tohoto zákona.

(5) U územních studií, o nichž byly údaje ke dni nabytí účinnosti tohoto zákona uvedeny v evidenci územně plánovací činnosti, běží lhůta pro prověření aktuálnosti jejich řešení ode dne nabytí účinnosti tohoto zákona a činí 4 roky.

(6) Činnosti při pořizování územně plánovacích podkladů ukončené přede dnem nabytí účinnosti tohoto zákona se posuzují podle dosavadních právních předpisů.

#### § 318 — Politika územního rozvoje a politika architektury a stavební kultury

(1) Politika územního rozvoje schválená přede dnem nabytí účinnosti tohoto zákona se považuje za politiku územního rozvoje podle tohoto zákona.

(2) Části politiky územního rozvoje schválené podle zákona č. 183/2006 Sb., které nemohou být podle tohoto zákona její součástí, se nepoužijí a při nejbližší změně musí být z politiky územního rozvoje vypuštěny; toto vypuštění nepodléhá posuzování vlivů na udržitelný rozvoj území. Vyhodnocení vlivů na udržitelný rozvoj území, které se vztahuje k původní politice územního rozvoje, se neupravuje.

(3) Bylo-li zahájeno pořizování zprávy o uplatňování politiky územního rozvoje přede dnem nabytí účinnosti tohoto zákona a nedošlo-li k předložení návrhu zprávy o uplatňování ke schválení vládě podle § 35 odst. 4 zákona č. 183/2006 Sb., dokončí se pořizování i předložení vládě podle dosavadních právních předpisů. Zpráva o uplatňování schválená vládou podle § 35 odst. 4 zákona č. 183/2006 Sb. se považuje za zprávu o plnění podle tohoto zákona a dále se postupuje podle tohoto zákona.

(4) Bylo-li zahájeno pořizování aktualizace politiky územního rozvoje přede dnem nabytí účinnosti tohoto zákona, a nedošlo-li k předložení návrhu ke schválení vládě podle § 34 zákona č. 183/2006 Sb., zajistí ministerstvo uvedení návrhu této aktualizace do souladu s tímto zákonem. V rozsahu provedených úprav se dále postupuje podle § 71b a 71c a § 71d odst. 1.

(5) Politika architektury a stavební kultury schválená přede dnem nabytí účinnosti tohoto zákona se považuje za politiku architektury a stavební kultury podle tohoto zákona.

#### § 319 — Územní rozvojový plán

(1) Ministerstvo pořídí první územní rozvojový plán, který bude obsahovat pouze nadregionální územní systém ekologické stability vymezený v zásadách územního rozvoje, u kterého marně uplynula lhůta pro přezkum podle správního řádu a soudního řádu správního, a záměry dopravní a technické infrastruktury vymezené v zásadách územního rozvoje a obsažené v politice územního rozvoje, které dosud nebyly dokončeny a u kterých marně uplynula lhůta pro přezkum podle správního řádu a soudního řádu správního.

(2) Vymezení záměrů podle odstavce 1 převezme ministerstvo ze zásad územního rozvoje tak, že textová část vymezení záměru bude obsahovat pouze výčet obcí dotčených tímto záměrem bez stanovení podmínek pro rozhodování v území, pořadí změn v území a kompenzační opatření podle § 100 odst. 4 tohoto zákona.

(3) Záměry přebírané do prvního územního rozvojového plánu podle odstavce 1 nepodléhají projednání a posuzování vlivů na udržitelný rozvoj území podle § 40 tohoto zákona. Soulad s politikou územního rozvoje se neposuzuje.

(4) Dotčenými orgány při pořizování územního rozvojového plánu podle tohoto přechodného ustanovení jsou pouze Ministerstvo dopravy, Ministerstvo průmyslu a obchodu a Ministerstvo zemědělství, které mohou záměry podle odstavce 1 vyloučit.

(5) Pro první územní rozvojový plán se § 73 odst. 2 a 3 tohoto zákona nepoužije do doby vydání změny, která jej uvede do souladu s požadavky podle tohoto zákona.

#### § 320 — Zásady územního rozvoje

(1) Zásady územního rozvoje vydané podle dosavadních právních předpisů se považují za zásady územního rozvoje podle tohoto zákona. Při nejbližší změně, jejíž pořizování bude zahájeno po dni nabytí účinnosti tohoto zákona, se zásady územního rozvoje uvedou do souladu s ustanoveními tohoto zákona o obsahu zásad územního rozvoje.

(2) Do doby uvedení zásad územního rozvoje do souladu s ustanoveními tohoto zákona o obsahu zásad územního rozvoje nejsou záměry na změny v území obsažené v zásadách územního rozvoje, které jsou v rozporu s územním rozvojovým plánem, závazné pro pořizování územně plánovací dokumentace obcí a pro rozhodování v území.

#### § 321 — Územní plán a regulační plán

(1) Územní plány vydané podle dosavadních právních předpisů se považují za územní plány podle tohoto zákona.

(2) Regulační plány vydané od 1. ledna 2007 do dne nabytí účinnosti tohoto zákona se považují za regulační plány vydané podle tohoto zákona.

(3) Při nejbližší změně regulačních plánů, jejíž pořizování bude zahájeno po dni nabytí účinnosti tohoto zákona, se tyto regulační plány uvedou do souladu s ustanoveními tohoto zákona o obsahu regulačního plánu.

(4) Regulační plán pořízený na žádost přede dnem nabytí účinnosti tohoto zákona se po dobu jeho platnosti, nejdéle však do 31. prosince 2025, považuje za regulační plán vydaný podle tohoto zákona. Jeho změny lze pořizovat pouze na podnět toho, komu přísluší vykonávat práva z něj vyplývající.

#### § 322 — Územně plánovací dokumentace schválené přede dnem 1. ledna 2007

(1) Územně plánovací dokumentace sídelního útvaru nebo zóny, územní plán obce a regulační plán, schválené přede dnem 1. ledna 2007, pozbývají platnosti dnem nabytí účinnosti nové územně plánovací dokumentace, která je nahrazuje, nejpozději však 31. prosince 2028. Obecně závazné vyhlášky, jimiž byla vymezena závazná část této územně plánovací dokumentace, se považují za opatření obecné povahy, které je závazné pro navazující územně plánovací dokumentaci a pro rozhodování v území. Části územně plánovací dokumentace schválené přede dnem 1. ledna 2007, které nemohou být podle tohoto zákona její součástí, se nepoužijí.

(2) Zastupitelstvo obce může opatřením obecné povahy ukončit platnost územně plánovací dokumentace sídelního útvaru nebo zóny, územního plánu obce a regulačního plánu, schválených přede dnem 1. ledna 2007. Pro vydání opatření obecné povahy podle věty první se použije § 113 odst. 2 až 6 obdobně.

(3) U územně plánovací dokumentace sídelního útvaru nebo zóny, územního plánu obce a regulačního plánu, byly-li schváleny přede dnem 1. ledna 2007, lze změnu vydat do 31. prosince 2028, jinak se pořizování zastaví.

(4) Rozhodne-li zastupitelstvo obce přede dnem nabytí účinnosti tohoto zákona o pořízení změny územně plánovací dokumentace sídelního útvaru nebo zóny, územního plánu obce a regulačního plánu, byly-li schváleny přede dnem 1. ledna 2007, a současně již bylo zastupitelstvem obce rozhodnuto o pořízení nového územního plánu nebo regulačního plánu, dokončí se pořizování této změny podle dosavadních právních předpisů. Požadavky na jednotný standard podle § 20a zákona č. 183/2006 Sb. se neuplatní.

(5) Územně plánovací dokumentaci sídelního útvaru nebo zóny, územní plán obce a regulační plán, byly-li schváleny přede dnem 1. ledna 2007, nelze upravit podle § 188 odst. 1 zákona č. 183/2006 Sb. a v rozsahu těchto úprav projednat a vydat, nebylo-li zahájeno společné jednání přede dnem nabytí účinnosti tohoto zákona; bylo-li přede dnem nabytí účinnosti tohoto zákona při pořizování úpravy podle § 188 odst. 1 zákona č. 183/2006 Sb. zahájeno společné jednání, dokončí se pořizování podle dosavadních právních předpisů. Takto upravenou dokumentaci lze vydat do 31. prosince 2025, jinak se pořizování zastaví.

#### § 323 — Pořizování územně plánovací dokumentace

(1) Činnosti při pořizování územně plánovací dokumentace ukončené přede dnem nabytí účinnosti tohoto zákona se posuzují podle dosavadních právních předpisů.

(2) Bylo-li ke dni nabytí účinnosti tohoto zákona zahájeno projednání zprávy o uplatňování zásad územního rozvoje nebo územního plánu, dokončí se její projednání a schválení podle dosavadních právních předpisů. Obsahuje-li zpráva pokyny pro zpracování nové územně plánovací dokumentace nebo její aktualizace nebo změny, považují se tyto pokyny za zadání změny podle tohoto zákona; požadavky obsažené v pokynech, které jsou v rozporu s tímto zákonem, se nepoužijí.

(3) Bylo-li ke dni nabytí účinnosti tohoto zákona zahájeno projednání zadání územního plánu, regulačního plánu nebo jejich změny, dokončí se projednání a schválení zadání podle dosavadních právních předpisů a toto zadání se považuje za zadání územního plánu, regulačního plánu, nebo za zadání změny podle tohoto zákona; požadavky, které jsou v rozporu s tímto zákonem, se nepoužijí.

(4) Zadání územně plánovací dokumentace nebo její změny, schválené přede dnem nabytí účinnosti tohoto zákona, se považuje za zadání územně plánovací dokumentace nebo její změny podle tohoto zákona; požadavky, které jsou v rozporu s tímto zákonem, se nepoužijí.

(5) Obsah změny územně plánovací dokumentace obce schválený zastupitelstvem obce současně s rozhodnutím o pořízení její změny zkráceným postupem se považuje za zadání změny podle tohoto zákona; požadavky, které jsou v rozporu s tímto zákonem, se nepoužijí.

(6) Pořizovatel zajistí úpravu návrhu územně plánovací dokumentace, u kterého nebylo zahájeno projednání ke dni nabytí účinnosti tohoto zákona, v souladu s tímto zákonem.

(7) Bylo-li přede dnem nabytí účinnosti tohoto zákona zahájeno projednávání návrhu územního rozvojového plánu, jeho aktualizace, nebo aktualizace zásad územního rozvoje, dokončí se podle dosavadních právních předpisů.

(8) Bylo-li přede dnem nabytí účinnosti tohoto zákona zahájeno společné jednání o návrhu územního plánu nebo jeho změny nebo regulačního plánu nebo jeho změny, dokončí se činnosti zakončené úpravou návrhu po společném jednání podle dosavadních právních předpisů. Při úpravě se zajistí soulad obsahu uvedené územně plánovací dokumentace s tímto zákonem. Veřejné projednání se bez nového projednávání vyhodnocení vlivů uskuteční v rozsahu vyžadovaném tímto zákonem. Dotčené orgány uplatní stanoviska k částem, které byly od společného jednání změněny.

(9) Bylo-li přede dnem nabytí účinnosti tohoto zákona zahájeno veřejné projednání nebo opakované veřejné projednání návrhu územního plánu nebo jeho změny nebo regulačního plánu nebo jeho změny, dokončí se podle dosavadních právních předpisů.

(10) Jde-li o návrh nového územního plánu a postupuje-li se podle odstavce 9, lze v tomto návrhu vymezit plochu nebo koridor, v němž je rozhodování v území podmíněno uzavřením plánovací smlouvy podle § 130. Ustanovení § 81 odst. 3 se použije obdobně. V takovém případě jde o podstatnou úpravu, pro kterou se § 53 odst. 2 zákona č. 183/2006 Sb. použije obdobně.

#### § 324 — Nepoužití některých částí územně plánovací dokumentace

Části územně plánovací dokumentace vydané podle zákona č. 183/2006 Sb., které nemohou být podle tohoto zákona její součástí, se nepoužijí a při nejbližší změně musí být z této dokumentace vypuštěny; toto vypuštění nepodléhá posuzování vlivů na udržitelný rozvoj území. Vyhodnocení vlivů, které se vztahuje k původní územně plánovací dokumentaci, se neupravuje.

#### § 325 — Zastavěné území

(1) Úřad územního plánování pořídí a vydá vymezení zastavěného území postupem podle tohoto zákona pro obec, která nemá územní plán nebo vymezené zastavěné území, do 2 let ode dne nabytí účinnosti tohoto zákona. Věta první se nepoužije v případě obcí, ve kterých před nabytím účinnosti tohoto zákona rozhodlo zastupitelstvo obce o pořízení územního plánu.

(2) Do doby vymezení zastavěného území územním plánem nebo postupem podle tohoto zákona se u obce, která nemá územní plán nebo vymezené zastavěné území, považuje za zastavěné území intravilán.

(3) Zastavěné území vymezené územním plánem se při nejbližší změně územního plánu, jejíž pořizování bude zahájeno po dni nabytí účinnosti tohoto zákona, upraví v souladu s tímto zákonem; do nabytí účinnosti této změny se zastavěné území vymezené v územním plánu považuje za zastavěné území vymezené podle tohoto zákona.

(4) Zastavěné území vymezené na území obce, která nemá územní plán, úřad územního plánování vyhodnotí a v případě potřeby pořídí a vydá jeho změnu podle § 121 nejpozději do 2 let ode dne nabytí účinnosti tohoto zákona. Do té doby se zastavěné území vymezené podle dosavadních právních předpisů považuje za zastavěné území podle tohoto zákona.

(5) Dojde-li k pozbytí účinnosti územně plánovací dokumentace sídelního útvaru nebo zóny, územního plánu obce nebo regulačního plánu marným uplynutím lhůty podle § 322 odst. 1, považuje se současně zastavěné území obce nebo zastavěné území obce vymezené touto územně plánovací dokumentaci sídelního útvaru nebo zóny, územním plánu obce nebo regulačním plánu za zastavěné území obce vymezené podle tohoto zákona. Úřad územního plánování ve lhůtě 3 měsíců vyhodnotí aktuálnost vymezení zastavěného území a případně zajistí jeho aktualizaci postupem podle tohoto zákona.

#### § 326 — Územní opatření

(1) Stavební uzávěry vydané podle zákona č. 50/1976 Sb. z důvodu zamezení možnosti ztížení nebo znemožnění budoucího využití území podle připravované územně plánovací dokumentace pozbývají platnosti dnem nabytí účinnosti tohoto ustanovení.

(2) Stavební uzávěry vydané přede dnem nabytí účinnosti tohoto zákona, nejde-li o stavební uzávěry podle odstavce 1, prověří příslušný úřad územního plánování z hlediska jejich aktuálnosti a souladu s požadavky tohoto zákona nejpozději do 1 roku ode dne nabytí jeho účinnosti a informaci o prověření vloží do národního geoportálu územního plánování, jinak pozbývají platnosti; nejsou-li splněny požadavky na aktuálnost a soulad s tímto zákonem a neuplynula-li lhůta 1 roku, postupuje se podle § 123 odst. 4. Ustanovení § 123 odst. 3 se na stavební uzávěry vydané přede dnem nabytí účinnosti tohoto zákona použije obdobně.

(3) Obsahují-li územní opatření o stavební uzávěře omezení, která nejsou v souladu s požadavky tohoto zákona, ode dne nabytí účinnosti tohoto zákona se k těmto omezením při rozhodování nepřihlíží.

(4) Výjimku z omezení nebo zákazu stavební činnosti podle § 99 odst. 3 zákona č. 183/2006 Sb. povoluje po dni nabytí účinnosti tohoto zákona rada obce, a v obcích, kde se rada nevolí, zastupitelstvo obce, nebo rada kraje postupem podle § 129.

(5) Bylo-li přede dnem nabytí účinnosti tohoto zákona zahájeno pořizování územního opatření o stavební uzávěře nebo územního opatření o asanaci území, dokončí se podle dosavadních právních předpisů. Ustanovení § 123 odst. 3 se použije obdobně.

#### § 327 — Úprava vztahů k území

(1) Plánovací smlouvy uzavřené podle zákona č. 183/2006 Sb. se posuzují podle dosavadních právních předpisů.

(2) Předkupní právo vymezené v územně plánovací dokumentaci podle dosavadních právních předpisů zaniká účinností změny územního plánu, kterou bylo jeho vymezení vypuštěno nebo nahrazeno vymezením veřejně prospěšné stavby nebo veřejně prospěšného opatření, pro které lze práva k pozemkům vyvlastnit, nejpozději však uplynutím 4 let ode dne nabytí účinnosti tohoto zákona. Po zániku předkupního práva zajistí osoba oprávněná z předkupního práva jeho výmaz z katastru nemovitostí. Listinou, na jejímž základě má být právo z katastru nemovitostí vymazáno, je potvrzení o zániku práva podle katastrální vyhlášky.

(3) Dohody o parcelaci uzavřené podle dosavadních právních předpisů zůstávají v platnosti a lze je měnit nebo zrušit jen se souhlasem všech, kterým přísluší vykonávat práva a povinnosti z dohody vyplývající.

#### § 328 — Řízení o návrhu na zrušení opatření obecné povahy nebo jeho části

Řízení o návrhu na zrušení opatření obecné povahy nebo jeho části zahájená přede dnem nabytí účinnosti tohoto zákona se dokončí podle dosavadních právních předpisů.

##### Díl 3

#### § 329

(1) Jako součást žádosti o povolení stavby nebo o rámcové povolení podané do 30. června 2027 lze namísto projektové dokumentace zpracované podle tohoto zákona předložit i dokumentaci zpracovanou podle dosavadních právních předpisů, jde-li o

a) projektovou dokumentaci nebo dokumentaci pro ohlášení stavby,

b) dokumentaci pro vydání rozhodnutí o umístění stavby, doplněnou o architektonicko-stavební řešení a stavebně konstrukční řešení zpracované podle prováděcího právního předpisu k tomuto zákonu,

c) dokumentaci pro vydání rozhodnutí o umístění souboru staveb v areálu jaderného zařízení,

d) projektovou dokumentaci pro vydání stavebního povolení nebo dokumentaci pro vydání společného povolení, nebo

e) dokumentaci pro vydání společného povolení, kterým se umisťuje a povoluje stavba dopravní infrastruktury podle liniového zákona, zpracovanou v omezeném rozsahu.

(2) Jako součást žádosti o povolení změny využití území podané do 30. června 2027 lze namísto projektové dokumentace zpracované podle tohoto zákona také předložit dokumentaci pro vydání rozhodnutí o změně využití území zpracovanou podle dosavadních právních předpisů.

(3) Bude-li provádění stavby zahájeno do 30. června 2027, lze jako dokumentaci pro provádění stavby podle tohoto zákona použít dokumentaci pro provádění stavby zpracovanou podle dosavadních právních předpisů.

(4) Jako součást žádosti o povolení odstranění stavby podané do 30. června 2027 lze namísto projektové dokumentace zpracované podle tohoto zákona předložit také dokumentaci bouracích prací zpracovanou podle dosavadních právních předpisů.

(5) Stavební úřad v řízení podle tohoto zákona přezkoumává dokumentaci podle odstavců 1 až 4 podle dosavadních právních předpisů.

##### Díl 4

#### § 330

(1) Řízení a postupy zahájené přede dnem nabytí účinnosti tohoto zákona se dokončí podle dosavadních právních předpisů.

(2) Řízení a postupy zahájené přede dnem nabytí účinnosti tohoto zákona, které se týkají záměrů, u nichž není vyžadováno povolení záměru, jiné rozhodnutí nebo úkon podle tohoto zákona, stavební úřad usnesením zastaví; proti tomuto usnesení se nelze odvolat.

(3) Řízení a postupy zahájené přede dnem nabytí účinnosti tohoto zákona dokončí stavební úřad, který se stal příslušným k vedení řízení nebo provedení postupu v dané věci podle tohoto zákona. Územní řízení zahájené přede dnem nabytí účinnosti tohoto zákona týkající se vyhrazené stavby uvedené v příloze č. 3 k tomuto zákonu nebo stavby s ní související dokončí stavební úřad, který toto řízení vedl přede dnem nabytí účinnosti tohoto zákona. Stavební řízení zahájené přede dnem nabytí účinnosti tohoto zákona týkající se stavby související s vyhrazenou stavbou uvedenou v příloze č. 3 k tomuto zákonu dokončí stavební úřad, který toto řízení vedl přede dnem nabytí účinnosti tohoto zákona. Společné územní a stavební řízení zahájené přede dnem nabytí účinnosti tohoto zákona týkající se stavby související s vyhrazenou stavbou uvedenou v příloze č. 3 k tomuto zákonu dokončí stavební úřad, který se stal podle tohoto zákona příslušným k vedení řízení o povolení vyhrazené stavby uvedené v příloze č. 3 k tomuto zákonu, je-li vyhrazená stavba stavbou hlavní, v ostatních případech dokončí řízení stavební úřad, který toto řízení vedl přede dnem nabytí účinnosti tohoto zákona.

(4) Změnu záměru před dokončením povolí a kolaudační řízení provede u záměrů povolených přede dnem nabytí účinnosti tohoto zákona stavební úřad, na který přešla působnost k povolení záměru podle tohoto zákona. Jde-li o stavbu související s vyhrazenou stavbou uvedenou v příloze č. 3 k tomuto zákonu, změnu záměru před dokončením povolí a kolaudační řízení provede stavební úřad, který tuto stavbu povolil.

(5) U řízení zahájených podle tohoto zákona do konce kalendářního roku, ve kterém tento zákon nabyl účinnosti, se lhůty pro vydání rozhodnutí podle tohoto zákona prodlužují na dvojnásobek.

(6) Pravomocné územní rozhodnutí o umístění stavby vydané v územním řízení, v územním řízení s posouzením vlivů na životní prostředí anebo ve zjednodušeném územním řízení, účinný územní souhlas, účinná veřejnoprávní smlouva a vydaný regulační plán nahrazující územní rozhodnutí o umístění stavby se považují za rozhodnutí v části věci v řízení o povolení záměru podle tohoto zákona, pokud jimi byl umístěn záměr vyžadující povolení podle tohoto zákona. Pravomocné územní rozhodnutí o umístění stavby vydané v územním řízení anebo ve zjednodušeném územním řízení a účinný územní souhlas a účinná veřejnoprávní smlouva nahrazující územní rozhodnutí o umístění stavby se považují za povolení podle tohoto zákona, pokud tyto záměry nevyžadovaly podle dosavadních právních předpisů stavební povolení nebo ohlášení.

(7) Účinný společný územní souhlas, souhlas s provedením ohlášeného stavebního záměru, pravomocné stavební povolení, společné povolení, společné povolení s posouzením vlivů na životní prostředí, oznámení s certifikátem stavebního inspektora stavebního záměru a účinná veřejnoprávní smlouva nahrazující stavební povolení a účinná veřejnoprávní smlouva nahrazující stavební územní rozhodnutí a stavební povolení se považují za povolení záměru podle tohoto zákona.

(8) Pravomocné územní rozhodnutí o změně využití území se považuje za rozhodnutí v části věci v řízení o povolení záměru podle tohoto zákona, pokud jím byl umístěn záměr vyžadující povolení podle tohoto zákona; v opačném případě se považuje za povolení podle tohoto zákona. Územní rozhodnutí o dělení nebo scelování pozemků nebo územní rozhodnutí o ochranném pásmu se považují za rozhodnutí o povolení nestavebního záměru podle tohoto zákona.

(9) Závazná stanoviska, stanoviska, souhlasy, popřípadě rozhodnutí dotčených orgánů, stanoviska vlastníků veřejné dopravní nebo technické infrastruktury a jiná vyjádření vydaná přede dnem nabytí účinnosti tohoto zákona se považují za podklady pro vydání rozhodnutí v řízeních podle tohoto zákona. Tyto podklady stavební úřad nepřezkoumává a jimi chráněné veřejné zájmy znovu neposuzuje. V řízeních o opravných prostředcích, jakož i při dalších postupech souvisejících s přezkumem správnosti a zákonnosti nebo změnou závazného stanoviska orgánu územního plánování podle § 96b zákona č. 183/2006 Sb. se postupuje podle dosavadních právních předpisů.

(10) Kolaudační souhlas se považuje za kolaudační rozhodnutí podle tohoto zákona.

(11) Osoba, která vykonávala činnost autorizovaného inspektora ke dni 31. prosince 2023, je oprávněna vykonávat činnost podle tohoto zákona do doby, která končí uplynutím 10 let ode dne jmenování ministrem pro místní rozvoj, nebo do doby prodloužené.

#### § 331 — Soudní řízení

Soudní řízení zahájená přede dnem nabytí účinnosti tohoto zákona se dokončí podle dosavadních právních předpisů.

##### Díl 5

#### § 332

(1) Obecní úřady, které nebudou vykonávat působnost obecního stavebního úřadu podle tohoto zákona, jsou povinny předat nejpozději do 30 dnů od ukončení činnosti stavebního úřadu veškeré doklady týkající se neukončených správních řízení a jiných postupů vedených podle zákona č. 183/2006 Sb., o územním plánování a stavebním řádu, ve znění pozdějších předpisů, stavebním úřadům, na která přešla působnost podle tohoto zákona, a o předání sepsat protokol.

(2) Při provedení spisové rozluky v souvislosti s ukončením činnosti stavebního úřadu se postupuje obdobně podle § 68a zákona č. 499/2004 Sb., o archivnictví a spisové službě a o změně některých zákonů, ve znění pozdějších předpisů.

##### Díl 6

#### § 332a

Do doby vydání prováděcích právních předpisů podle § 152 tohoto zákona, nejpozději však do 1. července 2027, se postupuje podle prováděcích právních předpisů k provedení § 194 zákona č. 183/2006 Sb., ve znění účinném ke dni předcházejícímu jejich zrušení tímto zákonem. Části prováděcích právních předpisů podle věty první, které jsou v rozporu s tímto zákonem, se nepoužijí.

#### HLAVA III

#### § 333

(1) Ministerstvo vydá vyhlášky k provedení § 18 odst. 4, § 30 odst. 3 a 4, § 59 odst. 4, § 62 odst. 3, § 64 odst. 1, § 66 odst. 3, § 87 odst. 4, § 109 odst. 4, § 152 odst. 1, § 154 odst. 2, § 158 odst. 5, § 161 odst. 4, § 166 odst. 4, § 167 písm. e), f), j) a k), § 169 odst. 2, § 172 odst. 2, § 227 odst. 5, § 267 odst. 5, § 268 odst. 3, § 269 odst. 7, § 270 odst. 3, § 271 odst. 4, § 273 odst. 3, § 278, § 285 odst. 4 a § 292 odst. 5.

(2) Ministerstvo dopravy vydá vyhlášku k provedení § 17 odst. 3, § 152 odst. 1 a § 158 odst. 5, kterou stanoví technické požadavky na stavby dálnic, silnic, místních komunikací a veřejně přístupných účelových komunikací, stavby drah a civilní letecké stavby a rozsah a obsah projektové dokumentace k těmto stavbám.

(3) Hlavní město Praha, statutární město Brno a statutární město Ostrava mohou v přenesené působnosti vydat nařízení k provedení § 152 odst. 2.

#### HLAVA IV

#### § 334

Zrušují se:

1. Zákon č. 183/2006 Sb., o územním plánování a stavebním řádu (stavební zákon).

2. Zákon č. 68/2007 Sb., kterým se mění zákon č. 183/2006 Sb., o územním plánování a stavebním řádu (stavební zákon).

3. Zákon č. 191/2008 Sb., kterým se mění zákon č. 183/2006 Sb., o územním plánování a stavebním řádu (stavební zákon), ve znění zákona č. 68/2007 Sb.

4. Část třicátá čtvrtá zákona č. 223/2009 Sb., kterým se mění některé zákony v souvislosti s přijetím zákona o volném pohybu služeb.

5. Zákon č. 345/2009 Sb., kterým se mění zákon č. 72/1994 Sb., kterým se upravují některé spoluvlastnické vztahy k budovám a některé vlastnické vztahy k bytům a nebytovým prostorům a doplňují některé zákony (zákon o vlastnictví bytů), ve znění pozdějších předpisů, a zákon č. 183/2006 Sb., o územním plánování a stavebním řádu (stavební zákon), ve znění pozdějších předpisů.

6. Zákon č. 379/2009 Sb., kterým se mění zákon č. 183/2006 Sb., o územním plánování a stavebním řádu (stavební zákon), ve znění pozdějších předpisů.

7. Část sto osmdesátá zákona č. 227/2009 Sb., kterým se mění některé zákony v souvislosti s přijetím zákona o základních registrech.

8. Část sedmnáctá zákona č. 424/2010 Sb., kterým se mění zákon č. 111/2009 Sb., o základních registrech, ve znění zákona č. 100/2010 Sb., a další související zákony.

9. Část sto sedmdesátá druhá zákona č. 281/2009 Sb., kterým se mění některé zákony v souvislosti s přijetím daňového řádu.

10. Část čtyřicátá první zákona č. 420/2011 Sb., o změně některých zákonů v souvislosti s přijetím zákona o trestní odpovědnosti právnických osob a řízení proti nim.

11. Část dvacátá sedmá zákona č. 142/2012 Sb., o změně některých zákonů v souvislosti se zavedením základních registrů.

12. Část třicátá druhá zákona č. 167/2012 Sb., kterým se mění zákon č. 499/2004 Sb., o archivnictví a spisové službě a o změně některých zákonů, ve znění pozdějších předpisů, zákon č. 227/2000 Sb., o elektronickém podpisu a o změně některých dalších zákonů (zákon o elektronickém podpisu), ve znění pozdějších předpisů, a další související zákony.

13. Část první zákona č. 350/2012 Sb., kterým se mění zákon č. 183/2006 Sb., o územním plánování a stavebním řádu (stavební zákon), ve znění pozdějších předpisů, a některé související zákony.

14. Část šestá zákona č. 257/2013 Sb., kterým se mění některé zákony v souvislosti s přijetím zákona o katastru nemovitostí.

15. Část čtvrtá zákona č. 39/2015 Sb., kterým se mění zákon č. 100/2001 Sb., o posuzování vlivů na životní prostředí a o změně některých souvisejících zákonů (zákon o posuzování vlivů na životní prostředí), ve znění pozdějších předpisů, a další související zákony.

16. Část čtvrtá zákona č. 91/2016 Sb., kterým se mění zákon č. 22/1997 Sb., o technických požadavcích na výrobky a o změně a doplnění některých zákonů, ve znění pozdějších předpisů, a některé další zákony.

17. Část čtyřicátá devátá zákona č. 298/2016 Sb., kterým se mění některé zákony v souvislosti s přijetím zákona o službách vytvářejících důvěru pro elektronické transakce, zákon č. 106/1999 Sb., o svobodném přístupu k informacím, ve znění pozdějších předpisů, a zákon č. 121/2000 Sb., o právu autorském, o právech souvisejících s právem autorským a o změně některých zákonů (autorský zákon), ve znění pozdějších předpisů.

18. Část desátá zákona č. 264/2016 Sb., kterým se mění některé zákony v souvislosti s přijetím atomového zákona.

19. Část sto sedmdesátá pátá zákona č. 183/2017 Sb., kterým se mění některé zákony v souvislosti s přijetím zákona o odpovědnosti za přestupky a řízení o nich a zákona o některých přestupcích.

20. Část čtvrtá zákona č. 194/2017 Sb., o opatřeních ke snížení nákladů na zavádění vysokorychlostních sítí elektronických komunikací a o změně některých souvisejících zákonů.

21. Část devátá zákona č. 205/2017 Sb., kterým se mění zákon č. 181/2014 Sb., o kybernetické bezpečnosti a o změně souvisejících zákonů (zákon o kybernetické bezpečnosti), ve znění zákona č. 104/2017 Sb., a některé další zákony.

22. Část devátá zákona č. 193/2017 Sb., kterým se mění zákon č. 256/2001 Sb., o pohřebnictví a o změně některých zákonů, ve znění pozdějších předpisů, a další související zákony.

23. Část první zákona č. 225/2017 Sb., kterým se mění zákon č. 183/2006 Sb., o územním plánování a stavebním řádu (stavební zákon), ve znění pozdějších předpisů, a další související zákony.

24. Část pátá zákona č. 169/2018 Sb., kterým se mění zákon č. 416/2009 Sb., o urychlení výstavby dopravní, vodní a energetické infrastruktury a infrastruktury elektronických komunikací, ve znění pozdějších předpisů, a další související zákony.

25. Část padesátá čtvrtá zákona č. 277/2019 Sb., kterým se mění některé zákony v souvislosti s přijetím zákona o Sbírce zákonů a mezinárodních smluv.

26. Část první zákona č. 312/2019 Sb., kterým se mění zákon č. 183/2006 Sb., o územním plánování a stavebním řádu (stavební zákon), ve znění pozdějších předpisů, a zákon č. 254/2001 Sb., o vodách a o změně některých zákonů (vodní zákon), ve znění pozdějších předpisů.

27. Část druhá zákona č. 47/2020 Sb., kterým se mění zákon č. 200/1994 Sb., o zeměměřictví a o změně a doplnění některých zákonů souvisejících s jeho zavedením, ve znění pozdějších předpisů, zákon č. 183/2006 Sb., o územním plánování a stavebním řádu (stavební zákon), ve znění pozdějších předpisů, a další související zákony.

28. Část dvacátá první zákona č. 403/2020 Sb., kterým se mění zákon č. 416/2009 Sb., o urychlení výstavby dopravní, vodní a energetické infrastruktury a infrastruktury elektronických komunikací, ve znění pozdějších předpisů, a další související zákony.

29. Část sto dvacátá šestá zákona č. 261/2021 Sb., kterým se mění některé zákony v souvislosti s další elektronizací postupů orgánů veřejné moci.

30. Část druhá zákona č. 19/2023 Sb., kterým se mění zákon č. 458/2000 Sb., o podmínkách podnikání a o výkonu státní správy v energetických odvětvích a o změně některých zákonů (energetický zákon), ve znění pozdějších předpisů, a další související zákony.

31. Vyhláška č. 590/2002 Sb., o technických požadavcích pro vodní díla.

32. Vyhláška č. 367/2005 Sb., kterou se mění vyhláška č. 590/2002 Sb., o technických požadavcích pro vodní díla.

33. Vyhláška č. 498/2006 Sb., o autorizovaných inspektorech.

34. Vyhláška č. 499/2006 Sb., o dokumentaci staveb.

35. Vyhláška č. 62/2013 Sb., kterou se mění vyhláška č. 499/2006 Sb., o dokumentaci staveb.

36. Část první vyhlášky č. 405/2017 Sb., kterou se mění vyhláška č. 499/2006 Sb., o dokumentaci staveb, ve znění vyhlášky č. 62/2013 Sb., a vyhláška č. 169/2016 Sb., o stanovení rozsahu dokumentace veřejné zakázky na stavební práce a soupisu stavebních prací, dodávek a služeb s výkazem výměr.

37. Vyhláška č. 500/2006 Sb., o územně analytických podkladech, územně plánovací dokumentaci a o způsobu evidence územně plánovací činnosti.

38. Vyhláška č. 458/2012 Sb., kterou se mění vyhláška č. 500/2006 Sb., o územně analytických podkladech, územně plánovací dokumentaci a způsobu evidence územně plánovací činnosti.

39. Vyhláška č. 13/2018 Sb., kterou se mění vyhláška č. 500/2006 Sb., o územně analytických podkladech, územně plánovací dokumentaci a způsobu evidence územně plánovací činnosti, ve znění vyhlášky č. 458/2012 Sb.

40. Vyhláška č. 501/2006 Sb., o obecných požadavcích na využívání území.

41. Vyhláška č. 269/2009 Sb., kterou se mění vyhláška č. 501/2006 Sb., o obecných požadavcích na využívání území.

42. Vyhláška č. 22/2010 Sb., kterou se mění vyhláška č. 501/2006 Sb., o obecných požadavcích na využívání území, ve znění vyhlášky č. 269/2009 Sb.

43. Vyhláška č. 20/2011 Sb., kterou se mění vyhláška č. 501/2006 Sb., o obecných požadavcích na využívání území, ve znění pozdějších předpisů.

44. Vyhláška č. 431/2012 Sb., kterou se mění vyhláška č. 501/2006 Sb., o obecných požadavcích na využívání území, ve znění pozdějších předpisů.

45. Vyhláška č. 360/2021 Sb., kterou se mění vyhláška č. 501/2006 Sb., o obecných požadavcích na využívání území, ve znění pozdějších předpisů.

46. Vyhláška č. 164/2022 Sb., kterou se mění vyhláška č. 360/2021 Sb., kterou se mění vyhláška č. 501/2006 Sb., o obecných požadavcích na využívání území, ve znění pozdějších předpisů.

47. Vyhláška č. 503/2006 Sb., o podrobnější úpravě územního rozhodování, územního opatření a stavebního řádu.

48. Vyhláška č. 63/2013 Sb., kterou se mění vyhláška č. 503/2006 Sb., o podrobnější úpravě územního řízení, veřejnoprávní smlouvy a územního opatření.

49. Vyhláška č. 66/2018 Sb., kterou se mění vyhláška č. 503/2006 Sb., o podrobnější úpravě územního rozhodování, územního opatření a stavebního řádu, ve znění vyhlášky č. 63/2013 Sb.

50. Vyhláška č. 146/2008 Sb., o rozsahu a obsahu projektové dokumentace dopravních staveb.

51. Vyhláška č. 251/2018 Sb., kterou se mění vyhláška č. 146/2008 Sb., o rozsahu a obsahu projektové dokumentace dopravních staveb.

52. Vyhláška č. 268/2009 Sb., o technických požadavcích na stavby.

53. Vyhláška č. 20/2012 Sb., kterou se mění vyhláška č. 268/2009 Sb., o technických požadavcích na stavby.

54. Vyhláška č. 323/2017 Sb., kterou se mění vyhláška č. 268/2009 Sb., o technických požadavcích na stavby, ve znění vyhlášky č. 20/2012 Sb.

55. Vyhláška č. 398/2009 Sb., o obecných technických požadavcích zabezpečujících bezbariérové užívání staveb.

56. Vyhláška č. 239/2017 Sb., o technických požadavcích pro stavby pro plnění funkcí lesa.

57. Vyhláška č. 418/2022 Sb., kterou se mění vyhláška č. 500/2006 Sb., o územně analytických podkladech, územně plánovací dokumentaci a způsobu evidence územně plánovací činnosti, ve znění pozdějších předpisů, vyhláška č. 501/2006 Sb., o obecných požadavcích na využívání území, ve znění pozdějších předpisů, a vyhláška č. 360/2021 Sb., kterou se mění vyhláška č. 501/2006 Sb., o obecných požadavcích na využívání území, ve znění pozdějších předpisů, ve znění vyhlášky č. 164/2022 Sb.

58. Nařízení hlavního města Prahy č. 10/2016 Sb. hl. m. Prahy, kterým se stanovují obecné požadavky na využívání území a technické požadavky na stavby v hlavním městě Praze (pražské stavební předpisy).

59. Nařízení hlavního města Prahy č. 14/2018 Sb. hl. m. Prahy, kterým se mění nařízení hlavního města Prahy č. 10/2016 Sb. hl. m. Prahy, kterým se stanovují obecné požadavky na využívání území a technické požadavky na stavby v hlavním městě Praze (pražské stavební předpisy).

#### HLAVA V

#### § 334a

(1) Přechodným obdobím se rozumí pro účely odstavců 2 a 3 období od 1. ledna 2024 do 30. června 2024 a pro účely odstavce 4 období od 1. července 2022 do 30. června 2023.

(2) Ve věcech týkajících se územního plánování se v přechodném období postupuje podle dosavadních právních předpisů, s výjimkou územního řízení týkajícího se vyhrazené stavby uvedené v příloze č. 3 k tomuto zákonu nebo stavby s ní související, které v přechodném období nelze zahájit. Pro účely přechodných ustanovení v části dvanácté hlavě II dílu 2 se za den nabytí účinnosti tohoto zákona považuje 1. červenec 2024.

(3) Ve věcech týkajících se záměrů podle tohoto zákona se v přechodném období postupuje podle dosavadních právních předpisů s výjimkou věcí týkajících se vyhrazených staveb uvedených v příloze č. 3 k tomuto zákonu, staveb s nimi souvisejících a staveb tvořících s nimi soubor staveb. Pro účely přechodných ustanovení v části dvanácté hlavě II dílu 4 se za den nabytí účinnosti tohoto zákona považuje 1. červenec 2024. Ve věcech týkajících se vyhrazených staveb uvedených v příloze č. 3 k tomuto zákonu, staveb s nimi souvisejících a staveb tvořících s nimi soubor staveb se postupuje podle tohoto zákona s výjimkou § 172, 173, § 185 odst. 3 písm. c) a části sedmé.

(4) V přechodném období vykonává působnost Nejvyššího stavebního úřadu jako služebního úřadu Ministerstvo pro místní rozvoj a působnost stanovenou předsedovi Nejvyššího stavebního úřadu jako služebnímu orgánu státní tajemník v Ministerstvu pro místní rozvoj.

#### § 334b — Použití informačních systémů stavební správy v přechodném období

(1) Přechodným obdobím se pro účely odstavce 2 rozumí období do 31. prosince 2027 a pro účely odstavců 3 a 5 až 9 období do 30. června 2027.

(2) V přechodném období se ve věcech stavebního řádu § 173, § 180 odst. 2, § 181 odst. 2 a 3, § 267 odst. 5, § 272 odst. 3 až 5 a § 273 odst. 2 nepoužijí.

(3) V přechodném období se ve věcech územního plánování § 22 písm. c), § 23 odst. 2 písm. f), § 25 písm. f), § 105 odst. 2, § 108 odst. 3, § 113 odst. 6, § 128 odst. 2 věta druhá, § 130 odst. 3, § 267 odst. 5, § 269 odst. 4 a 5 a § 303 odst. 4 nepoužijí.

(4) K výkonu působnosti orgánů územního plánování, stavebních úřadů a dotčených orgánů lze v přechodném období použít vedle informačních systémů stavební správy i jiné informační systémy. Orgán územního plánování, stavební úřad a dotčený orgán zajistí, aby na žádost ministerstva mohla být data z jiného informačního systému, která vznikla při výkonu jejich působnosti v přechodném období, předána ministerstvu za účelem jejich přenosu do informačních systémů stavební správy.

(5) Seznamy podle § 42 odst. 4 a § 50 odst. 2 zveřejňuje ministerstvo v přechodném období způsobem umožňujícím dálkový přístup namísto jejich zveřejnění v národním geoportálu územního plánování.

(6) Stanoví-li tento zákon, že ministerstvo nebo pořizovatel vkládá dokument do národního geoportálu územního plánování nebo zveřejňuje dokument v národním geoportálu územního plánování, je tato povinnost v přechodném období splněna, pokud je ministerstvo nebo pořizovatel zveřejní způsobem umožňujícím dálkový přístup s uvedením data jeho uveřejnění. Adresu zveřejnění zašle pořizovatel nadřízenému orgánu. V přechodném období nelze povinnost podle § 64 odst. 1 splnit vložením údajů o území do národního geoportálu územního plánování. Lhůta podle § 69 odst. 1 počíná běžet ode dne zveřejnění územní studie způsobem umožňujícím dálkový přístup.

(7) Stanoví-li tento zákon, že ministerstvo nebo pořizovatel odkazuje na dokument vložený do národního geoportálu územního plánování, lze v přechodném období odkázat na dokument zveřejněný postupem podle odstavce 6.

(8) Územně analytické podklady, územní studie, územně plánovací dokumentace, její úplné znění, vymezení zastavěného území, změna vymezení zastavěného území, úplné znění vymezení zastavěného území po jeho změně, územní opatření a informace o prověření stavební uzávěry podle § 326 se v přechodném období namísto jejich vložení do národního geoportálu územního plánování zveřejňují způsobem umožňujícím dálkový přístup. Pořizovatel vloží dokumenty podle věty první do národního geoportálu územního plánování do 31. prosince 2026.

(9) Ministerstvo zajišťuje v přechodném období evidenci územně plánovací činnosti. Předmětem evidence územně plánovací činnosti jsou metadata o územně plánovací dokumentaci, zastavěném území, územním opatření a územní studii včetně průběhu jejich pořizování. Data do evidence vkládá příslušný pořizovatel. Součástí metadat je i údaj o adrese zveřejnění dokumentů podle odstavce 8 způsobem umožňujícím dálkový přístup.

(10) Řízení a jiné postupy s výjimkou postupů podle části třetí zahájené od 1. července 2024 do konce přechodného období se dokončí podle odstavců 2 až 8.

### ČÁST TŘINÁCTÁ

#### § 335

Tento zákon nabývá účinnosti dnem 1. ledna 2024, s výjimkou ustanovení

a) § 36, 319, § 322 odst. 1 a 3, § 324 a § 326 odst. 1, která nabývají účinnosti dnem následujícím po dni jeho vyhlášení,

b) § 15 až 18, § 312 odst. 1 a 7, § 313 odst. 1 a 2 a § 315 odst. 1, která nabývají účinnosti dnem 1. ledna 2022,

c) § 312 odst. 4, které nabývá účinnosti dnem 1. ledna 2023.

### Vondráček v. r.

### Zeman v. r.

### Babiš v. r.

#### Příloha č. 1 k zákonu č. 283/2021 Sb.

### Drobné stavby

#### Příloha č. 2 k zákonu č. 283/2021 Sb.

### Jednoduché stavby

#### Příloha č. 3 k zákonu č. 283/2021 Sb.

### Vyhrazené stavby

#### Příloha č. 4 k zákonu č. 283/2021 Sb.

#### Příloha č. 5 k zákonu č. 283/2021 Sb.

### Obsah a struktura politiky územního rozvoje

#### Příloha č. 6 k zákonu č. 283/2021 Sb.

### Obsah a struktura územního rozvojového plánu

#### Příloha č. 7 k zákonu č. 283/2021 Sb.

### Obsah a struktura zásad územního rozvoje

#### Příloha č. 8 k zákonu č. 283/2021 Sb.

### Obsah a struktura územního plánu

#### Příloha č. 9 k zákonu č. 283/2021 Sb.

### Obsah a struktura regulačního plánu

**Poznámky pod čarou:**

1) § 34 zákona č. 128/2000 Sb., o obcích (obecní zřízení), ve znění pozdějších předpisů. § 14b zákona č. 131/2000 Sb., o hlavním městě Praze, ve znění pozdějších předpisů.
2) § 3 odst. 1 písm. a) zákona č. 114/1992 Sb., o ochraně přírody a krajiny, ve znění pozdějších předpisů.
3) Čl. 15 a 16 směrnice Evropského parlamentu a Rady (EU) 2018/2001 ze dne 11. prosince 2018 o podpoře využívání energie z obnovitelných zdrojů, v platném znění.
5) § 29 zákona č. 222/1999 Sb., o zajišťování obrany České republiky, ve znění pozdějších předpisů.
6) § 2 odst. 4 zákona č. 312/2002 Sb., o úřednících územních samosprávných celků a o změně některých zákonů, ve znění pozdějších předpisů.
7) Zákon č. 312/2002 Sb., o úřednících územních samosprávných celků a o změně některých zákonů, ve znění pozdějších předpisů.
8) § 34 odst. 1 zákona č. 312/2002 Sb.
9) Zákon č. 262/2006 Sb., zákoník práce, ve znění pozdějších předpisů.
10) § 3 odst. 7 zákona č. 106/1999 Sb., o svobodném přístupu k informacím, ve znění pozdějších předpisů.
11) § 2 písm. e) zákona č. 123/1998 Sb., o právu na informace o životním prostředí, ve znění pozdějších předpisů.
14) § 4b až 4d zákona č. 200/1994 Sb., o zeměměřictví a o změně a doplnění některých zákonů souvisejících s jeho zavedením, ve znění pozdějších předpisů.
15) Například zákon č. 61/1988 Sb., o hornické činnosti, výbušninách a o státní báňské správě, ve znění pozdějších předpisů.
16) § 4b odst. 7 a 8 zákona č. 200/1994 Sb.
17) Zákon č. 111/2009 Sb., o základních registrech, ve znění pozdějších předpisů.
18) Evropská úmluva o krajině, vyhlášená pod č. 12/2017 Sb. m. s.
19) § 17 písm. d) a § 18 písm. a) a b) zákona č. 360/1992 Sb., o výkonu povolání autorizovaných architektů a o výkonu povolání autorizovaných inženýrů a techniků činných ve výstavbě.
20) § 3 písm. f) zákona č. 100/2001 Sb., o posuzování vlivů na životní prostředí a o změně některých souvisejících zákonů (zákon o posuzování vlivů na životní prostředí), ve znění pozdějších předpisů.
21) § 10i zákona č. 100/2001 Sb.
22) Zákon č. 100/2001 Sb., ve znění pozdějších předpisů.
23) Zákon č. 13/1997 Sb., o pozemních komunikacích, ve znění pozdějších předpisů.
24) Zákon č. 541/2020 Sb., o odpadech, ve znění zákona č. 261/2021 Sb. Zákon č. 254/2001 Sb., o vodách a o změně některých zákonů (vodní zákon), ve znění pozdějších předpisů.
25) Zákon č. 12/1997 Sb., o bezpečnosti a plynulosti provozu na pozemních komunikacích, ve znění pozdějších předpisů.
26) Zákon č. 133/1985 Sb., o požární ochraně, ve znění pozdějších předpisů. Vyhláška č. 23/2008 Sb., o technických podmínkách požární ochrany staveb, ve znění vyhlášky č. 268/2011 Sb.
27) Zákon č. 258/2000 Sb., o ochraně veřejného zdraví a o změně některých souvisejících zákonů, ve znění pozdějších předpisů. Nařízení vlády č. 272/2011 Sb., o ochraně zdraví před nepříznivými účinky hluku a vibrací, ve znění pozdějších předpisů.
28) Například zákon č. 114/1992 Sb., zákon č. 334/1992 Sb., o ochraně zemědělského půdního fondu, ve znění pozdějších předpisů, zákon č. 201/2012 Sb., o ochraně ovzduší, ve znění pozdějších předpisů.
29) Zákon č. 406/2000 Sb., o hospodaření energií, ve znění pozdějších předpisů. Vyhláška č. 264/2020 Sb., o energetické náročnosti budov.
30) Zákon č. 541/2020 Sb. Vyhláška č. 273/2021 Sb., o podrobnostech nakládání s odpady.
31) § 3 odst. 2 písm. e) zákona č. 263/2016 Sb., atomový zákon, ve znění pozdějších předpisů.
32) Zákon č. 128/2000 Sb.
33) Příloha I nařízení Evropského parlamentu a Rady (EU) č. 305/2011 ze dne 9. března 2011, kterým se stanoví harmonizované podmínky pro uvádění stavebních výrobků na trh a kterým se zrušuje směrnice Rady 89/106/EHS, v platném znění.
34) Zákon č. 22/1997 Sb., o technických požadavcích na výrobky a o změně a doplnění některých zákonů, ve znění pozdějších předpisů, Nařízení vlády č. 163/2002 Sb., kterým se stanoví technické požadavky na vybrané stavební výrobky, ve znění pozdějších předpisů.
35) Zákon č. 360/1992 Sb., o výkonu povolání autorizovaných architektů a o výkonu povolání autorizovaných inženýrů a techniků činných ve výstavbě, ve znění pozdějších předpisů. Zákon č. 200/1994 Sb., o zeměměřictví a o změně a doplnění některých zákonů souvisejících s jeho zavedením, ve znění pozdějších předpisů.
36) Zákon č. 200/1994 Sb., o zeměměřictví a o změně a doplnění některých zákonů souvisejících s jeho zavedením, ve znění pozdějších předpisů.
37) Zákon č. 406/2000 Sb.
38) Například zákon č. 200/1994 Sb., zákon č. 44/1988 Sb., o ochraně a využití nerostného bohatství (horní zákon).
39) Například zákon č. 360/1992 Sb., zákon č. 200/1994 Sb.
40) Zákon č. 309/2006 Sb., kterým se upravují další požadavky bezpečnosti a ochrany zdraví při práci v pracovněprávních vztazích a o zajištění bezpečnosti a ochrany zdraví při činnosti nebo poskytování služeb mimo pracovněprávní vztahy (zákon o zajištění dalších podmínek bezpečnosti a ochrany zdraví při práci), ve znění pozdějších předpisů.
41) § 1194 zákona č. 89/2012 Sb., občanský zákoník, ve znění pozdějších předpisů.
42) § 7 zákona č. 100/2001 Sb. § 45h až 45i zákona č. 114/1992 Sb.
43) Směrnice Evropského parlamentu a Rady 2011/92/EU ze dne 13. prosince 2011 o posuzování vlivů některých veřejných a soukromých záměrů na životní prostředí. Směrnice Evropského parlamentu a Rady 2014/52/EU ze dne 16. dubna 2014, kterou se mění směrnice Rady 2011/92/EU o posuzování vlivů některých veřejných a soukromých záměrů na životní prostředí.
48) Zákon č. 256/2013 Sb., o katastru nemovitostí (katastrální zákon), ve znění pozdějších předpisů.
49) Vyhláška č. 357/2013 Sb., o katastru nemovitostí (katastrální vyhláška), ve znění pozdějších předpisů.
50) § 4b zákona č. 200/1994 Sb.
51) § 3 odst. 1 písm. a) bod 1 zákona č. 151/1997 Sb., o oceňování majetku a o změně některých zákonů (zákon o oceňování majetku), ve znění pozdějších předpisů.
52) § 2 zákona č. 458/2000 Sb., o podmínkách podnikání a o výkonu státní správy v energetických odvětvích a o změně některých zákonů (energetický zákon), ve znění pozdějších předpisů.
54) § 31 zákona č. 128/2000 Sb.
55) Zákon č. 365/2000 Sb., o informačních systémech veřejné správy a o změně některých dalších zákonů, ve znění pozdějších předpisů.
56) Zákon č. 12/2020 Sb., o právu na digitální služby a o změně některých zákonů.
57) § 4d zákona č. 200/1994 Sb.
58) § 21 až 26 zákona č. 312/2002 Sb.
59) § 2 zákona č. 449/2001 Sb., o myslivosti, ve znění pozdějších předpisů.
60) Zákon č. 458/2000 Sb., o podmínkách podnikání a o výkonu státní správy v energetických odvětvích a o změně některých zákonů, ve znění pozdějších předpisů.
61) § 10 zákona č. 13/1997 Sb.
62) § 2 zákona č. 311/2006 Sb., o pohonných hmotách a čerpacích stanicích pohonných hmot a o změně některých souvisejících zákonů (zákon o pohonných hmotách), ve znění pozdějších předpisů.
63) § 1 odst. 6 zákona č. 416/2009 Sb., o urychlení výstavby dopravní, vodní a energetické infrastruktury a infrastruktury elektronických komunikací (liniový zákon).
64) Vyhláška č. 104/1997 Sb., kterou se provádí zákon o pozemních komunikacích, ve znění pozdějších předpisů.
65) Zákon č. 189/1999 Sb., o nouzových zásobách ropy, o řešení stavů ropné nouze a o změně některých souvisejících zákonů (zákon o nouzových zásobách ropy), ve znění pozdějších předpisů.
66) Vyhláška č. 142/2018 Sb., o náležitostech posouzení vlivu záměru a koncepce na evropsky významné lokality a ptačí oblasti a o náležitostech hodnocení vlivu závažného zásahu na zájmy ochrany přírody a krajiny.
67) § 6a zákona č. 406/2000 Sb., o hospodaření energií, ve znění pozdějších předpisů.
67) Vyhláška č. 38/2022 Sb., o kontrole provozovaného systému vytápění a kombinovaného systému vytápění a větrání.
