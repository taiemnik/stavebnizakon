# Stenozáznam — 2. čtení, 20. schůze, část 2 (2026-05-28)

- **Komora:** Poslanecká sněmovna
- **Datum jednání:** 2026-05-28
- **Originál:** https://www.psp.cz/eknih/2025ps/stenprot/020schuz/bqbs/b19100301.htm
- **Staženo:** 2026-10-21
- **Pozn.:** Text převzatý ze stenozáznamu části projednávání bodu na psp.cz; při citaci ověř v originálu.

---

(pokračuje Tomio Okamura)

3. Návrh poslanců Andreje Babiše, Karla Havlíčka, Tomia Okamury, Petra Macinky, Aleny Schillerové, Zuzany Schwarz Bařtipánové, Radima Fialy, Borise Šťastného, Vojtěcha Krňanského a Marie Pošarové na vydání zákona, kterým se mění zákon č. 283/2021 Sb., stavební zákon, ve znění pozdějších předpisů, a některé další související zákony /sněmovní tisk 67/ – druhé čtení

Projednávání tohoto bodu jsme přerušili dne 27. května 2026 na 20. schůzi v obecné rozpravě. Připomínám, že návrh jsme v prvém čtení přikázali k projednání hospodářskému výboru jako výboru garančnímu. Dále byl tisk přikázán výboru pro veřejnou správu a regionální rozvoj a ústavně-právnímu výboru. Usnesení výboru byla doručena jako sněmovní tisky 67/2 až 11.

Prosím, aby místa u stolku zpravodajů zaujaly za navrhovatele poslankyně Zuzana Mrázová a zpravodajka garančního výboru a ústavně-právního výboru poslankyně Zuzana Ožanová. Dále připomínám, že zpravodajkou výboru pro veřejnou správu a regionální rozvoj je poslankyně Veronika Kovářová. Zpravodajky Sněmovnu s usneseními již seznámili.

Než budeme pokračovat v přerušené obecné rozpravě je nutné se vypořádat s hlasováními, která z důvodu neusnášeníschopnosti Poslanecké sněmovny 27. května nemohla proběhnout. Prvním návrhem byl procedurální návrh předsedy poslaneckého klubu ODS Marka Bendy, který navrhl přerušení bodu do středy 3. června 2026 do začátku odpoledního jednání. A za druhé byla vznesena panem poslancem Janem Bartoškem námitka proti postupu předsedajícího. Nyní se ptám pana předsedy Bendy z ODS a pana poslance Bartoška, zda na svých návrzích trvají.

Ani pan Benda není přítomen v sále, ani pan Bartošek z KDU-ČSL není přítomen v sále. Nicméně ale rozhodnout o ní musíme, takže bychom o tom hlasovali.

Takže jako první budeme hlasovat procedurální návrh na přerušení a poté bychom se měli vypořádat s hlasováním s námitkou proti postupu předsedajícího. Já vás odhlásím, přihlaste se znovu svými hlasovacími kartami. (Ťukání karet do lavic.)

Zajímavé je, že se mi na faktickou poznámku přihlásil pan poslanec Marek Benda teďka na monitoru, přitom... no a čí kartou tedy hlasuje? Marek Benda, mám tady na monitoru, že se přihlásil na faktickou poznámku. Snad někdo nemá jeho kartu? To nejde se přihlásit, aby se mi objevilo. To je divný. Jo. To se přihlásil před tím, že není přítomen. No dobrý. Teď to tady naskočilo. Takže dobrý.

Takže pojďme hlasovat o přerušení bodu do středy 3. června.

Zahajuji hlasování. Kdo je pro? Já radši už se ptám, jo? Tak kdo je proti?

Hlasování číslo 127 , přihlášeno 109, pro 34, proti 76. Návrh byl zamítnut.

Protože víte jak to je, když někdo hlasuje cizí kartou, jsou pak velký problémy. Tak nic, dobrý. Jdeme dál. Tak za druhé. Máme vznesenou tady poslancem Janem Bartoškou námitku proti postupu předsedajícího. Jenom na mikrofon říkám, že jsem to nebyl já jo, při tom řízení. Jo, to byl někdo jiný, ale já vím kdo, ale nebudu to říkat. (Pobavení a smích v sále.) Ne tak.

Takže já zahajuji hlasování. Kdo je pro? Kdo je proti?

Hlasování číslo 128 , přihlášeno 109 poslanců, pro 34, proti 74. Návrh byl zamítnut.

Takže nyní tedy budeme pokračovat v přerušené obecné rozpravě. Mám tady dvě přednostní práva. První je tady předseda STANu Vít Rakušan, ten ovšem není přítomen, přestože je přihlášen, dobře. A nyní tedy je tady s přednostním právem Michaela Šebelová a pak je připraven pan poslanec David Pražák. Tak prosím, máte slovo. Ještě někdo se hlásí? (Z pléna se ozývá, že poslanec Pražák již včera vystupoval.) No, mně to tady naskočilo, takže pana poslance Pražáka odhlásím, dobře .Takže je připravena paní poslankyně Lucie Smejkalová následně.

Prosím, paní předsedkyně, máte slovo. A prosím o klid v jednacím sále, tak prosím o klid v jednacím sále. Tak prosím o klid.

**Poslankyně Michaela Šebelová:** Děkuju vám za slovo, pane předsedo. Vážená paní ministryně, vážený pane ministře, kolegyně, kolegové, jinak pane předsedo, asi už jste unavený, ale paní kolegyně Smejkalová, nejmladší poslankyně naše se jmenuje Julie. Myslím, že jsme tady už nějakou dobu a bylo by fajn, jste řekl Lucie.

**Předseda PSP Tomio Okamura:** Julie se jmenuje, ne?

**Poslankyně Michaela Šebelová:** Julie Smejkalová. Tak já jenom...

**Předseda PSP Tomio Okamura:** A já jsem říkal Julie, ne, Smejkalová? Ano.

**Poslankyně Michaela Šebelová:** Já jsem slyšela Lucie.

**Předseda PSP Tomio Okamura:** Ne, já jsem četl Julie. Paní předsedkyně, prosím vás, jako... tak prosím, máte slovo ke stavebnímu zákonu, jo?

**Poslankyně Michaela Šebelová:** Ano, mám. Ano, mám, a jsem ráda, že je tady plná Sněmovna, protože mám pocit, že tady vznikl nějaký takový dojem a snažíte se jako koalice nás přesvědčit o tom, že my nedržíme jako opozice nějaké dohody. Já už jsem to tady říkala odpoledne to tady nikdo nebyl. V úterý jste si naplánovali, že chcete projednávat dva senátní tisky a jednací řád. Co jsme v úterý projednali? Dva senátní tisky a jednací řád. Ano, vy nejste asi spokojeni s tou rychlostí, jakou se to schválilo, ale schválilo se to, schválilo se v ten jednací den všechno, co jste si vy, jako koalice naplánovali, že se projedná.

**Předseda PSP Tomio Okamura:** Paní předsedkyně, promiňte, že vám do toho skáču. Velmi lehce naznačuji, že jsme v obecné rozpravě a že poslanec má mluvit podle § 59 (nesrozumitelné) k věci.

**Poslankyně Michaela Šebelová:** A já budu mluvit k jednacímu řádu a budu mluvit samozřejmě ke stavebnímu zákonu. (Předsedající: Ano, ale už jsme v obecné rozpravě, jo, tak...) Samozřejmě. Ale ono to souvisí taky s tím, jakým způsobem tady s námi jednáte. Tak já jsem to chtěla připomenout a nyní se samozřejmě dostanu k tomu paskvilu, který tady předložila paní ministryně. Jakých zákonů se tisk 67 týká?

Část první. Zákon č. 28/2021 Sb., stavební zákon.

Část druhá. Ne, nebudu číst telefonní seznam, pane ministře, to tady dělali vaši předchůdci. To se tady postavil třeba pan předseda Babiš a řekl, Alenka mě poslala obstruovat a obstruoval. Já tady hovořím k zákonu, který má 1 000 stran, 1 073 stran, komplexní pozměňovací zákon a ten se prostě týká 41 zákonů, tak je úplně v pořádku. (V sále je hluk.) A já, pane předsedo, se ale neslyšíme, je tady hluk v sále.

**Předseda PSP Tomio Okamura:** Tak je tady neklid. (Pobavení a smích v sále.) Prosím vás tedy o klid, ať se paní poslankyně může vyjádřit.

**Poslankyně Michaela Šebelová:** A ať se paní poslankyně slyší. Ať vás potom nepravdivě neobviňuju, že pletete jména, protože to neslyším z toho hluku.

**Předseda PSP Tomio Okamura:** Jasně. Tak prosím vás...

**Poslankyně Michaela Šebelová:** Takže za to se vám omlouvám, ale je to proto, že je tady prostě hluk v sále.

**Předseda PSP Tomio Okamura:** Tak ať se posuneme, prosím, takže prosím o klid. (Poslankyně Šebelová: No, já bych ráda.) Ano, prosím o klid. Prosím.

**Poslankyně Michaela Šebelová:** Část druhá. Zákon č. 2/1969 o zřízení ministerstev a jiných ústředních orgánů státní správy.

Část třetí – zákon číslo 133 z roku 1985, o požární ochraně. Část čtvrtá – zákon o státní památkové péči. Část pátá – zákon o ochraně využití nerostného bohatství, takzvaný horní zákon. Část šestá – zákon o hornické činnosti, výbušninách, o státní báňské správě. Část sedmá – o geologických pracích. Část osmá – zákon o ochraně přírody a krajiny. To je věc, která pro vás vůbec není důležitá. Vůbec se jí nevěnujete. Část devátá – zákon o ochraně zemědělského půdního fondu. Část desátá – zákon o dani z nemovitých věcí. Část jedenáctá – zákon o výkonu povolání autorizovaných architektů a o výkonu povolání autorizovaných inženýrů a techniků činných ve výstavbě, takzvaný autorizační zákon. Část dvanáctá – zákon o drahách. Část třináctá – zákon o vnitrozemské plavbě. Část čtrnáctá – zákon o lesích, takzvaný lesní zákon. Část patnáctá – zákon o pozemních komunikacích. Část šestnáctá – to je moje oblíbené číslo – zákon o civilním letectví. Část sedmnáctá – zákon o veterinární péči, takzvaný veterinární zákon. Část osmnáctá – zákon o majetku České republiky a jejím vystupování v právních vztazích. Část devatenáctá – zákon o integrovaném záchranném systému. Část dvacátá – zákon o ochraně veřejného zdraví.

Nechtějte, abych tady začala mluvit o zákoně o ochraně veřejného zdraví, protože to tady můžu být fakt dlouho. Tam je věcí, ke kterým bych se mohla vyjadřovat. Fakt hodně. Otvíráte i tento zákon. Poslanec, který mluví k tomuto zákonu, prostě mluví k věci.

Část dvacátá první – energetický zákon. K tomu by mohl jistě mluvit dlouze Lukáš Vlček. Ten tady mluvil včera a jistě zase někdy vystoupí. Část dvacátá druhá – o posuzování vlivu na životní prostředí. Část dvacátá třetí – o vodách, vodní zákon. Část dvacátá čtvrtá – o pohřebnictví. Chtělo by se mi říct, že jste tady pohřbili parlamentní kulturu, ale nechám si pitomou poznámku. Část dvacátá pátá – (Silný hluk v sále. Poslanci hlasitě diskutují.) Já už se zase neslyším. To, že na mě tady pokřikují kolegové Motoristé, nechám bez komentáře. Já to vydržím.

**Předseda PSP Tomio Okamura:** Prosím vás...

**Poslankyně Michaela Šebelová:** Poslouchejte. Vy jste rozhodl dneska svým usnesením, že končí zvyklost, že propadají přihlášky, ale myslím, že na tom, aby bylo ticho v jednacím sále, byste, pane předsedo, trvat mohl.

**Předseda PSP Tomio Okamura:** No jasně. Vždyť tady...

**Poslankyně Michaela Šebelová:** Je to taky jenom zvyklost, protože úplně klidně by to mohlo vypadat tak, že tady po sobě budeme křičet.

**Předseda PSP Tomio Okamura:** Jasně, paní předsedkyně, dělám, co můžu.

**Poslankyně Michaela Šebelová:** Neděláte.

**Předseda PSP Tomio Okamura:** Dělám, co můžu, ale víte, jak to je. Už je pozdní hodina.

**Poslankyně Michaela Šebelová:** Ne, pane předsedo, nesnažíte se. Nikoho jste nenapomenul a zdržujete mě od mého projevu. Já bych chtěla mluvit, ale nemůžu. (Potlesk z pravé strany sálu.)

**Předseda PSP Tomio Okamura:** Paní předsedkyně, já bych vás znovu chtěl důrazně požádat, abyste mluvila k věci! Podle jednacího řádu, když vás vyzvu dvakrát, tak potom vám můžu odejmout slovo. Takže mluvte k věci.

**Poslankyně Michaela Šebelová:** Já mluvím k věci, protože vám tady vypichuji zákony, kterých se to týká. Paní ministryně Mrázová spolu s dalšími kolegy... Předkládají tady poslanci novelu, která je z gesce Ministerstva pro místní rozvoj – měla by být, ale je to poslanecká novela – a ta se týká tady těch zákonů. Vy mi nemůžete odebrat právo vyjmenovávat, které zákony to jsou, protože se to tohoto týká.

**Předseda PSP Tomio Okamura:** Paní předsedkyně, diskuse se mnou není k věci. Takže mluvte k věci. Já se s vámi o tom nebudu bavit, jo? Takže, teď jsem vás upozornil v souladu s jednacím řádem a mluvte k věci. Vyzývám vás tímto ve vší slušnosti.

**Poslankyně Michaela Šebelová:** Ale já rozporuji, že mě nemáte k čemu vyzývat, neboť hovořím k věci.

**Předseda PSP Tomio Okamura:** Prosím vás, mluvte k věci. Slušně vás vyzývám.

**Poslankyně Michaela Šebelová:** Dvacátá šestá část – zákon o pozemkových úpravách a pozemkových úřadech. Dvacátá sedmá – soudní řád správní. Dvacátá osmá – zákon o dani z přidané hodnoty. Dvacátá devátá část – zákon o vyvlastnění. Další zákon, třicátá část – zákon o zajištění dalších podmínek bezpečnosti a ochrany zdraví při práci. To taky nechtějte, abych o tom mluvila dlouze, protože to bych tady byla ještě déle. Část třicátá první – trestní zákoník. Třicátá druhá – zákon o urychlení výstavby strategicky významné infrastruktury. Třicátá třetí – zákon o ochraně ovzduší. Třicátá čtvrtá – zákon o státním pozemkovém úřadu. Třicátá pátá – zákon o státní službě, který likvidujete jiným zákonem. Třicátá šestá – zákon o prevenci závažných havárií.

Také měníte třicátou sedmou částí zákon o zadávání veřejných zakázek. Třicátou osmou částí atomový zákon. Třicátou devátou částí zákon o odpadech. Čtyřicátou částí zákon o zvláštních postupech v oblasti územního plánování a Stavebního úřadu v souvislosti s konfliktem na Ukrajině. Čtyřicátá první část – zrušení zákona číslo 148/2023, o jednotném environmentálním stanovisku. Čtyřicátá druhá, poslední – zákon o urychlení využívání některých obnovitelných zdrojů energie.

To bych chtěla vědět, kdo z vás ví přesně, co v těch zákonech je. Jestli víte, co v tom návrhu, který jste předložili, je. Jestli byste to uměli vlastními slovy vysvětlit vašim voličům, lidem v regionech, co jim ta novela přinese. Jak konkrétně se jim zlepší život v jejich obcích a městech. Jestli byste jim to uměli popsat. Jestli byste uměli s čistým svědomím jim říct, v čem je to lepší a jestli to, co proklamujete do médií, je opravdu pravda. Jestli to náhodou není tak, že ve finále se za rok zhroutí stavební řízení, nebude fungovat. Objeví se stavby někde, kde lidé nechtějí a nebudou se k tomu moci najednou vyjádřit. Bude to rozhodnuto. Zjistí, že jim za barákem vyroste třeba větrná elektrárna, proti které vy teď bojujete a snažíte se omezovat věci. Ale co se všechno může stát právě s tím vašim stavebním zákonem, nevím, jestli vašim voličům říkáte pravdu.

Ale hlavně – co je horší, všechny tyhle zákony měníte bez odborné debaty, měníte bez standardního legislativního procesu, bez standardního připomínkového řízení. (Poslanec F. Turek: To není pravda.) Tady na mě pan zmocněnec, nevím pro co, pokřikuje, že není pravda, že nebyla odborná debata. No, nebyla, protože potom by na těch kulatých stolech, které organizoval náš první místopředseda Starostů a nezávislých Lukáš Vlček, nám ti stakeholdeři neříkali, že s nimi odbornou debatu nevedete, že se k tomu nemohli vyjádřit. No, protože kdybyste ji vedli, tak by neměli k tomu důvod.

Vy ukazujete, že nedáte na názor odborníků v celé řadě jiných věcí. Nebudu tady samozřejmě mluvit o tom, že rušíte funkční protidrogovou prevenci, protože to by mě pan předseda nařknul, že nemluvím k věci.

Nejhorší na tom je, že nemáme kontinuitu. Nemáme tady stabilní a předvídatelné prostředí. My jsme se v minulém období shodli na určitém bypassu stavebního řízení. Je to zákon, na kterém jsme se tady shodli napříč. Vyjednával se a hlasovala pro něj i tehdejší opozice, současná vládní koalice. Aniž bychom jej vyhodnotili v praxi, aniž bychom ověřili, jak v praxi funguje, nechali jsme to sednout, aniž bychom vyhodnotili přijatou změnu legislativy, tak naprosto nepřipraveně, chaoticky a rychle přicházíte s poslaneckým návrhem zákona.

Tady je na místě kritizovat ten proces. Ne proto, že vy sami jste v minulosti kritizovali, když naše koalice přišla u zdaleka méně závažných věcí s poslaneckými návrhy. Dneska zrovna o tom vyšel článek, že ano, dělo se to i v minulých obdobích, ale ne v takové míře a v takové síle jako to předvádí současná vláda Andreje Babiše. U takto zásadních věcí je to chyba. Je to chyba, která se nám vymstí.

Proč tedy nejdříve nevyhodnotíte stávající stavební zákon? Proč nevedete odbornou debatu a nezměníte parametry tak, aby se ty procesy zjednodušily a stavělo se rychleji? Proč? Takto se to dělalo v minulosti. Vy jste nám tady vyčítali, když jste u něčeho třeba měli pocit, že nevedeme odbornou debatu, ale tu odbornou debatu jsme vedli ve spoustě věcí. Myslím si, že zrovna Lukáš Vlček jako ministr průmyslu a obchodu toho byl příkladem, že vyjednával i s tehdejší opozicí. Tady u takto zásadní věci máte pocit, že se nemusíte bavit.

Dobře, když se nechcete bavit s námi jako s opozicí, to bych ještě i politicky uměla pochopit, byť to považuji za chybu. Protože jestli něco potřebujeme a zejména ve stavebním řízení, tak je to kontinuita, předvídatelnost, ale vy přinášíte pouze chaos.

Rezignovali jste prostě na základní kvalitativní postupy při tvorbě legislativy. No a podle toho ten paskvil, který jste předložili, ve kterém nevíte, co tam je – jsem zvědavá, jakým způsobem bude probíhat potom to hlasování, protože my tady máme nějakou původní novelu, pak máme komplexní pozměňovací návrh. Všichni kolegové musí pozměňovací návrhy načítat k tomu komplexnímu pozměňovací návrhu. Pamatuju si v minulém období, kdy spousta návrhů třeba pak byla nehlasovatelných, byl to neuvěřitelný zmatek. Tak jenom tady připomínka pro kolegy, kteří připravují pozměňovací návrhy a budou se k nim potom přihlašovat, aby je měli připraveny k tomu komplexnímu pozměňovacímu návrhu, k tomu, který má 1 073 stran, aby o něm mohlo být hlasováno. První návrh zákona měl 850 stran a asi jste si vyhodnotili, že není dobrý, tak jste ho opravili návrhem, který má 1 073 stran.

Já si myslím, že musíte vědět, že mnohem lepší by bylo, když to tak zásadně měníte, že přece by bylo určitě lepší, kdybyste to poslali do mezirezortního připomínkového řízení, kdybyste odbornou debatu vedli, ale vy to nemůžete přiznat. A já myslím, že je velké umění a velká schopnost člověka přiznat chybu. Když něco prostě neudělám dobře, tak je dobré to přiznat – ale ne, vy musíte to... tlačíte to, já si to pamatuju, v minulém období vždycky tady paní předsedkyně tehdy poslaneckého klubu Alena Schillerová stála a říkala: vy nás válcujete – tak vy to teď taky potřebujete válcovat, potřebujete to tlačit, potřebujete prostě ukázat sílu. A vy tady na mě pokřikovali jste před chvílí, že tady odborná debata... byla... ona možná nebyla nulová nebo možná byla... nebyla třeba čistě povrchní? Nebyla jenom taková jako formální? Byla opravdu taková, že chcete poslouchat? Probíhalo to tak jako dneska, když tento týden si premiér Andrej Babiš pozval odborníky, kteří kritizovali přesun protidrogové agendy z Úřadu vlády, a oni odešli z toho jednání, protože odmítli poslouchat frontální přednášku? Tak pokud tímto způsobem probíhala ta debata a vy si představujete, že takto debata probíhá, no tak... myslím si, že to ukazuje na tom, jak moc selháváte komunikačně, jaký je váš přístup – arogantní, jak je nekompetentní. Probíhala celá řada veřejných fór, na která zástupci předkladatelů prostě nepřišli, nepřišli obhájit svůj návrh, protože se za něj stydí, bojí se chodit mezi lidi, obávají se negativní zpětné vazby. Včera vás o tom tady zevrubně seznámil Lukáš Vlček, protože má tu zkušenost, byl u toho.

Ale je tady další rozměr nového stavebního zákona a postoj k institucionálnímu nastavení stavební správy. Osvědčil se přenesený, dvoukolejný model státní správy. Ano, není ideální, máme moc stavebních úřadů a je nutná jich redukce z mnoha důvodů. Ale současný návrh stavebního zákona zásadně vstupuje do tohoto modelu a vyčleňuje výrazný, významný rozsah agend mimo tento model. Stát musí být adekvátně reprezentován v území, není možná centralizace v prostředí České republiky, která má velmi fragmentovanou sídelní strukturu. A je potřeba zachovávat princip subsidiarity. Prostě není možné všechno rozhodovat z centra Prahy. Já jsem z Moravskoslezského kraje, myslím, že v tom původním návrhu historicky – a přiznám se, že nevím, jestli je to tak teď, že plánujete, že ten centrální úřad bude v Ostravě, abychom tam přesunuli úřady. Já bych třeba navrhovala, abychom jednání Poslanecké sněmovny měli pravidelně v Ostravě. Těším se na vaši účast, těším se na to, jak budete muset zažívat to, co my, že pojedete za námi do Ostravy čtyři hodiny. Já si pamatuju, jak jednou tady na Poslanecké sněmovně byly principy dobré praxe, příklady ze zahraničí – a jeden z příkladů byla Ostrava. Tak doufám, že nás neberete, Moravskoslezský kraj, jako dálku. A myslím si, že není dobře, když tento proces bude takhle zásadně centralizovaný. Ale v tom zákoně je řada nevyřešených technických věcí, bez kterých to stavební řízení prostě nemůže fungovat. Nemáte vyřešené lidi, v území se proslýchá, že 67 procent těch zaměstnanců nechce přejít na nové úřady. Jak to vyřešíte? Víte to? No, povíme si za dva roky, protože vy si samozřejmě jednou návrh toho zákona protlačíte, protože my víme, že je vás víc. My umíme počítat, my se vás tady pouze snažíme přesvědčit našimi vystoupeními, že to prostě není dobrý nápad, že to neděláte dobře, že se to vymstí jednou nám všem.

A říkáte, že jste tedy jednali – tak proč existuje společné memorandum ČKAIT a ČKA? Proč? Oni to nevidí tak, že jste s nimi komunikovali. K té připravované novele stavebního zákona se kriticky vyjádřily dvě klíčové profesní organizace. Proč se, když je to tedy tak super, jak vy říkáte, tak proč se kriticky vyjadřuje Česká komora autorizovaných inženýrů a techniků činných ve výstavbě – to je to ČKAIT, jak jsem řekla, ČKAIT? Proč se k tomu kriticky vyjadřuje Česká komora architektů? Proč ve společném memorandu upozorňují na celou řadu problémů? Oni jsou odborníci, oni moc dobře ví, proč nesouhlasí s tím zvoleným postupem, moc dobře ví, že je zásadní chybou, že je ta novela předložena formou poslaneckého návrhu, tedy mimo standardně legislativní proces, který já bych opravdu u takto zásadní legislativy, která mění tolik zákonů, které jsem tady z dobrého důvodu zcela záměrně a zcela v souladu s jednacím řádem, kdy jsem hovořila k věci, vypsala, abych Vám připomněla, co všechno měníte. A těmto profesním komorám nebylo umožněno návrh zákona připomínkovat před projednáním v Poslanecké sněmovně. To je prostě pravda, to je neoddiskutovatelný fakt, to nepopřete, nevylžete se z toho, prostě ta debata, ta diskuse neprobíhala.

Vyberu jenom několik připomínek, které se týkají širší veřejnosti, a to je třeba: ekonomická přiměřenost na úrovni stavebních požadavků. Komory zpochybňují, že má být ekonomická přiměřenost postavena na stejnou úroveň jako požadavky na výstavbu. Není jasné, zda má tato úleva pomáhat lidem a uživatelům staveb, nebo jenom usnadňovat povolování developerských projektů – a nic proti developerům, potřebujeme je, ale musí to být vyváženo se zájmy občanů.

Co bych chtěla vyzdvihnout, tak je omezení bezbariérovosti. Komory kritizují použití pojmu osoby se zdravotním postižením, které vede k omezení požadavků na přístupnost staveb pouze pro osoby s omezenou schopností pohybu nebo orientace. To je myslím něco, co je naprosto zásadní a nad čím byste se měli zamyslet, protože myslím si, že bezbariérovost je základ a je důležitá v dnešní době.

Ale připomeňme si, koho tyto komory zastupují. Tak Česká komora autorizovaných inženýrů a techniků činných ve výstavbě zastupuje 32 310 autorizovaných inženýrů a techniků. Česká komora architektů zastupuje 4 226 autorizovaných architektů a urbanistů. To je prostě 37 000 lidí, kteří tomu rozumí, chtějí se vyjadřovat prostřednictvím svých zástupců, chtějí připomínkovat a neměli tu možnost. Vy nechcete slyšet a naslouchat hlasům odborníků z praxe, kteří se výstavbou dlouhodobě zabývají? Protože kdo nenaslouchá odborníkům, tak je diletant! Ono to vypadá, že tady máme vládu diletantů.

Protože, vážení občané – to tady vždycky se tak dělalo v minulosti – já se tady snažím mluvit k vám v sále, ale vy říkáte, že to děláte pro lidi, tak novým stavebním zákonem se stane, že vám za barákem bude moci vyrůst cokoliv, i navzdory hlukovým limitům. Ona je to taková nenápadná, ale velmi problematická změna v připravované novele stavebního zákona, protože § 193 odst. 3 navrhuje umožnit povolit stavbu, i když nesplňuje hygienické limity hluku a vibrací. (Takže) tady hrozí zásadní ohrožení zdraví občanů. Prostě přestože nebude splněn hlukový limit, pokud o tom rozhodne úředník centrálního úřadu, který na tom místě nikdy nebyl, tak normálně to půjde.

Prý totiž stačí, že stavebník prokáže, že udělal všechna opatření, která po něm lze rozumně požadovat. On o tom už mluvil před chvílí náš předseda Vít Rakušan. Já si to vůbec neumím představit, jak se bude v praxi uplatňovat pravidlo rozumně požadovat. Tak co to je rozumně? Protože já mám pocit, že tady jsme ve Sněmovně někdy ten zdravý selský rozum už ztratili, protože se tady neumíme společně domluvit a považuju to za velkou chybu. Znovu připomínám, v úterý se měly projednat tři zákony. Všechny se projednaly v souladu s tím, co vládní koalice chtěla.

Protože co když úřad usoudí, že hluk odpovídá běžnému stávajícímu využití okolního území? Já jsem ráda, že tady zrovna sedí pan ministr zdravotnictví Adam Vojtěch, jehož podporuju v tom, jaké změny připravuje v rámci českého zdravotnictví a nebudu jako populistická opozice vykřikovat něco, budu se snažit mu pomoct z pozice opozice, protože to opravdu oceňuju. A uvidíme, jestli se nám to společně podaří, ale znepokojuje mě, že jako ministr zdravotnictví nechává plynout, že jeho kolegové z vládní koalice prostě chtějí takto prolomit hlukové limity a ohrožovat zdraví občanů, protože ty hygienické limity nejsou formalita. Chrání zdraví lidí před dlouhodobým vystavením hluku a ta novela z nich dělá doporučení, ne závazné pravidlo. A to je prostě velký problém, protože co to přinese v praxi pro konkrétní lidi? Že zrovna vedle jejich bydlení budou moci vzniknout hlučné výrobní provozy. Budou tam moci vzniknout velké logistické areály, velké a hlučné dopravní stavby, které by dneska nebylo možné kvůli těm hygienickým limitům povolit, nebo by se k tomu mohla vyjádřit obec, ale vy tam navrhujete zkrácení limitů, kdy ani nebude možné svolat radu obce podle zákonných možností. Prostě to nebude možné, ta obec nebude mít možnost podle zákona se včas vyjádřit.

Pojem rozumnost. Co to je? To není jasně definovatelný, to je vágní a naprosto subjektivní výraz. Já můžu mít úplně jinou představu o zdravém rozumu než ji máte vy. Zcela zjevně ji mám úplně jinou. Prostě otevírá to prostor pro velmi volný výklad a pro rozhodování na základě libovůle, nechci říct zlovůle. Ale co když bude rozhodovat někdo v nějakém zájmu a o co se opře? A jak se ti obyvatelé dozvědí, že jejich právo na ochranu zdraví ustupuje tomu, co je pro investora rozumně dosažitelné? Pokud už je území zatížené hlukem, může se argumentovat tím, že další zdroj hluku vlastně nic zásadního nemění, protože to máte hlučné, tam bydlíte.

Já bych vám tady mohla vyprávět problémy naší obce se vznikem, změnou, já jsem bývalá starostka podhorské vesnice v Kunčicích pod Ondřejníkem, v Beskydech, Kunčice pod Ondřejníkem, a máme tam takovou velkou zemědělskou plochu, na které podle stávající legislativy mohou nepravidelně, pokud je to včas oznámeno, přistávat ta malá letecká zařízení. A doposud jsme měli jako obec možnost ovlivnit v rámci územního plánu, aby se z toho nestalo letiště. Ale teď se třeba úplně klidně to bude moct stát, že se prostě řekne, že to je v pohodě a někdo si to tam prolobbuje. To prostě není možné. Protože vy vlastně můžete postupně ten hluk v tom území navyšovat, je to taková salámová metoda, zvýšíme to o trochu, zvýšíme to ještě trochu o trochu a pak už to najednou bude tak hlučné, že tam ti lidi nebudou schopni žít.

Ale my se přece máme starat o lidské zdraví, zejména v situaci, kdy čelíme zhoršujícímu se zdraví populace, zkracování doby života ve zdraví. Prodlužuje se nám sice délka života, ale prodlužuje se nám délka života ve zdraví? A my přece máme společně se starat o to, aby se prodlužovala délka života ve zdraví, aby se lidé dožívali déle, ale ve vysoké kvalitě a když budou vystaveni vysokým vibracím a vysokému hluku, no tak se moc dobré kvalitě zdraví prostě těšit nebudou. Protože ta drobná změna může umožnit, že se ty hlukové zdroje budou v tom jednom místě kumulovat.

A já tady opravdu důrazně apeluji na to, abyste zvážili, zda je to takto v pořádku zejména z důvodu ochrany zdraví našich občanů.

Další problém, černé stavby. Zbourá je někdo? Komu to má prospět? Připravovaná novela stavebního zákona výrazně oslabuje boj proti černým stavbám. Navrhuje totiž zrušit lhůtu pro podání žádosti o dodatečné povolení stavby. Majitele černé stavby tak nic nebude nutit, aby povolení řešil, prostě to postaví a hotovo. Já nevím, co když se někdo rozhodne v nejvyšší zóně chráněného území národního parku postavit dům? Tak ho tam prostě postaví, bude tam a nikdo mu ho nezboří? To se na mě můžete dívat, že se nic takového nestane. Ale co když jo? Co když se to postupně prolomí? Protože v praxi to opravdu může vypadat tak, že nějaká krásná louka s výhledy na – já použiju Beskydy – já žiju v Beskydech nebo na nějaké oblíbené místo, kde to máte rádi, kam chodíte čerpat sílu, kam chodíte na procházky, tak si někdo prostě vystaví, postaví tam rekreační apartmán, rodinný dům, přestože to ani nebude stavební pozemek, prostě se rozhodne, tak to tam bouchne. A bude hotovo. Už teď máme totiž problém odstraňovat černé stavby, rostou ve velkém, poměrně dost jich tam je a to je opravdu něco, co je potřeba zlepšit. Ale vy to nezlepšujete, naopak to zhoršíte, protože zmizí ta lhůta. Takže místo vlastně posílení toho boje proti černým stavbám, které bych od vás očekávala, od toho, že bude vymáhat právo zákon, tak naopak přijde legalizace porušování pravidel.

Co mě trápí hodně a zase to souvisí s tím zdravím, protože abychom byli zdraví, musíme žít ve zdravém životním prostředí. A trápí mě, že vámi předkládaná stavební novela stavebního zákona přináší změnu, že už stavební úřady nebudou chránit přírodu.

Připravovaná novela stavebního zákona zruší zákon o jednotném environmentálním stanovisku, takzvaný JES, přestože se v praxi osvědčil. Ochranu životního prostředí mají nově posuzovat stavební úřady s výjimkou tedy zvláště chráněných území. Ale ty stavební úřady na to nemají jednak odbornost, nemají na to dostatečnou oporu v zákoně, podle návrhu se sice mají vyvažovat různé veřejné zájmy, ale zároveň v tom vyvažování má vždy přednost výstavba. A co je ještě horší, vždycky je nejhorší, když to jde ode zdi ke zdi, když pro dobrý rozvoj země je důležitá kontinuita. Pokud jedna vláda navazuje na druhou, upraví třeba drobnosti, vylepší chyby, poučí se z praxe. Dobře to můžeme opravdu vidět v městech a obcích, kde postupně navazuje jeden starosta, starostka, na druhého, využije to, co ten jeho předchůdce připravil a přestože je třeba z opozice, tak pokračuje v celé řadě projektů. A na těch obcích pak vidíte, jak ty obce vzkvétají, jak vypadají skvěle. Ale když nastoupí nové vedení, jehož jediným cílem je prostě zbořit to, co ti předchůdci připravili, tak podle toho potom ta obec vypadá.

A vy vlastně tady rušíte zákon, který je účinný od 1. 7. 2024, funguje rok a půl. Osvědčil se. I tehdy, když se přijímal, byly obavy, že bude prodlužovat povolování staveb, ale ty obavy se v praxi nenaplnily. Naopak, úřady se naučily koordinovat dříve samostatná stanoviska k vlivům na životní prostředí, vlivům na vodu, ovzduší, půdu, odpady, druhovou ochranu, kácení dřevin a tak dále. Posuzují to úředníci s příslušnou odborností.

Systém samozřejmě měl počáteční porodní bolesti, ale začal fungovat a právě ve chvíli, kdy se rozběhl, tak vy jej chcete zrušit.

Ale co je důležité, tak zákon o tom jednotném environmentálním stanovisku byl připraven jako klíčová součást Národního plánu obnovy, jako komponenta zelené transformace, které nám umožňuje čerpat finanční prostředky z Evropské unie na základě splněných milníků a cílů, a ty cíle musí být splněny do června 2026, aby byly uvolněny další platby.

A pokud nebudou splněny, můžeme přijít i o desítky miliard, tak pokud neslyšíte na zdraví, pokud neslyšíte na životní prostředí, tak bych od vás očekávala, že uslyšíte na peníze. Že nám hrozí že budeme mít problém. Zjevně si žádný problém nepřipouštíte.

Ale co je dalšího – že bude vznikat s tím zákonem celá řada výjimek. Budou výjimky za zavřenými dveřmi. Je to zase nenápadná změna, ale zásadní, zásadní změna v připravované novele stavebního zákona, protože bude mít rada obce možnost udělit konkrétnímu záměru výjimku z územního plánu.

Ale problematické na tom je, že se o takové výjimce bude jednat za zavřenými dveřmi na neveřejném jednání rady města. Ale je to konkrétní rozhodnutí, které může ovlivnit zásadně život lidí v té čtvrti. Oni nebudou mít možnost se k tomu vyjádřit. Rada ani stavební úřad nebudou mít povinnost tu výjimku odůvodnit. Z územního plánu se stane trhací kalendář. Nebudou to žádná pravidla výstavby, nebude to žádný dlouhodobý strategický dokument, úplně se to rozcupuje podle toho, kdo koho zná, kdo komu bude chtít vyhovět. Nebude tam žádná transparentnost.

Jak zajistíte, že – jaká bude logika těch individuálních výjimek schvalovaných politickým rozhodnutím rady města? Je to zásadní chyba, že se mohou některá rozhodnutí, která zásadně mohou měnit charakter okolí se tak budou odehrávat bez veřejné kontroly a bez jasného odůvodnění.

Mohla bych tady mluvit dlouze o tom, že připravovaná novela stavebního zákona ve většině případů ruší odborná stanoviska orgánů ochrany přírody, památkářů, hygieny, ale ruší i závazná stanoviska požární ochrany a integrovaného záchranného systému. Nevím, jestli je dobře rušit závazné stanovisko požární ochrany? Vyjádření hasičů budou jen nezávazná. V kontextu nedávného silvestrovského požáru ve Švýcarsku si to neumím představit. Neumím si představit, že na sebe berete tu zodpovědnost, že někdo řekne, že to stanovisko je nezávazné. Co když nepoužije zdravý selský rozum a neadekvátně to rozhodne? Co když budou postaveny stavby, kde nebudou dostatečné únikové cesty? Kde nebude místo pro příjezd hasičského auta nebo sanitky? Když spoléháte na to, že se to nestane? No nestane se to – doteďka se to nemohlo stát, protože byly dodržovány nějaké pravidla a zákon.

Ale to není možné. To jsou ty nejčernější scénáře, které já si nepřeju, aby někdy nastaly. Ale tohleto obrovské riziko v té novele stavebního zákona je. A kdo za to ponese zodpovědnost, když opravdu by tato úplně extrémní situace nastala?

Zkuste se nad tím zamyslet. Protože vy tady – já se dívám po sále, držíte se za hlavu, kroutíte hlavou, tvrdíte, že nic takového není. Tak já doufám, že se pletu, ale pokud to není závazné, to stanovisko, tak když něco není závazného, tak se tím nemusíme řídit – a myslím si, že zákon by měl nastavovat jasná pravidla.

Nevím, jestli máte vyřešeno, že ten nový systém bude fungovat. Jak už jsem krátce zmínila, 67 procent zaměstnanců přecházet nechce. Raději z toho zaměstnání úplně odejdou anebo půjdou do penze a vyřeší to tím. Někteří si budou chtít najít jiné uplatnění na jiném úřadě. Přitom jsem na to zvědavá, kde ty lidi seženete, protože je dneska problém sehnat lidi.

No a hlavní je nakonec – jsem si říkala, že možná na něco byste mohli slyšet, tak tím skončím – to jsou peníze. Kolik to bude stát a kdo to zaplatí? Víme? Kolik nás bude stát přesun stavebních úřadů? A kdo to zaplatí? To je jasné, kdo to zaplatí. Občané z daní. Protože jinak stát moc peníze nezískává, pokud teda neuvažuje o tom, že naprosto nesmyslně by třeba prodal strategický podnik, jako je Explosia. Tak převážně získává peníze z daní, takže to zaplatí občané. Bude to stát miliardy, které zaplatí všichni ze svých daní a ještě to navíc nepovede ke zrychlování staveb. Nás ten systém úplně zasekne.

Vy říkáte, že stačí zvýšit státní tabulkové platy o 10 procent a přesun stavebních úřadů bude vyřešen. Tak to bych chtěla vidět. Protože často obce v současném systému doplácejí úředníkům mzdy, jako je třeba osobní ohodnocení, protože za ty čistě tabulkové platy lidi neseženou. A obce nesou další náklady. Reálné, celkové náklady na ty zaměstnance jsou prostě mnohem větší.

A vyjadřovala se k tomu i analýza sdružení tajemníků. Ta říká, že ten přesun se týká minimálně 5 443 odborných pracovníků na úrovni obcí s rozšířenou působností, dalších zaměstnanců obcí, krajů a nového centrálního úřadu. 6,7 miliardy korun ročně jsou celkové náklady jenom na úrovni ORP. 3,8 miliardy ročně – mzdové náklady zase jenom na ORP. Zhruba 1 200 000 korun na jednoho úředníka včetně provozu.

Co všechno tvoří ty neviditelné náklady? Je tam k tomu ekonomika, účetnictví, personalistika, IT podpora, spisová služba, služební auta, technik, úklid, údržba, bezpečnost ochrany zdraví při práci, řízení, management. Stát bude muset navíc pronajímat nebo stavět nové budovy, kam ty úředníky přesune. A to se bavíme jenom o těch každoročních výdajích.

A další miliardy spolkne samotný přesun, proces toho přesunu, nová organizační struktura a řízení, změny pracovněprávních vztahů pro tisíce lidí, nové IT systémy, stěhování archivu a spisů. Jaký bude výsledek? Reálná hrozba, že se stavební řízení výrazně zpomalí anebo dočasně totálně ochromí. Kvůli personálním odchodům procesu reorganizace a dlouhodobému podstavu zaměstnanců. Dopady pocítí obce, obyvatelé i investoři.

Systém se může úplně zhroutit. Ale uvidíme, řekneme si. Možná tady budeme za dva roky stát a říkat: my jsme vám to říkali. Možná už za rok. Uvidíme.

Já v tuto chvíli ukončím svůj projev s tím, že bych doporučovala vládní koalici, aby stáhla tento návrh z projednávání. Aby předložila – pokud chce opravdu měnit stavební řízení, tak aby předložila jiný návrh. Návrh který projde standardním legislativním procesem, který budete konzultovat s odborníky, protože ta zodpovědnost je na vás. A apeluji na vás, abyste se zaměřili na to, zda opravdu tou změnou nezhoršíte kvalitu života v této zemi a neohrozíte zdraví našich obyvatel. Děkuju vám za pozornost. (Potlesk z řad poslanců STAN.)

**Místopředseda PSP Patrik Nacher:** Já vám děkuji. Vystřídali jsme se při řízení schůze, já vás zdravím, přeju pěkný večer. Taková informace – v Praze byl právě schválen Metropolitní plán, tak to krásně navazuje na ten stavební zákon.

Nejprve přečtu omluvy, pak jsou faktické poznámky a pak budeme pokračovat v rozpravě. Patrik Nacher bere zpět omluvu od 13 hodin – z pracovních důvodů a omlouvá se od 13.30 do 17 hodin a od 18.30 do 20.15 – z pracovních důvodů, Josef Nerušil od 18 hodin do 21.30 – z pracovních důvodů.

V této chvíli máme zde faktické poznámky. Radek Koten už je proaktivně před mikrofonem, připraví se Vojtěch Krňanský a Matěj Gregor. Spouštím dvě minuty.

**Poslanec Radek Koten:** Děkuji za slovo, vážený pane předsedající. Vážení kolegové, kolegyně, dámy a pánové, já bych sem za normálních okolností opravdu nešel. Ale vzhledem k tomu, co se tady vlastně děje několik dní, já dostávám v podstatě na denní bázi zprávy od nespokojených občanů, jakým způsobem jedná Poslanecká sněmovna. Zaznívají tam v těch zprávách, které mi chodí na Whatsapp nebo do esemesek, jestli tady jsou pavlačoví bojovníci, bojovnice anebo zda to je nejdražší chráněná dílna v České republice. Zaznívají tady invektivy, těch věcných argumentů tady je jako šafránu a co se týká návrhů těch bodů, které se navrhují na úvod programu, tak to tady mně psali, že to jsou dětinské názvy bodů, dehonestující třeba konkrétní lidi.

já bych řekl, že tady je krátká paměť, protože za vlády Petra Fialy s Markétou Pekarovou Adamovou v čele Poslanecké sněmovny se tady říkalo, ať sedíme v koutě a šoupeme nohama.

Jinak, co se týká Moravskoslezského kraje. No tak vzpomeňte si, jak dopadl pan Zbyněk Stanjura se svou arogancí. Jinak, co se týká, zda chcete něco dělat pro občany. Tady zaznívalo mnohokrát, že pro ně chcete něco dělat a že my to tady blokujeme. No tak podle těch, co mi píšou, tak vy prý nechcete pro ně nic dělat, bojkotujete jednání Sněmovny a zejména tedy bojujete, ale bojujete o ty korýtka, které jste nedostali. Děkuju za pozornost.

**Místopředseda PSP Patrik Nacher:** Tak děkuji za dodržení času. Další faktická poznámka Vojtěch Krňanský, malý moment. Tak, můžete.

**Poslanec Vojtěch Krňanský:** Pane předsedající, děkuji za slovo, krásný dobrý večer. Vážené kolegyně, vážení kolegové, my jsme tady před chvílí viděli neuvěřitelně afektovaný projev paní kolegyně Šebelové. Dokonce nás nazvala diletanty, vládou diletantů. Paní kolegyně, prostřednictvím pana předsedajícího jste to vy, kdo je zastáncem té kultivované Sněmovny a při projednávání stavebního zákona nás tady nazvat takhle – já to považuji za poměrně nedůstojné, obzvláště proto, že je to vaše hnutí, který si které si říká Starostové. Ale já bych rád připomněl, že v této Sněmovně jsme ve složení, kdy skutečných starostů, kteří tu činnost vykonávají, budu počítat starosty, místostarosty, primátory a náměstky primátorů – tak Klub ANO má 20. ODS 4, KDU-ČSL 4, STAN 3, TOP 09 2, Motoristé 1, Piráti 1.Čili hnutí STAN má 3 aktivní starosty oproti celé koalici, která jich má 21. Je to jedna sedmina. A vy nás tady chcete poučovat o tom, že starostové, my starostové, víme, co potřebujeme. (Nacher: Prosím prostřednictvím, vždy.) Prostřednictvím pana předsedajícího, my skuteční starostové víme, co potřebujeme a co potřebuje stavební řízení. My skutečně chceme, aby samosprávy měly moc něco předávat.

A v těch vašich 3 starostech máte taky kolegu, který přivedl svou obec na pokraj bankrotu. Jestli vychováváte takové odborníky a chcete nás tady mistrovat v tom, že víte, co je potřeba, tak bohužel. Rád bych také řekl, že ten váš projev byl bohužel, prostřednictvím pana předsedajícího, plný nepochopení toho zákona. Já mám pocit, že jste ho ani nečetla, protože pokud tady vyprávíte o tom, o těch hasičích, tak každý takhle rozsáhlý projekt, který jste tady zmiňovala, potřebuje mít PBŘ od autorizovaného technika nebo inženýra. To není o tom, že si to někdo nakreslí v omalovánkách od dítěte. Stavební řízení funguje trochu jinak. Děkuju vám. (Potlesk z levé části sálu.)

**Místopředseda PSP Patrik Nacher:** Děkuji za dodržení času, v této chvíli na faktickou poznámku se připraví Matěj Gregor, dále v pořadí je Petr Sokol, Michaela Šebelová. Tak pojďte, pane poslanče, já vám spouštím 2 minuty.

**Poslanec Matěj Gregor:** Děkuji za slovo, pane předsedající. Já vlastně, když jsem poslouchal ten projev paní předsedkyně Šebelové, tak jsem přemýšlel hodně nad tím, jak to tady poslední dny vypadá a říkal jsem si celou dobu: Nejde ty věci říct normálně? Nejde to tak, abychom se bavili jako lidi? Já vím, že vy sama jste velmi citlivá na ty osobní útoky, na to, když se zbytečně používají emoce, ale nemohu se zbavit dojmu, mnohokrát jsem s vámi diskutoval prostřednictvím pana předsedajícího, že vy to trochu děláte taky a začíná to být z mého pohledu velmi, velmi za čarou. Vy jste na jedné straně v tom projevu řekla: je chyba nebavit se mezi stranami. Je chyba na těch věcech nespolupracovat. Ale pak jste to, jak to říkali můj předřečník, vyplnila celou řadou těch invektiv, kterými jste vlastně trošku nepřímo řekla, že o tu debatu nestojíte, protože když s někým stojíte o debatu, tak ho neurážíte. A to je podle mě problém té, obecně, dnešní politiky a Sněmovny. A to, co tady vidíme, jsou jenom příznaky, které jsou všude ve světě.

Z politiky se vytrácí ta nejdůležitější kompetence – a není to odbornost, není to nějaký kredit, to bych řekl, že tady většina lidí nějaký má – ale je to ta schopnost a ochota chtít se domluvit. A připomenu vám jednu věc, když jsme se spolu viděli možná poprvé, tak pan kolega Rajchl v jedné debatě, tak vás osočil neférově, útočně, za ty Poslanecké náhrady a já jsem se vás tehdy zastal. Po debatě jsem za vámi přišel a říkal jsem vám, to mi nepřišlo férové, co udělal pan kolega Rajchl, to nebylo fér. A vy jste mi řekla, lidé, co tohle dělají, tak je to vždycky doběhne. Tak, aby vás to nedoběhlo.

**Místopředseda PSP Patrik Nacher:** Mým prostřednictvím může něco doběhnout. Děkuji za dodržení času, poprosím další faktická, Petr Sokol, připraví se Michaela Šebelová a Lukáš Vlček. Pane poslanče chvilku počkejte, tady to má zpoždění, ať vám tam můžu dát 2 minuty, tak můžete.

**Poslanec Petr Sokol:** Děkuji. Vážený pane předsedající, abych se vaším prostřednictvím chtěl obrátit na pana poslance Kotena. Já myslím, že by tady nemělo zaznívat, že Poslanecká sněmovna Parlamentu České republiky chráněná dílna. A já znám samozřejmě ty vaše triky, jako když vy chcete si udělat mítink na náměstí, vaše strana, tak tvrdíte, že tam sbíráte petici a stejně tak tady bychom se asi měli vyvarovat toho, že si budeme posílat vzkazy, že nám někdo něco napsal. To, když mě napíše někdo něco ošklivého o vás, tak já to tady taky nebudu číst. Já myslím, že to je na každém z nás. To je první věc. Druhá věc. Říkal jste, že my nechceme pracovat? No tak jednak my jsme přesvědčeni, že když se nebudou schvalovat podobné zákony, tak to bude lepší. Ale pracovat chceme. A připomeňme si, že včera skončila schůze Poslanecké sněmovny, protože většina tady neměla dost lidí.

Takže asi kdybych používal vaši rétoriku, to já nechci dělat, tak by to znamenalo, že jste nebyli v práci a proto skončila schůze Poslanecké sněmovny. Jako nevytahovali bychom to tady ale po té vaší paličské řeči mi nic jiného nezbylo. O pavlači a tak podobně. A v neposlední řadě bych se chtěl zeptat, kde je prosím odpovědný ministr tady k tomuto bodu, proč tady není? Já vím, že používáte zase ten trik, že nebyli jste to schopni předložit jako přes vládu, tak jste to předložili jako poslanecký návrh. Ale k takhle velké novele by tady asi přece měl být přítomný ministr. Tak já se jenom chci zeptat kde je?

**Místopředseda PSP Patrik Nacher:** Děkuji za dodržení času. Dále na řadě je Michaela Šebelová, než sem dorazí, přečtu dvě omluvy. Robert Králíček bere zpět svou omluvu, Celý jednací den - osobní důvody. Robert Králíček do 18 h, osobní důvody. Tak dobře. Michaela Šebelová faktická – dvě minuty, připraví se Lukáš Vlček a Jan Berki. Můžete paní předsedkyně.

**Poslankyně Michaela Šebelová:** Děkuji vám za slovo. No, také bych očekávala, že paní ministryně Mrázová, která ten zákon nepředkládá jako ministryně, tady bude tu debatu poslouchat. V zimě se jí to zdá zbytečné. Na kolegu Krňanského: Ano, my Starostové nekumulujeme funkce. Celá řada starostů našich rezignovala na své funkce na obcích i ti, kteří jsou tady zvoleni. Jsou tady i Starostové, kteří už prostě nejsou starosty a někteří třeba byli v minulém období a nejsou, protože ne, anebo se rozhodli být jenom starosty a nekandidovali znovu do Poslanecké sněmovny. To znamená, vy jako hnutí jste z Motoristů – a já se vždycky pletu, pardon, jestli mám pocit, že jste z hnutí ANO, se omlouvám – tak... Nebo jsem to možná dopletla... Jo, možná jste tam byl a teď jste tam, to je jedno. Prostě obrovsky se kumulují funkce, tak tím to taky je. Pak máte velký počet starostů v Poslanecké sněmovně. Na kolegu Gregora? Já doufám, že až budeme projednávat s platy, prostřednictvím pana předsedajícího, na kolegu Gregora, že až budeme projednávat platy, ten váš populistický návrh na zmrazení platů, že podpoří celá vládní koalice můj návrh na redukci poslaneckých náhrad, protože jsou neadekvátní současným cenám. A všichni poslanci z Moravskoslezského kraje, nejenom já ze Starostů a nezávislých, ale i ti z hnutí ANO, SPD a Motoristů mají stejně vysoké náhrady jako já, automaticky součástí platu, to znamená navrhnou jejich snížení, protože opravdu odskočili a nejsou adekvátní, ne. Takže kdo chce řešit skutečný problém platu, řeší náhrady?

No a protože tady padlo, že tady včera nebylo dost poslanců, tak prověříme, zda je dost poslanců v práci a dávám procedurální návrh na přerušení projednávání tohoto zákona do 1. 1. 2028, děkuji.

**Místopředseda PSP Patrik Nacher:** Tak moment, to jste mě překvapila paní předsedkyně do 1. 1. 2028? (Zapsuje si.) Tak.(Poslanci vstávají z lavic a stojí frontu k pultíku.) Ale můžete mít jenom protinávrhy proti procedurálnímu návrhu. Ano, pan poslanec Pražák.

**Poslanec David Pražák:** Dobrý večer pane předsedající, tak já bych navázal pan na kolegyni a dal bych protinávrh, že si myslím, že tuto noční hodinu čekat na 1. 1. 2028 je trošku chaotické. Já bych tam dal protinávrh do dnešní dvacáté první hodiny a patnácté minuty, navrhuji přerušení. Děkuji.

**Místopředseda PSP Patrik Nacher:** Do 21.15. Máte další protinávrh pane poslanče?

**Poslanec Igor Hendrych:** Tak já vám moc děkuju za slovo, vážený pane místopředsedo. Vážené dámy, vážení pánové, vážená paní ministryně, já si myslím, že bychom to mohli přerušit na o 5minut kratší dobu a navrhuji tedy 21.10 hodin.

**Místopředseda PSP Patrik Nacher:** 21.10. Pan poslanec Mašek. Já jenom poprosím o klid. Já si ty časy píšu, ano? Prosím.

**Poslanec Jiří Mašek:** Dobrý den. Prosím, pane místopředsedo, dámy a pánové, já bych si dovolil dát protinávrh do 21.21 hodin. Děkuju.

**Místopředseda PSP Patrik Nacher:** Do 21.21 hodin?

**Poslanec Jiří Mašek:** Ano, 21.21 hodin.

**Místopředseda PSP Patrik Nacher:** Dobře, děkuju. Pan poslanec Gregor.

**Poslanec Matěj Gregor:** Děkuji. Já bych chtěl dát protinávrh na přerušení schůze do 23.10 hodin proti paní Šebelové, která teď odjela do televizní debaty a hlasování se nezúčastní.

**Místopředseda PSP Patrik Nacher:** Poprosím jenom o návrhy, ne o komentáře. Žádné další návrhy nemám. Já vás odhlásím... Tak ještě pan Krňanský.

**Poslanec Vojtěch Krňanský:** Já bych také chtěl dát protinávrh na přerušení schůze do 22.22 hodin.

**Místopředseda PSP Patrik Nacher:** 22.22. Já vás v této chvíli odhlásím. Přihlašte se svými identifikačními kartami. Tak a já nechám hlasovat. Jdeme odzadu.

Návrh pana poslance Krňanského na přerušení do 22.22.

Zahajuji hlasování. Kdo je pro? Ať zvedne ruku a stiskne tlačítko. Kdo je proti?

Hlasování číslo 129 , přihlášeno 93, pro 22, proti 62. Návrh nebyl přijat.

V této chvíli... Já vás poprosím o klid! Kolegové! Teď bude návrh pana poslance Gregora – přerušení do 23.10 hodin.

Zahajuji hlasování. Kdo je pro? Ať zvedne ruku a stiskne tlačítko. Kdo je proti?

Hlasování číslo 130 , přihlášeno 95 poslanců, pro 25, proti 61. Návrh nebyl přijat.

Třetí protinávrh je od pana poslance Maška – přerušení do 21.21.

Zahajuji hlasování. Kdo je pro? Ať zvedne ruku a stiskne tlačítko. Kdo je proti?

Hlasování číslo 131 , přihlášeno 96 poslanců, pro 28, proti 60. Návrh nebyl přijat.

Čtvrtý protinávrh je od pana poslance Hendrycha – přerušit do 21.10.

Zahajuji hlasování. Kdo je pro? Ať zvedne ruku a stiskne tlačítko. Kdo je proti?

Hlasování číslo 132 , přihlášeno 96 poslanců, pro 11, proti 61. Návrh nebyl přijat.

A poslední protinávrh je od pana poslance Pražáka – přerušit do 21.15. Zahajuji hlasování. Kdo je pro? Ať zvedne ruku a stiskne tlačítko. Kdo je proti?

Hlasování číslo 133 , přihlášeno 96 poslanců, pro 11, proti 62. Návrh nebyl přijat.

A v této chvíli budeme hlasovat o původním návrhu paní předsedkyně Šebelové přerušit tento tisk do 1. ledna 2028.

Zahajuji hlasování. Kdo je pro? Ať zvedne ruku a stiskne tlačítko. Kdo je proti?

Hlasování číslo 134 , přihlášeno 96, pro 24, proti 71. Návrh nebyl přijat.

Budeme pokračovat v rozpravě. Na řadě jsou faktické poznámky. V této chvíli je na řadě Lukáš Vlček, připraví se Jan Berki a Jitka Volfová. A já poprosím – moment, pane kolego, než přijdete, aby se mi zase ta obrazovka vrátila zpátky a já jsem to mohl ovládat, jestli můžu poprosit. (Na tabuli stále zobrazen výsledek posledního hlasování.) Můžu poprosit techniky, abyste mi vypnuli tu obrazovku já jsem mohl ovládat tady tu obrazovku? (Zobrazen seznam přihlášený.) Tak děkuji. Máte dvě minuty, pane poslanče. Omlouvám se.

**Poslanec Lukáš Vlček:** Já vám děkuji, pane předsedající, za slovo. Já bych chtěl reagovat na pana poslance Kotena, vaším prostřednictvím, když on tady hovořil vůči naší předsedkyni klubu a paní poslankyni Šebelové ohledně těch korýtek. A mě to od vás, pane kolego, přijde velmi úsměvné. Vy jste uvolněným předsedou výboru na Vysočině. Je to tak? Takže vy jste poslancem, zároveň uvolněným předsedou výboru zastupitelstva na Vysočině. To je tedy k té kumulaci těch korýtek. Berete dva platy, i když tam je nějaké krácení, takže to, že vy tady hovoříte o nějakých korýtkách, je z vaší strany velmi úsměvné, legrační, že zrovna vy o tom hovoříte.

A mně tam přijde ještě legrační jedna věc, která v souvislosti se stavebním zákonem je velmi smutná, a mě opravdu rozesmutněla, když jsem včera si poslechl stenozáznam pana ministra Havlíčka v Senátu, který hovoří o tom, že vlastně ten slib vůči obcím na Vysočině, že budou obce patřičně financovány, jejich projekty, tak nemusí být naplněn. A já bych zrovna od vás očekával, jakožto tedy od uvolněného předsedy výboru na Vysočině, tedy toho kumulátora, toho, který ta korýtka tedy velmi rázně využívá, že se o to budete nějakým způsobem zajímat, prát, a možná budete i ten, který bude iniciovat, aby tady právě stavební zákon byl v takové podobě, aby ty projekty, které mimochodem ten výbor, který vy vedete a kumulujete ty funkce a ta korýtka tedy nasbíráváte a pak tedy kritizujete ostatní, tak aby ty věci fungovaly. Ale to se bohužel neděje. Tudíž tedy bych vám doporučil si možná sám sáhnout do svědomí a odpustit si některé věci, když vy sám kumulujete ty funkce, berete dva platy a přitom ten výkon, který na Vysočině předvádíte, je tristní. Anebo možná není a možná nám řeknete k tomu více, co vlastně když sám jako kumulátor funkcí a pobíratel těch korýtek, co tedy pro to děláte. Děkuju.

**Místopředseda PSP Patrik Nacher:** Děkuju za dodržení času. Připomínám, oslovujte se prostřednictvím předsedajícího, pokud to není s ministrem vlády. Na řadě je Jan Berki, připraví se Jitka Volfová, Vojtěch Krňanský. Pane poslanče, spouštím dvě minuty.

**Poslanec Jan Berki:** Děkuju, pane místopředsedo. Já budu reagovat na své dva kolegy. Jednak vašim prostřednictvím k panu poslanci Kotenovi. Jasně, chápu, že vám to možná někdo píše. Možná byste jim měl ale vysvětlit, že ta korýtka, o která se jedná, jsou dána poměrným zastoupením. Jinými slovy, že i tato koalice seznala, že například Starostové mají nárok na jednoho místopředsedu Sněmovny. Vyměnili jsme nominanta, přesto jste ho nezvolili. Takže nejde o nějaká korýtka, ale o zastoupení, které bychom měli mít. Stejně tak se to týká například ódéesky a některých jejich nominantů nebo topky a jejich nominantů. Nejsou to žádná korýtka.

A ke kolegovi Krňanskému, vaším prostřednictvím. Já si vždycky vážím toho, že – doufám, že to i nadále budeme umět udržet v nějaké rozumné míře. Já bych se ale trošku ohradil proti tomu vašemu: my starostové nejlíp víme. Já když se starosty, a za chvilinku půjde starostka z našeho kraje, tak doufám, že to potvrdí, když se s nimi potkávám, tak to není tak, že všichni jásají nad tímto návrhem, ale dokonce ani oni mezi sebou nemají úplně jednotný názor. Záleží na zkušenosti, kterou mají se stavebním úřadem, jestli ho mají u sebe, nebo nemají u sebe, jak ho mají dostupný. Některých věcí se starostové a starostky z menších obcí obávají, některé ty věci ale na druhou stranu třeba starostové a starostky měst vítají.

Takže prosím, nedělejme tady iluzi toho, že starostové jako nějaká jednotná masa buď jásá, nebo nejásá. Tak jenom jsem tohle chtěl upřesnit, abychom se tomuhletomu trošku vyvarovali.

**Místopředseda PSP Patrik Nacher:** Já vám děkuji za dodržení času. Nyní poprosím a pozvu za mikrofon Jitku Volfovou s faktickou, připraví se Vojtěch Krňanský.

**Poslankyně Jitka Volfová:** Omlouvám se, pokud nestihnu dvě minuty, přihlásím se případně podruhé. Vážený pane předsedající, vážené poslankyně, vážení poslanci, dovolte mi zareagovat na paní poslankyni Šebelovou, prostřednictvím předsedajícího. Úplně na začátek řeknu, že tímto způsobem zkulturnění Poslanecké sněmovny nedosáhneme.

Ale nyní konkrétní reakce. Jako starostka města rozumím velmi tomu, že samosprávy mají obavy. Proto i diskutuji s MMR, aby byly komunikovány s obcemi jednotlivé kroky, aby byly eliminovány obavy a pochybnosti a jsem velmi ráda, že k tomu Ministerstvo pro místní rozvoj postupně přistupuje. Je pravdou, že každá velká změna ve stavebním řízení přináší otázky a nejistotu. Na tom se jistě shodneme, a proto je naší povinností jim naslouchat. Ale označovat nový stavební zákon předem za paskvil, je přinejmenším velmi odvážné. Zvlášť, když se podíváme na výsledek reformy, kterou připravovala vaše politická reprezentace. Prosím, řekněte nám zde na mikrofon někdo z tehdejší koalice, jestli jste věděli přesně, co vše v rámci digitalizace je připravováno. Protože pokud ano, tak mě velmi překvapuje, že jste mohli tento zákon schválit.

Připomeňme si fakta. Právě váš model v době působení exministra Bartoše měl zásadní nedostatky a v praxi se ukázalo, že nebyl dostatečně připraven. Nejviditelnějším symbolem selhání byla digitalizace stavebního řízení. Místo funkčního systému přišel chaos, nefunkčnost a frustrace jak na straně úředníků, tak stavebníků. To nejsou dojmy, to je skutečnost a zkušenost terénu. A ano, lidé ze stavebních úřadů odcházeli. Pro mnohé byla totiž nefunkčnost systému demotivující a skličující natolik, že už nechtěli nést odpovědnost za proces, který nefungoval. Personální oslabení nevzniká dnes, začalo už v době... (Předsedající: Čas, paní poslankyně.) kdy se zaváděly změny bez dostatečné připravenosti a podpory praxe.

**Místopředseda PSP Patrik Nacher:** Paní poslankyně, čas! Opravdu dodržujme ty 2 minuty všichni. Když tak se přihlašte znovu na faktickou. V této chvíli na řadě Vojtěch Krňanský, připraví si Jan Berki.

Než sem přijdete, pane poslanče, jedna omluva. Matěj Gregor od 21 do 22.30 – pracovní důvody.

A vám spouštím 2 minuty.

**Poslanec Vojtěch Krňanský:** Děkuji za slovo. Já budu znovu reagovat vaším prostřednictvím na paní kolegyni Šebelovou, která tady už není, a na pana poslance Berkiho. Znovu zopakuji to, co jsem zde říkal. Mně vadí to – a myslel jsem si, že se dočkáme omluvy, nedočkali – to, že jsme byli označeni za diletanty a vládu diletantů. To skutečně sem nepatří.

A pokud jsem zde zmiňoval počet těch starostů, místostarostů, náměstků a primátorů ve vedení měst, tak jsem čerpal data ke dni zvolení, nikoliv ti starostové, kteří potom rezignovali na svoje posty. Takových je i v koalici spousta. Takže nejde o kumulaci funkcí, ale skutečně jde o to, že do Sněmovny bylo zvoleno 20 starostů nebo primátorů nebo místostarostů za hnutí ANO, 4 za ódéesku, 4 za KDU-ČSL, 3 za STAN, 2 za TOP 09, 1 za Motoristy a 1 za Piráty. A to je ke dni zvolení. To není žádná kumulace funkcí, a proto já jsem se ohradil v tom, že vy občas říkáte, my Starostové máme v DNA. Starosta města neznamená člen hnutí STAN. Proto jsem se proti tomu ohradil. Souhlasím s kolegou Berkim, vaším prostřednictvím, že ano, že jsme různí starostové, máme různé názory a tak je to správně, tak to má být. Takže já jsem se nestavěl do pozice, že vládní koalice a starostové z vládní koalice mají patent na chytrost. Ani jsem to tak nepředkládal. Já jsem se pouze ohradil proti tomu, že můžeme mít rozdílné názory, a to, že si někdo říká hnutí Starostové, neznamená, že jste ze STANu.

A dovolte mi poslední připomínku. Ani jeden starosta z vládní koalice nepřivedl svou obec na pokraj bankrotu. (Potlesk poslanců Motoristů.)

**Místopředseda PSP Patrik Nacher:** Děkuji za dodržení času. V této chvíli je na řadě Jitka Volfová. Připraví se Eliška Olšáková. Tak, vaše dvě minuty.

**Poslankyně Jitka Volfová:** Takže jen dokončím a řeknu, že my netvrdíme, že vše bude jednoduché nebo bezchybné. Tvrdíme ale, že je potřeba systém opravit tak, aby byl předvídatelný, funkční a aby pomáhal obcím, ne je zahlcoval další administrativní nejistotou. Kritizovat je určitě snadné, ale každý by měl mít určitou míru sebereflexe nad tím, v jakém stavu byl systém zanechán. Pokud dnes slyšíme varování před paskvilem, pak je fér připomenout, že skutečný problém vznikl už tehdy, když se spustila nedotažená digitalizace bez dostatečné připravenosti a bez respektu k tomu, jak stavební úřady reálně fungují. Věřím, že se zde většinově shodneme, že zájmem nás všech je, aby stavební zákon byl funkční. Tak prosím, buďme v debatě věcní a korektní. Děkuji.

**Místopředseda PSP Patrik Nacher:** Děkuji za dodržení času. Teď to bylo zase až moc rychlé. Další faktická poznámka – Eliška Olšáková, připraví se Jan Berki. Ale počkejte, paní poslankyně, já to musím tady vynulovat. Ono to tady takhle vždycky funguje a nefunguje. Teď vám tam hážu 2 minuty.

**Poslankyně Eliška Olšáková:** Děkuju za slovo. Já bych si dovolila vaším prostřednictvím reagovat na svoji kolegyni paní Volfovou. Já jsem v podstatě ráda, že se ta diskuse dostala do takových jako reálných dimenzí. Já bych chtěla říct, že digitalizace stavebního řízení a novela stavebního zákona jsou dvě rozdílné věci. Souhlasím s vámi, že digitalizace se nepovedla, ale neznamená to, že byl špatně připraven stavební zákon. My jsme stavební zákon v minulém volebním období tady prohlasovali i s koalicí i s opozicí, to znamená i s kolegy z hnutí ANO. A samozřejmě byly rezervy, mohlo se počkat a po dvou letech působení zákona udělat reforma. Teďka ta norma, která přichází bez, to budu mluvit o tom ve svém projevu, nebudu s tím teďka tady zdržovat, přichází bez mezirezortního připomínkového řízení, bez komunikace s odborníky a v podstatě neřeší digitalizaci. To, o čem vy jste tady mluvila, tak vlastně zákon, který je tady dneska navržen, se digitalizace vůbec nedotýká, ba naopak ji ještě odsunuje. Takže to bych jenom chtěla říct.

Souhlasím s tím, že digitalizace se nepovedla, ale stavební zákon, který tady byl nebo tedy ještě v současné době platí, nebyl špatně připraven. A na druhou stranu to, co se teďka připravuje, tak oslabí ještě více ta pracoviště a podle těch průzkumů, které jsou, tak je otázka, kdo na těch pracovištích v podstatě bude pracovat, protože je nějaká analýza, kterou dělalo Sdružení místních samospráv, myslím, že i Česká komora architektů, a tam se to spíš line k tomu, že tam ti pracovníci spíš nebudou. Děkuju.

**Místopředseda PSP Patrik Nacher:** Děkuji paní, poslankyně za dodržení času. Nyní na faktickou přijde Jan Berki, připraví se Lukáš Vlček a Renáta Zajíčková. Pane poslanče, počkejte, vy jste byl moc energický. A můžete.

**Poslanec Jan Berki:** Děkuju. Já jenom na začátek na odlehčení na kolegu Krňanského, vaším prostřednictvím. Myslím, že ne, každý pirát je u Pirátské strany a stejně tak ne každý, kdo řídí auto je Motorista a chce něco pro sebe.

Útočit tady na kolegu, který se v tuhle chvíli nemůže bránit, nevím, jestli je úplně korektní, a myslím, že taky v tom veřejném prostoru bylo poměrně dost informací k této situaci, tak to, jakým způsobem jste to zjednodušil, mi nepřijde úplně fér.

Ale to co jsem chtěl vaším prostřednictvím reagovat na kolegyni Volfovou, v zásadě shrnula poměrně hezky Eliška Olšáková. Tu implikaci dělat opačným směrem, to znamená to, že – a já tu taky nejdu hájit tu digitalizaci stavebního řízení, že z toho automaticky plyne, že byl špatně připraven zákon, to prostě neplatí.

**Místopředseda PSP Patrik Nacher:** Děkuji. Vy jste nepoklesl hlasem, tak jsem myslel, že budete ještě pokračovat, pane kolego. V této chvíli je na řadě Lukáš Vlček, připraví se Renáta Zajíčková a Jitka Volfová. A vaše 2 minuty.

**Poslanec Lukáš Vlček:** Děkuju za slovo, 2 minuty mi budou stačit. Jsem rád, že – a já děkuju kolegyni Volfové, protože tu debatu konečně vracíme do nějaké věcné roviny, a děkuji za to, vaším prostřednictvím, pane předsedající, protože právě přesně ono to nahrazuje to, co tady chybělo a to, co bohužel tomuto tisku chybělo od začátku, a to je opravdu nějaká věcná debata s odborníky, která opravdu byla pouze a pouze jenom povrchní, tedy pokud si ji odbydeme tady faktickým, a máme asi hodně času, já jsem za to rád, budu se tady tomu rád věnovat opravdu několik večerů, tak to rád v těch faktických povedu. Ale každopádně uvědomme si, že ta rovina stavebního řízení opravdu není pouze v té rovině digitalizace, taktéž já jakožto zástupce té předchozí vládní většiny říkám, že digitalizace se nepovedla, taktéž ale zato někteří vyvodili právní nebo politickou odpovědnost, a tak by to v politice mělo být.

Já už jsem to říkal včera, že budu velmi zvědav, jakým způsobem, pokud zde máme od řady odborných organizací jasné argumenty, protože toto není dobře připraveno, kdo tedy potom tu politickou odpovědnost bude z toho vyvozovat. Já se obávám, že – a to potom může zase skončit jenom nějakým srdceryvným videem na sítích a vlastně to bude tak všechno. Já bych hrozně rád, abychom tu debatu rozdělili právě v otázkách stavebního řízení do několika rovin, a to není jenom samotná rovina toho zákona, který tedy čítá 42 jednotlivých norem, ale i do té samotné roviny digitalizace, ale i té samotné procesní roviny, která je právě vedena těmi lidmi, kteří ten stejný zákon vykonávají. Taktéž já jsem byl v situaci, kdy pode mě ten stejný zákon mnoho a mnoho let to určitým způsobem spadal v tom dvojkolejném režimu modelu státní správy a samosprávy, a taktéž já od těch lidí opravdu slýchávám velmi silné obavy, že ten systém prostě nebude fungovat. A není to jenom v tom úřadu, který je mi domovským, ale samozřejmě i z těch dalších, z kterých se ke mně ty věci dostávají tolik. Já tady končím ty 2 minuty, já se ještě mnohokráte přihlásím a budu rád za tu věcnou debatu. Děkuju.

**Místopředseda PSP Patrik Nacher:** Čas! Nyní pozvu paní poslankyni Renátu Zajíčkovou, připraví si Jitka Volfová a zapojí se i Karel Haas.

**Poslankyně Renáta Zajíčková:** Mně to nedá, já to musím zase hodit zpátky trošku do té politický roviny, protože mě tady nadzvedlo to, co říkal předřečník pan Krňanský, prostřednictvím vás, pane předsedající, kdy vlastně řekl, že očekává, že se mu omluvíme nebo že se vám omluvíme za to, že jsme vás nazvali diletanty. Tak já bych vám jenom chtěla připomenout, vážení, že minulé volební období jste tady na tenhleten mikrofon na nás řvali a označovali jste nás novou totalitou. A vychutnávali jste si to tady a řvali jste to od rána do večera. A takhle jste nás osočovali a nikdo se nám neomluvil.

A k paní kolegyni Šebelové. Já oceňuju, jak tady promluvila, jak kultivovaně tady mluvila, věcně, srozumitelně, s úsměvem. A kéž bychom my všichni udělali takový pokrok, jako udělala ona. Já jí za její projev tady chválím. (Potlesk opozičních poslanců.)

**Místopředseda PSP Patrik Nacher:** Děkuji za dodržení času. Teďka, nyní je na řadě Jitka Volfová, připraví se Karel Haas. Vaše 2 minuty.

**Poslankyně Jitka Volfová:** Já bych jen zareagovala na paní poslankyni Olšákovou a na pana Berkiho, na pana poslance Berkiho, prostřednictvím předsedajícího. Samozřejmě vím, že na pořadu dne není digitalizace. Jen jsem chtěla do kontrastu ten název, ten paskvil. Já to tady nerada opakuju. Já nemám ráda takováto slova, ale jenom jsem to chtěla prostě přirovnat k tomu, že opravdu to nebylo fajn.

A tady na kolegyni, která mluvila přede mnou, tak jenom to je právě ten rozdílný pohled na věc, jak vnímáme některé projevy. A myslím si, že opravdu, když to házíme stále do politické roviny a ta napadání neustále probíhají... Já jsem tady poprvé v Poslanecké sněmovně. Musím říct, že mě to velmi překvapilo a myslím si, že když se na nás lidé koukají zvenku, tak si musíme myslet své a myslím si, a věřím, že právě proto, že důvěra v politiky z těchto důvodů není a do budoucna nebude, a lidé k volbám chodit už vůbec nebudou, protože je tady pár poslanců, kteří opravdu mluví věcně. Teď tady koukám na pana poslance Haase, velmi si toho vážím, jsou tady další, ale někteří opravdu tady pouze exhibují. A já jsem si řekla, že to nikdy dělat nebudu. Možná k tomu sklouznu, ale doufám, že ne. A myslím si, že je to naprosto zbytečné a zdržuje nás to všechny od práce. Děkuji.

**Místopředseda PSP Patrik Nacher:** Děkuji za dodržení času. Nyní pozvu k mikrofonu Karla Haase, který se zapojí do rozpravy, připraví se Lukáš Vlček a Eliška Olšáková. Vaše 2 minuty.

**Poslanec Karel Haas:** Děkuji mnohokrát za slovo, vážený pane místopředsedo. Ač jsem byl teď osloven, tak věřte tomu, že nejdu reagovat na to poslední oslovení, já jsem byl přihlášen už dřív, jak i avizoval pan místopředseda. Já jdu zcela neosobně a věřím, že fakticky reagovat. Shodou okolností, vaším prostřednictvím, na paní starostku a kolegyni poslankyni Volfovou, na to její první vystoupení. Paní kolegyně, vy jste mluvila o tom, jestli jsme věděli, nebo nevěděli v zásadě, jakou verzi stavebního zákona jsme schvalovali v tom minulém volebním období, a bylo to od vás jakoby kritické. Já jsem tady o tom mluvil v prvním čtení. Tu velkou novelu stavebního zákona, a teď rozlišme legislativu a digitalizaci, já jsem vždycky říkal, že digitalizace byla jedním z top tří průšvihů naší vlády. Takhle to říkám naplacato. Ale vy jste tady kritizoval tu legislativu. Pro velkou novelu stavebního zákona v minulém volebním období hlasovalo 161 z tehdy 166 přítomných poslanců. Čili byla schválena opravdu průřezově. Žádný z poslanců, a já to jenom shrnuji fakticky, žádný z poslanců hnutí ANO, z vašeho hnutí, nehlasoval proti, zdrželi se jediní dva kolegové – kolega Ondřej Babka a kolega pan Tureček, prostřednictvím, byť nejsou přítomní, neoslovuji je, ale prostřednictvím pana předsedajícího.

Tím chci jenom shrnout, že podle mého názoru to, co si kritiku zaslouží z toho minulého volebního období, je to uživatelské rozhraní, všech těch pět aplikací, které měly dohromady tvořit digitální stavební řízení. To opravdu doručeno nebylo a kritiku si to zaslouží, ale určitě, a to je ta moje výhrada k vám, nekritizovat tu legislativu. Vždycky všechno může být lepší, ale prošla průřezově touto Sněmovnou, a já jsem za to rád. Aktivně, vlastně s výjimkou 2 zdržujících se kolegů, všemi hlasy vašeho hnutí, aktivně pro. Děkuju.

**Místopředseda PSP Patrik Nacher:** Děkuji za dodržení času. Nyní pozvu k řečništi Lukáše Vlčka s faktickou poznámkou, připraví se Eliška Olšáková a Jan Berki. Než sem dorazíte, pane poslanče, přečtu jednu omluvu. Michaela Šebelová se omlouvá od 21 do 23 z pracovních důvodů a vám spouštím 2 minuty.

**Poslanec Lukáš Vlček:** Děkuju, pane předsedající. Já budu reagovat na několik kolegů a začnu kolegou Haasem. On má pravdu, přesně tak to bylo. Oba dva jsme tady seděli, na těch věcech jsme společně pracovali, našli jsme společnou řeč a ten výsledek asi mluví vlastně za vše. Ty počty si může každý vlastně ve stenozáznamech dohledat, a to nebyla jenom otázka projednávání té stavební legislativy, ale bylo to vlastně i jiné legislativy, která s tím stavebnictvím přece je propojena, ať to byl například liniový zákon, vlastně poté přejmenován na zákon o strategických stavbách, a ten proces byl vlastně úplně stejný. A také jsme dokázali si k tomu sednout k jednomu stolu, dokázali jsme poslouchat odborníky, a to se vlastně v tomto případě neděje. My jsme k tomu udělali v poslední době několik kulatých stolů a k vyjádření těch odborníků já se milerád za chvilku zase vrátím zpátky, ale třeba v tom liniovém zákoně to byl přesně ten typický příklad. Prostě vytipovali jsme jasné typy staveb, řekli jsme si, jakým způsobem můžeme procesy zjednodušit. Vzal se ten původní zákon a řada těch věcí se opravdu povedla a tady pro to hlasovala většina Sněmovny. Dneska ty stavby se, samozřejmě řada z nich realizuje, mají povolení, posouvají se kupředu, a tak by to prostě podle mě mělo vlastně fungovat. A to je to, že nejdeme cestou nějaké revoluce za každou cenu, bez RIA, bez LRV, bez mezirezortního připomínkového řízení, ale prostě jdeme cestou nějaké evoluce, a to je, že postupem času a na základě jasné analýzy koukáme na to, co nefunguje, a to nějakým způsobem napravujeme. A to nebyla jenom věc tedy toho samotného liniového zákona. To samé jsme udělali třeba v energetických zákonech nebo v energetickém zákoně, kde to opět bylo o zrychleném povolovacím procesu na významném energetické stavby. A opět to bylo o tom, že jsme si k tomu v pohodě sedli, v klidu jsme si ty věci vyříkali, poradili jsme se s odborníky a pak jsme pro to našli obecnou shodu. A tak by to mělo fungovat. Děkuju.

**Místopředseda PSP Patrik Nacher:** Čas! Děkuji. Dvě faktické poznámky ještě – Eliška Olšáková a Jan Berki. Vaše 2 minuty, paní poslankyně.

**Poslankyně Eliška Olšáková:** Děkuji. Mně to ještě nedá, abych se nevrátila a prostřednictvím pana předsedajícího ještě se neobrátila na paní kolegyni Volfovou. Když byl nahrán tady tento poslanecký návrh, jestli si vzpomínáte, na přelomu roku, tak jsme byli všichni zděšeni, jaká obrovská norma se nahrála poslaneckým návrhem. My jsme dodneška, a věřím, že vy taky ne z koaličních řad, nezjistili lobbistickou stopu toho zákona. A potom vlastně po nějakém čase projednávání jsme zjistili, že vlastně vám to nevyhovuje, že jste nahráli pozměňovací komplexní návrh, který má tisíc stran, takže ta norma prostě není jednoduchá ani pro vás a obdivuji, jestli to tedy obhajujete.

A taky já jsem se včera chystala na vystoupení, trošku se mě to nepodařilo v tom čase, ale vy jste vlastně do včerejška neměli nahrán ani komplexní pozměňovací návrh, aby byl veřejně dostupný, aby odpovídal standardům transparentního legislativního procesu, to znamená s vyznačením změn a odůvodnění, tedy ten materiál v plné šíři, který byl předložen hospodářskému výboru. Takže to znamená, že ten materiál se k té veřejnosti a k lidem, kteří se zajímají o to, dostal teprve včera, a to děkuji, to bylo prostřednictvím paní zpravodajky, paní kolegyně Ožanové. Takže já opravdu obdivuju, kdo vlastně takto hájí tu normu, která tady je, protože je to velmi složité a dost nepřehledné a myslím si, že komplikované. Nechci protahovat, protože k tomu mám svoje vystoupení. Děkuju.

**Místopředseda PSP Patrik Nacher:** Děkuji za dodržení času. Jsou před námi 3 faktické. Jako první vystoupí Jan Berki, připraví se Zuzana Ožanová a Ivan Adamec.

**Poslanec Jan Berki:** Já to jenom doplním. My jsme původně protestovali proti té analogii mezi digitalizací a tou legislativou, protože to jsou skutečně dvě různé věci.

Druhá věc je, upozorňujeme na kvalitu toho legislativního procesu, a to už tu zase říkala kolegyně Olšáková. Jestliže původní návrh má něco přes 800 stran a k tomu je komplexní pozměňovací návrh, který má dokonce víc stran a ne o pár, víc stran než původní návrh, tak to je prostě známkou kvality toho původního návrhu. To se na mě nezlobte, to tak je.

A jenom k té digitalizaci. Já zase, abychom tu úplně Ivana Bartoše nepřibíjeli na kříž, nejdu hájit ten proces, protože z mého pohledu ale jediná nebo ta největší chyba byla, že nakonec nepřistoupil na to, co jsme mu všichni nabízeli: pojďme to odložit, protože to potřebuje více času. Nechci říct, že tam všechno bylo úplně blbě, prostě to potřebovalo více času a tou chybou zásadní z mého pohledu bylo to, že se to neodložilo.

**Místopředseda PSP Patrik Nacher:** Děkuji za dodržení času. Nyní vystoupí Zuzana Ožanová, připraví se Ivan Adamec. Paní poslankyně, počkejte.

**Poslankyně Zuzana Ožanová:** Děkuji, vážený pane předsedající. Já v této debatě nevystupuju, jsem v roli zpravodaje. Musím však reagovat na kolegyni Olšákovou. Víte, že věci, které se nahrávají na výborech, není vůbec povinnost a obvykle to nikdo nedělá, že by se nahrávaly do systému. Tady právě proto, že je to složitá materie, jsme udělali něco, co tady není běžnou praxí, a nahráli jsme ten komplexní pozměňovací návrh i s odůvodněním do systému Sněmovny. Přihlašovat se samozřejmě k němu nebudu. Nenahrála jsem ho proto, abych se přihlašovala, ale pouze proto, aby skutečně veřejnost, přestože naše žádné vnitřní předpisy, ani s prominutím tradice toto vlastně se nedělá v této Sněmovně, tak právě proto, aby veřejnost mohla se s tímto řádně seznámit. Takže prosím, abyste nám to nevyčítal. Vím, že jste mi potom poděkoval, vašim prostřednictvím, pane předsedající, ale nicméně tady jsme udělali něco, co není standardní, a já už v minulém volebním období jsem na tuto praxi poukazovala, že to, co projednáváme ve výborech, a jsou pozměňovací návrhy předkládány výborům po prvním čtení, nebývají nahrány v systému a nejsou v dostupnosti novinářům, veřejnosti vůbec nikomu, že tato praxe není vhodná. A protože jsem tuto praxi kritizovala, tak jsem se dovolila právě i samozřejmě s kolegy, co zpracovávali tento zákon, protože to bych já nebyla schopna udělat celé sama, tuto praxi aspoň nastínit, že bychom ji mohli změnit. Takže nevyčítejte nám to, že to bylo až teď nahráno. Praxe je v současnosti ve Sněmovně taková, že se tyto věci nenahrávají.

**Místopředseda PSP Patrik Nacher:** Děkuji za dodržení času a kolem mikrofonu už krouží Ivan Adamec, který má poslední faktickou poznámku. Vaše 2 minuty.

**Poslanec Ivan Adamec:** Děkuji. Vážený pane předsedající, dámy a pánové, já budu stručný. Tak tohohle jsem se přesně obával, tohoto typu diskuse a faktických poznámek, které prostě končí pak i u osobních útoků a podobně. Já jsem chtěl říct jednu věc. Budu o tom mluvit ve vystoupení, to odhaduju tak ve čtyři, v pět ráno, až se dostanu na řadu, nevím, jestli to budete poslouchat, ale co se týká toho takzvaného komplexního pozměňovacího návrhu, to nebyl komplexní pozměňovací návrh, tak jak byl podán do hospodářského výboru. To byl komplexní souhrn pozměňovacích návrhů předkladatelů. A ještě ne všech. A tento souhrn, komplexní souhrn, prostě my bychom nebyli schopni vůbec se něčeho dobrat, kdyby to takhle bylo. Takže ten komplexní pozměňovací návrh se stal až na můj návrh na hospodářském výboru, abychom se měli vůbec od čeho odpíchnout.

To, jestli to je takhle správně, tak samozřejmě ta diskuse tady je v pořádku, ale na druhou stranu řekněme si na rovinu, i my jsme používali poslanecké návrhy ne úplně u jednoduchých návrhů zákonů, jako byl třeba lex plyn, to vůbec nebylo jednoduché. Je pravda, že tam ta dohoda nakonec byla, protože oni většinou technicky zaměření lidé se dohodnou lépe než ti humanisti. To tak prostě je. A věřme tomu, že pokud budeme chtít, tak nakonec ten stavební zákon dotáhneme do hlasování. Jinak já tvrdím, že stavební zákon už léta je snad prokletý, protože každá vláda, která se o to snažila a snažila se hodně, tak to skončila jako vždycky. Děkuji. (Potlesk poslanců ODS.)

**Předseda PSP Tomio Okamura:** Nyní tedy se hlásí paní poslankyně Julie Smejkalová a připraví se pan poslanec Bohuslav Niemiec. Tak, paní poslankyně, máte slovo. Konečně jste se dostala ke slovu, že ano?

**Poslankyně Julie Smejkalová:** Vážené kolegyně, vážení kolegové, člověk vlastně ani nemusí být právník, právnička, architekt, architektka nebo developer, aby mu po chvíli došlo, že kolem toho stavebního zákona něco strašně nesedí. Ono totiž úplně stačí chvíli jenom poslouchat, jak o tom tahle vláda mluví, a pak si ten návrh otevřít a začíst se do něj. A najednou člověku začne docházet, že ta slavná revoluce ve stavebnictví je ve skutečnosti jenom další obrovský experiment, který někdo vymyslel někde u stolu, ale řešit ho budou úplně jiní lidé někde úplně jinde.

Na tomto stavebním zákonu je úplně absurdní už jenom to, že k němu vlastně pořádně neexistuje kvalitní RIA, tedy normální studie dopadů, která by seriózně popsala, co to celé udělá s fungováním obcí, úřadů, stavebního řízení nebo veřejných rozpočtů. Stát chce překopat jeden z nejzásadnějších systémů v celé republice, ale vlastně pořádně neví, jaké budou následky. A ještě se u toho tváří strašně sebevědomě, jakoby to měl všechno strašně dobře spočítáno.

A o to horší je způsob, jakým to celé vzniklo, protože když člověk slyší, že údajně probíhala široká debata s odbornou veřejností, tak by skoro čekal, že na tom návrhu existuje nějaká větší shoda. Jenže ona neexistuje v praxi skoro žádná. Kritiku nevznáší jen opozice nebo pár lidí někde na sociálních sítích. Kritiku mají prakticky všechny důležité organizace, které se kolem stavebního práva a fungování samospráv dlouhodobě pohybují. Například Sdružení místních samospráv, Svaz měst a obcí, Hospodářská komora, Česká komora architektů, Česká komora autorizovaných inženýrů ve stavebnictví. A to nejsou jen lidé, kteří si ráno otevřeli internet a rozhodli se proti všemu nadávat. To jsou starostové, starostky, architekti, architektky, projektanti, projektantky, lidé ze stavebních úřadů a z podnikatelského prostředí, kteří přesně vědí, jak samotné stavební řízení v Česku funguje v realitě, nejenom na nějaké tiskové konferenci nebo na papíře.

Milý kolektive poslanců a poslankyň, kteří tento návrh předkládáte, obešli jste legislativní proces, vykašlali jste se na všechny kritické komentáře, ignorujete zpětnou vazbu z území a dnes se snažíte lepit sněmovní tisk 67 jakýmisi komplexními pozměňovacími návrhy, což je doopravdy vlastně jenom další nový zákon. Opakujeme tady pořád dokola ty samé věci a právem, že ten zákon není dobře připravený, že stát podcenil jeho dopad na samosprávy, že malé obce nebudou mít kapacity to zvládnout a že městské části Prahy budou úplně vyňaty z celého rozhodovacího procesu při pořizování územního plánu. Celý systém působí strašně uspěchaně a nedotaženě. Jenže místo normální debaty tady člověk sleduje hlavně obrovskou snahu všechno rychle protlačit a odškrtnout si další hotovou reformu.

Na takové radnici malé obce sedí pár lidí. Starosta nebo starostka dopoledne řeší třeba vodovod, za hodinu jim někdo volá kvůli spadlému stromu, pak přijde problém s dotací, večer hasiči a mezitím se ještě snaží řešit rozvoj obce, rozpočet a zkrátka běžný provoz. A přesně do tohohle prostředí stát pošle další obrovskou administrativní zátěž a bude dělat překvapeného, že to někde nefunguje? A když se podíváme k nám do Prahy, tak by v extrémním případě územní plán měla výjimku měnit pouze Rada hlavního města Prahy? To je naprosto šílené! A pak se zase budou psát články o tom, jak v některých regionech trvá získat stavební povolení strašně dlouho. Jinde se bude psát, že je zase celý proces úplně netransparentní. A proč se to bude dít? Bude to proto, že stát znovu vymyslel systém, který odpovídá maximálně tak představám vybraných hráčů na trhu. No a přesně tím vznikne dvourychlostní Česko. Velká města si s tím pravděpodobně ještě nějak poradí, protože budou mít právníky, právničky, externisty, externistky, zkrátka kapacity na to se tím zabývat, ale malé obce budou dál ztrácet dech a postupně se dostanou do situace, kdy nebudou schopny některé věci vůbec normálně zvládat.

Jak jsem již říkala, do toho zákon nastavuje nebezpečné prostředí pro korupci a zákulisní dohody, protože čím složitější a méně přehledný systém existuje, tím víc začnou rozhodovat kontakty, peníze a známosti. A člověk ani nemusí být cynický, aby mu došlo, že komplikovaný systém vždycky nejvíc vyhovuje těm nejsilnějším hráčům. Takový normální člověk, který chce třeba postavit dům pro rodinu nebo opravit starý dům po rodičích, nebude mít armádu právníků, právniček, poradců a poradkyň, nebude mít člověka, který obvolá úřady a zařídí výjimky, a nebude mít ani čas studovat stovky stran nových a nových paragrafů a hledat skuliny v systému. Velký developer ale ano.

A přesně proto to na mě celé působí jako takový lex developer, ne jako zákon pro normální lidi, kteří chtějí normálně bydlet a normálně stavět. Obyčejný člověk totiž nepotřebuje další komplikace, nepotřebuje pocit, že bez právní kanceláře si dneska nepostaví ani plot. Potřebuje jednoduchý a předvídatelný systém. Přijít na úřad, dodat tam dokumenty a vědět, že pravidla platí pro všechny stejně. Jenže přesně tenhle pocit ten návrh bohužel vůbec nedává a situaci, která aktuálně není optimální, ale vůbec nezlepšuje. Naopak, čím víc se o tom člověk baví s lidmi z praxe, tak tím víc cítí obrovskou frustraci. A možná nejhorší na tom všem je ta arogance vůči lidem, kteří na problémy upozorňují už od začátku. Místo normální debaty se samosprávami, architekty, architektkami, projektanty, projektantkami a profesními organizacemi vznikl text, který působí, jako by ho někdo psal zavřený v kanceláři, bez kontaktu s tím, jak věci doopravdy fungují v reálném životě.

A pak se všichni strašně diví, že tomu lidé nevěří. Jenže jak by taky mohli? Ten zákon nepůsobí jako promyšlená reforma, která u nás konečně rozhýbe stavebnictví. Působí to jako uspěchaný legislativní experiment, který se teď někdo snaží za každou cenu dotlačit do cíle, aby mohl říct, že splnil plán. Jenže dělat něco rychle ještě neznamená dělat to dobře. Tenhle zákon prostě dobře napsaný není a je to strašně nefér vůči lidem, kteří chtějí normálně stavět a normálně bydlet. Celé se to mělo dávno vrátit na začátek. Sednout si se samosprávami, s odbornými svazy, s lidmi ze stavebních úřadů a normálně poslouchat, co říkají oni, protože zákon, kterému nevěří skoro nikdo, kromě těch, co ho napsali, opravdu nemůže fungovat dobře. A jestli se někdo tváří, že tohle je ta moderní a promyšlená reforma stavebnictví, tak se asi nikdy nebavil s lidmi, kteří to budou muset v reálu celé odnést.

Děkuju a vzhledem ke zmíněným chybám a nedostatkům daného zákona si myslím, že bychom měli mít čas na jeho pořádné projednání, a proto navrhuji přerušení projednávání tohoto tisku o rok do 28. 5. 2027. Děkuju

**Předseda PSP Tomio Okamura:** Ano, tak tady vidím zájem o protinávrhy. Počkejte. Takže do 28. 5. kolikátého roku? (Poslankyně Smejkalová: 2027.) 2027. Tak to je tedy paní poslankyně Smejkalová. Počkejte, já si to pomalu poznamenám, abych se nespletl. Takže prosím. Pan poslanec Kott a následně má protinávrh paní poslankyně Ožanová. Tak prosím.

**Poslanec Josef Kott:** Děkuji pěkně za slovo, pane předsedo. Dobrý večer všem. Já přiznávám, že některé malé nedostatky tam jsou, ale ty určitě poopravíme v pozměňovacích návrzích, a proto bych si dovolil navrhnout přerušení tohoto bodu do 21.40 hodin.

**Předseda PSP Tomio Okamura:** Paní poslankyně Ožanová má návrh. Tak prosím.

**Poslankyně Zuzana Ožanová:** Děkuji. Vážený pane předsedo, já si dovolím také navrhnout procedurální návrh na přerušení, a to do 21.55 hodin.

**Předseda PSP Tomio Okamura:** 21.55. Pan poslanec Lang.

**Poslanec Hubert Lang:** Děkuju, pane předsedo. Také bych navrhl procedurální přerušení tohoto návrhu do 21.55 hodin. Děkuji.

**Předseda PSP Tomio Okamura:** Takže máte stejný návrh jako paní poslankyně Ožanová?

**Poslanec Hubert Lang:** 56 minut, se omlouvám.

**Předseda PSP Tomio Okamura:** Ano, ano. Já jsem si říkal. Tak pojďte.

**Poslanec Lubomír Wenzl:** Dobrý večer. Já navrhuji čas přerušení do 22.30 dnešního dne. Děkuji.

**Předseda PSP Tomio Okamura:** Takže pan poslanec Wenzl – 22.30. Tak. Pan poslanec... Ano.

**Poslanec Igor Hendrych:** Děkuji za slovo, vážený pane předsedo. Já navrhuji přerušení schůze do 21.57 hodin.

**Předseda PSP Tomio Okamura:** Do 21 hodin 53 minut. Já si myslím, že jsme tady. Takže odhlásit? Já vás odhlásím. Přihlašte se znovu svými hlasovacími kartami. Takže máme tady návrhy a první hlasujeme o protinávrzích.

Takže pan poslanec Hendrych – přerušit ho 21.53.

Zahajuji hlasování. Kdo je pro? Kdo je proti?

Hlasování číslo 135 , přihlášeno 91 poslanců, pro 19, proti 67. Návrh byl zamítnut.

Pan poslanec Wenzl navrhuje přerušit do 22.30.

Zahajuji hlasování. Kdo je pro? Kdo je proti?

Hlasování číslo 136 , přihlášeno 91 poslanců, pro 18, proti 64. Návrh byl zamítnut.

Pan poslanec Lang navrhuje přerušit do 21.56.

Zahajuji hlasování. Kdo je pro? Kdo proti?

Hlasování číslo 137 , přihlášeno 91 poslanců, pro 20, proti 58. Návrh byl zamítnut.

Paní poslankyně Ožanová navrhuje přerušit do 21.55.

Takže já zahajuji hlasování. Kdo je pro? Kdo je proti?

Hlasování číslo 138 , přihlášeno 92 poslanců, pro 22, proti 58. Návrh byl zamítnut.

Pan poslanec Kott navrhuje přerušit do 21.40.

Zahajuji hlasování. Kdo je pro? Kdo je proti?

Hlasování číslo 139 , přihlášeno 92 poslanců, pro 24, proti 57.

A paní poslankyně Smejkalová navrhuje přerušit do 28. 5. 2027.

Zahajuji hlasování. Kdo je pro? Kdo je proti?

Hlasování číslo 140 , přihlášeno 92 poslanců, pro 23, proti 64. Návrh byl zamítnut.

Takže nyní budeme pokračovat a vystoupí pan poslanec Bohuslav Niemiec... Ano, s přednostním právem předseda klubu TOP 09 Jan Jakob. Ano.

Přečtu omluvu ještě. Kovářová Věra se omlouvá od 21.30 z osobních důvodů.

Tak prosím, máte slovo. **

**Poslanec Jan Jakob:** Děkuju, pane předsedo. Vážené kolegyně, vážení kolegové, jsem rád, že je vás tady tolik teď, dokonce jsme byli i usnášeníschopní. Možná pro kolegu Krňanského, jestli tady někde ještě je – je, výborně – tak vy jste tady argumentoval těmi počty starostů v klubech. Tak já jsem byl taky 12 let starostou, pořád jsem zastupitelem a úplně bych se tím taky nechlubil, že máte v řadách něco kolem 20 starostů. Když jsem se pak stal poslancem, tak opravdu jsem pak neměl dobrý pocit z toho, protože ono to nejde úplně stíhat všechno dohromady. Neměl jsem dobrý pocit z toho, že bych opravdu mohl v rámci toho času, co má člověk k dispozici, věnovat tolik kolik bych si přál, kolik bych chtěl. Takže to spíš svědčí o tom, že kumulujete funkce. Já jsem se pak rozhodl již na starostu nekandidovat, proto jsem teď, zastupitelem, byť předsedou finančního výboru. Takže se tím moc nechlubte, jak kumulujete funkce a jak pak nejste schopni se věnovat pořádně svým funkcím.

Tak. Ale dovolte mi, abych vystoupil také k té projednávané materii, tedy k novele stavebního zákona, a zejména také teď v druhém čtení ke komplexnímu pozměňovacímu návrhu, který prošel hospodářským výborem. A možná hned na začátek, já teď to vystoupení pojmu tak trochu obecně, pak tady máme části potom a možná dál v diskusi, protože je tam celá řada pozměňovacích návrhů, nejenom ten robustní, rekordní komplexní pozměňovací návrh, ale desítky, desítky dalších. A rád bych také je zhodnotil i z pohledu člověka, který v komunální politice působí, působil, člověka, který dělal starostu v době, kdy jsme přijali nový územní plán, přijali řadu regulačních plánů a studií a územněplánovací dokumentace, protože to je zcela zásadní a tady ty návrhy ten proces velmi radikálně mění.

Takže já už v tuhle chvíli spíš obecně jak k samotnému návrhu, tak k tomu komplexnímu pozměňovacímu návrhu, a tak jak tady zaznívá, tak je zcela evidentní, že to není běžná novela, není to úprava několika paragrafů. O tom nakonec vypovídá i ten rozsah předkládané materie. Je to opravdu rozsáhlý přepis fungování stavebního práva v České republice. Přepis fungování – to, na jsem narážel – územního plánování a také přepis vztahů mezi státem, obcemi, kraji, stavebními úřady, dotčenými orgány a občany. Děkuju, že je tady trošku nižší hladina hluku. Já vždycky takhle zpomalím, když cítím, že už je to trochu nad míru. A vláda, respektive tedy vládní většina zastoupená předkladateli, se to snaží prosadit způsobem, který je podle mého názoru ale naprosto, naprosto nepřijatelný, protože máme před sebou obří legislativní zásah předložený jako poslanecký návrh a následně k tomu ještě obří, větší, ještě gigantičtější komplexní pozměňovací návrh o více než tisíci – více než tisíci stranách.

To znamená, že vláda, tedy její představitelé, poslanci, kteří to navrhují, chtějí obejít standardní legislativní proces a vlastně hned dvakrát. Poprvé tím, že zásadní změnu stavebního práva nepředložili jako vládní návrh zákona, a podruhé tím, že teprve v hospodářském výboru přišel komplexní pozměňovací návrh. Ano, kvituji, že tedy byl nahrán do systému. Já také nahrávám svoje pozměňovací návrhy v okamžiku, kdy je mám zpracovány, zpravidla ihned po prvním čtení do systému tak, aby se s nimi každý mohl seznámit, a to jsou většinou poměrně jednodušší pozměňovací návrhy. Rozhodně nečítají více než tisíc stran. Ano, pravda občas je mám i ve variantách, což dělám v naději, že třeba alespoň některá ta slabší varianta pro vás by mohla v koalici být přijatelnější. Zatím se tak nestalo. Hlasujete, jak tady říkáte, jako ta válcovací mašina, jak jste to říkalo tedy v minulém období, takže to dostáváte i v tomto.

Takže přišel ten komplexní pozměňovací návrh, který ale ve skutečnosti, celý návrh, ten původní, celý návrh prakticky mění a přepisuje. A já se proto ptám, kde je řádné mezirezortní připomínkové řízení, kde je standardní vypořádání připomínek obcí, krajů, profesních komor, ekologických organizací, urbanistů, architektů, stavebních firem a samozřejmě také veřejnosti. Kde je důkladné hodnocení dopadů této robustní regulace a změny? Kde jsou analýzy dopadů na veřejné rozpočty? Kde jsou analýzy dopadů na samotné samosprávy a kde je hlavně seriózní odborná debata? Nikde nic z toho se nestalo. Nic, protože všechno bylo schováno do poslaneckého návrhu a následně ještě překryto gigantickým komplexním pozměňovacím návrhem. A to považuji za mimořádně, mimořádně nebezpečný precedent, protože stavební právo, to není jednoduchá, natož okrajová agenda. To je oblast, která rozhoduje o tom, kde se bude stavět, jak rychle se bude stavět, jak budou vypadat naše města, jak budou chráněny ale také veřejné zájmy, jak bude chráněna krajina, jak budou chráněny obce a hlavně jak budou chráněna práva občanů. A přesně proto má být legislativní proces maximálně, maximálně transparentní. Jenže my tady bohužel sledujeme pravý opak. Je tady gigantický – rozměrem, rozsahem – materiál, jsou tady gigantické změny, a to všechno samozřejmě ponese také gigantické dopady. A zároveň tady ale zcela minimální veřejná kontrola.

Když se začne člověk tím návrhem detailně zabývat, zjistí jednu věc. Ten návrh je veden hlavní filozofií: co nejvíce oslabit brzdy, co nejvíce oslabit kontrolní mechanismy, co nejvíce zkoncentrovat rozhodování a co nejvíce upozadit ochranu veřejných zájmů ve prospěch rychlosti výstavby. A ano, každý z nás chce rychlejší výstavbu, každý z nás chce méně byrokracie, každý z nás chce, aby se nestavělo 10 let, ale rychlost nesmí být jedinou, jedinou hodnotou, protože stát, který rezignuje na rovnováhu mezi veřejnými zájmy, ochranou území, právy obcí a právy občanů, není efektivní stát. To je stát, který přestává být předvídatelný, a právě tímto směrem tento váš návrh bohužel míří.

A podívejme se například na samotnou filozofii toho návrhu. Do zákona se vkládají formulace nebo do toho odůvodnění, že znemožnit rozvoj sídel, hospodářství a veřejné infrastruktury nebo nepovolit záměr lze jen tehdy, není-li možné zajistit dostatečnou ochranu jiných hodnot podmínkami kompenzačními nebo zmírňujícími opatřeními. To na první pohled může znít celkem rozumně, jenže ve skutečnosti jde zásadní hodnotový posun, protože ochrana veřejných zájmů přestává být rovnocennou hodnotou a začíná být překážkou, kterou je třeba minimalizovat. A to je velmi, velmi nebezpečné.

Stejně tak mě mimořádně znepokojuje trend koncentrace pravomocí. Vznikají nové úřady rozvoje území. Dochází k zásadní reorganizaci celého systému a současně se výrazně oslabuje role samotných dotčených orgánů. Stavební úřad má nově v řadě případů nahrazovat rozhodnutí, závazná stanoviska a jiné úkony dotčených orgánů. Jinými slovy, specializované orgány ochrany životního prostředí, ochrany památek, ochrany veřejného zdraví a další odborné instituce mají být fakticky zatlačeny do pozadí. A já se ptám, opravdu si myslíte, že jeden úřad bude odborně kvalitně suplovat všechny tyto specializované kompetence? Opravdu si myslíte, že tím vznikne kvalitnější rozhodování nebo vznikne hlavně větší tlak na to, aby se rozhodovalo rychleji a méně důkladně? Protože přesně tohle je reálné riziko.

Další mimořádně problematická část se týká samotného postavení obcí a samospráv. A to říkám, jak jsem i v úvodu svého vystoupení upozorňoval nejenom jako poslanec, ale jako člověk, který dlouhá léta působil a působí v komunální politice. Obce nejsou přece překážkou rozvoje, nejsou administrativní obtíží. Obce nesou odpovědnost za podobu svého území. Obce nesou odpovědnost vůči svým občanům. A právě proto musí mít silné postavení v rámci územního plánování. Jenže tento návrh jde zase přesně opačným směrem. Posiluje centralizaci, posiluje koncentraci rozhodování, posiluje státní aparát a oslabuje reálný vliv samospráv, a to pod záminkou efektivity. Jenže efektivita není v životě úplně všechno. Demokratická kontrola něco přirozeně stojí, veřejná debata také něco stojí, ale o to vy příliš nestojíte. Právo obcí hájit své území, to je taky důležitá záležitost. A stát, který začne tyto principy označovat, vlastně byť mezi řádky, za problém, se dostává na velmi nebezpečnou cestu.

Další věc, která mě velmi znepokojuje, je právní nepředvídatelnost celé konstrukce, protože ten návrh, jak tady zmiňujeme, je mimořádně rozsáhlý. Obsahuje obrovské množství nových definic, nové instituty, nové pojmy, kompetence, nové procesní vztahy a přitom není vůbec jasné, jak bude systém v praxi fungovat. Není jasné, jak budou řešeny kompetenční spory, jak bude fungovat metodické řízení, jaké budou personální nároky, jaké budou finanční nároky, kolik to celé bude vlastně dohromady stát a jak rychle bude možné systém personálně naplnit. A to je přesně ten velký další problém.

Vláda a předkladatelé vytváří iluzi jednoduchého řešení. Jenže ta realita potom bude úplně, úplně jiná, protože každý, kdo někdy pracoval ve veřejné správě, ví jednu věc. Čím složitější reorganizace, tím větší chaos v přechodném období. A tady se bavíme o reorganizaci, která se dotkne celé republiky, tisíců úředníků, tisíců řízení, tisíců staveb, tisíců investorů a samozřejmě i tisíců občanů. A přesto tady nevidíme odpovědi na základní otázky. Vidíme jen politický slogan: zrychlíme výstavbu. Jenže zrychlit výstavbu nejde tím, že rozbijete systém. Zrychlit výstavbu jde tím, že vytvoříte stabilní, předvídatelné a kvalitní prostředí, a to tady bohužel v tom návrhu rozhodně nevidím.

Další obrovský problém je kvalita. To, co tady zmiňujeme, kvalita legislativního procesu. A já to znovu zopakuji. Máme před sebou poslanecký návrh, následně komplexní pozměňovací návrh, který má přes tisíc stran a který v mnoha částech celý původní návrh přepisuje. To přece není normální legislativní proces. Tohle je legislativní chaos. A mě by opravdu upřímně zajímalo, kolik poslanců ten materiál skutečně detailně četlo, kolik poslanců skutečně analyzovalo všechny dopady. Ony ani vyčíslit nejdou. Kolik poslanců je schopno dnes přesně popsat všechny změny, které se tam zavádějí? Já mám obavu, že to nevědí ani mnozí z těch, co ten návrh podepsali.

Teď si představme tu druhou stranu, veřejnost. Představme si starosty, představme si menší obce, občany a vlastníky nemovitostí. Ti mají během velmi krátké doby pochopit obří změnu stavebního práva. To rozhodně není od vás seriózní přístup. To je legislativní smršť. A právě proto si myslím, že tento návrh měl opravdu projít standardním vládním procesem se všemi připomínkami, se všemi analýzami, se všemi propočty dopadů a se všemi odbornými diskusemi, které bohužel vůbec neproběhly, protože takto zásadní zásah do stavebního práva si nic menšího nezaslouží.

Zároveň také odmítám falešnou zkratku, kterou tak trochu cítím a mám pocit, že někteří se nám ji snaží podsouvat, že kdo kritizuje tento návrh, nechce stavět, nechce podpořit výstavbu. To ale rozhodně není pravda. Já chci rychlejší výstavbu, já chci dostupnější bydlení, já chci také efektivnější stát, ale nechci stát, který kvůli rychlosti rezignuje na kvalitu. Nechci stát, který kvůli rychlosti oslabí ochranu veřejných zájmů. Nechci stát, který kvůli rychlosti začne obcházet standardní legislativní proces. A přesně to se bohužel dnes děje.

Tato novela není jednoduchou technickou změnou. Je to velká, troufnu si říct mocenská změna, změna filozofie fungování státu, změna vztahu mezi státem a samosprávami, změna vztahů mezi investorem a veřejným zájmem. A právě proto bychom měli být maximálně opatrní.

Velmi problematická je i samotná argumentace předkladatelů, protože vytvářejí dojem, že hlavní překážkou výstavby jsou dotčené orgány samosprávy a veřejná kontrola. Jenže skutečnost je v realitě výrazně mnohem složitější. Hlavním problémem bývá nepřipravenost projektů, mnohdy nekvalitní dokumentace, ale z hlediska státu to, co má zabezpečit personální poddimenzování úřadů, nestabilita, dnes to vidíme, naprostá nestabilita legislativy, opakované změny systému, taky to tady padalo, že rušíte tím návrhem před rokem a půl zavedené jednotné environmentální stanovisko. Ano, problémem samozřejmě je i nefunkční digitalizace.

A co dělá tato novela? Další gigantickou reorganizaci, další zásadní přepis systému, další nejistotu, další tlak na úřady, další komplikace v rámci přechodných období. Já mám opravdu obavu, že výsledkem nebude zrychlení. Výsledkem bude chaos a následně další nezbytná novelizace, další opravy, další zásahy, další přepisování zákona, protože právě tak dnes bohužel vypadá a bude vypadat ještě víc české stavební právo. Tedy zahájíte další fázi permanentního experimentu, permanentní reorganizace a permanentního přepisování a stavebníci, obce i občané se v tom přestanou absolutně orientovat.

Ještě se musím zastavit u jedné věci, a to je koncentrace moci, protože návrh vytváří mimořádně silnou strukturu nových úřadů rozvoje území a současně výrazně oslabuje systém nezávislých kontrolních a odborných mechanismů. A to opravdu není detail. To je zásadní změna rovnováhy uvnitř veřejné správy. Jinými slovy, méně samostatných odborných vyjádření, více centralizace, více koncentrace rozhodování. A proto se ptám, je tohle opravdu ta správná cesta? Opravdu chceme takto silně centralizovaný model? Opravdu chceme, aby stát rozhodoval stále více shora a stále méně naslouchal konkrétním lidem v území? Protože územní plánování není jenom nějaká disciplína. To je otázka života těch obcí, života v obcích, to je otázka kvality veřejného prostoru, to je otázka budoucnosti měst, otázka rozvoje nebo budoucnosti krajiny, otázka dopravy a také otázka životního prostředí. A právě proto musí existovat rozumně nastavená rovnováha. Jenže tahle novela tuto rovnováhu narušuje.

Já si myslím, že české stavební právo potřebuje v tuhle chvíli hlavně stabilitu. Potřebuje předvídatelnost, potřebuje funkční digitalizaci, potřebuje personálně stabilní úřady, potřebuje kvalitní metodiku a hlavně potřebuje méně chaosu. A místo toho dostáváme další gigantický experiment. Experiment napsaný formou poslaneckého návrhu, experiment přepsaný tisícistránkovým komplexním pozměňovacím návrhem, experiment bez standardního legislativního procesu, experiment bez dostatečné odborné debaty, tedy vlastně bez žádné odborné debaty a bohužel také experiment s obrovskými dopady. Proto nemohu tento návrh podpořit, protože si myslím, že způsob jeho přípravy je mimořádně špatný, protože si myslím, že filozofie toho návrhu je nebezpečně jednostranná, protože jsem přesvědčen, že návrh oslabuje ochranu veřejných zájmů, protože si myslím, že návrh příliš centralizuje rozhodování, a protože si myslím, že návrh vytváří další legislativní nejistotu, a protože si myslím, že Česká republika potřebuje ve stavebním právu konečně stabilitu, nikoliv další obrovskou říkám gigantickou revoluci.

Tak tolik obecně tady k té obří materii a jsem připraven potom diskutovat i o jednotlivých pozměňovacích návrzích, o konkrétních dopadech. To si případně nechám na další část diskuse. Věřím, že tady budou i kolegové, kteří předkládají ty návrhy, tak je vysvětlovat, a to je důležitá debata a součást jednání ve druhém čtení, ale protože, jak jsem tady zmiňoval, ty rozsahy samotné materie a hlavně toho komplexního, ano, já myslím, že to není k smíchu, toho komplexního pozměňovacího návrhu, tak vyžaduje nějaký čas a odbornou diskusi minimálně jednoho měsíce, proto dávám procedurální návrh, abychom přerušili projednávání tohoto bodu do 8. července roku 2026, abychom měli alespoň ten měsíc nejenom my, ale i odborná veřejnost. Děkuju a prosím, aby se o tom procedurálním hlasování hlasovalo.

**Místopředseda PSP Patrik Nacher:** Já bych o procedurálním hlasování nechal hlasovat. Tak. Takže do 8. 7. – pan předseda Jakob. Viděl jsem zvednutou ruku. Nejprve Zuzana Ožanová. Jenom připomínám, že můžete mít jenom procedurální protinávrhy.

**Poslankyně Zuzana Ožanová:** Děkuji, vážený pane předsedající. Já dávám procedurální návrh na přerušení tohoto jednání do 22.13 hodin.

**Místopředseda PSP Patrik Nacher:** 22.13, ano. Pan poslanec Farhan.

**Poslanec Kamal Farhan:** Vážený pane předsedo, dámy a pánové, navrhuji přerušení do 22.30.

**Místopředseda PSP Patrik Nacher:** 22.30. Ano, pan kolega Kott.

**Poslanec Josef Kott:** Děkuji pěkně za slovo, pane místopředsedo. Já se asi budu opakovat, ale myslím si, že ta materie skutečně se dá opravit za velice krátkou dobu, a myslím si, že jestli někdo má nějakou potřebu k nějakému časovému... (Předsedající: Poprosím o návrh!) úseku, tak navrhuju abychom přerušili tento tisk do dnešního dne do 22.15 hodin.

**Místopředseda PSP Patrik Nacher:** 22.15. Pan kolega Pražák.

**Poslanec David Pražák:** Děkuju. Nečekali jsme to od pana Jakoba, proto dávám protinávrh 22.55.

**Místopředseda PSP Patrik Nacher:** 22.55. Ano, pane poslanče.

**Poslanec Jiří Penc:** Dobrý večer, pane místopředsedo, dámy a pánové, milí poslanci a poslankyně, dávám protinávrh do 22.22 hodin.

**Místopředseda PSP Patrik Nacher:** 22.22. Tak. Už se nikdo nehlásí. Já vás v této chvíli odhlásím všechny, přihlašte se svými identifikačními kartami. (Čekání na dosažení kvora.) Tak, ještě jednou gonguji. Prosím, nepokřikujte tady na mě, ano? Takže v této chvíli nejsme usnášeníschopni. Já přerušuji jednání na pět minut. Můžu poprosit, aby na té obrazovce se tam objevilo těch pět minut pauza, ať tady zase nenastane to, co bylo včera?

(Jednání přerušeno od 22.11 do 22.15 hodin.)

**Místopředseda PSP Patrik Nacher:** Takže, dámy a pánové, pauza skončila. Já vás v této chvíli odhlásím. Žádné faktické ani jiné nejsou možné a přihlašte se svými identifikačními kartami. Tak protože nejsme usnášeníschopni... V této chvíli jsme. Kolegové se vždycky odhlásí, ale dobře. Nechám tedy hlasovat o pozměňovacích návrzích k procedurálnímu hlasování.

Poslední návrh zazněl od poslance, kde jsem si ani nestačil napsat jméno, na přerušení do 22.22. Nechám o tomto návrhu hlasovat.

Kdo je pro? Ať zvedne ruku a stiskne tlačítko. Kdo je proti?

Hlasování 141 přihlášeno 91, pro 21, proti 59. Návrh nebyl přijat.

Pak zazněl návrh... Já vás poprosím o klid. Pak zazněl návrh od pana poslance Pražáka přerušit do 22.55.

Zahajuji hlasování. Kdo je pro? Ať zvedne ruku a stiskne tlačítko. Kdo je proti?

Hlasování číslo 142 , přihlášeno 91, pro 25, proti 55. Návrh nebyl přijat.

Nyní budeme hlasovat... Nyní tedy hlasovat o návrhu pana poslance Kotta nemůžeme, protože je nehlasovatelný, protože navrhl přerušit do 22.15.

Takže hlasujeme o návrhu pana poslance Farhana přerušit do 22.30.

Kdo je pro? Ať zvedne ruku a stiskne tlačítko. Kdo je proti?

Hlasování číslo 143 , přihlášeno 91, pro 24, proti 57.

Návrh nebo protinávrh paní poslankyně Ožanové je také nehlasovatelný, protože navrhla 22.13.

Takže budeme hlasovat o původním návrhu pana předsedy Jakoba přerušit do 8. července.

Zahajuji hlasování. Kdo je pro? Ať zvedne ruku a stiskne tlačítko. Kdo je proti?

Hlasování číslo 144 , přihlášeno 91, pro 22, proti 64. Návrh nebyl přijat.

V této chvíli pokračujeme v rozpravě a s přednostním právem vystoupí paní zpravodajka.

A než přijde, tak přečtu jednu omluvu: Helena Válková od 22 hodin ze zdravotních důvodů.

Já poprosím o klid! Pardon, já vám musím nejdřív zapnout mikrofon. Ano.

**Poslankyně Zuzana Ožanová:** Děkuji. Vážený pane předsedající, jako zpravodajka mám podle jednacího řádu možnost vystoupit kdykoliv o to požádám, tak jsem o to požádala. Ráda bych debatu vrátila k pozměňovacím návrhům. Tedy budu mluvit o pozměňovacích návrzích, které jsem navrhla do systému.

Už tady byla diskuse o tom, že jsem do systému navedla pod číslem 1256 komplexní pozměňovací návrh s odůvodněním, a už jsem avizovala, že se k němu nebudu přihlašovat. Je tam pouze proto, aby občané a veřejnost a kdokoliv měli možnost se s ním plně seznámit. To jenom k věci. Už jsem o tom hovořila, dále k tomu hovořit nebudu.

Další pozměňovací návrh 1172. Stručně řečeno, je to technický pozměňovací návrh. Jedná se o legislativně technické a další drobné změny vzešlé z projednávání návrhu v Poslanecké sněmovně. Doplnění v bodech 1 § 1a odst. 2, v bodě 15 § 193 odst. 1 a v bodě 16 § 195 odst. 2 – reaguje na připomínky zástupců Evropské komise a zpřesňuje způsob a nezbytnou kvalifikaci pro rozhodování v modelu integrovaného stavebního úřadu. Návrh je doplněn o platné znění s vyznačenými změnami.

Další pozměňovací návrh 1173 se týká účinnosti zákona. S ohledem na dobu trvání legislativního procesu v Poslanecké sněmovně se navrhuje odložit základní účinnost celé novely z 1. července 2026 na 1. ledna 2027. Tím dojde zároveň ke sjednocení účinnosti celého zákona se vznikem Úřadu rozvoje území České republiky a ke zjednodušení přechodných ustanovení.

**Místopředseda PSP Patrik Nacher:** Paní poslankyně, já vás teďka přeruším. Je tady příliš velký hluk. Poprosím kolegy, kteří jsou přímo před řečništěm, jestli by mohli ukončit svoje rozhovory.

**Poslankyně Zuzana Ožanová:** Návrh vybírá několik ustanovení s předsazenou účinností, které mají přinést okamžitý efekt v odbřemenění stavebních úřadů a zrychlení a zefektivnění povolovacích procesů nebo omezení zbytné byrokratické zátěže. Jde o změny, jejichž dřívější účinnost je odůvodněna důležitou společenskou potřebou urychlení povolovacích procesů a které zároveň nesouvisí s reformou, a nejsou tak závislé na vzniku Úřadu rozvoje území a organizačními změnami.

Další pozměňovací návrh 1174 se týká přechodných ustanovení. Jde o změny přechodných ustanovení na základě dohod s rezorty a dle výsledku projednávání návrhu v Poslanecké sněmovně. Rovněž tento návrh je doplněn o platné znění s vyznačenými změnami.

Potom je tady ještě jeden – ještě dva budu mít pozměňovací návrhy. Jeden z nich je 1180 a stručně řečeno nazváno městský architekt. Navržené doplnění novely stavebního zákona reaguje na dlouhodobou poptávku českých obcí, měst i krajů, které si zřizují nebo smluvně zajišťují pozici městského nebo obecního nebo krajského architekta jako odborného partnera samosprávy pro rozvoj území, kvalitu vystavěného prostředí a veřejného prostoru a instituci, která může z titulu pověření rady obce nebo kraje zajišťovat plnění vybraných úkolů samosprávy, jež nejsou vyhrazenou pravomocí zastupitelstva nebo rady obce. Přestože se tento institut v praxi reálně využívá a osvědčuje, nemá dosud výslovnou oporu v právním řádu. I přes absenci zákonné úpravy jej v České republice využívá více než 100 měst a obcí všech velikostí. Tato praxe vznikla spontánně v rámci autonomie samosprávy bez legislativní opory a napříč obcemi, a proto vykazuje značnou nejednotnost.

Návrh sleduje za cíl ukotvit institut městského, obecního, krajského architekta jako volitelný nástroj obce, případně pro více obcí společně v rámci společenství obcí nebo kraje. Městský architekt nenahrazuje orgány územního plánování, stavební úřady, volené orgány samosprávy ani jiné správní orgány a nevydává rozhodnutí. Smyslem právní úpravy je zakotvit městského architekta jako fakultativní zákonný institut a stanovit rámec, který bude pro praxi srozumitelný a předvídatelný. Městský architekt má být odborným garantem kvality v otázkách urbanismu, architektury a veřejného prostoru. Má poskytovat samosprávě odborné konzultace a doporučení, podílet se na přípravě koncepčních podkladů a přispívat k tomu, aby obec postupovala v těchto záležitostech jednotně, dlouhodobě a konzistentně.

Poslední pozměňovací návrh, tehdy jsem předložila, se týká něčeho, co mě velmi zajímá, a to je doprava. Je to návrh pod číslem 1255 a stručně řečeno, jedná se o vymezení ochranného pásma pozemních komunikací. Návrh novely stavebního zákona počítá se zrušením institutu zastavěného území s tím, že v územněplánovací dokumentaci bude vymezováno pouze zastavitelné území. Na to pak navazují změny i v dalších právních předpisech. Je nutno proto se zabývat i zákonem týkajícím se pozemních komunikacích, protože pojem zastavěné, respektive zastavitelné území je klíčový pro vymezení ochranného pásma pozemních komunikací, neboť v tomto území pozemní komunikace ochranné pásmo nemají. V důsledku nahrazení pojmu „zastavěné území“ obsahově širším pojmem „zastavitelné území“ v předmětných ustanoveních zákona o pozemních komunikacích by došlo ke zvětšení rozsahu pozemních komunikací, které ochranné pásmo nemají. To by mělo negativní vliv na ochranu pozemních komunikací a bezpečnost provozu na pozemních komunikacích, neboť řada činností, které jsou v ochranném pásmu regulované, by u dotčeného rozsahu pozemních komunikací regulaci nepodléhala. Tak k tomu se vztahuje tento pozměňovací návrh.

Já vám děkuji za pozornost a jenom budu ráda, když i další kolegové, tak jako já se budou věnovat svým pozměňovacím návrhům.

**Místopředseda PSP Patrik Nacher:** Já vám děkuju, paní zpravodajko. V této chvíli není žádná faktická, takže na řadě je pan poslanec Bohuslav Niemiec, připraví se Barbora Rázga. Pane poslanče, máte slovo.

**Poslanec Bohuslav Niemiec:** Dámy a pánové, děkuji a zdravím vás všechny v tuto noční hodinu, kdy si dovolím říct, že úplně důležitost toho zákona si nezaslouží tento čas projednávání a vlastně ani trošku nezaslouží to, co se kolem děje, protože jsme tady před chvilkou zaslechli, že na úpravu materie, která má 1 083 stran, nám stačí šest minut. Dobře. Nesouhlasím s tím, nestačí a já si myslím, že tato materie si opravdu zaslouží věcnou diskusi, jasnou diskusi a diskusi, která povede k cíli.

A možná se vrátím zpátky k tomu, když jsme projednávali geoportál, a to byl takový příklad velmi dobré praxe, kde jsme se domluvili, kde jsme našli jednoduché, rychlé řešení, a které vlastně ve finále dopadlo velmi dobře.

Když se vrátím na počátek celého toho procesu, tak pro mě jako pro nového poslance je tento proces vlastně svým způsobem zvláštní a učím se celé tyto procedury, protože za náš klub jsme podali 50 připomínek. Některé byly vypořádány, některé nebyly vypořádány, aspoň něco, dobře, nebylo toho moc, ale obecně ty zásadní chyby v tomto zákoně tam pořád jsou. A já jsem už o nich mluvil ve svém minulém vystoupení. Nechci se úplně opakovat, zmíním jenom pár zásadních, kterých se obávám, a pak se plynule přesunu ke svým pozměňovacím návrhům, protože v rámci spoluautorství je jich kolem 20 a hlavním autorem jsem asi u 8.

Dámy a pánové, cesta do pekel bývá dlážděna dobrými úmysly. Ano, je to tak. A v tomto případě hrozí, že místo dlážděné cesty k novým bytům postavíme právě legislativní zeď, kterou se celý systém povolování staveb definitivně roztříští.

Podívejme se pravdě do očí. Tato zásadní reforma, která čítá těch tisíc stran a od základu mění stavební řád v České republice, je vlastně poslaneckým návrhem. Obešli jsme standardní připomínkové řízení, nemáme na stole dopadovou studii RIA, schvalujeme zákon, ke kterému odborná veřejnost neměla pořádný přístup, a my sami se v našem druhém čtení tady topíme.

Pár zásadních chyb. Za prvé, bojím se – a opravdu se bojím – personálního kolapsu. Plánujeme do roku 2028 dokončit transformaci a převést úředníky z obcí pod stát, pod státní centrální správu. Zeptal se někdo těch úředníků, zda chtějí být převedeni? Opravdu přejdou, anebo si je ty obce a tajemníci stáhnou na investice, na odbor komunálního rozvoje, na odbor životního prostředí nebo někam jinam, kde už to znají, kde vědí, jaké budou podmínky a kde možná rádi zůstanou? Já se bojím toho, že opravdu hrozí masivní odchod zkušených lidí a bez úředníků žádný zákon, ani ten sebelepší, nové byty nepostaví.

Druhá záležitost je finanční neznámá. Nikdo z nás v tomto sále dnes netuší, kolik bude provoz nového systému stát. Odborníci jsou si však jisti, že centrální aparát bude dražší než ten současný. My tady schvalujeme bianko šek na systém, který může státní kasu stát miliardy navíc.

Třetí obava, kterou bych rád zmínil, je centralizace moci. Nový úřad rozvoje území dostane ve své podstatě do rukou velikou koncentraci moci a člověk, potažmo lidé... (Silný hluk v sále. Poslanci diskutují vedle řečnického pultu. Odmlčuje se.)

**Místopředseda PSP Patrik Nacher:** Poprosím, aby se nevedly diskuzní kroužky přímo před mikrofonem. Jestli se chcete o něčem bavit, tak prosím mimo tento sál. Pane poslanče, můžete pokračovat.

**Poslanec Bohuslav Niemiec:** Děkuji. Jak už jsem říkal, člověk v jeho čele bude mít relativně vysoké rozhodovací kompetence a silné postavení. Tato reforma vlastně hazarduje s velkým korupčním rizikem.

Už to tady padlo a zmíním to znovu, Česká komora architektů mluví o totálním kolapsu, pokud se tento pozměňovací komplexní návrh prosadí na sílu. Hrozí, že jediné, co se v této zemi postaví a bude povolovat, budou obří stavby, které bude povolovat DESÚ. Běžná bytová výstavba pro normální lidi může zamrznout a místo dostupného bydlení tak občanům doručíme paralýzu.

Kolegyně, kolegové, zavedení centrální stavební správy může mít přínos pro strategickou infrastrukturu, jak správně podotýká Svaz průmyslu a dopravy, ale nemusíme kvůli tomu obětovat kvalitu legislativního procesu, práva občanů a stabilitu celého systému. Nesmíme podlehnout iluzi, že pouhé napsání slova „veřejný zájem“ do zákona samo o sobě postaví jediný byt. Proto prosím o maximální opatrnost a opravdu dejme si čas, abychom věci, které v tom stavebním zákoně jsou špatně, se pokusili opravit.

Dámy a pánové, z těch osmi pozměňovacích návrhů jeden zásadní pozměňovací – nebo ony jsou všechny zásadní – návrh k § 193, vyloučení námitek a okamžik posuzování žádostí. Nové pravidlo, že námitky, které nespočívají v porušení právních předpisů, nejsou důvodné, fakticky vylučuje možnost kohokoliv napsat a namítat nesprávnost či nepřiměřenost záměru. Tedy nadměrnou dopravní zátěž, synergické účinky hluku, nepřiměřené zásahy do poměrů v území.

Řada významných zájmů je přitom chráněna obecními principy, nikoliv tvrdými limity. Automatické zamítání měkkých námitek povede k nepřezkoumatelnosti rozhodnutí a přesunu sporů na soudy. Navrhujeme proto zákaz námitek nesprávnosti a nepřiměřenosti bez náhrady vypustit.

Návrh dále zavádí pravidlo, že Stavební úřad posuzuje záměr podle podmínek platných ke dni podání žádosti, a to i v odvolacím, přezkumném a soudním řízení. To motivuje k podávání předčasných a spekulativních žádostí, které zamrazí právní stav v území a znemožní reakci na změněnou okolnost. Ať už jde o povodňová rizika, ubývání vodních zdrojů, změny bezpečnostní situace nebo prostou změnu potřeb komunity. Pozměňovací návrh sice doplňuje, že stavebník může zvolit i splnění podmínek ke dni rozhodnutí, riziko návrhu možnost zablokovat vývoj v území podáním žádosti ale zůstává nedotčeno. Navrhujeme proto, aby toto nové a ve správním právu bezprecedentní pravidlo v odst. 193 § 6 bylo zrušeno.

Další důležitou částí je vypuštění absolutní priority výstavby. Poslanecký návrh ve znění komplexního návrhu zakotvuje obecnou zásadu, podle níž lze znemožnit výstavbu jen tehdy, není-li možné ochranu jiných hodnot zajistit podmínkami nebo kompenzacemi. V kombinaci s jinými ustanoveními, například domněnkami přípustnosti záměru – to jest § 194 – vytváří návrh systém, v němž je ochrana životního prostředí, krajiny, zdraví obyvatel a práv sousedů, vždy podřízen zájmu nad povolováním záměru.

Stavební úřady přitom nedisponují metodickými vodítky ani odbornými kapacitami k posouzení, kdy je ochrana jiných hodnot nedostatečná. Výsledkem bude nikoliv urychlení, ale prohloubení právní nejistoty pro všechny účastníky, včetně stavebníků. Stavební řízení se prodlouží, protože řada sporných případů bude končit u soudu.

Jak jsme se dověděli v minulých dnech, tak předseda Nejvyššího správního soudu Karel Šimetka konstatoval, že správní soudnictví je ve velmi dobré kondici a rozhoduje relativně rychle, ale také připustil, že k soudu může nově chodit více nedotažených rozhodnutí. Podle něj proto budou muset úřady zavést důkladnější vnitřní kontrolu. Ve chvíli, kdy víme, že vydáváme jednoinstanční rozhodnutí, musíme si dát zatraceně pozor, varoval. Citace jeho slov. Proto, aby se tento stav nestával, tak si dovoluji navrhnout tento pozměňovací návrh.

Tato zásada o které tady mluvím, může znemožnit výstavbu, pokud nelze ochranu jiných hodnot zajistit podmínkami či kompenzacemi. V praxi to znamená, že ochrana přírody, krajiny, zdraví a lidí, práv sousedů, bude vždy až na druhém místě.

Dámy a pánové, další podle mě problematickou věcí je pozměňovací návrh k § 148, výjimka z hygienických limitů hluku a vibrací. Ustanovení 148 odst. 3 zavádí pravidlo, podle kterého Stavební úřad považuje hygienické limity hluku a vibrací za splněné, pokud stavebník prokáže, že je omezí na rozumnou dosažitelnou míru.

A já se ptám, co je rozumná, dosažitelná míra? Kdo tuto rozumnou, dosažitelnou míru určí, kdo ji bude posuzovat a proč? Jakým způsobem věci budou řešeny? Opět se tady vytváří velký prostor pro různé domněnky, spekulace a podobné jiné věci. Dále pak se tam píše nebo pokud imise odpovídají běžnému využití okolního území. Jde ale o alternativní podmínku. Postačí splnit pouze jednu z nich. Přitom právě kumulativní podmínka, to znamená provedení všech rozumných opatření a současně soulad s běžným využitím území, by zajistila, že nedojde k znehodnocení okolních stavebních projektů nepředvídatelnou hlukovou a vibrační zátěží. V navržené podobě může být výjimka zneužita k povolení záměru s výrazným nadlimitním hlukem, i pokud je okolí dostatečně bezhlučné. S výrazně omezenou povinností realizovat tato opatření. Navrhuji proto, aby ustanovení bylo upraveno tak, že musí být splněny obě podmínky omezení a také přiměřenost imisí běžnému využití okolního území.

Dále pak navrhujeme, a to je opatření, které je nové, chceme v rámci pozměňovacího návrhu k paragrafu číslo 11 zákona o ochraně zemědělského půdního fondu zrušit poplatky za vynětí ve stavební proluce. Od roku 2015 se odvody za odnětí ze zemědělského půdního fondu platí u bytové výstavby vždy i na pozemcích v zastavěném území, například na zahradách či prolukách uvnitř sídel. U jednoho rodinného domu mohou činit až desítky tisíc korun, což se může promítat do cen bydlení. Vzhledem k aktuální situaci a nedostupnosti bydlení a stále rostoucím nákladům na pořízení bydlení navrhujeme odvody zrušit pro jakoukoliv stavbu pro bydlení ve stavební proluce. Týká se to pojmově, ale opravdu pouze staveb v zastavitelném území, protože mimo něj stavby pro bydlení vznikat nemohou, a to ani pokud je bydlení jen doplňkovou funkcí stavby. Ochrana kvality zemědělské půdy mimo sídla zůstává nedotčena.

Dále pak pozměňovací návrh v § 137 rozvolnění požadavku pro novostavby v zastaněné části obce. Novela stavebního zákona výrazně rozvolňuje technické požadavky na výstavbu a umožňuje neuplatnit požadavky na parkování, odstupy, denní osvětlení, výtahy či úsporu energie u rekonstrukcí a u novostavby v prolukách, pokud by jejich uplatnění bylo ekonomicky nepřiměřené vůči přínosům. Vzhledem k aktuálnímu nedostatku bydlení na trhu se tímto pozměňovacím návrhem možnost neuplatnění vybraných technických požadavků i na jakoukoliv novostavbu pro bydlení v zastavěné části obce, to znamená dříve v intravilánu. V praxi to znamená, že například požadavek na počet parkovacích míst nebude bránit výstavbě bytového domu v centru města. Pokud to nebude ekonomicky přiměřené, vedle posílení možností bytové výstavby se tímto opatřením podpoří také zahušťování zástavby uvnitř sídel namísto rozprostírání výstavby do krajiny.

Dalším pozměňovacím návrhem je pozměňovací návrh, který řeší zachování dozoru a mezinárodní prestiž. Tento návrh, na něm jsem spolupracoval s kolegy, komplexní pozměňovací návrh zúžil výkon dozoru obecních úřadů obce s rozšířenou působností výlučně na obnovu kulturních památek. Je však třeba připomenout ustanovení 14 odst. 2 zákona o státní památkové péči, předkládá relativně rozsáhlý výčet činností, které povoluje tento úřad svým rozhodnutím. Ale neměl by prostor pro výkon jejich dozoru. Že je však následně povinen porušení povinností spojených s tímto postupem pokutovat jako přestupek. Jde o činnosti, které nepovoluje Stavební úřad, ale tyto činnosti by pak obecní úřad, ač je povinen je posuzovat i postihovat, neměl jak zajistit, Navržená úprava tento nesystémový deficit napravuje. Komplexní pozměňovací návrh dále předpokládá, že v případě záměru na nemovitostech v památkových rezervacích nebo v památkové zóně bude vydávat orgán památkové péče nezávazné vyjádření.

Vydávání nezávazného vyjádření založí nepředvídatelnost a subjektivní rozhodování stavebních úřadů. Proto se navrhuje, aby i v případě památkových rezervací a památkových zón měly orgány památkové péče pravomoc vydávat závazná stanoviska. Přechodná ustanovení komplexního pozměňovacího návrhu předpokládají, že všechna ochranná pásma vymezená před 1. 1. roku 2007 pozbývají platnosti nejpozději 31. prosince v roce 2028. A tady je problém, protože je zde reálná obava, že u rozsáhlých ochranných pásem, které současně tvoří zónu památek UNESCO, typicky ochranná (?) památková rezervace v Praze by nebylo možné toto ochranné pásmo vymezit a tím by se Česká republika a Praha dostala do nelichotivého výčtu památek, které byly z tohoto prestižního seznamu vyškrtnuty. Nyní mají být při stávajících kapacitách prohlášena ochranná pásma až za dva roky. Toto je zcela mimo přístup, který by bylo možné označit jako racionální. A proto navrhuji prodloužení této lhůty do 31. prosince roku 2029.

Dále si dovolím zmínit zrušení legalizace černých staveb. Komplexní pozměňovací návrh zavádí zcela nové pravidlo, podle kterého Stavební úřad nenařídí odstranění nepovolené stavby a dodatečně ji povolí i bez splnění zákonných podmínek, pokud by odstranění představovalo zcela zjevný zásah nepřiměřený přínosům zajímavý pojem, který jsem dlouho zkoumal, co vlastně znamená, a ponecháním stavby nejsou dotčené veřejné zájmy, ani práva třetích osob. Toto ustanovení je extrémně problematické. Fakticky legalizuje černé stavby a vytváří pobídky, které racionalizují strategii stavět bez povolení a spoléhat na následnou legalizaci. Odpovědnost za přestupek je sice formálně zachována, ale její praktický účinek je zcela podkopán.

Pokud je výsledkem legalizace stavby, jedná se o zásadní narušení principu právního státu v oblasti stavebního práva, která zásadně oslabí motivaci dodržovat stavební zákon. A proto navrhuji, aby toto nové a ve stavebním právu zcela nevhodné pravidlo v odst. 256 odst. 3 bylo bez náhrady zrušeno.

Dámy a pánové, ale vracím se k tomu, že tato materie je obrovská a prosím vás ještě jednou a vyzývám vás k tomu, abychom se vrátili k té racionalitě a začali racionálně diskutovat o všech těch věcech a o všech těch problémech a o všech těch chybách, které v komplexním pozměňováku jsou. Protože já se bojím jedné věci, že vlastně ani všichni nevíme, co všechno je tam špatně. Já jsem se poctivě snažil tento komplexní návrh procházet. Poctivě jsem se snažil hledat v tom další věci společně s dalšími lidmi a už jenom to, že u těch pozměňovacích návrhů jsme s kolegy podepsáni opravdu ve větším počtu, a těch komplexních pozměňovacích návrhů nebo těch pozměňovacích návrhů, které v rámci opozice předkládáme, bude opravdu hodně, znamená, že celý ten proces není nastavený dobře a proto já vím, ale proto opět předkladatelku chci vyzvat, aby se nad tím zamyslela, aby má slova už když je říkám potřetí vzala vážně a zpomalila tento proces, který nepovede k tomu, co chceme všichni. Opravdu všichni chceme zrychlit stavební řízení, zjednodušit. Nevyhrožuji a nevím, jestli to je běžné tu tak navzájem jako diskutovat. Já myslím, že úplně ne, já se omlouvám, já jsem nový, takže jsem v tom trošku zmatený, ale já se to věřím rychle naučím. Opravdu nechci vyhrožovat, opravdu se nechci hádat, opravdu nechci vnášet do tohoto ctěného pléna nějaké napětí, ale chci řešit problém a pokud ten problém nastane a já se opravdu bojím, že nastane, tak se nám vrátí jak bumerang a já vám to potom připomenu. Děkuji. (Potlesk opozičních poslanců.)

**Předseda PSP Tomio Okamura:** Nyní další vystoupí paní poslankyně Barbora Rázga.

Přečtu jednu omluvu: Matěj Gregor od 22.30 do 23 hodin z pracovních důvodů. Prosím, paní poslankyně, máte slovo.

**Poslankyně Barbora Rázga:** Po dvou dnech, děkuju pane předsedo, kolegyně, kolegové, já se pokusím být maximálně stručná, já bych ráda odůvodnila svůj pozměňovací návrh, který předkládám s kolegy Patrikem Nacherem a s kolegou Jiřím Havránkem a tento pozměňovací návrh se týká výdejních boxů, které chceme vyjmout z režimu drobných staveb. Děkuju, pane Lipavský, že souhlasíte. Já doufám, kolegové, že to podpoříte. Myslím si, že v debatě o výdejních boxech bychom měli používat zdravý rozum, hledat nějaké řešení, které bude funkční jak pro obce, tak pro občany, ale také samozřejmě pro provozovatele, protože výdejní boxy považuju za projekt moderních technologií, který využívá nebo využívají miliony lidí. Už dnes některá pravidla platí. Provozovatelé se snaží o jakousi seberegulaci. Už ty největší provozovatelé, jako je například Alza nebo PPL, mají kodex. Dochází tam ke kooperaci s těmi samosprávami. Takže myslím si, že bychom segment stavebního zákona dnes neměli zatěžovat, protože by vzniklo daleko více byrokracie a komplikací. Pokud bychom výdejní boxy pod stavební režim podřadili, tak výsledkem kromě té byrokracie a sporů bude i administrativní zátěž pro ty stavební úřady a pro ty obce. Takže prosím o podporu tohoto pozměňovacího návrhu, který je v systému nahrán pod číslem 1164. Děkuju mockrát.

**Předseda PSP Tomio Okamura:** Tak nyní máme tři faktické poznámky. Takže pan poslanec Marian Jurečka. Vaše 2 minuty.

**Poslanec Marian Jurečka:** Děkuji. Já bych chtěl reagovat na kolegyni Rázga s tím, že to téma výdejních boxů je téma, které určitě je palčivé téma a myslím si, že s ohledem na to, že je 22.53, by bylo dobré, abychom to přerušili a vrátili se k tomu v rozumném čase, tak prosím pěkně a navrhuji procedurální návrh přerušit ten bod do úterý příštího týdne do 14 hodin. Děkuji.

**Předseda PSP Tomio Okamura:** Ano, ano, já si to v klidu poznamenám. Marian Jurečka, předseda klubu KDU-ČSL – příští úterý do 14 hodin. Tak, paní poslankyně Rázga se hlásí s protinávrhem, paní zpravodajka Ožanová se hlásí. Moment, tak postupně. Takže paní zpravodajka, paní poslankyně Rázga a paní poslankyně Fialová se hlásila. Prosím.

**Poslankyně Zuzana Ožanová:** Já se omlouvám, já chci dát procedurální návrh, ale vzhledem k tomu, že je na tu dobu svolána mimořádná schůze, nepletu-li se, (Předsedající: Je to tak.) tak asi je to nehlasovatelné. (Předsedající: Ono to je...) Pro jistotu navrhuji přerušit do 22.57.

**Předseda PSP Tomio Okamura:** Do 22.57. Tak paní poslankyně Rázga, připravena je paní poslankyně Fialová, pan předseda Benda.

**Poslankyně Barbora Rázga:** Já si dovolím navrhnout protinávrh a to do 23.05.

**Předseda PSP Tomio Okamura:** Takže do 23.05. Paní poslankyně Fialová má návrh.

**Poslankyně Eva Fialová:** Já dávám také protinávrh a myslím si, že bychom měli projednávat v důstojné hodině, proto dávám návrh, abychom pokračovali zítra 29. 5. ve 14.00.

**Předseda PSP Tomio Okamura:** Pan poslanec Benda se hlásí, pozor.

**Poslanec Marek Benda:** Vážený pane místopředsedo, vážené dámy, vážení pánové, já si uvědomuju, že námitka, kterou vznesla paní zpravodajka, je v podstatě racionální, pokládám za pravděpodobné, že úterní schůze nebude úplně nejkratší vzhledem k počtu bodů, které tam byly zařazeny, takže navrhuji, abychom tento bod a tuto schůzi přerušili do středy do deváté hodiny ranní. Myslím si, že dřív se k tomu opravdu nedostaneme a že už je nedůstojné se tady tak zbytečně trápit.

**Předseda PSP Tomio Okamura:** Tak a teďka ještě pan poslanec Helebrant se hlásí.

**Poslanec Tomáš Helebrant:** Děkuji za slovo, já mám protinávrh, já navrhuji procedurální přerušení do 23.23.

**Předseda PSP Tomio Okamura:** On tady byl hluk, prosím vás, ještě jednou. Pardon.

**Poslanec Tomáš Helebrant:** Mám procedurální návrh na přerušení do 23.23.

**Předseda PSP Tomio Okamura:** 23.23. To jsou všechny návrhy, tak já ještě zagonguji. Jo, prosím vás. (Pobavení v sále.) Tak vidím, že jste plní energie pořád. Takže já vás odhlásím, přihlaste se znovu svými hlasovacími kartami.

Zahajuji hlasování (číslo 145 ). Ne, ne, pardon, pardon, já jsem to nepřečetl. Moment, zmatečné, moment, moment. Takže protinávrh, pan poslanec Helebrant a to teda strukturujeme do 23.23. (Nesouhlasná stanoviska z pléna.)

Zahajuji hlasování (číslo 146 ). Jo, ještě nejsme. Pardon, já už jsem... Jste tak aktivně ťukali, jsem myslel, že tady dostatečný počet. Tak máme 66, 67, 68... Vidíte, tak já nevím.

Prosím vás, takže zahajuji... Moment. Zahajuji hlasování o návrhu pana poslance Helebranta. Kdo je pro? Kdo je proti?

Hlasování číslo 147 , přihlášeno 101, pro 121 (na tabuli: 21), proti 67. Návrh byl zamítnut.

No já právě tuším, že si s tím někdo pohrává s tím vytahováním, zandaváním karet, když to osciluje. Ale toho jsem si všimnul už, jakože schválně tam někdo si to takhle dělá, aby... (Pobavení a smích v sále.) No, já to znám tyhlety věci, takže prosím vás, jo, ale my si počkáme a toho kvora dosáhneme.

Prosím vás, pan poslanec Benda protinávrh, takže do středy, příští týden do 9 hodin.

Zahajuji hlasování. Kdo je pro? Kdo je proti?

Hlasování číslo 148 , přihlášeno 101 poslanců (na tabuli: 102), pro 30 (na tabuli: 31), proti 63. Návrh byl zamítnut.

Paní poslankyně Fialová navrhuje přerušit do zítřka do 14 hodin.

Já zahajuji hlasování. Kdo je pro? Kdo je proti?

Hlasování číslo 149 , přihlášeno 102 poslanců, pro 64, proti 10. Návrh byl přijat.

A tato schůze je přerušená do zítra do 14 hodin. Připomínám, že zítra pokračujeme v 9 hodin mimořádnou schůzí. Přeji vám hezký večer.

(Schůze přerušena v 22.59 hodin.)
