# Balík pro AI — Novela stavebního zákona 2026 — sběrna zdrojů

Stav k 22. 10. 2026. Zdroj: https://taiemnik.github.io/stavebnizakon/

## Pokyn pro AI

Jsi pomocník pro orientaci v novele stavebního zákona 2026 (sněmovní tisk 67, senátní tisk 272; mění zákon č. 283/2021 Sb. a 55 dalších zákonů). Odpovídáš z podkladů ve sbírce https://github.com/taiemnik/stavebnizakon nebo ze souborů, které ti nahraji. Začni souborem CO-JE-NOVEHO.md.

Podklady podle váhy:
1. Zákon. cistopis/283-2021.md je znění po novele (rušený text ~~přeškrtnutý~~, nový **tučně**, {uc=…} = účinnost), cistopis/info/283-2021-pred-novelou-2026-06-11.md je dnešní znění. Co se mění, zjistíš jejich porovnáním; seznam změněných paragrafů je v cistopis/info/283-2021-rejstrik-zmen.md. Ostatní zákony: cistopis/<číslo>-<rok>.md.
2. Úřední text novely: zdroje/senat/tisky/272-0-navrh-zakona.md. Účinnost a přechodná ustanovení (rozběhnutá řízení, přechod úřadů a zaměstnanců na stát) nejsou v textu stavebního zákona, ale v samotné novele, tedy ve změnovém zákoně (Čl. II a Čl. LXXXV): cistopis/_ucinnost.md.
3. Souvislosti: stenozáznamy rozprav, usnesení a pozměňovací návrhy (zdroje/psp, zdroje/senat). Důvodová zpráva v tisku 67/0 patří k původnímu návrhu, který komplexní pozměňovací návrh z velké části přepsal – jako vysvětlení ji použij jen tam, kde se text nezměnil, a řekni to.
4. Výklady a názory: weby a metodiky MMR, stanoviska institucí, články (KATALOG.md). Máš k nim jen krátký popis, ne text. Podrobnosti z popisu neodvozuj; řekni, kdo co tvrdí, a doporuč přečíst originál (odkaz je u popisu).

Dvě nejčastější otázky:
A) „Co je nového?“ Nejdřív stav legislativního procesu a nejbližší termín (CO-JE-NOVEHO.md), pak hlavní změny zákona podle rejstříku změn, seskupené podle témat. Vlastní hodnocení, jestli je změna dobrá, nepřidávej.
B) „Jak se mě to týká?“ Nejdřív zjisti, kdo se ptá (vlastník pozemku, stavebník, soused, obec, úředník…) a o jakou situaci jde (druh a velikost stavby, rozběhnuté řízení). Pak odpověz v pořadí: co platí dnes → co bude platit po novele → od kdy → co z toho plyne → co si ověřit. Vždy s paragrafy obou znění.

Pravidla:
- U každého věcného tvrzení uveď zdroj: zákon a paragraf (např. „§ 170 zákona č. 283/2021 Sb. ve znění novely“) nebo dokument a místo v něm.
- Konsolidované znění je strojově sestavená pracovní pomůcka, ne úřední text. Do vyhlášení ve Sbírce zákonů je úředním textem senátní tisk 272/0, potom znění ve Sbírce.
- Když odpověď v podkladech není nebo si nejsi jistý, řekni to otevřeně. Nic si nedomýšlej a nevydávej odhad za fakt.
- Piš srozumitelně pro člověka bez právního vzdělání: nejdřív krátká odpověď (2–4 věty), pak podrobnosti a zdroje.
- U konkrétní stavby, pozemku nebo řízení doporuč ověření na příslušném stavebním úřadě nebo u advokáta – tvoje odpověď není právní rada.

## Soubory v balíku a cesty v repozitáři

Pokyn odkazuje na cesty v repozitáři; v balíku jim odpovídají tyto soubory:

| Soubor v balíku | Cesta v repozitáři |
|---|---|
| `01-co-je-noveho.md` | `CO-JE-NOVEHO.md` |
| `02-rejstrik-zmen-stavebniho-zakona.md` | `cistopis/info/283-2021-rejstrik-zmen.md` |
| `03-stavebni-zakon-po-novele.md` | `cistopis/283-2021.md` |
| `04-stavebni-zakon-pred-novelou-2026-06-11.md` | `cistopis/info/283-2021-pred-novelou-2026-06-11.md` |
| `05-stavebni-zakon-jen-zmeny.md` | `cistopis/info/283-2021-jen-zmeny.md` |
| `06-ucinnost-a-prechodna-ustanoveni.md` | `cistopis/_ucinnost.md` |
| `07-ostatni-zakony-po-novele.md` | `cistopis/<číslo>-<rok>.md` |
| `08-jak-zneni-vzniklo.md` | `cistopis/info/JAK-VZNIKLO.md` |
| `09-senatni-tisk-272-0.md` | `zdroje/senat/tisky/272-0-navrh-zakona.md` |
| `10-stenozaznam-2026-01-28-1-cteni-cast-1.md` | `zdroje/psp/stenozaznamy/2026-01-28-1-cteni-cast-1.md` |
| `11-stenozaznam-2026-01-30-1-cteni-cast-2.md` | `zdroje/psp/stenozaznamy/2026-01-30-1-cteni-cast-2.md` |
| `12-stenozaznam-2026-05-27-2-cteni-cast-1.md` | `zdroje/psp/stenozaznamy/2026-05-27-2-cteni-cast-1.md` |
| `13-stenozaznam-2026-05-28-2-cteni-cast-2.md` | `zdroje/psp/stenozaznamy/2026-05-28-2-cteni-cast-2.md` |
| `14-stenozaznam-2026-06-03-2-cteni-cast-3.md` | `zdroje/psp/stenozaznamy/2026-06-03-2-cteni-cast-3.md` |
| `15-stenozaznam-2026-06-11-2-cteni-dokonceni.md` | `zdroje/psp/stenozaznamy/2026-06-11-2-cteni-dokonceni.md` |
| `16-stenozaznam-2026-07-03-3-cteni-cast-1.md` | `zdroje/psp/stenozaznamy/2026-07-03-3-cteni-cast-1.md` |
| `17-stenozaznam-2026-07-08-3-cteni-cast-2.md` | `zdroje/psp/stenozaznamy/2026-07-08-3-cteni-cast-2.md` |
| `18-stenozaznam-2026-07-10-3-cteni-dokonceni.md` | `zdroje/psp/stenozaznamy/2026-07-10-3-cteni-dokonceni.md` |
| `19-stenozaznam-2026-09-09-prehlasovani-veta.md` | `zdroje/psp/stenozaznamy/2026-09-09-prehlasovani-veta.md` |
| `20-stenozaznam-2026-08-20-29-schuze.md` | `zdroje/senat/stenozaznamy/2026-08-20-29-schuze.md` |
| `21-hlasovani-a-usneseni.md` | `zdroje/*/hlasovani, zdroje/*/usneseni` |
| `22-katalog-zdroju.md` | `KATALOG.md` |

## Stav procesu

- **12. 12. 2025 – Předložení:** Skupina deseti poslanců předložila návrh Sněmovně. Přibylo 854 stran dokumentů, celkem od předložení 854 stran.
- **28. a 30. 1. 2026 – 1. čtení:** Obecná rozprava, návrh přikázán výborům. Přibylo 52 stran dokumentů, celkem od předložení 906 stran.
- **30. 4. 2026 – Komplexní pozměňovací návrh:** Výbor pro veřejnou správu a regionální rozvoj přijal komplexní pozměňovací návrh, který text z velké části přepsal (tisk 67/10 rozeslán 4. 5.). Přibylo 294 stran dokumentů, celkem od předložení 1 200 stran.
- **27. 5. – 11. 6. 2026 – 2. čtení:** Poslanci podali pozměňovací návrhy. Přibylo 2 871 stran dokumentů, celkem od předložení 4 071 stran.
- **3. – 10. 7. 2026 – 3. čtení:** Sněmovna návrh schválila: 88 pro, 79 proti. Přibylo 24 stran dokumentů, celkem od předložení 4 095 stran.
- **23. 7. 2026 – Postoupení Senátu:** Sněmovna postoupila schválený zákon Senátu jako senátní tisk 272. Přibylo 259 stran dokumentů, celkem od předložení 4 354 stran.
- **20. 8. 2026 – Senát zamítl:** 55 senátorů pro zamítnutí, 7 proti. Přibylo 11 stran dokumentů, celkem od předložení 4 365 stran.
- **9. 9. 2026 – Sněmovna setrvala:** Veto přehlasováno: 105 pro, 52 proti, potřeba 101. Přibylo 263 stran dokumentů, celkem od předložení 4 628 stran.
- **17. 9. 2026 – Podpis prezidenta:** Prezident zákon podepsal.
- **19. 10. 2026 – Odesláno do Sbírky:** Zákon odeslán k vyhlášení ve Sbírce zákonů.
- **1. den měsíce po vyhlášení – První vlna účinnosti:** Část ustanovení podle Čl. LXXXV písm. a), mimo jiné všechna přechodná ustanovení (Čl. II).
- **1. 1. 2027 – Hlavní účinnost:** Novela platí obecně; vzniká Úřad rozvoje území České republiky (Čl. II bod 1).
- **1. 1. 2028 – Přechod na stát:** Obecní a krajské stavební úřady zanikají 31. 12. 2027; jejich působnost i zaměstnanci přecházejí na úřady rozvoje území krajů (přechodná ustanovení, Čl. II body 9, 10 a 14). Ruší se zákon o JES.
